﻿
namespace WPP.ABSTRACTION.ENTITIES.MessageApplication
{
    public class MessageWhatsAppModel
    {
        public int messageId { get; set; }
        public string codeClient { get; set; } = string.Empty;
        public string cellphone { get; set; } = string.Empty;
        public string message { get; set; } = string.Empty;
        public string typeMessage { get; set; } = string.Empty;
        public string codeTypeMessage { get; set; } = string.Empty;
        public string stateMessage { get; set; } = string.Empty;
        public string jsonClient { get; set; } = string.Empty;
        public string user { get; set; } = string.Empty;
        public string nameUser { get; set; } = string.Empty;
        public bool whatsAppBot { get; set; }
        public DateTime dateRequest { get; set; }
        public DateTime timeRequest { get; set; }
        public string campaign { get; set; } = string.Empty;
        public int login { get; set; }
        public string messageClass { get; set; } = string.Empty;
        public DateTime dateDelivered { get; set; }
        public DateTime dateRead { get; set; }
        public string multimedia { get; set; } = string.Empty;
    }

    public class LastMessageWhatsApp
    {
        public int messageId { get; set; }
        public string codeClient { get; set; } = string.Empty;
        public string cellphone { get; set; } = string.Empty;
        public bool whatsAppBot { get; set; }
        public string user { get; set; } = string.Empty;
        public string nameUser { get; set; } = string.Empty;
        public string json { get; set; } = string.Empty;
        public string campaign { get; set; } = string.Empty;
        public int login { get; set; }
        public DateTime dateRequest { get; set; }
        public string messageClass { get; set; } = string.Empty;
        public bool firstChat { get; set; }
        public string message { get; set; } = string.Empty;
    }

    public class MessageWhatsAppApplication
    {
        public int messageId { get; set; }
        public string message { get; set; } = string.Empty;
        public string typeMessage { get; set; } = string.Empty;
        public string cellphone { get; set; } = string.Empty;
        public string multimediaUrl { get; set; } = string.Empty;
        public string typeMultimediaUrl { get; set; } = string.Empty;
        public string destinationAccount { get; set; } = string.Empty;
    }

    public class MessageApplicationReceptionRequest
    {
        public string? message { get; set; } = string.Empty; // TEXTO DEL MENSAJE 
        public int? messageId { get; set; } = 0; // ID DEL MENSAJE INSERTADO 
        public string? messageCode { get; set; } = string.Empty; // CODIGO CORRESPONDIENTE SI EL MENSAJE CORRESPONDE A LA RESPUESTA DE OTRO MENSAJE
        public string? typeMessage { get; set; } = string.Empty; // TIPO DE MENSAJE ESTE PUEDE SER TEXT, IMAGE, AUDIO, VIDEO, STICKER, INTERACTIVO, LOCATION, CONTACTO
        public string? classMultimedia { get; set; } = string.Empty; // TIPO DEL ARCHIVO MULTIMEDIA ESTE PUEDE SER: IMAGE: JPG, JPEG / AUDIO: MP3, OGG / VIDEO: MP4. GIF / STICKER: WEBP
        public string? classInteractive { get; set; } = string.Empty; // TIPO DE INTERACTIVO ESTE PUEDE SER: LIST_BUTTON, REPLY_BUTTON
        public bool identifyChatBot { get; set; }   // IDENTIFICADOR DE SI EL MENSAJE ES DEL OPERADOR O DEL BOT
        public string? cellphone { get; set; } = string.Empty; // NUMERO CELULAR DEL QUE ENVIO EL MENSAJE 
        public string? url { get; set; } = string.Empty;// URL DEL ARCHIVO MULTIMEDIA ENVIADO 
        public string? nameMultimediaUrl { get; set; } = string.Empty; // MENSAJE CON EL INGRESO EL ARVHIVO MULTIMEDIA 
        public string? user { get; set; }  // USUARIO QUE REALIZA EL ENVIO DEL MENSAJE
        public string? nameUser { get; set; }  // NOMBRE DEL USUARIO QUE REALIZA EL ENVIO DEL MENSAJE
        public string? campaignName { get; set; } = string.Empty; // NOMBRE DE LA CAMPAÑA A LA QUE PERTENECE EL MENSAJE ENTRANTE
        public string? destinationAccount { get; set; } = string.Empty; // NUMERO DE CELULAR DE LA CUENTA AL QUE VA EL MENSAJE 
        public string? json { get; set; } = string.Empty; // OBJETO JSON ENVIADO POR EL PROVEEDOR
    }
}
