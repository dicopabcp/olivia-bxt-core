﻿
namespace WPP.ABSTRACTION.ENTITIES.MessageApplication
{
    public class EndpointPayload
    {
        public string encrypted_aes_key { get; set; } = string.Empty;
        public string encrypted_flow_data { get; set; } = string.Empty;
        public string initial_vector { get; set; } = string.Empty;
    }
}
