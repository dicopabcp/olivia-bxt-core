﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPP.ABSTRACTION.ENTITIES.DistributorMessage
{
    public class DistributorMessageOptions
    {
        public string urlOperator {get;set;} = string.Empty;
        public string methodOperator {get;set;} = string.Empty;
        public string urlChatBot {get;set;} = string.Empty;
        public string methodChatBot { get; set; } = string.Empty;
        public string urlSentralizer { get; set; } = string.Empty;
        public string methodSentralizer { get; set; } = string.Empty;
        public string urlSignalR { get; set; } = string.Empty;
        public string methodSignalR { get; set; } = string.Empty;
    }
}
