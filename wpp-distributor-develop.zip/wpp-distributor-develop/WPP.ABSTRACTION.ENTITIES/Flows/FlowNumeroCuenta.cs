namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    // Pantalla CSM_DETALLE_SALDO (consulta_saldos_movimientos.json), accion "Ver movimientos".
    public class FlowNumeroCuenta
    {
        public string numero_cuenta { get; set; } = string.Empty;

        public string celular { get; set; } = string.Empty;

        public string wppSesionId { get; set; } = string.Empty;
    }
}
