namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class FlowAperturaSituacionLaboral
    {
        public string situacion_laboral { get; set; } = string.Empty;
    }
}
