namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class FlowAperturaEstadoCivil
    {
        public string estado_civil { get; set; } = string.Empty;
    }
}
