namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class FlowAperturaOtpCorreo
    {
        public string otp { get; set; } = string.Empty;
    }
}
