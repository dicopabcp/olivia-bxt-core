namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class WppFlowDocumentoId
    {
        public string Base64 { get; set; } = string.Empty;
    }
}
