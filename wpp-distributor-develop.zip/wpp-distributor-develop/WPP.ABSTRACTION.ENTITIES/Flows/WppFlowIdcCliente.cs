﻿namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class WppFlowIdcCliente
    {
        public string Carnet { get; set; } = string.Empty;

        public string Complemento { get; set; } = string.Empty;
    }
}