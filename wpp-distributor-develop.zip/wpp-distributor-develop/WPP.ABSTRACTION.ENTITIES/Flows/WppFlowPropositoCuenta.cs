namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class WppFlowPropositoCuenta
    {
        public string PropositoCuenta { get; set; } = string.Empty;
    }
}
