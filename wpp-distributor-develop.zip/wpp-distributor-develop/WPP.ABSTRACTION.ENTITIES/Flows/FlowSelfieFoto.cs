namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    // Pantalla CSM_SELFIE (consulta_saldos_validacion_identidad.json).
    public class FlowSelfieFoto
    {
        public string celular { get; set; } = string.Empty;

        public string wppSesionId { get; set; } = string.Empty;

        public List<ImageSent> selfie_foto { get; set; } = new();
    }
}
