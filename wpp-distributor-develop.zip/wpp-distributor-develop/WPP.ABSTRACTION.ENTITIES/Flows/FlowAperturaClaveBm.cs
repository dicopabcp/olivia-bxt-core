namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class FlowAperturaClaveBm
    {
        public string clave_bm { get; set; } = string.Empty;

        public string confirmar_clave_bm { get; set; } = string.Empty;
    }
}
