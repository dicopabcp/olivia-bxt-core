﻿namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class FlowImage
    {
        public string wppSesionId { get; set; } = string.Empty;

        public string celular { get; set; } = string.Empty;

        public List<ImageSent> imagen { get; set; } = new();
    }
}