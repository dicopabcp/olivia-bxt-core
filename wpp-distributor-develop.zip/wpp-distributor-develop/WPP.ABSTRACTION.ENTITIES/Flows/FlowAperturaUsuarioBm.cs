namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class FlowAperturaUsuarioBm
    {
        public string usuario_bm { get; set; } = string.Empty;
    }
}
