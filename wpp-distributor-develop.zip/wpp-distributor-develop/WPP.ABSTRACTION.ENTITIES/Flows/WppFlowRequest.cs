﻿namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class WppFlowRequest
    {
        public string SesionId { get; set; } = string.Empty;

        public string Usuario { get; set; } = string.Empty;

        public string? Data { get; set; }

        public string Flow { get; set; } = string.Empty;
    }
}