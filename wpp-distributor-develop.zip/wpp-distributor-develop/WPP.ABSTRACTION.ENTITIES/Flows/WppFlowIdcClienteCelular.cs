namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    // Mirror local de WppFlowIdcClienteCelular (olivia-bxt-core), enviado para la pantalla CSM_DATOS_CI.
    public class WppFlowIdcClienteCelular
    {
        public string Carnet { get; set; } = string.Empty;

        public string Complemento { get; set; } = "00";

        public string Celular { get; set; } = string.Empty;
    }
}
