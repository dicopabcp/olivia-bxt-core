namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class WppFlowContactoCorreo
    {
        public string Correo { get; set; } = string.Empty;
    }
}
