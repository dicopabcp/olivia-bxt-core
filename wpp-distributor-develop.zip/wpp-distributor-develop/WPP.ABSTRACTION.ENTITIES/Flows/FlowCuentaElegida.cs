namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    // Pantalla CSM_ELEGIR_CUENTA (consulta_saldos_movimientos.json).
    public class FlowCuentaElegida
    {
        public string cuenta { get; set; } = string.Empty;

        public string celular { get; set; } = string.Empty;

        public string wppSesionId { get; set; } = string.Empty;
    }
}
