﻿namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class FlowEncuesta
    {
        public string score_survey { get; set; } = string.Empty;

        public string comments { get; set; } = string.Empty;

        public string celular { get; set; } = string.Empty;

        public string wppSesionId { get; set; } = string.Empty;
    }
}