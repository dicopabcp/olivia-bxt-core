namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class WppFlowClaveBm
    {
        public string ClaveBm { get; set; } = string.Empty;

        public string ConfirmarClaveBm { get; set; } = string.Empty;
    }
}
