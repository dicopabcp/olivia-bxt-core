namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class FlowAperturaContactoCorreo
    {
        public string correo { get; set; } = string.Empty;
    }
}
