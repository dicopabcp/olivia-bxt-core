namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    // Pantalla CSM_LOGIN_CLAVE (consulta_saldos_validacion_identidad.json).
    public class FlowClaveWhatsapp
    {
        public string clave_whatsapp { get; set; } = string.Empty;

        public string celular { get; set; } = string.Empty;

        public string wppSesionId { get; set; } = string.Empty;
    }
}
