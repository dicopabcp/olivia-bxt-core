namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class FlowAperturaPropositoCuenta
    {
        public string proposito_cuenta { get; set; } = string.Empty;

        public string celular { get; set; } = string.Empty;

        public string wppSesionId { get; set; } = string.Empty;
    }
}
