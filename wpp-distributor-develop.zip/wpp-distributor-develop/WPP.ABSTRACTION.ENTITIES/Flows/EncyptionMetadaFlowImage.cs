﻿namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class EncyptionMetadaFlowImage
    {
        public string encryption_key { get; set; } = string.Empty;
        public string hmac_key { get; set; } = string.Empty;
        public string iv { get; set; } = string.Empty;
        public string plaintext_hash { get; set; } = string.Empty;
        public string encrypted_hash { get; set; } = string.Empty;
    }
}