namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    // Pantalla CSM_OTP_CORREO (consulta_saldos_movimientos.json): "otp" llega en el envio normal del Footer,
    // "accion" llega cuando el cliente usa el EmbeddedLink de reenvio ("reenviar_otp").
    public class FlowOtpIngresado
    {
        public string otp { get; set; } = string.Empty;

        public string? accion { get; set; }

        public string celular { get; set; } = string.Empty;

        public string wppSesionId { get; set; } = string.Empty;
    }
}
