namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    // Mirror local de SaldoResponse (olivia-bxt-core), recibido via WppFlowResponse.Data en la pantalla CSM_ELEGIR_CUENTA.
    public class WppFlowSaldoConsultado
    {
        public double Saldo { get; set; } = 0.0;

        public string Moneda { get; set; } = string.Empty;
    }
}
