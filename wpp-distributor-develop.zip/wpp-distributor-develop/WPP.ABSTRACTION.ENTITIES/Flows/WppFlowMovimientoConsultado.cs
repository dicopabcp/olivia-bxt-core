namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    // Mirror local de MovimientoResponse (olivia-bxt-core), recibido via WppFlowResponse.Data en la pantalla CSM_ELEGIR_MOVIMIENTO.
    public class WppFlowMovimientoConsultado
    {
        public string Fecha { get; set; } = string.Empty;

        public string Glosa { get; set; } = string.Empty;

        public double Monto { get; set; } = 0.0;
    }
}
