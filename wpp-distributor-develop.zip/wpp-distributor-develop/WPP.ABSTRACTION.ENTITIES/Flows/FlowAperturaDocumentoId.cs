namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class FlowAperturaDocumentoId
    {
        public List<ImageSent> documento_foto { get; set; } = new();
    }
}
