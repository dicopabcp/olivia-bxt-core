namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class WppFlowUsuarioBm
    {
        public string UsuarioBm { get; set; } = string.Empty;
    }
}
