namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class WppFlowValidarClaveBm
    {
        public string ClaveBm { get; set; } = string.Empty;
    }
}
