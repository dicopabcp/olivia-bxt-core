namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class WppFlowOtpCorreo
    {
        public string Otp { get; set; } = string.Empty;
    }
}
