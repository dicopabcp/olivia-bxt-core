﻿namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class FlowCarnetIdentidad
    {
        public string carnet { get; set; } = string.Empty;

        public string complemento { get; set; } = string.Empty;

        public string celular { get; set; } = string.Empty;

        public string wppSesionId { get; set; } = string.Empty;
    }
}