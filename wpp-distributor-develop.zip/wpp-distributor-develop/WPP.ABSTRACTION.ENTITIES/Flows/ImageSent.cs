﻿namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class ImageSent
    {
        public string file_name { get; set; } = string.Empty;
        public string media_id { get; set; } = string.Empty;
        public string cdn_url { get; set; } = string.Empty;
        public EncyptionMetadaFlowImage encryption_metadata { get; set; } = new EncyptionMetadaFlowImage();
    }
}