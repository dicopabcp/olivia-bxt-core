namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class FlowAperturaValidarClave
    {
        public string clave_bm { get; set; } = string.Empty;
    }
}
