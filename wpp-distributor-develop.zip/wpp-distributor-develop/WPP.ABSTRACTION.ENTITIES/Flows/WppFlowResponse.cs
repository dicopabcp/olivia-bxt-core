﻿namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class WppFlowResponse
    {
        public string Mensaje { get; set; } = string.Empty;
        public bool Expired { get; set; }
        public bool Success { get; set; }
        public bool EnviarGenesys { get; set; }

        // Datos de la siguiente pantalla del Flow (ej. cuenta creada, cuentas consultadas); null para flujos que no lo requieren (ej. Rekognition/Encuesta).
        public object? Data { get; set; }
    }
}