namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class FlowAperturaVerificacionInicial
    {
        public string celular { get; set; } = string.Empty;

        public string wppSesionId { get; set; } = string.Empty;
    }
}
