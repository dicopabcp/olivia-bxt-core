namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class FlowAperturaSelfie
    {
        public List<ImageSent> selfie_foto { get; set; } = new();
    }
}
