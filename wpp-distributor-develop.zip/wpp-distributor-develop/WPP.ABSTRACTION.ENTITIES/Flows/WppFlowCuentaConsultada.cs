namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    // Mirror local de CoreBancarioCuentaResponse (olivia-bxt-core), recibido via WppFlowResponse.Data en la pantalla ACSBM_CUENTAS.
    public class WppFlowCuentaConsultada
    {
        public string NumeroCuenta { get; set; } = string.Empty;

        public string Tipo { get; set; } = string.Empty;

        public string Descripcion { get; set; } = string.Empty;
    }
}
