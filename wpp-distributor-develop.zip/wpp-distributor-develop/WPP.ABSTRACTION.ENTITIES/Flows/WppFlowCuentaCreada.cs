namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    // Mirror local de CoreBancarioCrearCuentaResponse (olivia-bxt-core), recibido via WppFlowResponse.Data en la pantalla APC_RESUMEN.
    public class WppFlowCuentaCreada
    {
        public string NumeroCuenta { get; set; } = string.Empty;

        public string NumeroTarjetaDebito { get; set; } = string.Empty;

        public bool ContratoFirmado { get; set; }
    }
}
