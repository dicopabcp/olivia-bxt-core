﻿namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    public class WppFlowSelfi
    {
        public string Base64 { get; set; } = string.Empty;
    }
}