namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    // Pantalla CSM_ELEGIR_MOVIMIENTO (consulta_saldos_movimientos.json).
    public class FlowMovimientoElegido
    {
        public string movimiento { get; set; } = string.Empty;

        public string celular { get; set; } = string.Empty;

        public string wppSesionId { get; set; } = string.Empty;
    }
}
