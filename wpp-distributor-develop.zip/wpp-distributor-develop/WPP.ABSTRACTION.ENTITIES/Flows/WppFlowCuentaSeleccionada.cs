namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    // Mirror local de WppFlowCuentaSeleccionada (olivia-bxt-core), enviado para la pantalla CSM_ELEGIR_CUENTA.
    public class WppFlowCuentaSeleccionada
    {
        public string CuentaReferencial { get; set; } = string.Empty;
    }
}
