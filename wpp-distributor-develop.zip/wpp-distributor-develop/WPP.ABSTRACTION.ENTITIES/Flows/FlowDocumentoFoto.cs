namespace WPP.ABSTRACTION.ENTITIES.Flows
{
    // Pantalla CSM_DOCUMENTO_ID (consulta_saldos_validacion_identidad.json).
    public class FlowDocumentoFoto
    {
        public string celular { get; set; } = string.Empty;

        public string wppSesionId { get; set; } = string.Empty;

        public List<ImageSent> documento_foto { get; set; } = new();
    }
}
