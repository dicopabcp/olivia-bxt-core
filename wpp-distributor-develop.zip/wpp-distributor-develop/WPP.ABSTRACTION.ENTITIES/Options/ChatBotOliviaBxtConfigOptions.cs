﻿namespace WPP.ABSTRACTION.ENTITIES.Options
{
    public class ChatBotOliviaBxtConfigOptions
    {
        public string Url { get; set; } = string.Empty;
        
        public string UrlLynn { get; set; } = string.Empty;
        
        public string MetodoFlowRekognition { get; set; } = string.Empty;
        
        public string MetodoFlowEncuesta { get; set; } = string.Empty;

        public string MetodoFlowAperturaCuentaNoCliente { get; set; } = string.Empty;

        public string MetodoFlowAperturaCuentaYaClienteConBM { get; set; } = string.Empty;

        public string MetodoFlowAperturaCuentaYaClienteSinBM { get; set; } = string.Empty;

        public string MetodoFlowValidacionIdentidad { get; set; } = string.Empty;

        public string MetodoFlowConsultaMovimientos { get; set; } = string.Empty;
    }
}
