﻿namespace WPP.ABSTRACTION.ENTITIES.Options
{
    public class WhastAppConfigOptions
    {
        public string FlowCertificatePath { get; set; } = string.Empty;
    }
}
