﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPP.ABSTRACTION.ENTITIES.MessageReception
{
    public class MessageReceptionGupShupRequest
    {
        public string? app { get; set; }
        public int? version { get; set; }
        public string? type { get; set; }
        public datosMensajeWhatsapp? payload { get; set; }

    }

    public class datosMensajeWhatsapp
    {
        public string? id { get; set; }
        public string? source { get; set; }
        public string? type { get; set; }
        public payloadWhatsapp? payload { get; set; }
        public senderWhatsapp? sender { get; set; }
        public receiveMessageContext? context { get; set; }
        public receiveMessageReferral? referral { get; set; }

    }

    public class payloadWhatsapp
    {
        public string? text { get; set; }

        #region Multimedia
        public string? caption { get; set; }
        public string? url { get; set; }
        public string? contentType { get; set; }
        #endregion

        #region Mensaje Interativo

        public string? title { get; set; }
        public string? id { get; set; }
        public string? reply { get; set; }
        public string? postbackText { get; set; }
        public string? description { get; set; }

        #endregion

        #region reacciones

        public string? gsId { get; set; }
        public string? emoji { get; set; }


        #endregion

        #region location

        public int? longitude { get; set; }
        public string? latitude { get; set; }

        #endregion


        public int? code { get; set; }
        public string? reason { get; set; }

    }

    public class senderWhatsapp
    {
        public string? phone { get; set; }
        public string? name { get; set; }
        public string? country_code { get; set; }
        public string? dial_code { get; set; }

    }

    public class receiveMessageContext
    {
        public string? id { get; set; }
        public string? gsId { get; set; }


    }

    public class receiveMessageReferral
    {
        public string? body { get; set; }
        public string? headline { get; set; }
        public receiveMessageReferralImage? image { get; set; }
        public string? source_id { get; set; }
        public string? source_type { get; set; }
        public string? source_url { get; set; }

    }

    public class receiveMessageReferralImage
    {
        public string? id { get; set; }

    }



}
