﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPP.ABSTRACTION.ENTITIES.MessageReception
{
    public class FilePathOptions
    {
        public string path { get; set; } = string.Empty;
        public string pathTemplate { get; set; } = string.Empty;
    }
}
