﻿using WPP.ABSTRACTION.ENTITIES.StatusMessageReception;

namespace WPP.ABSTRACTION.ENTITIES.MessageReception
{
    public class MessageReceptionRequest
    {
        public string? total { get; set; } 
        public List<DatosMensajeWhatsapp>? data { get; set; } 
        public StatuClientInfo? clientInfo { get; set; } 
    }
    public class DatosMensajeWhatsapp
    {
        public string? id { get; set; } 
        public string? source { get; set; } 
        public string? origin { get; set; } 
        public DatosUsuarioWhatsapp? userProfile { get; set; } 
        public int campaignId { get; set; }
        public string? correlationId { get; set; } 
        public string? campaignAlias { get; set; } 
        public string? flowId { get; set; } 
        public string? extraInfo { get; set; } 
        public MensajeWhatsapp? message { get; set; } 
        public string? receivedAt { get; set; } 
        public string? receivedDate { get; set; } 
        public string? destination { get; set; } 
        public bool sent { get; set; }
        public int sentStatusCode { get; set; }
        public bool sentStatus { get; set; }
        public string? sentDate { get; set; } 
        public int sentAt { get; set; }
        public bool delivered { get; set; }
        public int deliveredStatusCode { get; set; }
        public string? deliveredStatus { get; set; }
        public string? deliveredDate { get; set; } 
        public int deliveredAt { get; set; }
        public bool read { get; set; }
        public string? readDate { get; set; } 
        public string? readAt { get; set; } 
        public string? updatedDate { get; set; } 
        public string? updatedAt { get; set; } 
    }
    public class DatosUsuarioWhatsapp
    {
        public string? name { get; set; } 
    }
    public class MensajeWhatsapp
    {
        public string? type { get; set; } 
        public string? messageText { get; set; } 
        public string? waGroupId { get; set; } 
        public string? mediaUrl { get; set; } 
        public string? mimeType { get; set; } 
        public string? caption { get; set; } 
        public ReceiveMessageLocation? location { get; set; } 
        public List<ReceiveMessageContact>? contacts { get; set; } 
    }
    public class ReceiveMessageLocation
    {
        public string? geoPoint { get; set; } 
        public string? name { get; set; } 
        public string? address { get; set; } 
    }
    public class ReceiveMessageContact
    {
        public List<ReceiveMessageAddress>? addresses { get; set; } 
        public string? birthday { get; set; } 
        public List<ReceiveMessageEmail>? emails { get; set; } 
        public ReceiveMessageName? name { get; set; } 
        public ReceiveMessageOrg? org { get; set; } 
        public List<ReceiveMessagePhone>? phones { get; set; } 
        public List<ReceiveMessageUrl>? urls { get; set; } 

    }
    public class ReceiveMessageAddress
    {
        public string? street { get; set; } 
        public string? city { get; set; } 
        public string? state { get; set; } 
        public string? zip { get; set; } 
        public string? country { get; set; } 
        public string? country_code { get; set; } 
        public string? type { get; set; } 
    }
    public class ReceiveMessageEmail
    {
        public string? email { get; set; } 
        public string? type { get; set; } 
    }
    public class ReceiveMessageName
    {
        public string? first_name { get; set; } 
        public string? last_name { get; set; } 
        public string? formatted_name { get; set; } 
    }
    public class ReceiveMessageOrg
    {
        public string? company { get; set; } 
        public string? department { get; set; } 
        public string? title { get; set; } 
    }
    public class ReceiveMessagePhone
    {
        public string? phone { get; set; } 
        public string? type { get; set; } 
        public string? wa_id { get; set; } 
    }
    public class ReceiveMessageUrl
    {
        public string? url { get; set; } 
        public string? type { get; set; } 
    }
}
