﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPP.ABSTRACTION.ENTITIES.Olivia
{
    public class OliviaRequest
    {
        public string? usuario { get; set; }
        public string? mensaje { get; set; }
    }
    public class OliviaResponse
    {
        public string? respuesta { get; set; }
        public bool enviarGenesys { get; set; }
    }
}
