﻿
namespace WPP.ABSTRACTION.ENTITIES.StatusMessageReception
{
    public class StatusMessageReceptionRequest
    {
        public string total { get; set; } = string.Empty;
        public List<StatusDataWhatsapp> data { get; set; } = new List<StatusDataWhatsapp>();
        public StatuClientInfo clientInfo { get; set; } = new StatuClientInfo();
    }
    public class StatusDataWhatsapp
    {
        public string id { get; set; }
        public string correlationId { get; set; }
        public string destination { get; set; }
        public string origin { get; set; }
        public string campaignId { get; set; }
        public string campaignAlias { get; set; }
        public string flowId { get; set; }
        public string extraInfo { get; set; }
        public bool sent { get; set; }
        public int sentStatusCode { get; set; }
        public bool sentStatus { get; set; }
        public string sentDate { get; set; }
        public int sentAt { get; set; }
        public bool delivered { get; set; }
        public int deliveredStatusCode { get; set; }
        public string deliveredStatus { get; set; }
        public string deliveredDate { get; set; }
        public int deliveredAt { get; set; }
        public bool read { get; set; }
        public string readDate { get; set; }
        public string readAt { get; set; }
        public string updatedDate { get; set; }
        public string updatedAt { get; set; }

    }

    public class StatuClientInfo
    {
        public int customerId { get; set; }
        public int subAccountId { get; set; }
        public int userId { get; set; }

    }
}
