﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.ENTITIES.MessageApplication;

namespace WPP.APPLICATION.CONNECTION.DATABASE
{
    public interface IConnectionDistributorDataBase
    {
        DataTable GetLastestMessage(string _cellphone);
        List<Tags> GetTagConfig(string _Tag);
        List<string> GetCellphoneTest();
        int InsertNewMessage(MessageApplicationReceptionRequest _messageWhatsApp);
    }
}
