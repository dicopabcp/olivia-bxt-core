﻿using Microsoft.Data.SqlClient;
using System.Data;
using WPP.ABSTRACTION.DATAACCESS;
using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.ENTITIES.MessageApplication;

namespace WPP.APPLICATION.CONNECTION.DATABASE
{
    public class ConnectionDistributorDataBase : IConnectionDistributorDataBase
    {
        private readonly IDataAccess _dataAccess;
        private static readonly string DATABASE_CONNECTION_NAME = "MESSAGE.DISTRIBUTOR";
        public ConnectionDistributorDataBase(IDataAccess dataAccess) { this._dataAccess = dataAccess; }

        public DataTable GetLastestMessage(string _cellphone)
        {
            try
            {
                List<SqlParameter> _parameters = new();
                _parameters.Add(new SqlParameter("@CELLPHONE", _cellphone.Trim()));
                return this._dataAccess.SelectStoredProcedure(DATABASE_CONNECTION_NAME, "[wpp].[WPP_RECEIVE_THE_LAST_MESSAGE]", _parameters);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Tags> GetTagConfig(string _Tag)
        {
            List<Tags> _response= new List<Tags>();
            try
            {

                List<SqlParameter> _parameters = new();
                _parameters.Add(new SqlParameter("@TAG", _Tag.Trim()));
                DataTable dtm = this._dataAccess.SelectStoredProcedure(DATABASE_CONNECTION_NAME, "[wpp].[WPP_GET_PARAMETROS]", _parameters);

                foreach (DataRow item in dtm.Rows)
                {
                    Tags tg = new Tags();

                    tg.tag = item.Field<string>("TAG");
                    tg.valor = item.Field<string>("VALOR_TAG");

                    _response.Add(tg);
                }

                return _response;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<string> GetCellphoneTest()
        {
            List<string> response = new List<string>();
            try
            {

                List<SqlParameter> _parameters = new();
                DataTable dt = this._dataAccess.SelectStoredProcedure(DATABASE_CONNECTION_NAME, "[wpp].[WPP_GET_CELLPHONE_TEST]", _parameters);

                foreach (DataRow item in dt.Rows)
                {
                    response.Add(item.Field<string>("CELULAR"));
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }

        public int InsertNewMessage(MessageApplicationReceptionRequest _messageWhatsApp)
        {
            try
            {
                List<SqlParameter> _parameter = new();
                _parameter.Add(new SqlParameter("@COD_CLIENTE", _messageWhatsApp.messageCode));
                _parameter.Add(new SqlParameter("@CELULAR", _messageWhatsApp.cellphone));
                _parameter.Add(new SqlParameter("@MENSAJE", _messageWhatsApp.message));
                _parameter.Add(new SqlParameter("@TIPO_MENSAJE", "ENTRANTE"));
                _parameter.Add(new SqlParameter("@COD_TIPO_MENSAJE", "E"));
                _parameter.Add(new SqlParameter("@JSON", _messageWhatsApp.json));
                _parameter.Add(new SqlParameter("@USUARIO", _messageWhatsApp.user));
                _parameter.Add(new SqlParameter("@NOMBRE_USAURIO", _messageWhatsApp.nameUser));
                _parameter.Add(new SqlParameter("@WHATSAPP_BOT", _messageWhatsApp.identifyChatBot));
                _parameter.Add(new SqlParameter("@CAMPAÑA", _messageWhatsApp.campaignName));
                _parameter.Add(new SqlParameter("@INICIOSECION", 0));
                _parameter.Add(new SqlParameter("@CLASEMENSAJE", string.IsNullOrEmpty(_messageWhatsApp.classMultimedia) ? "TEXT" : _messageWhatsApp.classMultimedia.Trim().ToUpper()));
                _parameter.Add(new SqlParameter("@URLMULTIMEDIA", _messageWhatsApp.url));
                _parameter.Add(new SqlParameter("@FECHAENTREGADO", DateTime.Now.ToString()));
                _parameter.Add(new SqlParameter("@FECHALEIDO", DateTime.Now.ToString()));
                _parameter.Add(new SqlParameter() { ParameterName = "@MESSAGE_ID", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output, Value = _messageWhatsApp.messageId });
                this._dataAccess.ExecuteStoredProcedure(DATABASE_CONNECTION_NAME, "[wpp].[WPP_INSERT_NEW_MESSAGE]", ref _parameter);
                return Convert.ToInt32(_parameter.First(x => x.Direction == ParameterDirection.Output && x.ParameterName.Equals("@MESSAGE_ID")).Value);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}