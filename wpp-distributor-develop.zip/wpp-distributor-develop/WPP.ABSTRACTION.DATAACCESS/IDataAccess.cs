﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using System.Data;

namespace WPP.ABSTRACTION.DATAACCESS
{
    public interface IDataAccess
    {
        HealthCheckResult Check(string name);
        DataTable SelectStoredProcedure(string name, string query, List<SqlParameter> parameter);
        bool ExecuteStoredProcedure(string name, string query,ref List<SqlParameter> parameter);
        DataTable Select(string name, string query);
    }
}
