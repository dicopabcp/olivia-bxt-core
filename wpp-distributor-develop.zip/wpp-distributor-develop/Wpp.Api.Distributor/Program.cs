using Microsoft.AspNetCore.Identity;
using System.Reflection;
using WPP.ABSTRACTION.DATAACCESS;
using WPP.ABSTRACTION.ENTITIES.DistributorMessage;
using WPP.ABSTRACTION.ENTITIES.Options;
using WPP.ABSTRACTION.LOGGER;
using WPP.ABSTRACTION.SECRYPT;
using WPP.APPLICATION.BUSSINESS;
using WPP.APPLICATION.BUSSINESS.Flows;
using WPP.APPLICATION.CONNECTION.DATABASE;
using WPP.APPLICATION.CONNECTION.SERVICE;
using WPP.APPLICATION.CONNECTION.SERVICE.Interfaces;
using WPP.APPLICATION.CONNECTION.SERVICE.RestConnectionService;
using WPP.APPLICATION.CONNECTION.SERVICE.Services;

var builder = WebApplication.CreateBuilder(args);

const string _sectionNameFileDirectory = "File.Directory";


// Add services to the container.
builder.Services.Configure<DistributorMessageOptions>(options => builder.Configuration.GetSection("Configuration.Manager.Distributor").Bind(options));
builder.Services.Configure<FileManagementOptions>(options => builder.Configuration.GetSection(_sectionNameFileDirectory).Bind(options));
builder.Services.Configure<WhastAppConfigOptions>(options => builder.Configuration.GetSection("WhatsAppConfig").Bind(options));
builder.Services.Configure<ChatBotOliviaBxtConfigOptions>(options => builder.Configuration.GetSection("Api.ChatBot.OliviaBxt").Bind(options));

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(swagger =>
{
    var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    swagger.IncludeXmlComments(Path.Combine(AppContext.BaseDirectory, xmlFile));
});
builder.Services.AddLogger();
builder.Services.AddDataBase();
builder.Services.AddSecrypt();

builder.Services.AddSingleton<WhatsAppFlowsCommands>();
builder.Services.AddSingleton<IMessageDistributorBussiness, MessageDistributorBussiness>();
builder.Services.AddSingleton<IConnectionDistributorDataBase, ConnectionDistributorDataBase>();
builder.Services.AddSingleton<IDistributorConnectionService, DistributorConnectionService>();
builder.Services.AddSingleton<IVerifyIncomingMessageBussiness, VerifyIncomingMessageBussiness>();
builder.Services.AddSingleton<IConnectionDataBaseBussiness, ConnectionDataBaseBussiness>();
builder.Services.AddSingleton<IDistributorMessageConnectionService, DistributorMessageConnectionService>();
builder.Services.AddSingleton<IFileManager, FileManager>();
builder.Services.AddSingleton<IDataFlowManager, DataFlowManager>();

var app = builder.Build();

bool dev = app.Configuration.GetValue<bool>("Dev");
if (dev)
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();
