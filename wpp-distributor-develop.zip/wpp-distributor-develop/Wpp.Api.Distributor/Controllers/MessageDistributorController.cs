﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Wpp.Api.Distributor.Commons;
using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.ENTITIES.MessageApplication;
using WPP.ABSTRACTION.LOGGER;
using WPP.APPLICATION.BUSSINESS;

namespace Wpp.Api.Distributor.Controllers
{
    /// <summary>
    /// Controlador para el envio de mensajes de WhatsApp a Olivia Chat Bot
    /// </summary>
    [Route("api/v1/[controller]")]
    [ApiController]
    public class MessageDistributorController : ControllerBase
    {
        private readonly ILoggerInfo _logger;
        private readonly IMessageDistributorBussiness _bussiness;
        public MessageDistributorController(ILoggerInfo logger, IMessageDistributorBussiness bussiness) { this._logger = logger; this._bussiness = bussiness; }

        /// <summary>
        /// Envia el mensaje procesado desde ReceivedCentralizer a WhatsApp
        /// </summary>
        /// <param name="_request">Mensaje del cliente desde WhastApp</param>
        /// <remarks>
        /// Request example:
        /// ```json
        ///        {
        ///    "message": "Hola",
        ///    "messageId": 0,
        ///    "messageCode": "ABGGWRY0RzRfAgo6dFXegf5k9U6j",
        ///    "typeMessage": "TEXT",
        ///    "classMultimedia": "",
        ///    "classInteractive": null,
        ///    "identifyChatBot": false,
        ///    "cellphone": "59160128357",
        ///    "url": "",
        ///    "nameMultimediaUrl": "",
        ///    "user": null,
        ///    "nameUser": null,
        ///    "campaignName": "i5UUJhYy8fKe3GaRvwvj7WQO",
        ///    "destinationAccount": "59164198005",
        ///    "json": "{\"app\":\"i5UUJhYy8fKe3GaRvwvj7WQO\",\"version\":2,\"type\":\"message\",\"payload\":{\"id\":\"ABGGWRY0RzRfAgo6dFXegf5k9U6j\",\"source\":\"59163447345\",\"type\":\"text\",\"payload\":{\"text\":\"Buenas\"},\"sender\":{\"phone\":\"59163447345\",\"name\":\"RodrigoQuispeFlores\",\"country_code\":\"591\",\"dial_code\":\"63447345\"}}"
        ///}
        /// ```
        /// </remarks>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Respuesta generada por el chatbot</returns>
        [HttpPost("MessageReceptionWsp")]
        [ProducesResponseType(typeof(GenericResponse), 200)]
        public async Task<ActionResult> MessageReceptionWhatsApp(MessageApplicationReceptionRequest _request)
        {
            GenericResponse _response = new();
            string _operation = GenerateOperation.generateOperation();

            await Task.Factory.StartNew(async delegate
            {
                try
                {
                    this._logger.Debug(string.Format("[{0}]  REQUEST: {1}", _operation, JsonConvert.SerializeObject(_request)));
                    _response = await this._bussiness.MessageWhatsAppDistributor(_request, _operation);
                    this._logger.Debug(string.Format("[{0}] RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
                }
                catch (Exception ex)
                {
                    _response.code = "500";
                    _response.success = false;
                    _response.message = ex.Message;
                    this._logger.Debug(string.Format("[{0}]    ERROR: {1}", _operation, ex.Message + " EXCEPTIO: " + JsonConvert.SerializeObject(ex)));
                }
            });

            return Ok(new GenericResponse { message = "processing complete", code = "200", success = true });
        }
    }
}
