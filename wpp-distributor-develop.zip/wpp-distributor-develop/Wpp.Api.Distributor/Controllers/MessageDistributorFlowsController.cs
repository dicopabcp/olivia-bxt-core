﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Wpp.Api.Distributor.Commons;
using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.ENTITIES.MessageApplication;
using WPP.ABSTRACTION.LOGGER;
using WPP.APPLICATION.BUSSINESS;

namespace Wpp.Api.Distributor.Controllers
{
    /// <summary>
    /// Controlador para el envio de informacion desde los formularios de WhatsApp
    /// </summary>
    [Route("api/v1/[controller]")]
    [ApiController]
    public class MessageDistributorFlowsController : ControllerBase
    {
        private readonly ILoggerInfo _logger;
        private readonly IMessageDistributorBussiness _bussiness;
        public MessageDistributorFlowsController(ILoggerInfo logger, IMessageDistributorBussiness bussiness)
        {
            this._logger = logger;
            this._bussiness = bussiness;
        }

        /// <summary>
        /// Se envia la informacion del formulario encriptada
        /// </summary>
        /// <param name="wppFlowMessage">Informacion encriptada de los datos del formulario</param>
        /// <remarks>
        /// Request example:
        /// ```json
        ///{
        ///	"encrypted_aes_key": "nA1ETxlmcfhEqgezJ1rGcvRrObx0SN3aDGUChgSJQSq00skMmkNvaw012ES/ntpTh4QYKVz1StLZDv/1FE/y3pU8ATZa55wGx7tRwFPRVguG6kiohwckkg4x41tKmfkKo6VW5ysq6NLTNC+qlLpD6R7oEx/QFQcipAdAKT++bumDKGAIK5Eh0nExutfRHhjuBDFByo1B2PNYWD77FAC0mcyhn6DZNi43+7wqzfJtcfK+yjDshh86HGlKluHYSJ6fp/DPQvt57uZbc0TZL3JnHHua83iRhpHiKX+JnkrPSggbKUt5P3fwmZ4Iuwm7a3hAl4lPdEaR9Z3ZBH7vqzr6vA==",
        ///	"encrypted_flow_data": "AK85GSpNjhnJdQy/D63ue4OObDq0wtR2uX1p6GMaXat/osMrrbvxxK+C6h93kv38Uw==",
        ///	"initial_vector": "u6Wt5PkHC4uLTaeYkNe88Q=="
        ///}
        /// ```
        /// </remarks>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Respuesta generada por la api de flows</returns>
        [ApiExplorerSettings(GroupName = "v1")]
        [HttpPost("{flowName}")]
        [ProducesResponseType(typeof(GenericResponse), 200)]
        public async Task<GenericResponse<string>> MessageReceptionWhatsAppFlow(string flowName, [FromBody] EndpointPayload _request)
        {
            GenericResponse<string> _response = new();
            string _operation = GenerateOperation.generateOperation();
            try
            {
                this._logger.Debug(string.Format("[{0}]  REQUEST: {1}", _operation, JsonConvert.SerializeObject(_request)));
                _response = await this._bussiness.MessageWhatsAppFlowDistributor(_request, flowName, _operation);
                this._logger.Debug(string.Format("[{0}] RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
            }
            catch (Exception ex)
            {
                _response.code = "500";
                _response.success = false;
                _response.message = ex.Message;
                this._logger.Debug(string.Format("[{0}]    ERROR: {1}", _operation, ex.Message));
            }
            return _response;
        }
    }
}
