﻿namespace Wpp.Api.Distributor.Commons
{
    public static class GenerateOperation
    {
        public static string generateOperation() { return DateTime.Now.ToString("yyyyMMddhhmmssff"); }
    }
}
