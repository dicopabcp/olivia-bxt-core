﻿using Org.BouncyCastle.OpenSsl;

namespace REKOGNITION.APPLICATION.CONNECTION.SERVICE.Helpers
{
    public class PasswordFinder : IPasswordFinder
    {
        private readonly char[] _password;

        public PasswordFinder(string password)
        {
            _password = password.ToCharArray();
        }

        public char[] GetPassword()
        {
            return _password;
        }
    }
}
