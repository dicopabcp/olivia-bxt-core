﻿namespace WPP.APPLICATION.CONNECTION.SERVICE.Interfaces
{
    public interface IDataFlowManager
    {
        public (dynamic decryptedBody, byte[] aesKeyBytes, byte[] initialVectorBytes) DecryptRequest(string encryptedAesKey, string encryptedFlowData, string initialVector);
        public string EncryptResponse(dynamic response, byte[] aesKeyBytes, byte[] initialVectorBytes);
    }
}
