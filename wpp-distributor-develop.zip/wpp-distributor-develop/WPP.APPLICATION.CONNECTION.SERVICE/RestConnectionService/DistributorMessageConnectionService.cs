﻿using Newtonsoft.Json;
using System.Net;
using System.Security.Authentication;
using System.Text;
using WPP.ABSTRACTION.ENTITIES;

namespace WPP.APPLICATION.CONNECTION.SERVICE.RestConnectionService
{
    public enum Authentication { None, Header, Basic, Complete, WhatsApp }
    public interface IDistributorMessageConnectionService
    {
        Task<T> PostAsync<T>(string _urlBase, string _method, object _request, Authentication _authentication, string _usuario = "", string _password = "", string _channel = "", string _publicToken = "", string _appUserid = "");
        Task<T> PostWebHookAsync<T>(string _urlBase, string _method, string _json, Authentication _authentication, string _usuario = "", string _password = "", string _channel = "", string _publicToken = "", string _appUserid = "");
        T Post<T>(string _urlBase, string _method, object _request, Authentication _authentication, string _usuario = "", string _password = "", string _channel = "", string _publicToken = "", string _appUserid = "");
    }
    public class DistributorMessageConnectionService : IDistributorMessageConnectionService
    {
        public async Task<T> PostAsync<T>(string _urlBase, string _method, object _request, Authentication _authentication, string _usuario = "", string _password = "", string _channel = "", string _publicToken = "", string _appUserid = "")
        {
            HttpClientHandler httpHandler = new HttpClientHandler();
            httpHandler.SslProtocols = SslProtocols.Tls12;
            using (var httpClient = new HttpClient(httpHandler)) 
            {
                httpClient.Timeout = TimeSpan.FromMinutes(5);
                switch (_authentication)
                {
                    case Authentication.None:
                        break;
                    case Authentication.Header:
                        httpClient.DefaultRequestHeaders.Add("USUARIO", _usuario);
                        httpClient.DefaultRequestHeaders.Add("PASSWORD", _password);
                        break;
                    case Authentication.Basic:
                        string _encodeBasic = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(_usuario + ":" + _password));
                        httpClient.DefaultRequestHeaders.Add("Authorization", $"Basic {_encodeBasic}");
                        break;
                    case Authentication.Complete:
                        string _encodeComplete = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(_usuario + ":" + _password));
                        httpClient.DefaultRequestHeaders.Add("Authorization", $"Basic {_encodeComplete}");
                        httpClient.DefaultRequestHeaders.Add("channel", _channel);
                        httpClient.DefaultRequestHeaders.Add("publicToken", _publicToken);
                        httpClient.DefaultRequestHeaders.Add("appUserId", _appUserid);
                        break;
                    case Authentication.WhatsApp:
                        httpClient.DefaultRequestHeaders.Add("username", _usuario);
                        httpClient.DefaultRequestHeaders.Add("authenticationToken", _password);
                        break;
                    default:
                        break;
                }
                var _json = JsonConvert.SerializeObject(_request);
                var _content = new StringContent(_json, Encoding.UTF8, "application/json");
                var _result = await httpClient.PostAsync(new Uri(_urlBase + _method), _content);
                var _resultContent = await _result.Content.ReadAsStringAsync();
                HttpStatusCode _statusCode = _result.StatusCode;
                if (_statusCode == HttpStatusCode.OK)
                {
                    var _responseService = _resultContent == null ? "" : _resultContent;
                    return JsonConvert.DeserializeObject<T>(_responseService);
                }
                else
                {
                    throw new Exception($"ERROR => URL METHOD: {_urlBase + _method} ; STATUS: {_statusCode} ; CONTENT: {_resultContent}");
                }
            }
        }

        public async Task<T> PostWebHookAsync<T>(string _urlBase, string _method, string _json, Authentication _authentication, string _usuario = "", string _password = "", string _channel = "", string _publicToken = "", string _appUserid = "")
        {
            HttpClientHandler httpHandler = new HttpClientHandler();
            httpHandler.SslProtocols = SslProtocols.Tls12;
            using (var httpClient = new HttpClient(httpHandler))
            {
                httpClient.Timeout = TimeSpan.FromMinutes(5);
                switch (_authentication)
                {
                    case Authentication.None:
                        break;
                    case Authentication.Header:
                        httpClient.DefaultRequestHeaders.Add("USUARIO", _usuario);
                        httpClient.DefaultRequestHeaders.Add("PASSWORD", _password);
                        break;
                    case Authentication.Basic:
                        string _encodeBasic = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(_usuario + ":" + _password));
                        httpClient.DefaultRequestHeaders.Add("Authorization", $"Basic {_encodeBasic}");
                        break;
                    case Authentication.Complete:
                        string _encodeComplete = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(_usuario + ":" + _password));
                        httpClient.DefaultRequestHeaders.Add("Authorization", $"Basic {_encodeComplete}");
                        httpClient.DefaultRequestHeaders.Add("channel", _channel);
                        httpClient.DefaultRequestHeaders.Add("publicToken", _publicToken);
                        httpClient.DefaultRequestHeaders.Add("appUserId", _appUserid);
                        break;
                    case Authentication.WhatsApp:
                        httpClient.DefaultRequestHeaders.Add("username", _usuario);
                        httpClient.DefaultRequestHeaders.Add("authenticationToken", _password);
                        break;
                    default:
                        break;
                }
                //var _json = JsonConvert.SerializeObject(_request);
                var _content = new StringContent(_json, Encoding.UTF8, "application/json");
                var _result = await httpClient.PostAsync(new Uri(_urlBase + _method), _content);
                var _resultContent = await _result.Content.ReadAsStringAsync();
                HttpStatusCode _statusCode = _result.StatusCode;
                if (_statusCode == HttpStatusCode.OK)
                {
                    var _responseService = _resultContent == null ? "" : _resultContent;

                    GenericResponse _res = new GenericResponse()
                    {
                        message = _responseService,
                        code = _statusCode.ToString(),
                        success = true

                    };
                    var _responseDatos = JsonConvert.SerializeObject(_res);
                    return JsonConvert.DeserializeObject<T>(_responseDatos);
                }
                else
                {
                    throw new Exception($"ERROR => URL METHOD: {_urlBase + _method} ; STATUS: {_statusCode} ; CONTENT: {_resultContent}");
                }
            }
        }


        public T Post<T>(string _urlBase, string _method, object _request, Authentication _authentication, string _usuario = "", string _password = "", string _channel = "", string _publicToken = "", string _appUserid = "")
        {
            HttpClientHandler httpHandler = new HttpClientHandler();
            httpHandler.SslProtocols = SslProtocols.Tls12;
            using (var httpClient = new HttpClient(httpHandler))
            {
                httpClient.Timeout = TimeSpan.FromMinutes(5);
                switch (_authentication)
                {
                    case Authentication.None:
                        break;
                    case Authentication.Header:
                        httpClient.DefaultRequestHeaders.Add("USUARIO", _usuario);
                        httpClient.DefaultRequestHeaders.Add("PASSWORD", _password);
                        break;
                    case Authentication.Basic:
                        string _encodeBasic = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(_usuario + ":" + _password));
                        httpClient.DefaultRequestHeaders.Add("Authorization", $"Basic {_encodeBasic}");
                        break;
                    case Authentication.Complete:
                        string _encodeComplete = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(_usuario + ":" + _password));
                        httpClient.DefaultRequestHeaders.Add("Authorization", $"Basic {_encodeComplete}");
                        httpClient.DefaultRequestHeaders.Add("channel", _channel);
                        httpClient.DefaultRequestHeaders.Add("publicToken", _publicToken);
                        httpClient.DefaultRequestHeaders.Add("appUserId", _appUserid);
                        break;
                    case Authentication.WhatsApp:
                        httpClient.DefaultRequestHeaders.Add("username", _usuario);
                        httpClient.DefaultRequestHeaders.Add("authenticationToken", _password);
                        break;
                    default:
                        break;
                }
                var _json = JsonConvert.SerializeObject(_request);
                var _content = new StringContent(_json, Encoding.UTF8, "application/json");
                var _result = httpClient.PostAsync(new Uri(_urlBase + _method), _content).Result;
                var _resultContent = _result.Content.ReadAsStringAsync().Result;
                HttpStatusCode _statusCode = _result.StatusCode;
                if (_statusCode == HttpStatusCode.OK)
                {
                    var _responseService = _resultContent == null ? "" : _resultContent;
                    return JsonConvert.DeserializeObject<T>(_responseService);
                }
                else
                {
                    throw new Exception($"ERROR => URL METHOD: {_urlBase + _method} ; STATUS: {_statusCode} ; CONTENT: {_resultContent}");
                }
            }
        }
    }
}
