﻿using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.ENTITIES.Flows;
using WPP.ABSTRACTION.ENTITIES.MessageApplication;
using WPP.ABSTRACTION.ENTITIES.Olivia;

namespace WPP.APPLICATION.CONNECTION.SERVICE
{
    public interface IDistributorConnectionService
    {
        Task<GenericResponse> SendChatBotMessage(MessageWhatsAppApplication _request);
        Task<GenericResponse> SendMessageSignalR(MessageWhatsAppApplication _request);
        Task<GenericResponse> SendChatBotGenesis(string _request, string _urlGenesis);
        Task<OliviaResponse> SendChatBotOlivia(OliviaRequest _request, string _urlOlivia);
        Task<WppFlowResponse> SendFlowOlivia(WppFlowRequest _request, string _operation);
        Task<WppFlowResponse> SendFlowEncuestaOlivia(WppFlowRequest _request, string _operation);
        Task<WppFlowResponse> SendFlowAperturaCuentaNoCliente(WppFlowRequest _request, string _operation);
        Task<WppFlowResponse> SendFlowAperturaCuentaYaClienteConBM(WppFlowRequest _request, string _operation);
        Task<WppFlowResponse> SendFlowAperturaCuentaYaClienteSinBM(WppFlowRequest _request, string _operation);
        Task<WppFlowResponse> SendFlowValidacionIdentidad(WppFlowRequest _request, string _operation);
        Task<WppFlowResponse> SendFlowConsultaMovimientos(WppFlowRequest _request, string _operation);
        Task<GenericResponse> SendFlowGenesis(string _request, string _operation);
    }
}
