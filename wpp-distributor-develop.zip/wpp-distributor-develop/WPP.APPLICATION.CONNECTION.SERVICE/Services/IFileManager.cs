﻿using WPP.ABSTRACTION.ENTITIES.Flows;

namespace WPP.APPLICATION.CONNECTION.SERVICE.Services
{
    public interface IFileManager
    {
        Task<string> SaveFileAsync(string data, string classFile, string typeFile);
        
        Task<string> ConvertToBase64(ImageSent imageSent);
    }
}
