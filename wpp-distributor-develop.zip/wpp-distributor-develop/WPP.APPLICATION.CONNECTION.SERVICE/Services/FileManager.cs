﻿using Microsoft.Extensions.Options;
using System.Security.Cryptography;
using WPP.ABSTRACTION.ENTITIES.Flows;
using WPP.ABSTRACTION.ENTITIES.Options;
using WPP.ABSTRACTION.LOGGER;

namespace WPP.APPLICATION.CONNECTION.SERVICE.Services
{
    public class FileManager : IFileManager
    {
        private readonly ILoggerInfo _logger;
        private readonly FileManagementOptions _fileOptions;
        public FileManager(IOptions<FileManagementOptions> fileOptions, ILoggerInfo logger)
        {
            this._logger = logger;
            _fileOptions = fileOptions.Value;
        }

        public async Task<string> SaveFileAsync(string data, string classFile, string typeFile)
        {
            try
            {
                _fileOptions.Root = string.IsNullOrEmpty(_fileOptions.Root) ? Environment.CurrentDirectory : _fileOptions.Root;
                string destinationFolder = string.Empty;
                string pathComplete = string.Empty;
                switch (typeFile.ToUpper())
                {
                    case "IMAGE":
                        destinationFolder = _fileOptions.PathImagenes;
                        break;
                    case "AUDIO":
                        destinationFolder = _fileOptions.PathAudios;
                        break;
                    case "VIDEO":
                        destinationFolder = _fileOptions.PathVideos;
                        break;
                    case "APPLICATION":
                    case "DOCUMENT":
                        destinationFolder = _fileOptions.PathDocumentos;
                        break;
                    case "STICKER":
                        destinationFolder = _fileOptions.PathSticker;
                        break;
                    default:
                        break;
                }
                string[] typeMultimedia = classFile.Split('/');
                string file = $"{Guid.NewGuid()}.{typeMultimedia[1].ToLower()}";
                string pathToSave = Path.Combine(_fileOptions.Root, destinationFolder);

                if (!Directory.Exists(pathToSave))
                {
                    Directory.CreateDirectory(pathToSave);
                }

                pathComplete = Path.Combine(pathToSave, file);
                await File.WriteAllBytesAsync(pathComplete, Convert.FromBase64String(data));
                return (_fileOptions.RootUrlPath + file);
            }
            catch (Exception ex)
            {
                this._logger.Error(string.Format("ERROR: {0}", ex.Message));
                return string.Empty;
            }
        }

        public async Task<string> ConvertToBase64(ImageSent imageSent)
        {
            var imagenByte = await DecryptMedia(imageSent);
            return Convert.ToBase64String(imagenByte);
        }

        private async Task<byte[]> DecryptMedia(ImageSent mediaObject)
        {
            using (HttpClient client = new HttpClient())
            {
                byte[] cdnFile = await client.GetByteArrayAsync(mediaObject.cdn_url);

                using (SHA256 sha256 = SHA256.Create())
                {
                    byte[] cdnFileHash = sha256.ComputeHash(cdnFile);
                    string cdnFileHashBase64 = Convert.ToBase64String(cdnFileHash);
                    if (cdnFileHashBase64 != mediaObject.encryption_metadata.encrypted_hash)
                    {
                        throw new Exception("SHA256 hash of cdn_file does not match enc_hash");
                    }
                }

                byte[] ciphertext = new byte[cdnFile.Length - 10];
                byte[] hmac10 = new byte[10];
                Array.Copy(cdnFile, 0, ciphertext, 0, ciphertext.Length);
                Array.Copy(cdnFile, ciphertext.Length, hmac10, 0, hmac10.Length);

                byte[] hmacKey = Convert.FromBase64String(mediaObject.encryption_metadata.hmac_key);
                byte[] iv = Convert.FromBase64String(mediaObject.encryption_metadata.iv);
                using (HMACSHA256 hmac = new HMACSHA256(hmacKey))
                {
                    hmac.TransformBlock(iv, 0, iv.Length, null, 0);
                    hmac.TransformFinalBlock(ciphertext, 0, ciphertext.Length);
                    byte[] hmacCalculated = hmac.Hash;
                    for (int i = 0; i < 10; i++)
                    {
                        if (hmacCalculated[i] != hmac10[i])
                        {
                            throw new Exception("HMAC-SHA256 validation failed");
                        }
                    }
                }

                byte[] encryptionKey = Convert.FromBase64String(mediaObject.encryption_metadata.encryption_key);
                byte[] decryptedMedia;
                using (Aes aes = Aes.Create())
                {
                    aes.Key = encryptionKey;
                    aes.IV = iv;
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;

                    using (ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV))
                    {
                        decryptedMedia = decryptor.TransformFinalBlock(ciphertext, 0, ciphertext.Length);
                    }
                }

                using (SHA256 sha256 = SHA256.Create())
                {
                    byte[] decryptedMediaHash = sha256.ComputeHash(decryptedMedia);
                    string decryptedMediaHashBase64 = Convert.ToBase64String(decryptedMediaHash);
                    if (decryptedMediaHashBase64 != mediaObject.encryption_metadata.plaintext_hash)
                    {
                        throw new Exception("SHA256 hash of decrypted media does not match plaintext_hash");
                    }
                }

                return decryptedMedia;
            }
        }
    }
}
