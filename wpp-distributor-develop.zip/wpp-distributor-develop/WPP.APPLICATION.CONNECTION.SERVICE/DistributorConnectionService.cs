﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.ENTITIES.DistributorMessage;
using WPP.ABSTRACTION.ENTITIES.Flows;
using WPP.ABSTRACTION.ENTITIES.MessageApplication;
using WPP.ABSTRACTION.ENTITIES.Olivia;
using WPP.ABSTRACTION.ENTITIES.Options;
using WPP.ABSTRACTION.LOGGER;
using WPP.APPLICATION.CONNECTION.SERVICE.RestConnectionService;

namespace WPP.APPLICATION.CONNECTION.SERVICE
{
    public class DistributorConnectionService : IDistributorConnectionService
    {
        private readonly ILoggerInfo _logger;
        private readonly IDistributorMessageConnectionService _connectionServiceHttp;
        public readonly DistributorMessageOptions _distributorEndpoint;
        public readonly ChatBotOliviaBxtConfigOptions oliviaBxTConfig;
        public DistributorConnectionService(ILoggerInfo logger, IConfiguration configuration, IOptions<DistributorMessageOptions> distributorEndpoint, IDistributorMessageConnectionService connectionServiceHttp, IOptions<ChatBotOliviaBxtConfigOptions> oliviaBxTConfig)
        {
            this._logger = logger;
            this._connectionServiceHttp = connectionServiceHttp;

            this._distributorEndpoint = distributorEndpoint.Value;
            this.oliviaBxTConfig = oliviaBxTConfig.Value;
        }

        public async Task<GenericResponse> SendChatBotMessage(MessageWhatsAppApplication _request)
        {
            GenericResponse _response = new();
            try
            {
                this._logger.Debug(string.Format("ENDPOINT: {0}", this._distributorEndpoint.urlChatBot + this._distributorEndpoint.methodChatBot));
                this._logger.Debug(string.Format(" REQUEST: {0}", JsonConvert.SerializeObject(_request)));
                _response = await this._connectionServiceHttp.PostAsync<GenericResponse>(this._distributorEndpoint.urlChatBot, this._distributorEndpoint.methodChatBot, _request, Authentication.None);
                this._logger.Debug(string.Format("RESPONSE: {0}", JsonConvert.SerializeObject(_response)));
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _response;
        }
        public async Task<GenericResponse> SendMessageSignalR(MessageWhatsAppApplication _request)
        {
            try
            {
                GenericResponse _response = new();
                this._logger.Debug(string.Format("ENDPOINT: {0}", this._distributorEndpoint.urlSignalR + this._distributorEndpoint.methodSignalR));
                this._logger.Debug(string.Format(" REQUEST: {0}", JsonConvert.SerializeObject(_request)));
                _response = await this._connectionServiceHttp.PostAsync<GenericResponse>(this._distributorEndpoint.urlSignalR, this._distributorEndpoint.methodSignalR, _request, Authentication.None);
                this._logger.Debug(string.Format("RESPONSE: {0}", JsonConvert.SerializeObject(_response)));
                return _response;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<OliviaResponse> SendChatBotOlivia(OliviaRequest _request, string _urlOlivia)
        {
            OliviaResponse _response = new();
            try
            {
                this._logger.Debug(string.Format("ENDPOINT: {0}", _urlOlivia));
                this._logger.Debug(string.Format(" REQUEST: {0}", JsonConvert.SerializeObject(_request)));
                _response = await this._connectionServiceHttp.PostAsync<OliviaResponse>(_urlOlivia, string.Empty, _request, Authentication.None);
                this._logger.Debug(string.Format("RESPONSE: {0}", JsonConvert.SerializeObject(_response)));
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _response;
        }

        public async Task<GenericResponse> SendChatBotGenesis(string _request, string _urlGenesis)
        {
            GenericResponse _response = new();
            try
            {
                this._logger.Debug(string.Format("ENDPOINT: {0}", _urlGenesis));
                this._logger.Debug(string.Format(" REQUEST: {0}", JsonConvert.SerializeObject(_request)));
                _response = await this._connectionServiceHttp.PostWebHookAsync<GenericResponse>(_urlGenesis, string.Empty, _request, Authentication.None);
                this._logger.Debug(string.Format("RESPONSE: {0}", JsonConvert.SerializeObject(_response)));
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _response;
        }

        public async Task<WppFlowResponse> SendFlowOlivia(WppFlowRequest _request, string _operation)
        {
            try
            {
                _logger.Debug(string.Format("[{0}] ENDPOINT: {1}", _operation, oliviaBxTConfig.Url + oliviaBxTConfig.MetodoFlowRekognition));
                _logger.Debug(string.Format("[{0}]  REQUEST: {1}", _operation, JsonConvert.SerializeObject(_request)));

                WppFlowResponse _response = await _connectionServiceHttp.PostAsync<WppFlowResponse>(oliviaBxTConfig.Url, oliviaBxTConfig.MetodoFlowRekognition, _request, Authentication.None);
                _logger.Debug(string.Format("[{0}] RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
                return _response;
            }
            catch (Exception ex)
            {
                _logger.Debug(string.Format("[{0}] ERROR: {1}", _operation, ex.Message));
                throw;
            }
        }

        public async Task<WppFlowResponse> SendFlowEncuestaOlivia(WppFlowRequest _request, string _operation)
        {
            try
            {
                _logger.Debug(string.Format("[{0}] ENDPOINT: {1}", _operation, oliviaBxTConfig.Url + oliviaBxTConfig.MetodoFlowEncuesta));
                _logger.Debug(string.Format("[{0}]  REQUEST: {1}", _operation, JsonConvert.SerializeObject(_request)));

                WppFlowResponse _response = await _connectionServiceHttp.PostAsync<WppFlowResponse>(oliviaBxTConfig.Url, oliviaBxTConfig.MetodoFlowEncuesta, _request, Authentication.None);
                _logger.Debug(string.Format("[{0}] RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
                return _response;
            }
            catch (Exception ex)
            {
                _logger.Debug(string.Format("[{0}] ERROR: {1}", _operation, ex.Message));
                throw;
            }
        }

        public async Task<WppFlowResponse> SendFlowAperturaCuentaNoCliente(WppFlowRequest _request, string _operation)
        {
            try
            {
                _logger.Debug(string.Format("[{0}] ENDPOINT: {1}", _operation, oliviaBxTConfig.Url + oliviaBxTConfig.MetodoFlowAperturaCuentaNoCliente));
                _logger.Debug(string.Format("[{0}]  REQUEST: {1}", _operation, JsonConvert.SerializeObject(_request)));

                WppFlowResponse _response = await _connectionServiceHttp.PostAsync<WppFlowResponse>(oliviaBxTConfig.Url, oliviaBxTConfig.MetodoFlowAperturaCuentaNoCliente, _request, Authentication.None);
                _logger.Debug(string.Format("[{0}] RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
                return _response;
            }
            catch (Exception ex)
            {
                _logger.Debug(string.Format("[{0}] ERROR: {1}", _operation, ex.Message));
                throw;
            }
        }

        public async Task<WppFlowResponse> SendFlowAperturaCuentaYaClienteConBM(WppFlowRequest _request, string _operation)
        {
            try
            {
                _logger.Debug(string.Format("[{0}] ENDPOINT: {1}", _operation, oliviaBxTConfig.Url + oliviaBxTConfig.MetodoFlowAperturaCuentaYaClienteConBM));
                _logger.Debug(string.Format("[{0}]  REQUEST: {1}", _operation, JsonConvert.SerializeObject(_request)));

                WppFlowResponse _response = await _connectionServiceHttp.PostAsync<WppFlowResponse>(oliviaBxTConfig.Url, oliviaBxTConfig.MetodoFlowAperturaCuentaYaClienteConBM, _request, Authentication.None);
                _logger.Debug(string.Format("[{0}] RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
                return _response;
            }
            catch (Exception ex)
            {
                _logger.Debug(string.Format("[{0}] ERROR: {1}", _operation, ex.Message));
                throw;
            }
        }

        public async Task<WppFlowResponse> SendFlowAperturaCuentaYaClienteSinBM(WppFlowRequest _request, string _operation)
        {
            try
            {
                _logger.Debug(string.Format("[{0}] ENDPOINT: {1}", _operation, oliviaBxTConfig.Url + oliviaBxTConfig.MetodoFlowAperturaCuentaYaClienteSinBM));
                _logger.Debug(string.Format("[{0}]  REQUEST: {1}", _operation, JsonConvert.SerializeObject(_request)));

                WppFlowResponse _response = await _connectionServiceHttp.PostAsync<WppFlowResponse>(oliviaBxTConfig.Url, oliviaBxTConfig.MetodoFlowAperturaCuentaYaClienteSinBM, _request, Authentication.None);
                _logger.Debug(string.Format("[{0}] RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
                return _response;
            }
            catch (Exception ex)
            {
                _logger.Debug(string.Format("[{0}] ERROR: {1}", _operation, ex.Message));
                throw;
            }
        }

        public async Task<WppFlowResponse> SendFlowValidacionIdentidad(WppFlowRequest _request, string _operation)
        {
            try
            {
                _logger.Debug(string.Format("[{0}] ENDPOINT: {1}", _operation, oliviaBxTConfig.Url + oliviaBxTConfig.MetodoFlowValidacionIdentidad));
                _logger.Debug(string.Format("[{0}]  REQUEST: {1}", _operation, JsonConvert.SerializeObject(_request)));

                WppFlowResponse _response = await _connectionServiceHttp.PostAsync<WppFlowResponse>(oliviaBxTConfig.Url, oliviaBxTConfig.MetodoFlowValidacionIdentidad, _request, Authentication.None);
                _logger.Debug(string.Format("[{0}] RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
                return _response;
            }
            catch (Exception ex)
            {
                _logger.Debug(string.Format("[{0}] ERROR: {1}", _operation, ex.Message));
                throw;
            }
        }

        public async Task<WppFlowResponse> SendFlowConsultaMovimientos(WppFlowRequest _request, string _operation)
        {
            try
            {
                _logger.Debug(string.Format("[{0}] ENDPOINT: {1}", _operation, oliviaBxTConfig.Url + oliviaBxTConfig.MetodoFlowConsultaMovimientos));
                _logger.Debug(string.Format("[{0}]  REQUEST: {1}", _operation, JsonConvert.SerializeObject(_request)));

                WppFlowResponse _response = await _connectionServiceHttp.PostAsync<WppFlowResponse>(oliviaBxTConfig.Url, oliviaBxTConfig.MetodoFlowConsultaMovimientos, _request, Authentication.None);
                _logger.Debug(string.Format("[{0}] RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
                return _response;
            }
            catch (Exception ex)
            {
                _logger.Debug(string.Format("[{0}] ERROR: {1}", _operation, ex.Message));
                throw;
            }
        }

        public async Task<GenericResponse> SendFlowGenesis(string _request, string _operation)
        {
            try
            {
                GenericResponse _response = new();
                this._logger.Debug(string.Format("[{0}] ENDPOINT: {1}", _operation, oliviaBxTConfig.UrlLynn));
                this._logger.Debug(string.Format("[{0}] REQUEST: {1}", _operation, JsonConvert.SerializeObject(_request)));
                _response = await this._connectionServiceHttp.PostWebHookAsync<GenericResponse>(oliviaBxTConfig.UrlLynn, string.Empty, _request, Authentication.None);
                this._logger.Debug(string.Format("[{0}] RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
                return _response;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
