﻿using Newtonsoft.Json;
using WPP.ABSTRACTION.ENTITIES.MessageApplication;
using WPP.ABSTRACTION.ENTITIES.MessageReception;
using WPP.APPLICATION.BUSSINESS.ManagerMessageConvert;
using WPP.APPLICATION.CONNECTION.DATABASE;
using WPP.APPLICATION.CONNECTION.SERVICE;
using WPP.APPLICATION.CONNECTION.SERVICE.Services;

namespace WPP.APPLICATION.BUSSINESS
{
    public class VerifyIncomingMessageBussiness : IVerifyIncomingMessageBussiness
    {
        private readonly IConnectionDistributorDataBase _connectionDatabase;
        private readonly IConnectionDataBaseBussiness _connectionDatabaseBussiness;
        private readonly IDistributorConnectionService _connectionService;
        private readonly IFileManager _fileManager;
        public VerifyIncomingMessageBussiness(IConnectionDistributorDataBase connectionDatabase, IConnectionDataBaseBussiness connectionDatabaseBussiness, IDistributorConnectionService connectionService, IFileManager fileManager)
        {
            this._connectionDatabase = connectionDatabase;
            this._connectionDatabaseBussiness = connectionDatabaseBussiness;
            this._connectionService = connectionService;
            this._fileManager = fileManager;
        }



        public MessageApplicationReceptionRequest VerifyMessageWhatsApp(MessageApplicationReceptionRequest _request)
        {
            try
            {
                // OBTENER EL ULTIMO MENSAJE DEL CELULAR ENTRANTE 
                LastMessageWhatsApp _responseLastMessage = this._connectionDatabaseBussiness.GetLastestMessage(_request.cellphone??string.Empty);
                // COMPLEMENTAR DATOS AL REQUEST INGRESADO 
                if (_responseLastMessage.firstChat)
                {
                    _request.user = "UsrBotWhatsapp";
                    _request.nameUser = "UsrBotWhatsapp";
                    _request.identifyChatBot = true;
                }
                else
                {
                    _request.user = string.IsNullOrEmpty(_responseLastMessage.user) ? "UsrBotWhatsapp" : _responseLastMessage.user;
                    _request.nameUser = string.IsNullOrEmpty(_responseLastMessage.user) ? "UsrBotWhatsapp" : _responseLastMessage.user;
                    _request.identifyChatBot = _responseLastMessage.whatsAppBot;
                }
                
                switch (_request.typeMessage)
                {
                    case "TEXT":
                        break;
                    case "IMAGE":
                    case "AUDIO":
                    case "VIDEO":
                    case "DOCUMENT":
                    case "STICKER":
                        _request.url = _fileManager.SaveFileAsync(MessageConvert.ConvertImageUrlToBase64(_request.url ?? string.Empty), _request.classMultimedia.ToUpper(), _request.typeMessage.ToUpper()).Result;
                break;
                    default:
                        break;
                }
                _request.messageId = this._connectionDatabase.InsertNewMessage(_request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _request;
        }

        public MessageApplicationReceptionRequest VerifyMessageWhatsAppOlivia(MessageApplicationReceptionRequest _request, string _usario)
        {
            try
            {
                _request.user = _usario;
                _request.nameUser = _usario;
                _request.identifyChatBot = true;
                switch (_request.typeMessage)
                {
                    case "TEXT":
                        break;
                    case "IMAGE":
                    case "AUDIO":
                    case "VIDEO":
                    case "DOCUMENT":
                    case "STICKER":
                        _request.url = _fileManager.SaveFileAsync(MessageConvert.ConvertImageUrlToBase64(_request.url ?? string.Empty), _request.classMultimedia.ToUpper(), _request.typeMessage.ToUpper()).Result;
                        break;
                    default:
                        break;
                }
                _request.messageId = this._connectionDatabase.InsertNewMessage(_request);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _request;
        }


    }
}
