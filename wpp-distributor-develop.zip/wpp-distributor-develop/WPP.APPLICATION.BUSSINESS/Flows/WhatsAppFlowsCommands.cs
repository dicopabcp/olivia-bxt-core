﻿using WPP.ABSTRACTION.LOGGER;
using WPP.APPLICATION.BUSSINESS.Commands;
using WPP.APPLICATION.BUSSINESS.Commands.Flows;
using WPP.APPLICATION.CONNECTION.SERVICE;
using WPP.APPLICATION.CONNECTION.SERVICE.Services;

namespace WPP.APPLICATION.BUSSINESS.Flows
{
    public class WhatsAppFlowsCommands
    {
        protected readonly ILoggerInfo _logger;
        protected readonly IFileManager _fileManager;
        protected readonly IDistributorConnectionService _oliviaBxtService;

        public WhatsAppFlowsCommands(ILoggerInfo logger, IFileManager fileManager, IDistributorConnectionService oliviaBxtService)
        {
            _logger = logger;
            _fileManager = fileManager;
            _oliviaBxtService = oliviaBxtService;
        }
        public FlowCommand GetFlowCommand(string command)
        {
            switch (command)
            {
                case "FlowRekognition":
                    return new RekognitionFlow(_logger, _oliviaBxtService, _fileManager);
                case "FlowEncuesta":
                    return new EncuestaFlow(_logger, _oliviaBxtService, _fileManager);
                case "FlowValidacionIdentidad":
                    return new ValidacionIdentidadFlow(_logger, _oliviaBxtService, _fileManager, "CSM_DATOS_CI");
                case "FlowValidacionIdentidadClave":
                    return new ValidacionIdentidadFlow(_logger, _oliviaBxtService, _fileManager, "CSM_LOGIN_CLAVE");
                case "FlowConsultaMovimientos":
                    return new ConsultaMovimientosFlow(_logger, _oliviaBxtService, _fileManager);
                default:
                    throw new NotImplementedException();
            }
        }
    }
}
