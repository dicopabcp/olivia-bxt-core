﻿using System.Security.Authentication;

namespace WPP.APPLICATION.BUSSINESS.ManagerMessageConvert
{
    public static class MessageConvert
    {
        public static string ConvertImageUrlToBase64(string _url)
        {
            try
            {
                HttpClientHandler httpHandler = new HttpClientHandler();
                httpHandler.SslProtocols = SslProtocols.Tls12;
                using (HttpClient client = new HttpClient(httpHandler))
                {
                    var bytes = client.GetByteArrayAsync(_url).Result;
                    return Convert.ToBase64String(bytes);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string GuardarArchivoAdjunto(string _path, string pathFile, string _url)
        {
            string Error = String.Empty;
            try
            {
                                
                if (!Directory.Exists(_path))
                {
                    Directory.CreateDirectory(_path);
                }
                String base64 = ConvertImageUrlToBase64(_url);
                File.WriteAllBytes(pathFile, Convert.FromBase64String(base64));
                

            }
            catch (Exception Ex)
            {
                Error = Ex.Message;
            }
            return Error;
        }



    }
}
