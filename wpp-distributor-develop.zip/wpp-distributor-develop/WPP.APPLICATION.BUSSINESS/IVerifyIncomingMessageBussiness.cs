﻿using WPP.ABSTRACTION.ENTITIES.MessageApplication;
using WPP.ABSTRACTION.ENTITIES.MessageReception;

namespace WPP.APPLICATION.BUSSINESS
{
    public interface IVerifyIncomingMessageBussiness
    {
        MessageApplicationReceptionRequest VerifyMessageWhatsApp(MessageApplicationReceptionRequest _request);
        MessageApplicationReceptionRequest VerifyMessageWhatsAppOlivia(MessageApplicationReceptionRequest _request, string _usario);
    }
}
