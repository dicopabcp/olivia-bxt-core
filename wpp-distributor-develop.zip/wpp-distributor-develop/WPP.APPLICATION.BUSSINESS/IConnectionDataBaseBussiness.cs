﻿using WPP.ABSTRACTION.ENTITIES.MessageApplication;

namespace WPP.APPLICATION.BUSSINESS
{
    public interface IConnectionDataBaseBussiness
    {
        LastMessageWhatsApp GetLastestMessage(string _cellphone);
    }
}
