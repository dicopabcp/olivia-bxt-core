﻿using System.Data;
using WPP.ABSTRACTION.ENTITIES.MessageApplication;
using WPP.APPLICATION.CONNECTION.DATABASE;

namespace WPP.APPLICATION.BUSSINESS
{
    public class ConnectionDataBaseBussiness : IConnectionDataBaseBussiness
    {
        private readonly IConnectionDistributorDataBase _connectionDataBase;
        public ConnectionDataBaseBussiness(IConnectionDistributorDataBase connectionDataBase) { this._connectionDataBase = connectionDataBase; }        
        public LastMessageWhatsApp GetLastestMessage(string _cellphone)
        {
            LastMessageWhatsApp _response = new();
            try
            {
                DataTable _data = this._connectionDataBase.GetLastestMessage(_cellphone);
                if (_data.Rows.Count > 0)
                {
                    _response.messageId = Convert.ToInt32(_data.Rows[0]["ID_CHAT"].ToString());
                    _response.codeClient = _data.Rows[0]["COD_CLIENTE"].ToString() ?? string.Empty;
                    _response.cellphone = _data.Rows[0]["CELULAR"].ToString() ?? string.Empty;
                    _response.whatsAppBot = Convert.ToInt32(_data.Rows[0]["WHATSAPP_BOT"].ToString()) == 1 ? true : false;
                    _response.user = _data.Rows[0]["USUARIO"].ToString() ?? string.Empty;
                    _response.nameUser = _data.Rows[0]["NOMBRE_USAURIO"].ToString() ?? string.Empty;
                    _response.json = _data.Rows[0]["JSON"].ToString() ?? string.Empty;
                    _response.campaign = _data.Rows[0]["CAMPAÑA"].ToString() ?? string.Empty;
                    _response.login = Convert.ToInt32(_data.Rows[0]["INICIO_SECION"].ToString());
                    _response.messageClass = _data.Rows[0]["CLASE_MENSAJE"].ToString() ?? string.Empty;
                    _response.message = _data.Rows[0]["MENSAJE"].ToString() ?? string.Empty;
                }
                else
                {
                    _response.firstChat = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _response;
        }


    }
}
