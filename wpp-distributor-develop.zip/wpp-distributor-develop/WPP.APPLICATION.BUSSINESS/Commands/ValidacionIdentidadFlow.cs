using System.Text.Json;
using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.ENTITIES.Flows;
using WPP.ABSTRACTION.LOGGER;
using WPP.APPLICATION.CONNECTION.SERVICE;
using WPP.APPLICATION.CONNECTION.SERVICE.Services;

namespace WPP.APPLICATION.BUSSINESS.Commands.Flows
{
    public class ValidacionIdentidadFlow : FlowCommand
    {
        protected readonly IFileManager _fileManager;
        protected readonly IDistributorConnectionService _oliviaBxtService;
        protected readonly string _screenInicial;

        // screenInicial: pantalla que responde el action=INIT; permite reutilizar este handler entre FlowValidacionIdentidad
        // (CSM_DATOS_CI, flujo completo) y FlowValidacionIdentidadClave (CSM_LOGIN_CLAVE, solo clave BM) sin duplicar codigo.
        public ValidacionIdentidadFlow(ILoggerInfo logger, IDistributorConnectionService oliviaBxtService, IFileManager fileManager, string screenInicial = "CSM_DATOS_CI") : base(logger)
        {
            _fileManager = fileManager;
            _oliviaBxtService = oliviaBxtService;
            _screenInicial = screenInicial;
        }

        public async override Task<GenericResponse<object>> Execute()
        {
            try
            {
                GenericResponse<object> _response = new();

                if (Action == "ping")
                {
                    _response.data = new { data = new { status = "active" } };
                }

                if (Action == "INIT")
                {
                    _response.data = new { screen = _screenInicial, data = new { error = new { message = string.Empty, visible = false } } };
                }

                if (Action == "data_exchange")
                {
                    switch (Screen)
                    {
                        case "CSM_DATOS_CI":
                            FlowCarnetIdentidad datosCi = JsonSerializer.Deserialize<FlowCarnetIdentidad>(DataFlow)!;

                            WppFlowIdcClienteCelular dataCi = new WppFlowIdcClienteCelular()
                            {
                                Carnet = datosCi.carnet.PadLeft(8, '0'),
                                Complemento = string.IsNullOrEmpty(datosCi.complemento) ? "00" : datosCi.complemento.ToUpper(),
                                Celular = datosCi.celular
                            };

                            WppFlowRequest requestCi = new WppFlowRequest()
                            {
                                SesionId = datosCi.wppSesionId,
                                Usuario = datosCi.celular,
                                Flow = Screen,
                                Data = JsonSerializer.Serialize(dataCi)
                            };

                            var responseCi = await _oliviaBxtService.SendFlowValidacionIdentidad(requestCi, Operacion);

                            if (responseCi.Success)
                            {
                                _response.data = new { screen = "CSM_SELFIE", data = new { celular = datosCi.celular, wppSesionId = datosCi.wppSesionId } };
                            }
                            else
                            {
                                string errorCi = responseCi.Mensaje;
                                if (responseCi.Expired)
                                {
                                    _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = errorCi } } } };
                                }
                                else if (responseCi.EnviarGenesys)
                                {
                                    _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = errorCi } } } };
                                    await _oliviaBxtService.SendFlowGenesis(string.Empty, Operacion);
                                }
                                else
                                {
                                    _response.data = new { screen = "CSM_DATOS_CI", data = new { celular = datosCi.celular, wppSesionId = datosCi.wppSesionId, error_message = errorCi } };
                                }
                            }
                            break;

                        case "CSM_SELFIE":
                            FlowSelfieFoto datosSelfie = JsonSerializer.Deserialize<FlowSelfieFoto>(DataFlow)!;
                            var fotoSelfie = datosSelfie.selfie_foto.FirstOrDefault()!;

                            WppFlowSelfi dataSelfi = new WppFlowSelfi()
                            {
                                Base64 = (await _fileManager.ConvertToBase64(fotoSelfie))
                            };

                            WppFlowRequest requestSelfie = new WppFlowRequest()
                            {
                                SesionId = datosSelfie.wppSesionId,
                                Usuario = datosSelfie.celular,
                                Flow = Screen,
                                Data = JsonSerializer.Serialize(dataSelfi)
                            };

                            var responseSelfie = await _oliviaBxtService.SendFlowValidacionIdentidad(requestSelfie, Operacion);

                            if (responseSelfie.Success)
                            {
                                _response.data = new { screen = "CSM_DOCUMENTO_ID", data = new { celular = datosSelfie.celular, wppSesionId = datosSelfie.wppSesionId } };
                            }
                            else
                            {
                                string errorSelfie = responseSelfie.Mensaje;
                                if (responseSelfie.Expired)
                                {
                                    _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = errorSelfie } } } };
                                }
                                else if (responseSelfie.EnviarGenesys)
                                {
                                    _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = errorSelfie } } } };
                                    await _oliviaBxtService.SendFlowGenesis(string.Empty, Operacion);
                                }
                                else
                                {
                                    _response.data = new { screen = "CSM_SELFIE", data = new { celular = datosSelfie.celular, wppSesionId = datosSelfie.wppSesionId, error_message = errorSelfie } };
                                }
                            }
                            break;

                        case "CSM_DOCUMENTO_ID":
                            FlowDocumentoFoto datosDocumento = JsonSerializer.Deserialize<FlowDocumentoFoto>(DataFlow)!;
                            var fotoDocumento = datosDocumento.documento_foto.FirstOrDefault()!;

                            WppFlowDocumentoId dataDocumento = new WppFlowDocumentoId()
                            {
                                Base64 = (await _fileManager.ConvertToBase64(fotoDocumento))
                            };

                            WppFlowRequest requestDocumento = new WppFlowRequest()
                            {
                                SesionId = datosDocumento.wppSesionId,
                                Usuario = datosDocumento.celular,
                                Flow = Screen,
                                Data = JsonSerializer.Serialize(dataDocumento)
                            };

                            var responseDocumento = await _oliviaBxtService.SendFlowValidacionIdentidad(requestDocumento, Operacion);

                            if (responseDocumento.Success)
                            {
                                _response.data = new { screen = "CSM_LOGIN_CLAVE", data = new { celular = datosDocumento.celular, wppSesionId = datosDocumento.wppSesionId } };
                            }
                            else
                            {
                                string errorDocumento = responseDocumento.Mensaje;
                                if (responseDocumento.Expired)
                                {
                                    _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = errorDocumento } } } };
                                }
                                else if (responseDocumento.EnviarGenesys)
                                {
                                    _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = errorDocumento } } } };
                                    await _oliviaBxtService.SendFlowGenesis(string.Empty, Operacion);
                                }
                                else
                                {
                                    _response.data = new { screen = "CSM_DOCUMENTO_ID", data = new { celular = datosDocumento.celular, wppSesionId = datosDocumento.wppSesionId, error_message = errorDocumento } };
                                }
                            }
                            break;

                        case "CSM_LOGIN_CLAVE":
                            FlowClaveWhatsapp datosClave = JsonSerializer.Deserialize<FlowClaveWhatsapp>(DataFlow)!;

                            WppFlowValidarClaveBm dataClave = new WppFlowValidarClaveBm()
                            {
                                ClaveBm = datosClave.clave_whatsapp
                            };

                            WppFlowRequest requestClave = new WppFlowRequest()
                            {
                                SesionId = datosClave.wppSesionId,
                                Usuario = datosClave.celular,
                                Flow = Screen,
                                Data = JsonSerializer.Serialize(dataClave)
                            };

                            var responseClave = await _oliviaBxtService.SendFlowValidacionIdentidad(requestClave, Operacion);

                            if (responseClave.Success)
                            {
                                _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = string.Empty } } } };
                            }
                            else
                            {
                                string errorClave = responseClave.Mensaje;
                                if (responseClave.Expired)
                                {
                                    _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = errorClave } } } };
                                }
                                else if (responseClave.EnviarGenesys)
                                {
                                    _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = errorClave } } } };
                                    await _oliviaBxtService.SendFlowGenesis(string.Empty, Operacion);
                                }
                                else
                                {
                                    _response.data = new { screen = "CSM_LOGIN_CLAVE", data = new { celular = datosClave.celular, wppSesionId = datosClave.wppSesionId, error_message = errorClave } };
                                }
                            }
                            break;

                        default:
                            _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = "Lo sentimos 😔, ocurrio un error desconocido." } } } };
                            break;
                    }
                }
                _response.success = true;
                _response.code = "200";
                return _response;
            }
            catch (Exception ex)
            {
                this.logger.Debug(string.Format("[{0}] ERROR: {1}", Operacion, ex.Message));
                throw;
            }
        }
    }
}
