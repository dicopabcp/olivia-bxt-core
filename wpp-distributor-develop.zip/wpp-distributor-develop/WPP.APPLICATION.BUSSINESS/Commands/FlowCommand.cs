﻿using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.LOGGER;

namespace WPP.APPLICATION.BUSSINESS.Commands
{
    public abstract class FlowCommand
    {
        protected readonly ILoggerInfo logger;

        public string Operacion { get; set; } = string.Empty;

        public string Action { get; set; } = string.Empty;

        public string Screen { get; set; } = string.Empty;

        public string DataFlow { get; set; } = string.Empty;

        public string FlowToken { get; set; } = string.Empty;

        public FlowCommand(ILoggerInfo logger)
        {
            this.logger = logger;
        }

        public abstract Task<GenericResponse<object>> Execute();
    }
}
