using Newtonsoft.Json;
using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.ENTITIES.Flows;
using WPP.ABSTRACTION.LOGGER;
using WPP.APPLICATION.CONNECTION.SERVICE;
using WPP.APPLICATION.CONNECTION.SERVICE.Services;

namespace WPP.APPLICATION.BUSSINESS.Commands.Flows
{
    public class ConsultaMovimientosFlow : FlowCommand
    {
        protected readonly IFileManager _fileManager;
        protected readonly IDistributorConnectionService _oliviaBxtService;

        public ConsultaMovimientosFlow(ILoggerInfo logger, IDistributorConnectionService oliviaBxtService, IFileManager fileManager) : base(logger)
        {
            _fileManager = fileManager;
            _oliviaBxtService = oliviaBxtService;
        }

        public async override Task<GenericResponse<object>> Execute()
        {
            try
            {
                GenericResponse<object> _response = new();

                if (Action == "ping")
                {
                    _response.data = new { data = new { status = "active" } };
                }

                if (Action == "INIT")
                {
                    _response.data = new { screen = "CSM_OTP_CORREO", data = new { correo_enmascarado = string.Empty, celular = string.Empty, wppSesionId = string.Empty, error = new { message = string.Empty, visible = false } } };
                }

                if (Action == "data_exchange" || Action == "complete")
                {
                    switch (Screen)
                    {
                        case "CSM_OTP_CORREO":
                            FlowOtpIngresado datosOtp = System.Text.Json.JsonSerializer.Deserialize<FlowOtpIngresado>(DataFlow)!;

                            if (datosOtp.accion == "reenviar_otp")
                            {
                                // Pendiente: el reenvio real de OTP requiere exponer OtpGenerar para este Flow en olivia-bxt-core.
                                _response.data = new { screen = "CSM_OTP_CORREO", data = new { correo_enmascarado = string.Empty, celular = datosOtp.celular, wppSesionId = datosOtp.wppSesionId } };
                                break;
                            }

                            WppFlowOtpCorreo dataOtp = new WppFlowOtpCorreo() { Otp = datosOtp.otp };

                            WppFlowRequest requestOtp = new WppFlowRequest()
                            {
                                SesionId = datosOtp.wppSesionId,
                                Usuario = datosOtp.celular,
                                Flow = Screen,
                                Data = System.Text.Json.JsonSerializer.Serialize(dataOtp)
                            };

                            var responseOtp = await _oliviaBxtService.SendFlowConsultaMovimientos(requestOtp, Operacion);

                            if (responseOtp.Success)
                            {
                                // Pendiente: WppFlowService (caso CSM_OTP_CORREO) aun no llama a GetCuentas para poblar esta lista.
                                _response.data = new { screen = "CSM_ELEGIR_CUENTA", data = new { all_cuentas = Array.Empty<object>(), celular = datosOtp.celular, wppSesionId = datosOtp.wppSesionId } };
                            }
                            else
                            {
                                string errorOtp = responseOtp.Mensaje;
                                if (responseOtp.Expired)
                                {
                                    _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = errorOtp } } } };
                                }
                                else if (responseOtp.EnviarGenesys)
                                {
                                    _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = errorOtp } } } };
                                    await _oliviaBxtService.SendFlowGenesis(string.Empty, Operacion);
                                }
                                else
                                {
                                    _response.data = new { screen = "CSM_OTP_CORREO", data = new { correo_enmascarado = string.Empty, celular = datosOtp.celular, wppSesionId = datosOtp.wppSesionId, error_message = errorOtp } };
                                }
                            }
                            break;

                        case "CSM_ELEGIR_CUENTA":
                            FlowCuentaElegida datosCuenta = System.Text.Json.JsonSerializer.Deserialize<FlowCuentaElegida>(DataFlow)!;

                            WppFlowCuentaSeleccionada dataCuenta = new WppFlowCuentaSeleccionada() { CuentaReferencial = datosCuenta.cuenta };

                            WppFlowRequest requestCuenta = new WppFlowRequest()
                            {
                                SesionId = datosCuenta.wppSesionId,
                                Usuario = datosCuenta.celular,
                                Flow = Screen,
                                Data = System.Text.Json.JsonSerializer.Serialize(dataCuenta)
                            };

                            var responseCuenta = await _oliviaBxtService.SendFlowConsultaMovimientos(requestCuenta, Operacion);

                            if (responseCuenta.Success)
                            {
                                WppFlowSaldoConsultado saldo = JsonConvert.DeserializeObject<WppFlowSaldoConsultado>(JsonConvert.SerializeObject(responseCuenta.Data)) ?? new WppFlowSaldoConsultado();

                                _response.data = new
                                {
                                    screen = "CSM_DETALLE_SALDO",
                                    data = new
                                    {
                                        // Pendiente: "nombre_cuenta" se muestra con el codigo de cuenta hasta que el backend
                                        // devuelva el catalogo de cuentas (title/description) junto con all_cuentas.
                                        nombre_cuenta = datosCuenta.cuenta,
                                        numero_cuenta = datosCuenta.cuenta,
                                        saldo_disponible = string.Format("{0} {1:N2}", saldo.Moneda, saldo.Saldo),
                                        celular = datosCuenta.celular,
                                        wppSesionId = datosCuenta.wppSesionId
                                    }
                                };
                            }
                            else
                            {
                                string errorCuenta = responseCuenta.Mensaje;
                                if (responseCuenta.Expired)
                                {
                                    _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = errorCuenta } } } };
                                }
                                else if (responseCuenta.EnviarGenesys)
                                {
                                    _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = errorCuenta } } } };
                                    await _oliviaBxtService.SendFlowGenesis(string.Empty, Operacion);
                                }
                                else
                                {
                                    _response.data = new { screen = "CSM_ELEGIR_CUENTA", data = new { all_cuentas = Array.Empty<object>(), celular = datosCuenta.celular, wppSesionId = datosCuenta.wppSesionId, error_message = errorCuenta } };
                                }
                            }
                            break;

                        case "CSM_DETALLE_SALDO":
                            FlowNumeroCuenta datosDetalle = System.Text.Json.JsonSerializer.Deserialize<FlowNumeroCuenta>(DataFlow)!;

                            WppFlowRequest requestDetalle = new WppFlowRequest()
                            {
                                SesionId = datosDetalle.wppSesionId,
                                Usuario = datosDetalle.celular,
                                Flow = Screen,
                                Data = System.Text.Json.JsonSerializer.Serialize(new { numero_cuenta = datosDetalle.numero_cuenta })
                            };

                            var responseDetalle = await _oliviaBxtService.SendFlowConsultaMovimientos(requestDetalle, Operacion);

                            if (responseDetalle.Success)
                            {
                                // Pendiente: WppFlowService (caso CSM_DETALLE_SALDO) aun no llama a GetMovimientos para poblar
                                // esta lista; hoy ese fetch esta implementado (con alcance incorrecto) en el caso CSM_ELEGIR_MOVIMIENTO.
                                _response.data = new { screen = "CSM_ELEGIR_MOVIMIENTO", data = new { all_movimientos = Array.Empty<object>(), celular = datosDetalle.celular, wppSesionId = datosDetalle.wppSesionId } };
                            }
                            else
                            {
                                string errorDetalle = responseDetalle.Mensaje;
                                _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = errorDetalle } } } };
                                if (responseDetalle.EnviarGenesys)
                                {
                                    await _oliviaBxtService.SendFlowGenesis(string.Empty, Operacion);
                                }
                            }
                            break;

                        case "CSM_ELEGIR_MOVIMIENTO":
                            FlowMovimientoElegido datosMovimiento = System.Text.Json.JsonSerializer.Deserialize<FlowMovimientoElegido>(DataFlow)!;

                            WppFlowRequest requestMovimiento = new WppFlowRequest()
                            {
                                SesionId = datosMovimiento.wppSesionId,
                                Usuario = datosMovimiento.celular,
                                Flow = Screen,
                                Data = System.Text.Json.JsonSerializer.Serialize(new { movimiento = datosMovimiento.movimiento })
                            };

                            var responseMovimiento = await _oliviaBxtService.SendFlowConsultaMovimientos(requestMovimiento, Operacion);

                            if (responseMovimiento.Success)
                            {
                                // Pendiente: WppFlowService (caso CSM_ELEGIR_MOVIMIENTO) devuelve hoy la lista completa de
                                // movimientos en vez del detalle del movimiento elegido; se toma el primero como mejor esfuerzo.
                                List<WppFlowMovimientoConsultado> movimientos = JsonConvert.DeserializeObject<List<WppFlowMovimientoConsultado>>(JsonConvert.SerializeObject(responseMovimiento.Data)) ?? new();
                                WppFlowMovimientoConsultado movimiento = movimientos.FirstOrDefault() ?? new WppFlowMovimientoConsultado();

                                _response.data = new
                                {
                                    screen = "CSM_DETALLE_MOVIMIENTO",
                                    data = new
                                    {
                                        fecha = movimiento.Fecha,
                                        tipo = movimiento.Glosa,
                                        monto = movimiento.Monto.ToString("N2")
                                    }
                                };
                            }
                            else
                            {
                                string errorMovimiento = responseMovimiento.Mensaje;
                                _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = errorMovimiento } } } };
                                if (responseMovimiento.EnviarGenesys)
                                {
                                    await _oliviaBxtService.SendFlowGenesis(string.Empty, Operacion);
                                }
                            }
                            break;

                        case "CSM_DETALLE_MOVIMIENTO":
                        case "CSM_COMPARTIR_DATOS":
                            // Pantallas de cierre ("complete" en el Flow JSON): no llevan celular/wppSesionId en su payload,
                            // por lo que no requieren llamada adicional al backend.
                            _response.data = new { };
                            break;

                        default:
                            _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = "Lo sentimos 😔, ocurrio un error desconocido." } } } };
                            break;
                    }
                }
                _response.success = true;
                _response.code = "200";
                return _response;
            }
            catch (Exception ex)
            {
                this.logger.Debug(string.Format("[{0}] ERROR: {1}", Operacion, ex.Message));
                throw;
            }
        }
    }
}
