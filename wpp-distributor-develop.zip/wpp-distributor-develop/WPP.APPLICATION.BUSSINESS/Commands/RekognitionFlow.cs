﻿using System.Text.Json;
using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.ENTITIES.Flows;
using WPP.ABSTRACTION.LOGGER;
using WPP.APPLICATION.CONNECTION.SERVICE;
using WPP.APPLICATION.CONNECTION.SERVICE.Services;

namespace WPP.APPLICATION.BUSSINESS.Commands.Flows
{
    public class RekognitionFlow : FlowCommand
    {
        protected readonly IFileManager _fileManager;
        protected readonly IDistributorConnectionService _oliviaBxtService;

        public RekognitionFlow(ILoggerInfo logger, IDistributorConnectionService oliviaBxtService, IFileManager fileManager) : base(logger)
        {
            _fileManager = fileManager;
            _oliviaBxtService = oliviaBxtService;
        }

        public async override Task<GenericResponse<object>> Execute()
        {
            try
            {
                GenericResponse<object> _response = new();

                if (Action == "ping")
                {
                    _response.data = new { data = new { status = "active" } };
                }

                if (Action == "INIT")
                {
                    _response.data = new { screen = "REKOGNITION_INIT", data = new { error = new { message = string.Empty, visible = false } } };
                }

                if (Action == "data_exchange")
                {
                    switch (Screen)
                    {
                        case "REKOGNITION_INIT":
                            FlowCarnetIdentidad dataCarnetIdentidad = JsonSerializer.Deserialize<FlowCarnetIdentidad>(DataFlow)!;

                            WppFlowIdcCliente data = new WppFlowIdcCliente()
                            {
                                Carnet = dataCarnetIdentidad.carnet.PadLeft(8, '0'),
                                Complemento = string.IsNullOrEmpty(dataCarnetIdentidad.complemento) ? "00" : dataCarnetIdentidad.complemento.ToUpper(),
                            };

                            WppFlowRequest request = new WppFlowRequest()
                            {
                                SesionId = dataCarnetIdentidad.wppSesionId,
                                Usuario = dataCarnetIdentidad.celular,
                                Flow = Screen,
                                Data = JsonSerializer.Serialize(data)
                            };

                            var response = await _oliviaBxtService.SendFlowOlivia(request, Operacion);

                            if (response.Success)
                            {
                                _response.data = new
                                {
                                    screen = "INSTRUCCIONES_SELFIE",
                                    data = new
                                    {
                                    }
                                };
                            }
                            else
                            {
                                string error = response.Mensaje;
                                if (response.Expired)
                                {
                                    _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = error } } } };
                                }
                                else
                                {
                                    if (response.EnviarGenesys)
                                    {
                                        _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = error } } } };
                                        await _oliviaBxtService.SendFlowGenesis(string.Empty, Operacion);
                                    }
                                    else
                                    {
                                        _response.data = new { screen = "REKOGNITION_INIT", data = new { error_message = error } };
                                    }
                                }
                            }
                            break;

                        case "SELFIE":
                            var flowImage = JsonSerializer.Deserialize<FlowImage>(DataFlow)!;
                            var fotoSelfie = flowImage.imagen.FirstOrDefault()!;

                            WppFlowSelfi dataSelfi = new WppFlowSelfi()
                            {
                                Base64 = (await _fileManager.ConvertToBase64(fotoSelfie))
                            };

                            WppFlowRequest requestRekog = new WppFlowRequest()
                            {
                                SesionId = flowImage.wppSesionId,
                                Usuario = flowImage.celular,
                                Flow = Screen,
                                Data = JsonSerializer.Serialize(dataSelfi)
                            };

                            var responseRekog = await _oliviaBxtService.SendFlowOlivia(requestRekog, Operacion);

                            if (responseRekog.Success)
                            {
                                _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = "Lo sentimos 😔, ocurrio un error desconocido." } } } };
                            }
                            else
                            {
                                string error = responseRekog.Mensaje;
                                if (responseRekog.Expired)
                                {
                                    _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = error } } } };
                                }
                                else
                                {
                                    if (responseRekog.EnviarGenesys)
                                    {
                                        _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = error } } } };
                                        await _oliviaBxtService.SendFlowGenesis(string.Empty, Operacion);
                                    }
                                    else
                                    {
                                        _response.data = new { screen = "SELFIE", data = new { error_message = error } };
                                    }
                                }
                            }
                            break;
                        default:
                            _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = "Lo sentimos 😔, ocurrio un error desconocido." } } } };
                            break;
                    }
                }
                _response.success = true;
                _response.code = "200";
                return _response;
            }
            catch (Exception ex)
            {
                this.logger.Debug(string.Format("[{0}] ERROR: {1}", Operacion, ex.Message));
                throw;
            }
        }
    }
}
