﻿using System.Text.Json;
using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.ENTITIES.Flows;
using WPP.ABSTRACTION.LOGGER;
using WPP.APPLICATION.CONNECTION.SERVICE;
using WPP.APPLICATION.CONNECTION.SERVICE.Services;

namespace WPP.APPLICATION.BUSSINESS.Commands.Flows
{
    public class EncuestaFlow : FlowCommand
    {
        protected readonly IFileManager _fileManager;
        protected readonly IDistributorConnectionService _oliviaBxtService;

        public EncuestaFlow(ILoggerInfo logger, IDistributorConnectionService oliviaBxtService, IFileManager fileManager) : base(logger)
        {
            _fileManager = fileManager;
            _oliviaBxtService = oliviaBxtService;
        }

        public async override Task<GenericResponse<object>> Execute()
        {
            try
            {
                GenericResponse<object> _response = new();

                if (Action == "ping")
                {
                    _response.data = new { data = new { status = "active" } };
                }

                if (Action == "INIT")
                {
                    _response.data = new { screen = "SURVEY_INIT", data = new { error = new { message = string.Empty, visible = false } } };
                }

                if (Action == "data_exchange")
                {
                    switch (Screen)
                    {
                        case "SURVEY_INIT":
                            FlowEncuesta data = JsonSerializer.Deserialize<FlowEncuesta>(DataFlow)!;

                            WppFlowRequest request = new WppFlowRequest()
                            {
                                SesionId = data.wppSesionId,
                                Usuario = data.celular,
                                Flow = Screen,
                                Data = JsonSerializer.Serialize(data)
                            };

                            var response = await _oliviaBxtService.SendFlowEncuestaOlivia(request, Operacion);

                            if (response.Success)
                            {
                                _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = response.Mensaje } } } };
                            }
                            else
                            {
                                if (response.Expired)
                                {
                                    _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = response.Mensaje } } } };
                                }
                                else
                                {
                                    _response.data = new { screen = "SURVEY_INIT", data = new { error_message = response.Mensaje } };
                                }
                            }

                            break;
                        default:
                            _response.data = new { screen = "SUCCESS", data = new { extension_message_response = new { @params = new { message = "Lo sentimos 😔, ocurrio un error desconocido." } } } };
                            break;
                    }
                }
                _response.success = true;
                _response.code = "200";
                return _response;
            }
            catch (Exception ex)
            {
                this.logger.Debug(string.Format("[{0}] ERROR: {1}", Operacion, ex.Message));
                throw;
            }
        }
    }
}
