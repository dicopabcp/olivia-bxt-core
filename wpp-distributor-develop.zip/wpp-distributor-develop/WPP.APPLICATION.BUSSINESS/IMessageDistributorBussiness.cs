﻿using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.ENTITIES.MessageApplication;

namespace WPP.APPLICATION.BUSSINESS
{
    public interface IMessageDistributorBussiness
    {
        Task<GenericResponse> MessageWhatsAppDistributor(MessageApplicationReceptionRequest _request, string _operation);
        
        Task<GenericResponse<string>> MessageWhatsAppFlowDistributor(EndpointPayload _request, string flowName, string _operation);
    }
}
