﻿using Newtonsoft.Json;
using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.ENTITIES.MessageApplication;
using WPP.ABSTRACTION.ENTITIES.MessageReception;
using WPP.ABSTRACTION.ENTITIES.Olivia;
using WPP.ABSTRACTION.LOGGER;
using WPP.APPLICATION.BUSSINESS.Flows;
using WPP.APPLICATION.CONNECTION.DATABASE;
using WPP.APPLICATION.CONNECTION.SERVICE;
using WPP.APPLICATION.CONNECTION.SERVICE.Interfaces;

namespace WPP.APPLICATION.BUSSINESS
{
    public class MessageDistributorBussiness : IMessageDistributorBussiness
    {
        private readonly ILoggerInfo _logger;
        private readonly IConnectionDistributorDataBase _connectionDatabase;
        private readonly IDistributorConnectionService _connectionService;
        private readonly IDataFlowManager _dataFlowManager;
        private readonly IVerifyIncomingMessageBussiness _verifyBussiness;
        private readonly WhatsAppFlowsCommands _flowFactory;
        public MessageDistributorBussiness(ILoggerInfo logger, WhatsAppFlowsCommands flowFactory, IConnectionDistributorDataBase connectionDatabase, IDistributorConnectionService connectionService, IVerifyIncomingMessageBussiness verifyBussiness, IDataFlowManager dataFlowManager)
        {
            this._logger = logger;
            this._connectionDatabase = connectionDatabase;
            this._connectionService = connectionService;
            this._verifyBussiness = verifyBussiness;
            this._dataFlowManager = dataFlowManager;
            this._flowFactory = flowFactory;
        }

        public async Task<GenericResponse> MessageWhatsAppDistributor(MessageApplicationReceptionRequest _request, string _operation)
        {
            try
            {
                List<Tags> _tagConfig = this._connectionDatabase.GetTagConfig("CELLPHONE.OLIVIA");

                var cellphoneOlivia = (from row in _tagConfig where row.valor == _request.destinationAccount select row).ToList();

                if (cellphoneOlivia.Count > 0)
                {
                    MessageReceptionGupShupRequest _requestGupShup = new MessageReceptionGupShupRequest();
                    _requestGupShup = JsonConvert.DeserializeObject<MessageReceptionGupShupRequest>(_request.json);

                    _request = this._verifyBussiness.VerifyMessageWhatsAppOlivia(_request, "OLIVIA");


                    #region parametros Olivia
                    string urlGenesis = this._connectionDatabase.GetTagConfig("URL.GENESIS")[0].valor.ToString();
                    string urlOlivia = this._connectionDatabase.GetTagConfig("URL.OLIVIA")[0].valor.ToString();
                    string CellphoneTest = this._connectionDatabase.GetTagConfig("CELLPHONE.TEST.DESA")[0].valor.ToString();
                    string horaInicioOlivia = this._connectionDatabase.GetTagConfig("HORA.INICIO.OLIVIA")[0].valor.ToString();
                    string horaFinOlivia = this._connectionDatabase.GetTagConfig("HORA.FIN.OLIVIA")[0].valor.ToString();
                    string messgeOliviaGenesis = this._connectionDatabase.GetTagConfig("MESSAGE.OLIVIA.GENESIS")[0].valor.ToString();

                    DateTime _horaInicioOlivia = Convert.ToDateTime(horaInicioOlivia);
                    DateTime _horaFinOlivia = Convert.ToDateTime(horaFinOlivia);
                    #endregion

                    if ((DateTime.Now.TimeOfDay >= _horaInicioOlivia.TimeOfDay) && (DateTime.Now.TimeOfDay <= _horaFinOlivia.TimeOfDay))
                    {

                        OliviaRequest _requestOlivia = new OliviaRequest();
                        OliviaResponse _responseOlivia = new OliviaResponse();

                        if (CellphoneTest.Equals("OFF"))
                        {
                            List<string> cellphone_test = this._connectionDatabase.GetCellphoneTest();
                            var filtroCelular = (from row in cellphone_test where row == _request.cellphone select row).ToList();

                            if (filtroCelular.Count == 0)
                                return await this._connectionService.SendChatBotGenesis(_request.json, urlGenesis);


                            _requestOlivia.mensaje = _request.message;
                            _requestOlivia.usuario = _request.cellphone;
                            _responseOlivia = await this._connectionService.SendChatBotOlivia(_requestOlivia, urlOlivia);

                            if (_responseOlivia.enviarGenesys)
                            {
                                _requestGupShup.payload.payload.text = _responseOlivia.respuesta == "PRIMERO" ? messgeOliviaGenesis : _requestGupShup.payload.payload.text;

                                return await this._connectionService.SendChatBotGenesis(_request.json, urlGenesis);
                            }

                            GenericResponse _response = new GenericResponse()
                            {
                                message = "processing complete",
                                code = "200",
                                success = true

                            };
                            return _response;


                        }
                        else
                        {

                            _requestOlivia.mensaje = _request.message;
                            _requestOlivia.usuario = _request.cellphone;

                            _responseOlivia = await this._connectionService.SendChatBotOlivia(_requestOlivia, urlOlivia);

                            if (_responseOlivia.enviarGenesys)
                            {
                                _requestGupShup.payload.payload.text = _responseOlivia.respuesta == "PRIMERO" ? messgeOliviaGenesis : _requestGupShup.payload.payload.text;
                                return await this._connectionService.SendChatBotGenesis(_request.json, urlGenesis);
                            }

                            GenericResponse _response = new GenericResponse()
                            {
                                message = "processing complete",
                                code = "200",
                                success = true

                            };
                            return _response;

                        }

                    }
                    else
                    {


                        return await this._connectionService.SendChatBotGenesis(_request.json, urlGenesis);

                    }

                }
                else
                {

                    MessageWhatsAppApplication _sendMessageDistribution = new();
                    _request = this._verifyBussiness.VerifyMessageWhatsApp(_request);

                    _sendMessageDistribution.messageId = _request.messageId ?? 0;
                    _sendMessageDistribution.message = _request.message ?? string.Empty;
                    _sendMessageDistribution.typeMessage = _request.typeMessage ?? string.Empty;
                    _sendMessageDistribution.cellphone = _request.cellphone ?? string.Empty;
                    _sendMessageDistribution.multimediaUrl = _request.url ?? string.Empty;
                    _sendMessageDistribution.typeMultimediaUrl = _request.classMultimedia ?? string.Empty;
                    _sendMessageDistribution.destinationAccount = _request.destinationAccount ?? string.Empty;
                    if (_request.identifyChatBot)
                    {
                        return await this._connectionService.SendChatBotMessage(_sendMessageDistribution);
                    }
                    else
                    {
                        return await this._connectionService.SendMessageSignalR(_sendMessageDistribution);
                    }
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<GenericResponse<string>> MessageWhatsAppFlowDistributor(EndpointPayload _request, string flowName, string _operation)
        {
            GenericResponse<string> response = new GenericResponse<string>();
            var decrypted = _dataFlowManager.DecryptRequest(_request.encrypted_aes_key, _request.encrypted_flow_data, _request.initial_vector);
            string action = decrypted.decryptedBody.GetProperty("action").GetString();
            string screen = string.Empty, dataFlow = string.Empty, flowToken = string.Empty;

            if (action != "ping" && action != "INIT")
            {
                flowToken = decrypted.decryptedBody.GetProperty("flow_token").GetString();
                screen = decrypted.decryptedBody.GetProperty("screen").GetString();
                dataFlow = decrypted.decryptedBody.GetProperty("data").ToString();
            }

            this._logger.Debug(string.Format("[{0}] ACTION: {1} SCREEN: {2} DATAFLOW: {3}", _operation, action, screen, dataFlow));
            var flow = _flowFactory.GetFlowCommand(flowName);
            flow.Action = action;
            flow.Screen = screen;
            flow.DataFlow = dataFlow;
            flow.FlowToken = flowToken;
            flow.Operacion = _operation;
            GenericResponse<object> responseFlow = await flow.Execute();
            this._logger.Debug(string.Format("[{0}] RESPONSE: {1}", _operation, JsonConvert.SerializeObject(responseFlow)));
            response.data = _dataFlowManager.EncryptResponse(responseFlow.data, decrypted.aesKeyBytes, decrypted.initialVectorBytes);
            response.success = responseFlow.success;
            response.code = responseFlow.code;
            response.message = responseFlow.message;
            return response;
        }
    }
}
