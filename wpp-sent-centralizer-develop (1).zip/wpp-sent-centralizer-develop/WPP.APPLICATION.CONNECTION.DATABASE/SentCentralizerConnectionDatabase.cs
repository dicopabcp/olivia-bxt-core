﻿using System.Data;
using System.Data.SqlClient;
using WPP.ABSTRACTION.DATAACCESS;
using WPP.ABSTRACTION.ENTITIES.MessageApplication;

namespace WPP.APPLICATION.CONNECTION.DATABASE
{
    public interface ISentCentralizerConnectionDatabase
    {
        int InsertNewMessage(MessageWhatsAppModel _messageWhatsApp);
        string GetValueByParameter(string _parameterName);
    }
    public class SentCentralizerConnectionDatabase : ISentCentralizerConnectionDatabase
    {
        public readonly IDataAccess _dataAccess;
        private static readonly string DATABASE_CONNECTION_NAME = "SENT.CENTRALIZER";
        public SentCentralizerConnectionDatabase(IDataAccess dataAccess)
        {
            this._dataAccess = dataAccess;
        }

        public int InsertNewMessage(MessageWhatsAppModel _messageWhatsApp)
        {
            // ADECUACION INSERT MESSAGE
            try
            {
                List<SqlParameter> _parameter = new();
                _parameter.Add(new SqlParameter("@COD_CLIENTE", _messageWhatsApp.codeClient));
                //_parameter.Add(new SqlParameter("@NUMERO_ORIGEN", _messageWhatsApp.cellphone));
                _parameter.Add(new SqlParameter("@CELULAR", _messageWhatsApp.cellphone));
                _parameter.Add(new SqlParameter("@MENSAJE", _messageWhatsApp.message));
                _parameter.Add(new SqlParameter("@TIPO_MENSAJE", _messageWhatsApp.typeMessage));
                _parameter.Add(new SqlParameter("@COD_TIPO_MENSAJE", _messageWhatsApp.codeTypeMessage));
                _parameter.Add(new SqlParameter("@JSON", _messageWhatsApp.jsonClient));
                _parameter.Add(new SqlParameter("@USUARIO", _messageWhatsApp.user));
                _parameter.Add(new SqlParameter("@NOMBRE_USAURIO", _messageWhatsApp.nameUser));
                _parameter.Add(new SqlParameter("@WHATSAPP_BOT", _messageWhatsApp.whatsAppBot));
                _parameter.Add(new SqlParameter("@CAMPAÑA", _messageWhatsApp.campaign));
                _parameter.Add(new SqlParameter("@INICIOSECION", _messageWhatsApp.login));
                _parameter.Add(new SqlParameter("@CLASEMENSAJE", _messageWhatsApp.messageClass));
                _parameter.Add(new SqlParameter("@URLMULTIMEDIA", _messageWhatsApp.multimedia));
                _parameter.Add(new SqlParameter("@FECHAENTREGADO", _messageWhatsApp.dateDelivered));
                _parameter.Add(new SqlParameter("@FECHALEIDO", _messageWhatsApp.dateRead));
                _parameter.Add(new SqlParameter() { ParameterName = "@MESSAGE_ID", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output, Value = _messageWhatsApp.messageId });
                this._dataAccess.ExecuteStoredProcedure(DATABASE_CONNECTION_NAME, "[wpp].[WPP_INSERT_NEW_MESSAGE]", ref _parameter);
                return Convert.ToInt32(_parameter.First(x => x.Direction == ParameterDirection.Output && x.ParameterName.Equals("@MESSAGE_ID")).Value);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public string GetValueByParameter(string _parameterName)
        {
            try
            {
                List<SqlParameter> _parameter = new();
                _parameter.Add(new SqlParameter("TAG", _parameterName));
                DataTable _response = this._dataAccess.SelectStoredProcedure(DATABASE_CONNECTION_NAME, "[wpp].[WPP_GET_PARAMETROS]", _parameter);

                string valorTag = _response.AsEnumerable()
                                           .Select(row => row.Field<string>("VALOR_TAG"))
                                           .FirstOrDefault() ?? string.Empty;

                return valorTag;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}