﻿
namespace WPP.ABSTRACTION.SECRYPT
{
    public class SecryptOptions
    {
        public string semilla { get; set; } = String.Empty;
    }
}
