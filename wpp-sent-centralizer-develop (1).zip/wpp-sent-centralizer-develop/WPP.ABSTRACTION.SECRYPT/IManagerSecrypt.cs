﻿
namespace WPP.ABSTRACTION.SECRYPT
{
    internal interface IManagerSecrypt
    {
        string Encriptar(string value);
        string Desencriptar(string value);
        Tuple<bool, string> Check();
    }
}
