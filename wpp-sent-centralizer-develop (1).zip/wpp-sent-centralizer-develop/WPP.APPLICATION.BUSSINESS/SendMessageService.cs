﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.ENTITIES.MessageApplication;
using WPP.ABSTRACTION.ENTITIES.Options;
using WPP.ABSTRACTION.ENTITIES.ParameterMessage;
using WPP.ABSTRACTION.ENTITIES.SendMessage;
using WPP.ABSTRACTION.ENTITIES.SendMessageApplication;
using WPP.ABSTRACTION.ENTITIES.SendMessageApplicationGupshup;
using WPP.APPLICATION.COMMON;
using WPP.APPLICATION.COMMON.Extensions;
using WPP.APPLICATION.CONNECTION.DATABASE;
using WPP.APPLICATION.CONNECTION.SERVICE;
using WPP.APPLICATION.CONNECTION.SERVICE.Services;

namespace WPP.APPLICATION.BUSSINESS
{
    public interface ISendMessageService
    {
        Task<GenericResponse> SendMessageWhatsAppServiceGupshup(MessageApplicationModel _request, SendMessageApplicationParameter _wppAppication, string _operation);


        Task<GenericResponse> SendMessageWhatsAppServiceSinch(MessageApplicationModel _request, SendMessageApplicationParameter _wppAppication, string _operation);

        Task<GenericResponse> SendMessageWhatsDistributorService(MessageApplicationModel _request, string _operation);
    }
    public class SendMessageService : ISendMessageService
    {
        private readonly ISentCentralizerConnection _connectionService;
        private readonly ISentCentralizerConnectionDatabase _connectionDataBase;
        private readonly IFileManager _fileManager;
        private readonly FileManagementOptions _fileOptions;
        private readonly SendMessageApplicationAuthentication _sendMessageApplication;
        private ParameterMessageModel _parameterMessage;
        private static readonly string _sectionNameParameterName = "Parameter.Compound.Message";

        
        public SendMessageService(IOptions<FileManagementOptions> fileOptions, ISentCentralizerConnection connectionService, ISentCentralizerConnectionDatabase connectionDataBase, IConfiguration configuration, IFileManager fileManager, IOptions<SendMessageApplicationAuthentication> sendMessageApplication)
        {
            this._connectionService = connectionService;
            this._connectionDataBase = connectionDataBase;
            this._parameterMessage = new();
            configuration.GetSection(_sectionNameParameterName).Bind(this._parameterMessage);
            _fileManager = fileManager;
            _fileOptions = fileOptions.Value;
            this._sendMessageApplication = sendMessageApplication.Value;

        }
        #region SECTION.00: METODOS PARA EL ENVIO DE MENSAJE AL PROVEEDOR DE GUPSHUP
        public async Task<GenericResponse> SendMessageWhatsAppServiceGupshup(MessageApplicationModel _request, SendMessageApplicationParameter _wppAppication, string _operation)
        {
            GenericResponse _response = new();
            SendMessageApplicationGupshupResponse _responseMessage = new();
            try
            {
                switch (_request.typeMessage)
                {
                    case "TEXT":
                        SendMessageGupshupTextRequest _messageText = new();
                        _messageText.text = string.IsNullOrEmpty(_request.message) ? string.Empty : _request.message;
                        _messageText.type = "text";
                        _responseMessage = await this._connectionService.SendMessageWhatsAppGupshup(_messageText, null, _request.cellphone[0], _wppAppication, _operation);
                        _response.data = FormaterModelMessageWhatsAppInsertGupShup(_request, _responseMessage, _messageText);
                        break;
                    case "IMAGE":
                        SendMessageGupshupImageRequest _messageImage = new();
                        _messageImage.type = "image";
                        _request.url = _fileManager.SaveFileAsync(_request.multimediaUrl ?? string.Empty, _request.url ?? string.Empty, _request.classMultimedia ?? "TEXT", _request.typeMessage ?? "TEXT", _wppAppication.providerWhatsApp).Result;
                        _messageImage.originalUrl = _request.url ?? string.Empty;
                        _messageImage.previewUrl = _request.url ?? string.Empty;
                        _messageImage.caption = string.IsNullOrEmpty(_request.nameMultimediaUrl) ? string.Empty : _request.nameMultimediaUrl;
                        _responseMessage = await this._connectionService.SendMessageWhatsAppGupshup(_messageImage, null, _request.cellphone[0], _wppAppication, _operation);
                        _response.data = FormaterModelMessageWhatsAppInsertGupShup(_request, _responseMessage, _messageImage);
                        break;
                    case "AUDIO":
                        SendMessageGupshupAudioRequest _messageAudio = new();
                        _messageAudio.type = "audio";
                        _request.url = _fileManager.SaveFileAsync(_request.multimediaUrl ?? string.Empty, _request.url ?? string.Empty, _request.classMultimedia ?? "TEXT", _request.typeMessage ?? "TEXT", _wppAppication.providerWhatsApp).Result;
                        _messageAudio.url = _request.url ?? string.Empty;
                        _responseMessage = await this._connectionService.SendMessageWhatsAppGupshup(_messageAudio, null, _request.cellphone[0], _wppAppication, _operation);
                        _response.data = FormaterModelMessageWhatsAppInsertGupShup(_request, _responseMessage, _messageAudio);
                        break;
                    case "VIDEO":
                        SendMessageGupshupVideoRequest _messageVideo = new();
                        _messageVideo.type = "video";
                        _request.url = _fileManager.SaveFileAsync(_request.multimediaUrl ?? string.Empty, _request.url ?? string.Empty, _request.classMultimedia ?? "TEXT", _request.typeMessage ?? "TEXT", _wppAppication.providerWhatsApp).Result;
                        _messageVideo.url = _request.url ?? string.Empty;
                        _responseMessage = await this._connectionService.SendMessageWhatsAppGupshup(_messageVideo, null, _request.cellphone[0], _wppAppication, _operation);
                        _response.data = FormaterModelMessageWhatsAppInsertGupShup(_request, _responseMessage, _messageVideo);
                        break;
                    case "DOCUMENT":
                        SendMessageGupshupDocumentRequest _messageDocument = new();
                        _messageDocument.type = "file";
                        _request.url = _fileManager.SaveFileAsync(_request.multimediaUrl ?? string.Empty, _request.url ?? string.Empty, _request.classMultimedia ?? "TEXT", _request.typeMessage ?? "TEXT", _wppAppication.providerWhatsApp).Result;
                        _messageDocument.url = _request.url ?? string.Empty;
                        _messageDocument.filename = string.IsNullOrEmpty(_request.nameMultimediaUrl) ? string.Empty : _request.nameMultimediaUrl;
                        _responseMessage = await this._connectionService.SendMessageWhatsAppGupshup(_messageDocument, null, _request.cellphone[0], _wppAppication, _operation);
                        _response.data = FormaterModelMessageWhatsAppInsertGupShup(_request, _responseMessage, _messageDocument);
                        break;
                    case "LOCATION":
                        SendMessageGupshuplocationRequest _messageLocation = new();
                        _messageLocation.type = "location";
                        _messageLocation.longitude = Convert.ToDouble(_request.parameterMessage[0]);
                        _messageLocation.latitude = Convert.ToDouble(_request.parameterMessage[1]);
                        _messageLocation.name = _request.parameterMessage[2];
                        _messageLocation.address = _request.parameterMessage[3];
                        _responseMessage = await this._connectionService.SendMessageWhatsAppGupshup(_messageLocation, null, _request.cellphone[0], _wppAppication, _operation);
                        _response.data = FormaterModelMessageWhatsAppInsertGupShup(_request, _responseMessage, _messageLocation);
                        break;
                    case "TEMPLATE":
                        SendMessageGushupTemplateRequest _messageTemplate = new();
                        _messageTemplate.id = this._connectionDataBase.GetValueByParameter(_request.nameHsmOfTemplate);
                        _messageTemplate.@params = _request.parameterMessage;
                        _request.url = _fileManager.SaveFileAsync(_request.multimediaUrl ?? string.Empty, _request.url ?? string.Empty, _request.classMultimedia ?? "TEXT", _request.parametersTemplate.classMessageTemplate ?? "TEXT", _wppAppication.providerWhatsApp).Result;
                        var _responseMessageTemplate = SentCentralizerCommon.validationHeaderTemplateMessage(_request);
                        _responseMessage = await this._connectionService.SendMessageWhatsAppGupshup(_responseMessageTemplate, _messageTemplate, _request.cellphone[0], _wppAppication, _operation);
                        _response.data = FormaterModelMessageWhatsAppInsertGupShup(_request, _responseMessage, _messageTemplate);
                        break;
                    case "CTA_URL":
                        SendMessageGushupCtaUrlRequest _messageCtaUrl = new();
                        _messageCtaUrl.type = "cta_url";
                        _messageCtaUrl.body = SentCentralizerCommon.validationContentInteractiveGupshup(_request.message ?? string.Empty, "BODY");
                        _messageCtaUrl.display_text = (_request.parametersInteractive.nameSelectorButton ?? string.Empty).SubStringConditional(20);
                        _messageCtaUrl.url = _request.url ?? string.Empty;
                        _messageCtaUrl.footer = string.IsNullOrEmpty(_request.parametersInteractive.footer) ? null : _request.parametersInteractive.footer.SubStringConditional(60);
                        if (!string.IsNullOrEmpty(_request.classMessageCtaUrlHeader) && !string.IsNullOrEmpty(_request.urlHeaderCtaUrl))
                        {
                            _messageCtaUrl.header = new SendMessageGushupCtaUrlHeader() { type = _request.classMessageCtaUrlHeader.ToLower() };
                            if (_request.classMessageCtaUrlHeader.Equals("IMAGE", StringComparison.OrdinalIgnoreCase))
                                _messageCtaUrl.header.image = new SendMessageGushupTemplate() { link = _request.urlHeaderCtaUrl };
                            else if (_request.classMessageCtaUrlHeader.Equals("VIDEO", StringComparison.OrdinalIgnoreCase))
                                _messageCtaUrl.header.video = new SendMessageGushupTemplate() { link = _request.urlHeaderCtaUrl };
                        }
                        _responseMessage = await this._connectionService.SendMessageWhatsAppGupshup(_messageCtaUrl, null, _request.cellphone[0], _wppAppication, _operation);
                        _response.data = FormaterModelMessageWhatsAppInsertGupShup(_request, _responseMessage, _messageCtaUrl);
                        break;
                    case "CAROUSEL":
                        SendMessageGushupTemplateRequest _messageCarouselTemplate = new();
                        _messageCarouselTemplate.id = this._connectionDataBase.GetValueByParameter(_request.nameHsmOfTemplate);
                        _messageCarouselTemplate.@params = _request.parameterMessage;
                        SendMessageGushupCarouselRequest _messageCarousel = new();
                        _messageCarousel.type = "carousel";
                        _messageCarousel.cardHeaderType = string.IsNullOrEmpty(_request.cardHeaderTypeCarousel) ? "IMAGE" : _request.cardHeaderTypeCarousel.ToUpper();
                        _messageCarousel.cards = _request.cardsCarousel;
                        _responseMessage = await this._connectionService.SendMessageWhatsAppGupshup(_messageCarousel, _messageCarouselTemplate, _request.cellphone[0], _wppAppication, _operation);
                        _response.data = FormaterModelMessageWhatsAppInsertGupShup(_request, _responseMessage, _messageCarousel);
                        break;
                    case "INTERACTIVE":
                        _request.url = _fileManager.SaveFileAsync(_request.multimediaUrl ?? string.Empty, _request.url ?? string.Empty, _request.classMultimedia ?? "TEXT", _request.typeMessage ?? "TEXT", _wppAppication.providerWhatsApp).Result;
                        if ((_request.classInteractive ?? string.Empty).Equals("REPLY_BUTTON"))
                        {
                            var _messageInteractiveReplyButton = FormaterContentMessageInteractiveGupshup(_request, _request.classInteractive ?? string.Empty);
                            _responseMessage = await this._connectionService.SendMessageWhatsAppGupshup(_messageInteractiveReplyButton, null, _request.cellphone[0], _wppAppication, _operation);
                            _response.data = FormaterModelMessageWhatsAppInsertGupShup(_request, _responseMessage, _messageInteractiveReplyButton);
                        }
                        if ((_request.classInteractive ?? string.Empty).Equals("LIST_BUTTON"))
                        {
                            var _messageInteractiveListButton = FormaterContentMessageInteractiveGupshup(_request, _request.classInteractive ?? string.Empty);
                            _responseMessage = await this._connectionService.SendMessageWhatsAppGupshup(_messageInteractiveListButton, null, _request.cellphone[0], _wppAppication, _operation);
                            _response.data = FormaterModelMessageWhatsAppInsertGupShup(_request, _responseMessage, _messageInteractiveListButton);
                        }
                        break;
                    case "STICKER":
                        SendMessageGupshupStickerRequest _messageSticker = new();
                        _messageSticker.type = "sticker";
                        _request.url = _fileManager.SaveFileAsync(_request.multimediaUrl ?? string.Empty, _request.url ?? string.Empty, _request.classMultimedia ?? "TEXT", _request.typeMessage ?? "TEXT", _wppAppication.providerWhatsApp).Result;
                        _messageSticker.url = _request.url ?? string.Empty;
                        _responseMessage = await this._connectionService.SendMessageWhatsAppGupshup(_messageSticker, null, _request.cellphone[0], _wppAppication, _operation);
                        _response.data = FormaterModelMessageWhatsAppInsertGupShup(_request, _responseMessage, _messageSticker);
                        break;
                    default:
                        break;
                }
                _response.success = true;
                _response.message = "Process completed successfully.";
                _response.code = "200";
            }
            catch (Exception)
            {
                throw;
            }
            return _response;
        }
        public MessageInformation FormaterModelMessageWhatsAppInsertGupShup(MessageApplicationModel _request, SendMessageApplicationGupshupResponse _responseSend, object? _jsonSend)
        {
            try
            {
                MessageWhatsAppModel _modelMessageWhatsApp = new();
                _modelMessageWhatsApp.codeClient = _responseSend.messageId ?? _request.cellphone[0];
                _modelMessageWhatsApp.cellphone = _request.cellphone[0];
                _modelMessageWhatsApp.message = GetMessageFromTypeMessage(_request.typeMessage ?? "TEXT", _request.nameMultimediaUrl ?? "TEXT", _request.message ?? string.Empty, @$"{_request.parametersInteractive?.header?.SubStringConditional(1024)} \\r\\n {_request.parametersInteractive?.body?.SubStringConditional(1024)} \\r\\n {_request.parametersInteractive?.footer?.SubStringConditional(1024)}", $"{_request.nameHsmOfTemplate};{string.Join("|", _request.parameterMessage)}");
                _modelMessageWhatsApp.typeMessage = "SALIENTE";
                _modelMessageWhatsApp.codeTypeMessage = "S";
                _modelMessageWhatsApp.jsonClient = JsonConvert.SerializeObject(_jsonSend);
                _modelMessageWhatsApp.user = _request.user;
                _modelMessageWhatsApp.nameUser = _request.nameUser;
                _modelMessageWhatsApp.campaign = _request.campaignName;
                _modelMessageWhatsApp.login = 0;
                _modelMessageWhatsApp.whatsAppBot = _request.identifyChatBot;
                _modelMessageWhatsApp.messageClass = GetMessageClassFromTypeMessage(_request.typeMessage ?? "TEXT", _request.classMultimedia ?? "TEXT").ToUpper();
                _modelMessageWhatsApp.multimedia = string.IsNullOrEmpty(_request.url) ? "" : _request.url.Replace(_fileOptions.RootUrlPathDownload, _fileOptions.RootUrlPath);
                _modelMessageWhatsApp.dateDelivered = DateTime.Now;
                _modelMessageWhatsApp.dateRead = DateTime.Now;
                _modelMessageWhatsApp.messageId = this._connectionDataBase.InsertNewMessage(_modelMessageWhatsApp);
                return new MessageInformation()
                {
                    messageId = _modelMessageWhatsApp.messageId,
                    messageCode = _responseSend.messageId ?? _request.cellphone[0],
                    dateDelivered = _modelMessageWhatsApp.dateDelivered,
                    multimedia = _modelMessageWhatsApp.multimedia,
                    cellphone = _modelMessageWhatsApp.cellphone,
                    messageClass = _modelMessageWhatsApp.messageClass
                };
            }
            catch (Exception)
            {
                throw;
            }
        }
        public object? FormaterContentMessageInteractiveGupshup(MessageApplicationModel _request, string _classInteractive)
        {
            try
            {
                if (_classInteractive.Equals("REPLY_BUTTON"))
                {
                    if ((_request.parametersInteractive.classMessageInteractive ?? string.Empty).Equals("TEXT"))
                    {
                        SendMessageGushupInteractiveQuickRequest<InteractiveQuickContentText> _textInteractive = new();
                        _textInteractive.content = new();
                        _textInteractive.type = "quick_reply";
                        _textInteractive.msgid = _request.parametersInteractive.nameSelectorButton ?? string.Empty;
                        _textInteractive.content.type = "text";
                        _textInteractive.content.header = SentCentralizerCommon.validationContentInteractiveGupshup(_request.parametersInteractive.header ?? string.Empty, "HEADER");
                        _textInteractive.content.text = SentCentralizerCommon.validationContentInteractiveGupshup(_request.parametersInteractive.body ?? string.Empty, "BODY");
                        _textInteractive.content.caption = SentCentralizerCommon.validationContentInteractiveGupshup(_request.parametersInteractive.footer ?? string.Empty, "FOOTER");
                        _textInteractive.options = _request.parametersInteractive.parameters.AsEnumerable().Select(x => new InteractiveListOptions { type = "text", title = x.title?.SubStringConditional(20) ?? string.Empty, description = string.Empty, postbackText = x.identifier?.SubStringConditional(256) ?? string.Empty }).Take(3).ToList();
                        return _textInteractive;
                    }
                    if ((_request.parametersInteractive.classMessageInteractive ?? string.Empty).Equals("IMAGE"))
                    {
                        SendMessageGushupInteractiveQuickRequest<InteractiveQuickContentImage> _imageInteractive = new();
                        _imageInteractive.content = new();
                        _imageInteractive.type = "quick_reply";
                        _imageInteractive.msgid = _request.parametersInteractive.nameSelectorButton ?? string.Empty;
                        _imageInteractive.content.type = "image";
                        _imageInteractive.content.url = _request.url ?? string.Empty;
                        _imageInteractive.content.text = SentCentralizerCommon.validationContentInteractiveGupshup(_request.parametersInteractive.body ?? string.Empty, "BODY");
                        _imageInteractive.content.caption = SentCentralizerCommon.validationContentInteractiveGupshup(_request.parametersInteractive.footer ?? string.Empty, "FOOTER");
                        _imageInteractive.options = _request.parametersInteractive.parameters.AsEnumerable().Select(x => new InteractiveListOptions { type = "text", title = x.title?.SubStringConditional(20) ?? string.Empty, description = string.Empty, postbackText = x.identifier?.SubStringConditional(256) ?? string.Empty }).Take(3).ToList();
                        return _imageInteractive;
                    }
                    if ((_request.parametersInteractive.classMessageInteractive ?? string.Empty).Equals("VIDEO"))
                    {
                        SendMessageGushupInteractiveQuickRequest<InteractiveQuickContentVideo> _videoInteractive = new();
                        _videoInteractive.content = new();
                        _videoInteractive.type = "quick_reply";
                        _videoInteractive.msgid = _request.parametersInteractive.nameSelectorButton ?? string.Empty;
                        _videoInteractive.content.type = "video";
                        _videoInteractive.content.url = _request.url ?? string.Empty;
                        _videoInteractive.content.text = SentCentralizerCommon.validationContentInteractiveGupshup(_request.parametersInteractive.body ?? string.Empty, "BODY");
                        _videoInteractive.content.caption = SentCentralizerCommon.validationContentInteractiveGupshup(_request.parametersInteractive.footer ?? string.Empty, "FOOTER");
                        _videoInteractive.options = _request.parametersInteractive.parameters.AsEnumerable().Select(x => new InteractiveListOptions { type = "text", title = x.title?.SubStringConditional(20) ?? string.Empty, description = string.Empty, postbackText = x.identifier?.SubStringConditional(256) ?? string.Empty }).Take(3).ToList();
                        return _videoInteractive;
                    }
                    if ((_request.parametersInteractive.classMessageInteractive ?? string.Empty).Equals("DOCUMENT"))
                    {
                        SendMessageGushupInteractiveQuickRequest<InteractiveQuickContentFile> _documentInteractive = new();
                        _documentInteractive.content = new();
                        _documentInteractive.type = "quick_reply";
                        _documentInteractive.msgid = _request.parametersInteractive.nameSelectorButton ?? string.Empty;
                        _documentInteractive.content.type = "file";
                        _documentInteractive.content.url = _request.url ?? string.Empty;
                        _documentInteractive.content.text = SentCentralizerCommon.validationContentInteractiveGupshup(_request.parametersInteractive.body ?? string.Empty, "BODY");
                        _documentInteractive.content.filename = _request.nameMultimediaUrl ?? string.Empty;
                        _documentInteractive.content.caption = SentCentralizerCommon.validationContentInteractiveGupshup(_request.parametersInteractive.footer ?? string.Empty, "FOOTER");
                        _documentInteractive.options = _request.parametersInteractive.parameters.AsEnumerable().Select(x => new InteractiveListOptions { type = "text", title = x.title?.SubStringConditional(20) ?? string.Empty, description = string.Empty, postbackText = x.identifier?.SubStringConditional(256) ?? string.Empty }).Take(3).ToList();
                        return _documentInteractive;
                    }
                }
                if (_classInteractive.Equals("LIST_BUTTON"))
                {
                    SendMessageGushupInteractiveListRequest _textInteractiveList = new();
                    _textInteractiveList.type = "list";
                    _textInteractiveList.title = SentCentralizerCommon.validationContentInteractiveGupshup(_request.parametersInteractive.header ?? string.Empty, "HEADER"); ;
                    _textInteractiveList.body = SentCentralizerCommon.validationContentInteractiveGupshup(_request.parametersInteractive.body ?? string.Empty, "BODY"); ;
                    _textInteractiveList.msgid = _request.parametersInteractive.nameSelectorButton ?? string.Empty;
                    _textInteractiveList.globalButtons.Add(new InteractiveListButtons() { type = "text", title = _request.parametersInteractive.nameSelectorButton ?? string.Empty });
                    _textInteractiveList.items.Add(new InteractiveListItems() { title = string.Empty, subtitle = string.Empty, options = _request.parametersInteractive.parameters.AsEnumerable().Select(y => new InteractiveListOptions { type = "text", title = y.title?.SubStringConditional(20) ?? string.Empty, description = y.description?.SubStringConditional(72) ?? string.Empty, postbackText = y.identifier }).Take(10).ToList() });
                    return _textInteractiveList;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        #endregion

        #region SECTION.01: METODOS PARA EL ENVIO DE MENSAJES AL PROVEEDOR DE SINCH
        public async Task<GenericResponse> SendMessageWhatsAppServiceSinch(MessageApplicationModel _request, SendMessageApplicationParameter _wppAppication, string _operation)
        {
            GenericResponse _response = new();
            SendMessageResponse _responseMessageSend = new();
            try
            {
                List<SendMessageDestinations> destinations;
                MessageInformation messages = new();
                switch (_request.typeMessage)
                {
                    case "TEXT":
                        SendMessageTextRequest _messageText = new();
                        _messageText.campaignAlias = _request.campaignName;
                        _messageText.message.messageText = string.IsNullOrEmpty(_request.message) ? string.Empty : _request.message;
                        (destinations, messages) = sendMessageDestinations(_request, _messageText, _wppAppication.sourceAccount);
                        _messageText.destinations = destinations;
                        _responseMessageSend = await this._connectionService.SendMessageWhatsApp(_messageText, _operation);
                        messages.messageCode = _responseMessageSend.destinations.Count > 0 ? _responseMessageSend.destinations[0].id : string.Empty;
                        break;
                    case "IMAGE":
                        SendMessageImageRequest _messageImage = new();
                        _messageImage.campaignAlias = _request.campaignName;
                        _messageImage.message.image.url = string.IsNullOrEmpty(_request.url) ? null : _request.url;
                        _messageImage.message.image.caption = string.IsNullOrEmpty(_request.nameMultimediaUrl) ? null : _request.nameMultimediaUrl;
                        _messageImage.message.image.type = string.IsNullOrEmpty(_request.classMultimedia) ? "JPG" : _request.classMultimedia.Trim().ToUpper();
                        (destinations, messages) = sendMessageDestinations(_request, _messageImage, _wppAppication.sourceAccount);
                        _messageImage.destinations = destinations;
                        _messageImage.message.image.data = string.IsNullOrEmpty(_request.multimediaUrl) ? null : _request.multimediaUrl;
                        _responseMessageSend = await this._connectionService.SendMessageWhatsApp(_messageImage, _operation);
                        messages.messageCode = _responseMessageSend.destinations.Count > 0 ? _responseMessageSend.destinations[0].id : string.Empty;
                        break;
                    case "AUDIO":
                        SendMessageAudioRequest _messageAudio = new();
                        _messageAudio.campaignAlias = _request.campaignName;
                        _messageAudio.message.audio.url = string.IsNullOrEmpty(_request.url) ? null : _request.url;
                        _messageAudio.message.audio.type = string.IsNullOrEmpty(_request.classMultimedia) || _request.classMultimedia == "MPEG" ? "MP3" : _request.classMultimedia.Trim().ToUpper();
                        (destinations, messages) = sendMessageDestinations(_request, _messageAudio, _wppAppication.sourceAccount);
                        _messageAudio.destinations = destinations;
                        _messageAudio.message.audio.data = string.IsNullOrEmpty(_request.multimediaUrl) ? null : _request.multimediaUrl;
                        _responseMessageSend = await this._connectionService.SendMessageWhatsApp(_messageAudio, _operation);
                        messages.messageCode = _responseMessageSend.destinations.Count > 0 ? _responseMessageSend.destinations[0].id : string.Empty;
                        break;
                    case "VIDEO":
                        SendMessageVideoRequest _messageVideo = new();
                        _messageVideo.campaignAlias = _request.campaignName;
                        _messageVideo.message.video.url = string.IsNullOrEmpty(_request.url) ? null : _request.url;
                        _messageVideo.message.video.caption = string.IsNullOrEmpty(_request.nameMultimediaUrl) ? null : _request.nameMultimediaUrl;
                        _messageVideo.message.video.type = string.IsNullOrEmpty(_request.classMultimedia) ? "MP4" : _request.classMultimedia.Trim().ToUpper();
                        (destinations, messages) = sendMessageDestinations(_request, _messageVideo, _wppAppication.sourceAccount);
                        _messageVideo.destinations = destinations;
                        _messageVideo.message.video.data = string.IsNullOrEmpty(_request.multimediaUrl) ? null : _request.multimediaUrl;
                        _responseMessageSend = await this._connectionService.SendMessageWhatsApp(_messageVideo, _operation);
                        messages.messageCode = _responseMessageSend.destinations.Count > 0 ? _responseMessageSend.destinations[0].id : string.Empty;
                        break;
                    case "DOCUMENT":
                        SendMessageDocumentRequest _messageDocument = new();
                        _messageDocument.campaignAlias = _request.campaignName;
                        _messageDocument.message.document.url = string.IsNullOrEmpty(_request.url) ? null : _request.url;
                        _messageDocument.message.document.caption = string.IsNullOrEmpty(_request.nameMultimediaUrl) ? null : _request.nameMultimediaUrl;
                        _messageDocument.message.document.type = string.IsNullOrEmpty(_request.classMultimedia) ? "PDF" : _request.classMultimedia.Trim().ToUpper();
                        (destinations, messages) = sendMessageDestinations(_request, _messageDocument, _wppAppication.sourceAccount);
                        _messageDocument.destinations = destinations;
                        _messageDocument.message.document.data = string.IsNullOrEmpty(_request.multimediaUrl) ? null : _request.multimediaUrl;
                        _responseMessageSend = await this._connectionService.SendMessageWhatsApp(_messageDocument, _operation);
                        messages.messageCode = _responseMessageSend.destinations.Count > 0 ? _responseMessageSend.destinations[0].id : string.Empty;
                        break;
                    case "LOCATION":
                        SendMessageLocationRequest _messageLocation = new();
                        _messageLocation.campaignAlias = _request.campaignName;
                        _messageLocation.message.location.geoPoint = _request.parameterMessage[0].ToString();
                        _messageLocation.message.location.name = _request.parameterMessage[1].ToString();
                        _messageLocation.message.location.address = _request.parameterMessage[2].ToString();
                        (destinations, messages) = sendMessageDestinations(_request, _messageLocation, _wppAppication.sourceAccount);
                        _messageLocation.destinations = destinations;
                        _responseMessageSend = await this._connectionService.SendMessageWhatsApp(_messageLocation, _operation);
                        messages.messageCode = _responseMessageSend.destinations.Count > 0 ? _responseMessageSend.destinations[0].id : string.Empty;
                        break;
                    case "HSM":
                        SendMessageHsmRequest _messageHsm = new();
                        _messageHsm.campaignAlias = _request.campaignName;
                        _messageHsm.message.hsm.@namespace = this._parameterMessage.hsmNamespace;
                        _messageHsm.message.hsm.elementName = _request.nameHsmOfTemplate;
                        _messageHsm.message.hsm.languageCode = this._parameterMessage.hsmLanguageCode;
                        _messageHsm.message.hsm.parameters = _request.parameterMessage;
                        (destinations, messages) = sendMessageDestinations(_request, _messageHsm, _wppAppication.sourceAccount);
                        _messageHsm.destinations = destinations;
                        _responseMessageSend = await this._connectionService.SendMessageWhatsApp(_messageHsm, _operation);
                        messages.messageCode = _responseMessageSend.destinations.Count > 0 ? _responseMessageSend.destinations[0].id : string.Empty;
                        break;
                    case "TEMPLATE":
                        SendMessageTemplateRequest _messageTemplate = new();
                        _messageTemplate.campaignAlias = _request.campaignName;
                        _messageTemplate.message.template.@namespace = this._parameterMessage.templateNamespace;
                        _messageTemplate.message.template.elementName = _request.nameHsmOfTemplate;
                        _messageTemplate.message.template.languagePolicy = this._parameterMessage.templateLanguagePolicy;
                        _messageTemplate.message.template.languageCode = this._parameterMessage.templateLanguageCode;
                        _messageTemplate.message.template.bodyParameters = _request.parameterMessage;
                        (destinations, messages) = sendMessageDestinations(_request, _messageTemplate, _wppAppication.sourceAccount);
                        _messageTemplate.destinations = destinations;
                        _messageTemplate.message.template.header = SentCentralizerCommon.validationHeaderTemplate(_request);
                        _responseMessageSend = await this._connectionService.SendMessageWhatsApp(_messageTemplate, _operation);
                        messages.messageCode = _responseMessageSend.destinations.Count > 0 ? _responseMessageSend.destinations[0].id : string.Empty;
                        break;
                    case "INTERACTIVE":
                        SendMessageInteractiveRequest _messageInteractive = new();
                        _messageInteractive.campaignAlias = _request.campaignName;
                        _messageInteractive.message.interactive.messageInteractiveType = _request.classInteractive;
                        _messageInteractive.message.interactive.body = SentCentralizerCommon.validationBodyInteractive(_request);
                        _messageInteractive.message.interactive.footer = SentCentralizerCommon.validationFooterInteractive(_request);
                        if (_messageInteractive.message.interactive.messageInteractiveType == "LIST")
                        {
                            _messageInteractive.message.interactive.replyButtonAction = null;
                            _messageInteractive.message.interactive.listAction = new();
                            _messageInteractive.message.interactive.listAction.sections = new();
                            _messageInteractive.message.interactive.listAction.button = _request.parametersInteractive.nameSelectorButton.SubStringConditional(20);
                            _messageInteractive.message.interactive.listAction.sections.Add(new SectionsButton() { rows = _request.parametersInteractive.parameters?.Select(x => new InteractiveParameterModel { identifier = x.identifier, title = x.title, description = x.description }).Take(10).ToList() }); // SOLO SE ESTA MANEJANDO UNA SECCION, SE PUEDEN MANEJAR MAS DE 1 PERO EL TOTAL DE ROWS NO PUEDE SUPERAR EL DE 10
                        }
                        else if (_messageInteractive.message.interactive.messageInteractiveType == "REPLY_BUTTON")
                        {
                            _messageInteractive.message.interactive.listAction = null;
                            _messageInteractive.message.interactive.replyButtonAction = new();
                            _messageInteractive.message.interactive.replyButtonAction.buttons = _request.parametersInteractive.parameters.AsEnumerable().Select(y => new ButtonReply { reply = new Reply { title = string.IsNullOrEmpty(y.title) ? string.Empty : y.title.SubStringConditional(20), payload = string.IsNullOrEmpty(y.identifier) ? string.Empty : y.identifier.SubStringConditional(256) } }).Take(3).ToList(); // EL MAXIMO PERMITIDO DE BOTONES SON DE 3
                        }
                        _messageInteractive.message.interactive.alternativeText = string.IsNullOrEmpty(_request.parametersInteractive.alternativeText) ? null : _request.parametersInteractive.alternativeText;
                        (destinations, messages) = sendMessageDestinations(_request, _messageInteractive, _wppAppication.sourceAccount);
                        _messageInteractive.destinations = destinations;
                        _messageInteractive.message.interactive.header = SentCentralizerCommon.validationHeaderInterative(_request);
                        _responseMessageSend = await this._connectionService.SendMessageWhatsApp(_messageInteractive, _operation);
                        messages.messageCode = _responseMessageSend.destinations.Count > 0 ? _responseMessageSend.destinations[0].id : string.Empty;
                        break;
                    case "STICKER":
                        break;
                    default:
                        // SE DEBE AGREGAR LA FUNCIONALIDAD DE ENVIAR CONTACTOS  
                        break;
                }
                _response.success = true;
                _response.message = "Process completed successfully.";
                _response.code = "200";
                _response.data = messages;
            }
            catch (Exception)
            {
                throw;
            }
            return _response;
        }
        public (List<SendMessageDestinations>, MessageInformation) sendMessageDestinations(MessageApplicationModel _request, object _message, string wppProvider)
        {
            List<SendMessageDestinations> _response = new();
            MessageInformation _responseW = new();
            try
            {
                foreach (string item in _request.cellphone)
                {
                    _responseW = FormaterModelMessageWhatsAppInsert(_request, _message, item, wppProvider);
                    _response.Add(new SendMessageDestinations() { correlationId = _responseW.messageId.ToString(), destination = item });
                }
            }
            catch (Exception)
            {
                throw;
            }
            return (_response, _responseW);
        }
        public MessageInformation FormaterModelMessageWhatsAppInsert(MessageApplicationModel _request, object _jsonSend, string _cellphone, string wppProvider)
        {
            try
            {
                MessageWhatsAppModel _modelMessageWhatsApp = new();
                _modelMessageWhatsApp.codeClient = _cellphone;
                _modelMessageWhatsApp.cellphone = _cellphone;
                _modelMessageWhatsApp.message = GetMessageFromTypeMessage(_request.typeMessage ?? "TEXT", _request.nameMultimediaUrl ?? "TEXT", _request.message ?? string.Empty, @$"{_request.parametersInteractive?.header?.SubStringConditional(1024)} \\r\\n {_request.parametersInteractive?.body?.SubStringConditional(1024)} \\r\\n {_request.parametersInteractive?.footer?.SubStringConditional(1024)}", $"{_request.nameHsmOfTemplate};{string.Join("|", _request.parameterMessage)}");
                _modelMessageWhatsApp.typeMessage = "SALIENTE";
                _modelMessageWhatsApp.codeTypeMessage = "S";
                _modelMessageWhatsApp.jsonClient = JsonConvert.SerializeObject(_jsonSend);
                _modelMessageWhatsApp.user = _request.user;
                _modelMessageWhatsApp.nameUser = _request.nameUser;
                _modelMessageWhatsApp.campaign = _request.campaignName;
                _modelMessageWhatsApp.login = 0;
                _modelMessageWhatsApp.whatsAppBot = _request.identifyChatBot;
                _modelMessageWhatsApp.messageClass = GetMessageClassFromTypeMessage(_request.typeMessage ?? "TEXT", _request.classMultimedia ?? "TEXT");
                _modelMessageWhatsApp.multimedia = _fileManager.SaveFileAsync(_request.multimediaUrl ?? string.Empty, _request.url ?? string.Empty, _request.classMultimedia ?? "TEXT", _request.typeMessage ?? "TEXT", wppProvider).Result;
                _modelMessageWhatsApp.dateDelivered = DateTime.Now;
                _modelMessageWhatsApp.dateRead = DateTime.Now;
                _modelMessageWhatsApp.messageId = this._connectionDataBase.InsertNewMessage(_modelMessageWhatsApp);
                return new MessageInformation()
                {
                    messageId = _modelMessageWhatsApp.messageId,
                    messageCode = string.Empty,
                    cellphone = _modelMessageWhatsApp.cellphone,
                    dateDelivered = _modelMessageWhatsApp.dateDelivered,
                    multimedia = _modelMessageWhatsApp.multimedia,
                    messageClass = _modelMessageWhatsApp.messageClass
                };
            }
            catch (Exception)
            {
                throw;
            }
        }
        private string GetMessageFromTypeMessage(string typeMessage, string nameMultimediaUrl, string message, string messageInteractive, string messageTemplate)
        {
            switch (typeMessage)
            {
                case "IMAGE":
                case "AUDIO":
                case "VIDEO":
                    return nameMultimediaUrl;
                case "INTERACTIVE":
                    return messageInteractive;
                case "TEMPLATE":
                    return messageTemplate;
                default:
                    return message;
            }
        }
        private string GetMessageClassFromTypeMessage(string typeMessage, string classMultimedia)
        {
            switch (typeMessage)
            {
                case "IMAGE":
                case "AUDIO":
                case "VIDEO":
                case "DOCUMENT":
                    return $"{typeMessage}/{classMultimedia}";
                default:
                    return typeMessage;
            }
        }
        #endregion

        #region SECTION.02: VALIDACION DEL DISTRIBUIDOR PARA REDIRECCIONAR AL PROVEEDOR DE WHATSAPP CORRESPONDIENTE
        public async Task<GenericResponse> SendMessageWhatsDistributorService(MessageApplicationModel _request, string _operation)
        {
            try
            {                
                var filterProvider = (from row in this._sendMessageApplication.sendApplicationParameters where row.sourceAccount == _request.destinationAccount select row).ToList();
                SendMessageApplicationParameter _wppAppication = new();
                _wppAppication = filterProvider.FirstOrDefault() ?? new();

                if (_wppAppication.providerWhatsApp.Equals("GUPSHUP"))
                    return await SendMessageWhatsAppServiceGupshup(_request, _wppAppication, _operation);
                else
                    return await SendMessageWhatsAppServiceSinch(_request, _wppAppication, _operation);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion
    }
}
