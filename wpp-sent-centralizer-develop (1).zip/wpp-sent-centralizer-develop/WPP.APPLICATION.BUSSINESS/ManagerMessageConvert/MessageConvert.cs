﻿using System.Net;
using System.Text;

namespace WPP.APPLICATION.BUSSINESS.ManagerMessageConvert
{
    public static class MessageConvert
    {
        public static string ConvertImageUrlToBase64(string _url)
        {
            try
            {
                StringBuilder _stringBuilder = new StringBuilder();
                byte[] _byteImagen = null;
                Stream _streamImagen = null;
                WebProxy myProxy = new WebProxy();
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(_url);
                HttpWebResponse response = (HttpWebResponse)req.GetResponse();
                _streamImagen = response.GetResponseStream();
                using (BinaryReader br = new BinaryReader(_streamImagen))
                {
                    int len = (int)(response.ContentLength);
                    _byteImagen = br.ReadBytes(len);
                    br.Close();
                }
                _streamImagen.Close();
                response.Close();
                _stringBuilder.Append(Convert.ToBase64String(_byteImagen, 0, _byteImagen.Length));
                return _stringBuilder.ToString();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
