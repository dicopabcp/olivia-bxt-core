﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using WPP.ABSTRACTION.ENTITIES.Authentication;
using WPP.ABSTRACTION.ENTITIES.Authorization;
using WPP.ABSTRACTION.ENTITIES.SendMessage;
using WPP.ABSTRACTION.ENTITIES.SendMessageApplicationGupshup;
using WPP.ABSTRACTION.ENTITIES.SendWhatsApp;
using WPP.ABSTRACTION.LOGGER;
using WPP.APPLICATION.CONNECTION.SERVICE.RestConnectionService;

namespace WPP.APPLICATION.CONNECTION.SERVICE
{
    public interface ISentCentralizerConnection
    {
        List<BasicAutorizacionModel> getUserIN(string _user, string _password, AuthorizationRequest _authorization);
        Task<SendMessageResponse> SendMessageWhatsApp(object request, string _operation);
        Task<SendMessageApplicationGupshupResponse> SendMessageWhatsAppGupshup(object? request, object? requestTemplate, string cellphone, SendMessageApplicationParameter _authenticationWhatsAppGupshup, string operation);
    }
    public class SentCentralizerConnection : ISentCentralizerConnection
    {
        private readonly ILoggerInfo _logger;
        public readonly AuthenticationOptions _authenticationApi;
        public readonly SendMessageWhatsApp _sendMessageWhatsApp;
        public readonly AuthenticationRequest _authenticationProvider;
        private readonly ISendCentralizerConnectionService _httpConnection;
        private readonly SendMessageApplicationGupshupOptions _sendMessageWhatsAppGupshup;
        

        public SentCentralizerConnection(IConfiguration configuration, ILoggerInfo logger, IOptions<AuthenticationOptions> authenticationApi, IOptions<SendMessageWhatsApp> sendMessageWhatsApp, IOptions<AuthenticationRequest> authenticationProvider, ISendCentralizerConnectionService httpConnection, IOptions<SendMessageApplicationGupshupOptions> sendMessageWhatsAppGupshup)
        {
            this._logger = logger;
            this._authenticationApi = authenticationApi.Value;
            this._sendMessageWhatsApp = sendMessageWhatsApp.Value;
            this._authenticationProvider = authenticationProvider.Value;
            this._httpConnection = httpConnection;
            this._sendMessageWhatsAppGupshup = sendMessageWhatsAppGupshup.Value;
            
        }

        #region VALIDACION DE CREDENCIALES DE IAM
        public List<BasicAutorizacionModel> getUserIN(string _user, string _password, AuthorizationRequest _authorization)
        {
            List<BasicAutorizacionModel> _response = new();
            _authorization.date = DateTime.Now.ToString("yyyyMMdd");
            AutorizacionResponse _responseAuthentication = this._httpConnection.PostAsync<AutorizacionResponse>(this._authenticationApi.urlAuthentication, this._authenticationApi.methodAuthentication, _authorization, Authentication.Basic, _user, _password).Result;
            if (_responseAuthentication.state.Equals("00"))
            {
                _response.Add(new BasicAutorizacionModel { id = _responseAuthentication.data.id, userName = _responseAuthentication.data.username, password = "" });
            }
            return _response;
        }
        #endregion

        public async Task<SendMessageResponse> SendMessageWhatsApp(object request, string _operation)
        {
            SendMessageResponse responsewhatsapp = new();
            try
            {
                var json = JsonConvert.SerializeObject(request);
                this._logger.Debug(string.Format("[ {0} ]      URL: {1}", _operation, this._sendMessageWhatsApp.urlSendMessage + this._sendMessageWhatsApp.methodSndMessage));
                this._logger.Debug(string.Format("[ {0} ]  REQUEST: {1}", _operation, JsonConvert.SerializeObject(request)));
                responsewhatsapp = await this._httpConnection.PostAsync<SendMessageResponse>(this._sendMessageWhatsApp.urlSendMessage, this._sendMessageWhatsApp.methodSndMessage, request, Authentication.WhatsApp, this._authenticationProvider.userWhatsAppProvider, this._authenticationProvider.tokenWhatsAppProvider);
                this._logger.Debug(string.Format("[ {0} ] RESPONSE: {1}", _operation, JsonConvert.SerializeObject(responsewhatsapp)));
            }
            catch (Exception)
            {
                throw;
            }
            return responsewhatsapp;
        }

        public async Task<SendMessageApplicationGupshupResponse> SendMessageWhatsAppGupshup(object? request, object? requestTemplate,string cellphone, SendMessageApplicationParameter _authenticationWhatsAppGupshup, string operation)
        {
            try
            {
                string _url = this._sendMessageWhatsAppGupshup.urlSendMessageGushup;
                string _method = requestTemplate == null ? this._sendMessageWhatsAppGupshup.methodSendMessageGushup : this._sendMessageWhatsAppGupshup.methodSendMessageTemplateGushup;
                this._logger.Debug(string.Format("[ {0} ]      URL: {1}", operation, _url + _method));
                this._logger.Debug(string.Format("[ {0} ]  REQUEST: {1}", operation, JsonConvert.SerializeObject(request)));
                var responsewhatsapp = await this._httpConnection.PostGupshup<SendMessageApplicationGupshupResponse>(_url, _method, request, _authenticationWhatsAppGupshup.apiKeyProvider, _authenticationWhatsAppGupshup.channel, _authenticationWhatsAppGupshup.sourceAccount, cellphone, _authenticationWhatsAppGupshup.userProvider, _authenticationWhatsAppGupshup.disablePreview, _authenticationWhatsAppGupshup.encode, (requestTemplate == null ? MessageSendingType.CommonMessage : MessageSendingType.MessageTemplate), requestTemplate);
                this._logger.Debug(string.Format("[ {0} ] RESPONSE: {1}", operation, JsonConvert.SerializeObject(responsewhatsapp)));
                return responsewhatsapp;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}