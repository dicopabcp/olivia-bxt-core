﻿using Newtonsoft.Json;
using System.Net;
using System.Security.Authentication;
using System.Text;

namespace WPP.APPLICATION.CONNECTION.SERVICE.RestConnectionService
{
    public enum WorkEnvironment { Development, Certification, Production }
    public enum Authentication { None, Header, Basic, Complete, WhatsApp, Gupshup }
    public enum MessageSendingType { CommonMessage, MessageTemplate }
    public interface ISendCentralizerConnectionService
    {
        Task<T> PostGupshup<T>(string _urlBase, string _method, object? _request, string _apiKey, string _channel, string _source, string _destination, string _name, bool _encode, bool _preview, MessageSendingType _messageSendingType, object? _requestTemplate);
        Task<T> PostAsync<T>(string _urlBase, string _method, object? _request, Authentication _authentication, string _usuario = "", string _password = "", string _channel = "", string _publicToken = "", string _appUserid = "");
    }
    public class SendCentralizerConnectionService : ISendCentralizerConnectionService
    {
        public async Task<T> PostGupshup<T>(string _urlBase, string _method, object? _request, string _apiKey, string _channel, string _source, string _destination, string _name, bool _encode, bool _preview, MessageSendingType _messageSendingType, object? _requestTemplate )
        {
            HttpClientHandler httpHandler = new HttpClientHandler();
            httpHandler.SslProtocols = SslProtocols.Tls12;
            HttpRequestMessage request = new HttpRequestMessage();
            request.Method = HttpMethod.Post;
            request.RequestUri = new Uri(_urlBase + _method);
            request.Headers.Add("accept", "application/json");
            request.Headers.Add("apikey", _apiKey);
            Dictionary<string, string> _content = new Dictionary<string, string>();
            switch (_messageSendingType)
            {
                case MessageSendingType.CommonMessage:
                    _content.Add("message", JsonConvert.SerializeObject(_request));
                    _content.Add("channel", _channel);
                    _content.Add("source", _source);
                    _content.Add("destination", _destination);
                    _content.Add("src.name", _name);
                    _content.Add("encode", Convert.ToString(_encode));
                    _content.Add("disablePreview", Convert.ToString(_preview));
                    break;
                case MessageSendingType.MessageTemplate:
                    if(_request != null)
                        _content.Add("message", JsonConvert.SerializeObject(_request));
                    _content.Add("channel", _channel);
                    _content.Add("source", _source);
                    _content.Add("destination", _destination);
                    _content.Add("src.name", _name);
                    _content.Add("encode", Convert.ToString(_encode));
                    _content.Add("disablePreview", Convert.ToString(_preview));
                    _content.Add("template", JsonConvert.SerializeObject(_requestTemplate));
                    break;
                default:
                    break;
            }
            request.Content = new FormUrlEncodedContent(_content);
            using (var httpClient = new HttpClient(httpHandler))
            {
                httpClient.Timeout = TimeSpan.FromMinutes(5);
                var _response = await httpClient.SendAsync(request);
                var _result = await _response.Content.ReadAsStringAsync();
                HttpStatusCode _statusCode = _response.StatusCode;
                if (_statusCode == HttpStatusCode.OK || _statusCode == HttpStatusCode.Accepted)
                {
                    var _responseService = _result == null ? "" : _result;
                    return JsonConvert.DeserializeObject<T>(_responseService);
                }
                else
                {
                    throw new Exception($"ERROR => URL METHOD: {_urlBase + _method} ; STATUS: {_statusCode} ; CONTENT: {_result}");
                }
            }
        }
        public async Task<T> PostAsync<T>(string _urlBase, string _method, object? _request, Authentication _authentication, string _usuario = "", string _password = "", string _channel = "", string _publicToken = "", string _appUserid = "")
        {
            HttpClientHandler httpHandler = new HttpClientHandler();
            httpHandler.SslProtocols = SslProtocols.Tls12 ;
            using (var httpClient = new HttpClient(httpHandler))
            {
                httpClient.Timeout = TimeSpan.FromMinutes(5);
                switch (_authentication)
                {
                    case Authentication.None:
                        break;
                    case Authentication.Header:
                        httpClient.DefaultRequestHeaders.Add("USUARIO", _usuario);
                        httpClient.DefaultRequestHeaders.Add("PASSWORD", _password);
                        break;
                    case Authentication.Basic:
                        string _encodeBasic = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(_usuario + ":" + _password));
                        httpClient.DefaultRequestHeaders.Add("Authorization", $"Basic {_encodeBasic}");
                        break;
                    case Authentication.Complete:
                        string _encodeComplete = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(_usuario + ":" + _password));
                        httpClient.DefaultRequestHeaders.Add("Authorization", $"Basic {_encodeComplete}");
                        httpClient.DefaultRequestHeaders.Add("channel", _channel);
                        httpClient.DefaultRequestHeaders.Add("publicToken", _publicToken);
                        httpClient.DefaultRequestHeaders.Add("appUserId", _appUserid);
                        break;
                    case Authentication.WhatsApp:
                        httpClient.DefaultRequestHeaders.Add("username", _usuario);
                        httpClient.DefaultRequestHeaders.Add("authenticationToken", _password);
                        break;
                    case Authentication.Gupshup:
                        break;
                    default:
                        break;
                }
                var _json = JsonConvert.SerializeObject(_request);
                var _content = new StringContent(_json, Encoding.UTF8, "application/json");
                var _result = await httpClient.PostAsync(new Uri(_urlBase + _method), _content);
                var _resultContent = await _result.Content.ReadAsStringAsync();
                HttpStatusCode _statusCode = _result.StatusCode;
                if (_statusCode == HttpStatusCode.OK)
                {
                    var _responseService = _resultContent == null ? "" : _resultContent;
                    return JsonConvert.DeserializeObject<T>(_responseService);
                }
                else
                {
                    throw new Exception($"ERROR => URL METHOD: {_urlBase + _method} ; STATUS: {_statusCode} ; CONTENT: {_resultContent}");
                }
            }
        }
    }
}
