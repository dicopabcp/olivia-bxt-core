﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System.Configuration;
using System.Security.Authentication;
using WPP.ABSTRACTION.ENTITIES.Options;
using WPP.ABSTRACTION.ENTITIES.ParameterMessage;

namespace WPP.APPLICATION.CONNECTION.SERVICE.Services
{
    public class FileManager : IFileManager
    {
        private readonly FileManagementOptions _fileOptions;
        
        public FileManager(IOptions<FileManagementOptions> fileOptions, IConfiguration configuration) { _fileOptions = fileOptions.Value; }
        public async Task<string> DownloadUrl(string url)
        {
            try
            {
                HttpClientHandler httpHandler = new HttpClientHandler();
                httpHandler.SslProtocols = SslProtocols.Tls12;
                using (HttpClient client = new HttpClient(httpHandler))
                {
                    var bytes = await client.GetByteArrayAsync(url);
                    return Convert.ToBase64String(bytes);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<string> SaveFileAsync(string data, string url, string classFile, string typeFile, string wppProvider)
        {
            try
            {
                _fileOptions.Root = string.IsNullOrEmpty(_fileOptions.Root) ? Environment.CurrentDirectory : _fileOptions.Root;
                string destinationFolder = string.Empty;
                string pathComplete = string.Empty;
                switch (typeFile.ToUpper())
                {
                    case "IMAGE":
                        destinationFolder = _fileOptions.PathImagenes;
                        break;
                    case "AUDIO":
                        destinationFolder = _fileOptions.PathAudios;
                        break;
                    case "VIDEO":
                        destinationFolder = _fileOptions.PathVideos;
                        break;
                    case "APPLICATION":
                    case "DOCUMENT":
                        destinationFolder = _fileOptions.PathDocumentos;
                        break;
                    case "STICKER":
                        destinationFolder = _fileOptions.PathSticker;
                        break;
                    default:
                        break;
                }
                string file = $"{Guid.NewGuid()}.{classFile.ToLower()}";
                string pathToSave = Path.Combine(_fileOptions.Root, destinationFolder);

                if (!Directory.Exists(pathToSave))
                {
                    Directory.CreateDirectory(pathToSave);
                }

                pathComplete = Path.Combine(pathToSave, file);
                if (wppProvider.Equals("GUPSHUP"))
                {
                    if (string.IsNullOrEmpty(url))
                    {
                        await File.WriteAllBytesAsync(pathComplete, Convert.FromBase64String(data));
                        return (_fileOptions.RootUrlPathDownload + file);
                    }
                    else
                    {
                        string _base64Url = await DownloadUrl(url);
                        await File.WriteAllBytesAsync(pathComplete, Convert.FromBase64String(_base64Url));
                        return (_fileOptions.RootUrlPathDownload + file);
                    }
                }
                else
                {
                    await File.WriteAllBytesAsync(pathComplete, Convert.FromBase64String(data));
                    return (_fileOptions.RootUrlPathDownload + file);
                }
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }
    }
}
