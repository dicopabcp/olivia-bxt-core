﻿namespace WPP.APPLICATION.CONNECTION.SERVICE.Services
{
    public interface IFileManager
    {
        Task<string> DownloadUrl(string url);
        Task<string> SaveFileAsync(string data, string url, string classFile, string typeFile, string wppProvider);
    }
}
