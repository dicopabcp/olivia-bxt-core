﻿using WPP.ABSTRACTION.ENTITIES.MessageApplication;
using WPP.ABSTRACTION.ENTITIES.SendMessageApplication;
using WPP.ABSTRACTION.ENTITIES.SendMessageApplicationGupshup;
using WPP.APPLICATION.COMMON.Extensions;

namespace WPP.APPLICATION.COMMON
{
    public static class SentCentralizerCommon
    {
        public static string validationContentInteractiveGupshup(string _content, string _typeContent)
        {
            string _response = string.Empty;    
            try
            {
                switch (_typeContent) 
                {
                    case "HEADER":
                        _response = _content.SubStringConditional(60);
                        break;
                    case "BODY":
                        _response = _content.SubStringConditional(1024);
                        break;
                    case "FOOTER":
                        _response = _content.SubStringConditional(1024);
                        break;
                    default:
                        break;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return _response;
        }
        public static SendMessageInteractiveText? validationFooterInteractive(MessageApplicationModel _request)
        {
            try
            {
                if (string.IsNullOrEmpty(_request.parametersInteractive.footer))
                    return null;
                else
                    return new SendMessageInteractiveText() { text = _request.parametersInteractive.footer.SubStringConditional(60) };
            }
            catch (Exception)
            {
                throw;
            }
        }
        public static SendMessageInteractiveText? validationBodyInteractive(MessageApplicationModel _request)
        {
            try
            {
                if (string.IsNullOrEmpty(_request.parametersInteractive.body))
                    return null;
                else
                    return new SendMessageInteractiveText() { text = _request.parametersInteractive.body.SubStringConditional(1024) };
            }
            catch (Exception)
            {
                throw;
            }
        }
        public static object? validationHeaderTemplateMessage(MessageApplicationModel _request)
        {
            try
            {
                if ((_request.parametersTemplate.classMessageTemplate ?? string.Empty).Equals("IMAGE"))
                {
                    SendMessageGushupTemplateImageRequest _templateImage = new();
                    _templateImage.type = "image";
                    _templateImage.image.link = _request.url ?? string.Empty;
                    return _templateImage;
                }
                if ((_request.parametersTemplate.classMessageTemplate ?? string.Empty).Equals("DOCUMENT"))
                {
                    SendMessageGushupTemplateDocumentRequest _templateDocument = new();
                    _templateDocument.type = "document";
                    _templateDocument.document.link = _request.url ?? string.Empty;
                    _templateDocument.document.filename = _request.nameMultimediaUrl ?? string.Empty;
                    return _templateDocument;

                }
                if ((_request.parametersTemplate.classMessageTemplate ?? string.Empty).Equals("VIDEO"))
                {
                    SendMessageGushupTemplateVideoRequest _templateVideo = new();
                    _templateVideo.type = "video";
                    _templateVideo.video.link = _request.url ?? string.Empty;
                    return _templateVideo;
                }
                if ((_request.parametersTemplate.classMessageTemplate ?? string.Empty).Equals("LOCATION"))
                {
                    SendMessageGushupTemplateLocationRequest _templateLocation = new();
                    _templateLocation.type = "location";
                    _templateLocation.location.longitude = 0;
                    _templateLocation.location.latitude = 0;
                    return _templateLocation;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        public static SendMessageTemplateHeader? validationHeaderTemplate(MessageApplicationModel _request)
        {
            SendMessageTemplateHeader? _response = new();
            try
            {
                switch (_request.parametersTemplate.classMessageTemplate)
                {
                    case "AUDIO":
                        _response.audio = new();
                        _response.audio.type = string.IsNullOrEmpty(_request.classMultimedia) ? "MP3" : _request.classMultimedia;
                        _response.audio.url = string.IsNullOrEmpty(_request.url) ? null : _request.url;
                        _response.audio.data = string.IsNullOrEmpty(_request.multimediaUrl) ? null : _request.multimediaUrl;
                        break;
                    case "IMAGE":
                        _response.image = new();
                        _response.image.type = string.IsNullOrEmpty(_request.classMultimedia) ? "JPG" : _request.classMultimedia;
                        _response.image.url = string.IsNullOrEmpty(_request.url) ? null : _request.url;
                        _response.image.data = string.IsNullOrEmpty(_request.multimediaUrl) ? null : _request.multimediaUrl;
                        break;
                    case "VIDEO":
                        _response.video = new();
                        _response.video.type = string.IsNullOrEmpty(_request.classMultimedia) ? "MP4" : _request.classMultimedia;
                        _response.video.url = string.IsNullOrEmpty(_request.url) ? null : _request.url;
                        _response.video.data = string.IsNullOrEmpty(_request.multimediaUrl) ? null : _request.multimediaUrl;
                        break;
                    case "DOCUMENT":
                        _response.document = new();
                        _response.document.type = string.IsNullOrEmpty(_request.classMultimedia) ? "PDF" : _request.classMultimedia;
                        _response.document.url = string.IsNullOrEmpty(_request.url) ? null : _request.url;
                        _response.document.data = string.IsNullOrEmpty(_request.multimediaUrl) ? null : _request.multimediaUrl;
                        break;
                    default:
                        _response = null;
                        break;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return _response;
        }
        public static SendMessageInteractiveHeader? validationHeaderInterative(MessageApplicationModel _request)
        {
            SendMessageInteractiveHeader? _response = new();
            try
            {
                if (_request.classInteractive == "LIST" && _request.classInteractive is not null)
                {
                    if (string.IsNullOrEmpty(_request.message))
                        return null;
                    _response.text = _request.message.SubStringConditional(60);
                }
                else if (_request.classInteractive == "REPLY_BUTTON" && _request.classInteractive is not null)
                {
                    switch (_request.parametersInteractive.classMessageInteractive)
                    {
                        case "TEXT":
                            if (string.IsNullOrEmpty(_request.message))
                                return null;
                            _response.text = _request.message.SubStringConditional(60);
                            break;
                        case "IMAGE":
                            _response.image = new();
                            _response.image.type = string.IsNullOrEmpty(_request.classMultimedia) ? "JPG" : _request.classMultimedia;
                            _response.image.url = string.IsNullOrEmpty(_request.url) ? null : _request.url;
                            _response.image.data = string.IsNullOrEmpty(_request.multimediaUrl) ? null : _request.multimediaUrl;
                            break;
                        case "VIDEO":
                            _response.video = new();
                            _response.video.type = string.IsNullOrEmpty(_request.classMultimedia) ? "MP4" : _request.classMultimedia;
                            _response.video.url = string.IsNullOrEmpty(_request.url) ? null : _request.url;
                            _response.video.data = string.IsNullOrEmpty(_request.multimediaUrl) ? null : _request.multimediaUrl;
                            break;
                        case "DOCUMENT":
                            _response.document = new();
                            _response.document.type = string.IsNullOrEmpty(_request.classMultimedia) ? "PDF" : _request.classMultimedia;
                            _response.document.url = string.IsNullOrEmpty(_request.url) ? null : _request.url;
                            _response.document.data = string.IsNullOrEmpty(_request.multimediaUrl) ? null : _request.multimediaUrl;
                            break;
                        case "LOCATION":
                            _response.location = new();
                            _response.location.geoPoint = _request.parameterMessage[0].ToString();
                            _response.location.name = _request.parameterMessage[1].ToString();
                            _response.location.address = _request.parameterMessage[2].ToString();
                            break;
                        default:
                            _response = null;
                            break;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return _response;
        }
    }
}