﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPP.APPLICATION.COMMON.Extensions
{
    public static class StringExtensions
    {
        public static string SubStringConditional(this string value, int len)
        {
            return string.IsNullOrEmpty(value) ? string.Empty : value.Length > len ? value.Substring(0, len) : value;
        }
    }
}
