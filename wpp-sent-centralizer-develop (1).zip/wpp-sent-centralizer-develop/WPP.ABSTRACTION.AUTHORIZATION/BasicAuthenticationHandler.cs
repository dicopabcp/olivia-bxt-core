﻿using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text.Encodings.Web;
using System.Text;
using WPP.ABSTRACTION.ENTITIES.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Logging;

namespace WPP.ABSTRACTION.AUTHORIZATION
{
    public class BasicAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
    {
        private readonly IManagerUserService _userService;
        public BasicAuthenticationHandler(
            IOptionsMonitor<AuthenticationSchemeOptions> options,
            ILoggerFactory logger,
            UrlEncoder encoder,
            ISystemClock clock,
            IManagerUserService userService)
            : base(options, logger, encoder, clock)
        {
            this._userService = userService;
        }
        protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            try
            {
                AuthorizationRequest _request = new();
                var authHeader = AuthenticationHeaderValue.Parse(Request.Headers["Authorization"].FirstOrDefault() ?? string.Empty);
                var credentialBytes = Convert.FromBase64String(authHeader.Parameter ?? string.Empty);
                var credentials = Encoding.UTF8.GetString(credentialBytes).Split(new[] { ':' }, 2);
                var username = credentials[0];
                var password = credentials[1];
                _request.channel = Request.Headers["channel"].FirstOrDefault() ?? string.Empty;
                _request.publicToken = Request.Headers["publicToken"].FirstOrDefault() ?? string.Empty;
                _request.appUserId = Request.Headers["appUserId"].FirstOrDefault() ?? string.Empty;
                BasicAutorizacionModel? user = await this._userService.Authenticate(username, password, _request);
                if (user == null)
                    return AuthenticateResult.Fail("Invalid Username or Password");
                try
                {
                    var claims = new[] {
                    new Claim(ClaimTypes.NameIdentifier, user.id.ToString()),
                    new Claim(ClaimTypes.Name, user.userName)};
                    var identity = new ClaimsIdentity(claims, Scheme.Name);
                    var principal = new ClaimsPrincipal(identity);
                    var ticket = new AuthenticationTicket(principal, Scheme.Name);

                    return AuthenticateResult.Success(ticket);
                }
                catch (Exception)
                {
                    return AuthenticateResult.Fail("Invalid Authorization Header");
                }
            }
            catch (Exception)
            {
                return AuthenticateResult.Fail("Invalid Authorization Header");
            }
        }
    }
}