﻿using WPP.ABSTRACTION.ENTITIES.SendMessageApplication;
using WPP.ABSTRACTION.ENTITIES.SendMessageApplicationGupshup;

namespace WPP.ABSTRACTION.ENTITIES.MessageApplication
{
    public class MessageApplicationModel
    {
        public string? message { get; set; } // MENSAJE DE TEXTO A ENVIAR 
        public string? typeMessage { get; set; }  // TIPO DE MENSAJE EJ: TEXT, IMAGE, AUDIO, VIDEO, DOCUMENT, LOCATION, CONTACTS, HSM, TEMPLATE, INTERACTIVE, STICKER
        public string? classMultimedia { get; set; }  // EXTENSION DEL ARCHIVO MULTIMEDIA EJ: IMAGE (JPG, JPEG, PNG) AUDIO (ACC, AMR, MP3(MPEG), OGG) : VIDEO (MP4) : DOCUMENT (PDF) 
        public string? classInteractive { get; set; }  // INTERACTIVE (LIST, REPLY_BUTTON)
        public List<string> cellphone { get; set; } = new List<string>(); // LISTA DE CELULARES PARA ENVIAR EL MENSAJE EJ: 59175806163
        public string? destinationAccount { get; set; } = string.Empty; // NUMERO DE CELULAR DE LA CUENTA AL QUE VA EL MENSAJE EJ: 
        public bool identifyChatBot { get; set; }   // IDENTIFICADOR DE SI EL MENSAJE ES DEL OPERADOR O DEL BOT
        public string? multimediaUrl { get; set; }    //  BASE 64 ARCHIVO MULTIMEDIA DE TIPO: IMAGEN, AUDIO, VIDEO, DOCUMENTO
        public string? url { get; set; }    // URL DEL ARCHIVO MULTIMEDIA DE TIPO: IMAGEN, AUDIO, VIDEO, DOCUMENTO
        public string? nameMultimediaUrl { get; set; }    // NOMBRE CON EL QUE SE ENVIARA EL ARVHIVO MULTIMEDIA (IMAGE, VIDEO, DOCUMENT)
        public string? user { get; set; }  // USUARIO QUE REALIZA EL ENVIO DEL MENSAJE
        public string? nameUser { get; set; }  // NOMBRE DEL USUARIO QUE REALIZA EL ENVIO DEL MENSAJE
        public List<string> parameterMessage { get; set; } = new List<string>();    //  LISTA DE PARAMETROS PARA LA CLASE DE MENSAJE DE TIPO HSM, TEMPLATE, LOCATION, 
        public string nameHsmOfTemplate { get; set; } = string.Empty;    //  NOMBRE DE LA CLASE DE MENSAJE HSM, TEMPLATE
        public string? campaignName { get; set; }     //  NOMBRE DE LA CAMPAÑA PARA EL ENVIO DEL MENSAJE
        public MessageInteractiveModel parametersInteractive { get; set; } = new MessageInteractiveModel(); // PARAMETROS PARA EL ENVIO DE MENSAJES INTERACTIVOS 
        public MessageTemplateModel parametersTemplate { get; set; } = new MessageTemplateModel();
        public string? classMessageCtaUrlHeader { get; set; }  // TIPO DE HEADER OPCIONAL PARA MENSAJE CTA_URL: IMAGE, VIDEO
        public string? urlHeaderCtaUrl { get; set; }  // URL DEL HEADER (IMAGEN O VIDEO) OPCIONAL PARA MENSAJE CTA_URL
        public string? cardHeaderTypeCarousel { get; set; }  // TIPO DE HEADER DE LAS TARJETAS PARA MENSAJE CAROUSEL: IMAGE, VIDEO
        public List<CarouselCardRequest> cardsCarousel { get; set; } = new List<CarouselCardRequest>();  // LISTA DE TARJETAS (MEDIA + POSTBACK TEXTS OPCIONALES) PARA MENSAJE CAROUSEL
    }
}