﻿namespace WPP.ABSTRACTION.ENTITIES.MessageApplication
{
    public class MessageWhatsAppModel
    {
        public int messageId { get; set; }
        public string codeClient { get; set; } = string.Empty;
        public string cellphone { get; set; } = string.Empty;
        public string message { get; set; } = string.Empty;
        public string typeMessage { get; set; } = string.Empty;
        public string codeTypeMessage { get; set; } = string.Empty;
        public string stateMessage { get; set; } = string.Empty;
        public string jsonClient { get; set; } = string.Empty;
        public string? user { get; set; } = string.Empty;
        public string? nameUser { get; set; } = string.Empty;
        public bool whatsAppBot { get; set; }
        public DateTime dateRequest { get; set; }
        public DateTime timeRequest { get; set; }
        public string? campaign { get; set; } = string.Empty;
        public int login { get; set; }
        public string? messageClass { get; set; } = string.Empty;
        public DateTime dateDelivered { get; set; }
        public DateTime dateRead { get; set; }
        public string? multimedia { get; set; } = string.Empty;
    }
}
