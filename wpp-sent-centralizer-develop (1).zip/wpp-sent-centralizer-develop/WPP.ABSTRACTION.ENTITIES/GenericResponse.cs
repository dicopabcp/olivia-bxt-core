﻿namespace WPP.ABSTRACTION.ENTITIES
{
    public class GenericResponse
    {
        public bool success { get; set; }
        public string message { get; set; } = string.Empty;
        public string code { get; set; } = string.Empty;
        public MessageInformation data { get; set; } = new MessageInformation();
    }
    public class MessageInformation
    {
        public int messageId { get; set; }
        public string messageCode { get; set; } = string.Empty;
        public string cellphone { get; set; } = string.Empty;
        public DateTime dateDelivered { get; set; }
        public string? multimedia { get; set; } = string.Empty;
        public string? messageClass { get; set; } = string.Empty;
    }
}