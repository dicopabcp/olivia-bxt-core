﻿
namespace WPP.ABSTRACTION.ENTITIES.SendWhatsApp
{
    public class SendMessageWhatsApp
    {
        public string urlSendMessage { get; set; } = string.Empty;
        public string methodSndMessage { get; set; } = string.Empty;
    }
}
