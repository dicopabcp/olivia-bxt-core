﻿
namespace WPP.ABSTRACTION.ENTITIES.SendMessageApplicationGupshup
{
    public class SendMessageApplicationGupshupResponse
    {
        public string? status { get; set; } = string.Empty;
        public string? messageId { get; set; } = string.Empty;
    }
}
