﻿
namespace WPP.ABSTRACTION.ENTITIES.SendMessageApplicationGupshup
{
    public class SendMessageApplicationAuthentication
    {
        public List<SendMessageApplicationParameter> sendApplicationParameters { get; set; } = new List<SendMessageApplicationParameter>();
    }

    public class SendMessageApplicationParameter
    {
        public string sourceAccount { get; set; } = string.Empty;
        public string providerWhatsApp { get; set; } = string.Empty;
        public string userProvider { get; set; } = string.Empty;
        public string apiKeyProvider { get; set; } = string.Empty;
        public string appKeyProvider { get; set; } = string.Empty;
        public string channel { get; set; } = string.Empty;
        public bool disablePreview { get; set; }
        public bool encode { get; set; }
    }

}
