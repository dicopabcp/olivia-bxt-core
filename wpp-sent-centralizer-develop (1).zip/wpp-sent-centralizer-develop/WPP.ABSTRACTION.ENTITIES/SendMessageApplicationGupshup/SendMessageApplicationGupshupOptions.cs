﻿namespace WPP.ABSTRACTION.ENTITIES.SendMessageApplicationGupshup
{
    public class SendMessageApplicationGupshupOptions
    {
        public string urlSendMessageGushup { get; set; } = string.Empty;
        public string methodSendMessageGushup { get; set; } = string.Empty;
        public string methodSendMessageTemplateGushup { get; set; } = string.Empty;
    }
}