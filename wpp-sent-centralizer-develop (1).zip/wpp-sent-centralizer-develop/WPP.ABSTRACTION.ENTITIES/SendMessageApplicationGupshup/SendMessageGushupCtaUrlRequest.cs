namespace WPP.ABSTRACTION.ENTITIES.SendMessageApplicationGupshup
{
    // CTA URL MESSAGE (MENSAJE DE SESION, BOTON UNICO QUE ABRE UNA URL - docs.gupshup.io/reference/cta-url)
    public class SendMessageGushupCtaUrlRequest : SendMessageApplicationGupshupRequest
    {
        public string body { get; set; } = string.Empty;
        public string display_text { get; set; } = string.Empty;
        public string url { get; set; } = string.Empty;
        public string? footer { get; set; }
        public SendMessageGushupCtaUrlHeader? header { get; set; }
    }
    public class SendMessageGushupCtaUrlHeader
    {
        public string type { get; set; } = string.Empty;
        public SendMessageGushupTemplate? image { get; set; }
        public SendMessageGushupTemplate? video { get; set; }
    }
}
