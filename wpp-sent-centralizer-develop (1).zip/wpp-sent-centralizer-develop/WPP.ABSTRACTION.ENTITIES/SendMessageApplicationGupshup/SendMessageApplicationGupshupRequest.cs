﻿namespace WPP.ABSTRACTION.ENTITIES.SendMessageApplicationGupshup
{
    // TYPE MESSAGE
    public class SendMessageApplicationGupshupRequest
    {
        public string type { get; set; } = string.Empty;
    }
    // TEXT MESSAGE
    public class SendMessageGupshupTextRequest : SendMessageApplicationGupshupRequest
    {
        public string text { get; set; } = string.Empty;
    }
    // IMAGE MESSAGE
    public class SendMessageGupshupImageRequest : SendMessageApplicationGupshupRequest
    {
        public string originalUrl { get; set; } = string.Empty;
        public string previewUrl { get; set; } = string.Empty;
        public string caption { get; set; } = string.Empty;
    }
    // FILE MESSAGE
    public class SendMessageGupshupDocumentRequest : SendMessageApplicationGupshupRequest 
    {
        public string url { get; set; } = string.Empty;
        public string filename { get; set; } = string.Empty;
    }
    // AUDIO MESSAGE
    public class SendMessageGupshupAudioRequest : SendMessageApplicationGupshupRequest
    {
        public string url { get; set; } = string.Empty;
    }
    // VIDEO MESSAGE
    public class SendMessageGupshupVideoRequest : SendMessageApplicationGupshupRequest
    {
        public string url { get; set; } = string.Empty;
        public string caption { get; set; } = string.Empty;
    }
    // STICKER MESSAGE
    public class SendMessageGupshupStickerRequest : SendMessageApplicationGupshupRequest
    {
        public string url { get; set; } = string.Empty;
    }
    // LOCATION MESSAGE
    public class SendMessageGupshuplocationRequest : SendMessageApplicationGupshupRequest
    {
        public double longitude { get; set; }
        public double latitude { get; set; }
        public string name { get; set; } = string.Empty;
        public string address { get; set; } = string.Empty;
    }
    // INTERACTIVE LIST MESSAGE
    public class SendMessageGushupInteractiveListRequest : SendMessageApplicationGupshupRequest
    {
        public string title { get; set; } = string.Empty;
        public string body { get; set; } = string.Empty;
        public string msgid { get; set; } = string.Empty;
        public List<InteractiveListButtons> globalButtons { get; set; } = new List<InteractiveListButtons>();
        public List<InteractiveListItems> items { get; set; } = new List<InteractiveListItems>();

    }
    public class InteractiveListButtons
    {
        public string type { get; set; } = string.Empty;
        public string title { get; set; } = string.Empty;
    }
    public class InteractiveListItems
    {
        public string title { get; set; } = string.Empty;
        public string subtitle { get; set; } = string.Empty;
        public List<InteractiveListOptions> options { get; set; } = new List<InteractiveListOptions>();
    }
    public class InteractiveListOptions
    {
        public string? type { get; set; } = string.Empty;
        public string? title { get; set; } = string.Empty;
        public string? description { get; set; } = string.Empty;
        public string? postbackText { get; set; } = string.Empty;
    }
    // INTERACTIVE QUICK RESPONSE MESSAGE
    public class SendMessageGushupInteractiveQuickRequest<T> : SendMessageApplicationGupshupRequest
    {
        public string msgid { get; set; } = string.Empty;
        public T? content { get; set; }
        public List<InteractiveListOptions> options { get; set; } = new List<InteractiveListOptions>();

    }
    public class InteractiveQuick
    {
        public string? type { get; set; } = string.Empty;
        public string? text { get; set; } = string.Empty;
        public string? caption { get; set; } = string.Empty;
    }
    public class InteractiveQuickContentText : InteractiveQuick
    {
        public string? header { get; set; } = string.Empty;
    }
    public class InteractiveQuickContentImage : InteractiveQuick
    {
        public string url { get; set; } = string.Empty;
    }
    public class InteractiveQuickContentVideo : InteractiveQuick
    {
        public string url { get; set; } = string.Empty;
    }
    public class InteractiveQuickContentFile : InteractiveQuick
    {
        public string url { get; set; } = string.Empty;
        public string filename { get; set; } = string.Empty;
    }
    public class InteractiveQuickOptions
    {
        public string type { get; set; } = string.Empty;
        public string title { get; set; } = string.Empty;
        public string postbackText { get; set; } = string.Empty;
    }
    // TEMPLATE MESSAGE TEXT
    public class SendMessageGushupTemplateRequest
    {
        public string id { get; set; } = string.Empty;
        public List<string> @params {get;set;} = new List<string>();
    }
    // TEMPLATE MESSAGE IMAGE 
    public class SendMessageGushupTemplateImageRequest : SendMessageApplicationGupshupRequest
    {
        public SendMessageGushupTemplate image { get; set; } = new SendMessageGushupTemplate();
    }
    public class SendMessageGushupTemplate
    {
        public string link { get; set; } = string.Empty;
    }
    // TEMPLATE MESSAGE DOCUMENT 
    public class SendMessageGushupTemplateDocumentRequest : SendMessageApplicationGupshupRequest
    {
        public SendMessageGushupTemplateDocument document { get; set; } = new SendMessageGushupTemplateDocument();
    }
    public class SendMessageGushupTemplateDocument
    {
        public string link { get; set; } = string.Empty;
        public string filename { get; set; } = string.Empty;
    }
    // TEMPLATE MESSAGE VIDEO 
    public class SendMessageGushupTemplateVideoRequest : SendMessageApplicationGupshupRequest
    {
        public SendMessageGushupTemplate video { get; set; } = new SendMessageGushupTemplate();
    }
    // TEMPLATE MESSAGE LOCATION 
    public class SendMessageGushupTemplateLocationRequest : SendMessageApplicationGupshupRequest
    {
        public SendMessageGushupTemplateLocation location = new SendMessageGushupTemplateLocation();
    }
    public class SendMessageGushupTemplateLocation
    {
        public double longitude { get; set; }
        public double latitude { get; set; }
    }
}
