namespace WPP.ABSTRACTION.ENTITIES.SendMessageApplicationGupshup
{
    // CAROUSEL MESSAGE (SOLO DISPONIBLE VIA TEMPLATE - docs.gupshup.io/reference/sending-carousel-template-1)
    public class SendMessageGushupCarouselRequest : SendMessageApplicationGupshupRequest
    {
        public string cardHeaderType { get; set; } = string.Empty;
        public List<CarouselCardRequest> cards { get; set; } = new List<CarouselCardRequest>();
    }
    public class CarouselCardRequest
    {
        public string? id { get; set; }
        public string? link { get; set; }
        public List<CarouselPostbackTextRequest>? postbackTexts { get; set; }
    }
    public class CarouselPostbackTextRequest
    {
        public int index { get; set; }
        public string text { get; set; } = string.Empty;
    }
}
