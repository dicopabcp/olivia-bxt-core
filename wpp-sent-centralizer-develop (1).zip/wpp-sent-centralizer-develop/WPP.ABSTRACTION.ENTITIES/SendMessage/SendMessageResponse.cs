﻿
namespace WPP.ABSTRACTION.ENTITIES.SendMessage
{
    public class SendMessageResponse
    {
        public string id { get; set; } = string.Empty;
        public List<SendMessageDestinationsResponse> destinations { get; set; } = new List<SendMessageDestinationsResponse>();
    }
    public class SendMessageDestinationsResponse
    {
        public string id { get; set; } = string.Empty;
        public string correlationId { get; set; } = string.Empty;
        public string destination { get; set; } = string.Empty;
    }
}
