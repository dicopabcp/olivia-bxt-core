﻿namespace WPP.ABSTRACTION.ENTITIES.SendMessageApplication
{
    // OBJETO PRINCIPAL DATO CELULAR DE ENVIO
    public class SendMessageApplication
    {
        public List<SendMessageDestinations> destinations { get; set; } = new List<SendMessageDestinations>();
        public string? flowId { get; set; }
        public string? defaultExtraInfo { get; set; }
        public string? campaignAlias { get; set; }
    }
    public class SendMessageDestinations
    {
        public string correlationId { get; set; } = string.Empty;
        public string destination { get; set; } = string.Empty;
    }

    // OBJETO PARA EL ENVIO DE MENSAJES DE TIPO TEXTO 
    public class SendMessageTextRequest : SendMessageApplication
    {
        public SendMessageDataText message { get; set; } = new SendMessageDataText();
    }
    public class SendMessageDataText
    {
        public string messageText { get; set; } = string.Empty;
    }

    // OBJETO PARA EL ENVIO DE MENSAJES DE TIPO IMAGEN FORMATOS PERMITIDOS (JPG, JPEG, PNG)
    public class SendMessageImageRequest : SendMessageApplication
    {
        public SendMessageDataImage message { get; set; } = new SendMessageDataImage();
    }
    public class SendMessageDataImage
    {
        public SendMessageType image { get; set; } = new SendMessageType();
    }

    // OBJETO PARA EL ENVIO DE MENSAJES DE TIPO AUDIO FORMATOS PERMITIDOS (AAC, MP3, AMR, OGG)
    public class SendMessageAudioRequest : SendMessageApplication
    {
        public SenMessageDataAudio message { get; set; } = new SenMessageDataAudio();
    }
    public class SenMessageDataAudio
    {
        public SendMessageType audio { get; set; } = new SendMessageType();
    }

    // OBJETO PARA EL ENVIO DE MENSAJES DE TIPO VIDEO FORMATOS PERMITIDOS (MP4)
    public class SendMessageVideoRequest : SendMessageApplication
    {
        public SendMessageDataVideo message { get; set; } = new SendMessageDataVideo();
    }
    public class SendMessageDataVideo
    {
        public SendMessageType video { get; set; } = new SendMessageType();
    }

    // OBJETO PARA EL ENVIO DE MENSAJES DE TIPO DOCUMENTO FORMATOS PERMITIDOS (PDF)
    public class SendMessageDocumentRequest : SendMessageApplication
    {
        public SendMessageDataDocument message { get; set; } = new SendMessageDataDocument();
    }
    public class SendMessageDataDocument
    {
        public SendMessageType document { get; set; } = new SendMessageType();
    }

    // OBJETO PARA EL ENVIO DE MENSAJES DE TIPO UBICACION 
    public class SendMessageLocationRequest : SendMessageApplication
    {
        public SendMessageDataLocation message { get; set; } = new SendMessageDataLocation();
    }
    public class SendMessageDataLocation
    {
        public SendMessageLocation location { get; set; } = new SendMessageLocation();
    }

    // OBJETO PARA EL ENVIO DE MENSAJES DE TIPO CONTACTO
    public class SendMessageContactsRequest : SendMessageApplication
    {
        public SendMessageDataContacts message { get; set; } = new SendMessageDataContacts();
    }
    public class SendMessageDataContacts
    {
        public List<SendMessageContact> contacts { get; set; } = new List<SendMessageContact>();
    }

    // OBJETO PARA EL ENVIO DE MENSAJES DE TIPO HSM 
    public class SendMessageHsmRequest : SendMessageApplication
    {
        public SendMessageDataHsm message { get; set; } = new SendMessageDataHsm();
    }
    public class SendMessageDataHsm
    {
        public int ttl { get; set; } = 7;
        public SendMessageHsm hsm { get; set; } = new SendMessageHsm();
    }

    // OBJETO PARA EL ENVIO DE MENSAJES DE TIPO TEMPLATE
    public class SendMessageTemplateRequest : SendMessageApplication
    {
        public SendMessageDataTemplate message { get; set; } = new SendMessageDataTemplate();
    }
    public class SendMessageDataTemplate
    {
        public int ttl { get; set; } = 7;
        public SendMessageTemplate template { get; set; } = new SendMessageTemplate();
    }

    //OBJETO PARA EL ENVIO DE MENSAJES DE TIPO INTERACTIVO BOTONES 
    public class SendMessageInteractiveRequest : SendMessageApplication
    {
        public SendMessageDataInteractive message { get; set; } = new SendMessageDataInteractive();
    }
    public class SendMessageDataInteractive
    {
        public SendMessageInteractive interactive { get; set; } = new SendMessageInteractive();
    }











    public class SendMessageApplicationRequest
    {
        public List<SendMessageDestinations> destinations { get; set; } = new List<SendMessageDestinations>();
        public SendMessageData message { get; set; } = new SendMessageData();
        public string campaignAlias { get; set; } = string.Empty;
    }


    public class SendMessageData
    {
        public string messageText { get; set; } = string.Empty;
        public SendMessageType? image { get; set; }
        public SendMessageType? video { get; set; }
        public SendMessageType? audio { get; set; }
        public SendMessageType? document { get; set; }
        public List<SendMessageContact>? contacts { get; set; }
        public SendMessageLocation? location { get; set; }
        public SendMessageHsm? hsm { get; set; }
        public SendMessageTemplate? template { get; set; }
    }
    public class SendMessageTemplate
    {
        public string @namespace { get; set; } = string.Empty;
        public string elementName { get; set; } = string.Empty;
        public SendMessageTemplateHeader? header { get; set; }
        public List<string> bodyParameters { get; set; } = new List<string>();
        public string languagePolicy { get; set; } = string.Empty;
        public string languageCode { get; set; } = string.Empty;
    }

    public class SendMessageInteractive
    {
        public string? messageInteractiveType { get; set; } = string.Empty;
        public SendMessageInteractiveHeader? header { get; set; } = new SendMessageInteractiveHeader();
        public SendMessageInteractiveText? body { get; set; } = new SendMessageInteractiveText();
        public SendMessageInteractiveText? footer { get; set; } = new SendMessageInteractiveText();
        public ListButtonAction? listAction { get; set; } = new ListButtonAction();
        public ReplyButtonAction? replyButtonAction { get; set; } = new();
        public string? alternativeText { get; set; }
    }

    public class ReplyButtonAction
    {
        public List<ButtonReply>? buttons { get; set; } = new();
    }

    public class ButtonReply
    {
        public Reply? reply { get; set; }
    }
    public class Reply
    {
        public string title { get; set; } = string.Empty;
        public string payload { get; set; } = string.Empty;
    }
    public class SendMessageInteractiveHeader
    {
        public string? text { get; set; }
        public SendMessageUrl? image { get; set; } 
        public SendMessageUrl? video { get; set; } 
        public SendMessageUrl? document { get; set; } 
        public SendMessageLocation? location { get; set; } 
    }

    public class SendMessageInteractiveText
    {
        public string? text { get; set; } = string.Empty;
    }

    public class ButtonTemplate
    {
        public string type { get; set; } = string.Empty;

        public string url { get; set; } = string.Empty;

        public string replyPayload { get; set; } = string.Empty;
    }

    public class ButtonInteractive
    {
        public string title { get; set; } = string.Empty;

        public string payload { get; set; } = string.Empty;
    }
    public class SendMessageTemplateHeader
    {
        public List<string>? parameters { get; set; }
        public string? title { get; set; }
        public SendMessageUrl? image { get; set; }
        public SendMessageUrl? audio { get; set; }
        public SendMessageUrl? document { get; set; }
        public SendMessageUrl? video { get; set; }
    }
    public class SendMessageType
    {
        public string? type { get; set; }
        public string? url { get; set; } = null;
        public string? data { get; set; } = null;
        public string? caption { get; set; } = null;
    }
    public class SendMessageHsm
    {
        public string @namespace { get; set; } = string.Empty;
        public string elementName { get; set; } = string.Empty;
        public List<string> parameters { get; set; } = new List<string>();
        public string? languagePolicy { get; set; }
        public string languageCode { get; set; } = string.Empty;
    }
    public class SendMessageContact
    {
        public List<SendMessageAddress> addresses { get; set; } = new List<SendMessageAddress>();
        public string birthday { get; set; } = string.Empty;
        public List<SendMessageEmail> emails { get; set; } = new List<SendMessageEmail>();
        public SendMessageName name { get; set; } = new SendMessageName();
        public SendMessageOrg org { get; set; } = new SendMessageOrg();
        public List<SendMessagePhone> phones { get; set; } = new List<SendMessagePhone>();
        public List<SendMessageUrl> urls { get; set; } = new List<SendMessageUrl>();
    }
    public class SendMessageLocation
    {
        public string geoPoint { get; set; } = string.Empty;
        public string name { get; set; } = string.Empty;
        public string address { get; set; } = string.Empty;
    }
    public class SendMessageAddress
    {
        public string street { get; set; } = string.Empty;
        public string city { get; set; } = string.Empty;
        public string state { get; set; } = string.Empty;
        public string zip { get; set; } = string.Empty;
        public string country { get; set; } = string.Empty;
        public string country_code { get; set; } = string.Empty;
        public string type { get; set; } = string.Empty;
    }
    public class SendMessageEmail
    {
        public string email { get; set; } = string.Empty;
        public string type { get; set; } = string.Empty;
    }
    public class SendMessageName
    {
        public string first_name { get; set; } = string.Empty;
        public string last_name { get; set; } = string.Empty;
        public string formatted_name { get; set; } = string.Empty;
    }
    public class SendMessageOrg
    {
        public string company { get; set; } = string.Empty;
        public string department { get; set; } = string.Empty;
        public string title { get; set; } = string.Empty;
    }
    public class SendMessagePhone
    {
        public string phone { get; set; } = string.Empty;
        public string type { get; set; } = string.Empty;
    }
    public class SendMessageUrl
    {
        public string? url { get; set; }
        public string? type { get; set; }
        public string? data { get; set; }
    }

    public class ListButtonAction
    {
        public string? button { get; set; }
        public List<SectionsButton>? sections { get; set; }

    }

    public class SectionsButton
    {
        public List<InteractiveParameterModel>? rows { get; set; }
    }


    public class MessageTemplateModel
    {
        public string? classMessageTemplate { get; set; } = string.Empty;
    }

    public class MessageInteractiveModel
    {
        public string nameSelectorButton { get; set; } = string.Empty;
        public string? classMessageInteractive { get; set; } = string.Empty;
        public string? header { get; set; }
        public string? body { get; set; }
        public string? footer { get; set; }
        public List<InteractiveParameterModel> parameters { get; set; } = new List<InteractiveParameterModel>();
        public string? alternativeText { get; set; }
    }
    public class InteractiveParameterModel
    {
        public string? title { get; set; }
        public string? description { get; set; }
        public string? identifier { get; set; }
    }
}
