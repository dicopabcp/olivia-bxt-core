﻿
namespace WPP.ABSTRACTION.ENTITIES.Authorization
{
    public class AuthenticationOptions
    {
        public string urlAuthentication { get; set; } = string.Empty;
        public string methodAuthentication { get; set; } = string.Empty;
    }
}
