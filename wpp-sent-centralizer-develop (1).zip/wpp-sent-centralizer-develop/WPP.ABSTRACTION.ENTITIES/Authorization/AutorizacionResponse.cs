﻿
namespace WPP.ABSTRACTION.ENTITIES.Authorization
{
    public class AutorizacionResponse
    {
        public string state { get; set; } = string.Empty;
        public string message { get; set; } = string.Empty;
        public AutorizacionData data { get; set; } = new AutorizacionData();
    }
    public class AutorizacionData
    {
        public int id { get; set; }
        public string username { get; set; } = string.Empty;
        public string publicToken { get; set; } = string.Empty;
        public string status { get; set; } = string.Empty;
        public string date { get; set; } = string.Empty;
    }
}
