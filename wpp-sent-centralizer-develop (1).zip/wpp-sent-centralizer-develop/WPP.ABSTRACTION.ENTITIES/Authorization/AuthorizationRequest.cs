﻿
namespace WPP.ABSTRACTION.ENTITIES.Authorization
{
    public class AuthorizationRequest
    {
        public string date { get; set; } = string.Empty;
        public string channel { get; set; } = string.Empty;
        public string publicToken { get; set; } = string.Empty;
        public string appUserId { get; set; } = string.Empty;
    }
}
