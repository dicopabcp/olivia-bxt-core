﻿namespace WPP.ABSTRACTION.ENTITIES.ParameterMessage
{
    public class ParameterMessageModel
    {
        public string hsmNamespace { get; set; } = string.Empty;
        public string hsmLanguageCode { get; set; } = string.Empty;
        public string templateNamespace { get; set; } = string.Empty;
        public string templateLanguagePolicy { get; set; } = string.Empty;
        public string templateLanguageCode { get; set; } = string.Empty;
    }

}
