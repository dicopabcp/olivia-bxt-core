﻿namespace WPP.ABSTRACTION.ENTITIES.Options
{
    public class FileManagementOptions
    {
        public string Root { get; set; } = string.Empty;
        public string RootUrlPath { get; set; } = string.Empty;
        public string RootUrlPathDownload { get; set; } = string.Empty;
        public string RequestPath { get; set; } = string.Empty;
        public string PathImagenes { get; set; } = string.Empty;
        public string PathAudios { get; set; } = string.Empty;
        public string PathVideos { get; set; } = string.Empty;
        public string PathDocumentos { get; set; } = string.Empty;
        public string PathSticker { get; set; } = string.Empty;
    }
}
