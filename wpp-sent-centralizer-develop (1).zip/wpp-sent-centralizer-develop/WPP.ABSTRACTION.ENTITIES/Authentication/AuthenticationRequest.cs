﻿
namespace WPP.ABSTRACTION.ENTITIES.Authentication
{
    public class AuthenticationRequest
    {
        public string userWhatsAppProvider { get; set; } = string.Empty;
        public string tokenWhatsAppProvider { get; set; } = string.Empty;
    }
}
