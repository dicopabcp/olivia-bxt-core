using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.FileProviders;
using Microsoft.OpenApi.Models;
using WPP.ABSTRACTION.AUTHORIZATION;
using WPP.ABSTRACTION.DATAACCESS;
using WPP.ABSTRACTION.ENTITIES.Authentication;
using WPP.ABSTRACTION.ENTITIES.Options;
using WPP.ABSTRACTION.ENTITIES.SendMessageApplicationGupshup;
using WPP.ABSTRACTION.ENTITIES.SendWhatsApp;
using WPP.ABSTRACTION.LOGGER;
using WPP.ABSTRACTION.SECRYPT;
using WPP.APPLICATION.BUSSINESS;
using WPP.APPLICATION.CONNECTION.DATABASE;
using WPP.APPLICATION.CONNECTION.SERVICE;
using WPP.APPLICATION.CONNECTION.SERVICE.RestConnectionService;
using WPP.APPLICATION.CONNECTION.SERVICE.Services;

const string _sectionNameEndpointAddessAuthenticationApi = "Authentication.Api";
const string _sectionNameEndpointAddressSendMessageWhatsApp = "Connection.SendMessage.Api";
const string _sectionNameFileDirectory = "File.Directory";
const string _sectionNameEndpointAddressSendMessageWhatsAppGushup = "Connection.SendMessage.Gushup.Api";
const string _sectionNameAuthenticationSendMessageWhatsApp = "Parameter.Source.Provider.WhatsApp";

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Api Centralizador Mensajes Enviados WSP",
        Version = "v1",
        Description = "Api para el envio de mensajes a travez de whatsapp.",
        Contact = new OpenApiContact
        {
            Name = "Canales Presenciales",
            Email = "BolCanPres@bancred.com.bo",
            Url = new Uri("http://intranetbcp/"),
        }
    });
    c.OperationFilter<CustomHeaderSwaggerAttribute>();
    c.AddSecurityDefinition("basic", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "basic",
        In = ParameterLocation.Header,
        Description = "Basic Authorization header using the Bearer scheme."
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement { { new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "basic" } }, new string[] { } } });
});
builder.Services.AddLogger();
builder.Services.AddDataBase();
builder.Services.AddSecrypt();

builder.Services.AddHttpContextAccessor();

builder.Services.AddSingleton<ISentCentralizerConnection, SentCentralizerConnection>();
builder.Services.AddSingleton<ISendMessageService, SendMessageService>();
builder.Services.AddSingleton<ISendCentralizerConnectionService, SendCentralizerConnectionService>();
builder.Services.AddSingleton<ISentCentralizerConnectionDatabase, SentCentralizerConnectionDatabase>();
builder.Services.AddTransient<IFileManager, FileManager>();

builder.Services.Configure<AuthenticationOptions>(options => builder.Configuration.GetSection(_sectionNameEndpointAddessAuthenticationApi).Bind(options));
builder.Services.Configure<SendMessageWhatsApp>(options => builder.Configuration.GetSection(_sectionNameEndpointAddressSendMessageWhatsApp).Bind(options));

builder.Services.Configure<SendMessageApplicationGupshupOptions>(options => builder.Configuration.GetSection(_sectionNameEndpointAddressSendMessageWhatsAppGushup).Bind(options));
builder.Services.Configure<SendMessageApplicationAuthentication>(options => builder.Configuration.GetSection(_sectionNameAuthenticationSendMessageWhatsApp).Bind(options));
builder.Services.Configure<FileManagementOptions>(options => builder.Configuration.GetSection(_sectionNameFileDirectory).Bind(options));


var app = builder.Build();
if (app.Environment.IsDevelopment())
{
}
app.UseSwagger();
app.UseSwaggerUI();
app.UseHttpsRedirection();

string rootPath = string.IsNullOrEmpty(builder.Configuration["File.Directory:Root"]) ? builder.Environment.ContentRootPath : builder.Configuration["File.Directory:Root"];
string fileProviderImages = Path.Combine(rootPath, builder.Configuration["File.Directory:PathImagenes"]);
string fileProviderAudios = Path.Combine(rootPath, builder.Configuration["File.Directory:PathAudios"]);
string fileProviderVideos = Path.Combine(rootPath, builder.Configuration["File.Directory:PathVideos"]);
string fileProviderDocumentos = Path.Combine(rootPath, builder.Configuration["File.Directory:PathDocumentos"]);


string imagesPath = Directory.Exists(fileProviderImages) ? fileProviderImages : Directory.CreateDirectory(fileProviderImages).FullName;
string audiosPath = Directory.Exists(fileProviderAudios) ? fileProviderAudios : Directory.CreateDirectory(fileProviderAudios).FullName;
string videosPath = Directory.Exists(fileProviderVideos) ? fileProviderVideos : Directory.CreateDirectory(fileProviderVideos).FullName;
string documentosPath = Directory.Exists(fileProviderDocumentos) ? fileProviderDocumentos : Directory.CreateDirectory(fileProviderDocumentos).FullName;


app.UseStaticFiles(new StaticFileOptions
{

    FileProvider = new CompositeFileProvider(
        new PhysicalFileProvider(imagesPath),
        new PhysicalFileProvider(audiosPath),
        new PhysicalFileProvider(videosPath),
        new PhysicalFileProvider(documentosPath)
    ),
    RequestPath = builder.Configuration["File.Directory:RequestPath"]
});
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.Run();