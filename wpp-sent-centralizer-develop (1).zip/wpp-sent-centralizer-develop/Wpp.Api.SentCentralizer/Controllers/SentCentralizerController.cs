﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.ENTITIES.MessageApplication;
using WPP.ABSTRACTION.LOGGER;
using WPP.APPLICATION.BUSSINESS;

namespace Wpp.Api.SentCentralizer.Controllers
{
    [ApiVersion("1")]
    [Route("api/v1/[controller]")]
    [ApiController]
    public class SentCentralizerController : ControllerBase
    {
        private readonly ILoggerInfo _logger;
        private readonly ISendMessageService _bussinessServiceSend;
        public SentCentralizerController(ILoggerInfo logger, ISendMessageService bussinessServiceSend) { this._logger = logger; this._bussinessServiceSend = bussinessServiceSend; }

        [ApiExplorerSettings(GroupName = "v1")]
        [HttpPost("SendMessageCentralizer")]
        [ProducesResponseType(typeof(GenericResponse), 200)]
        public async Task<ActionResult> SendMessageCentralizer(MessageApplicationModel _request)
        {
            string _operation = DateTime.Now.ToString("yyyyMMddhhmmssff");
            try
            {
                this._logger.Debug(string.Format("[ {0} ]  REQUEST: {1}", _operation, JsonConvert.SerializeObject(_request)));
                var _response = await this._bussinessServiceSend.SendMessageWhatsDistributorService(_request, _operation);
                this._logger.Debug(string.Format("[ {0} ] RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
                return Ok(_response);
            }
            catch (Exception ex)
            {
                this._logger.Debug(string.Format("ERROR: {0}", ex.Message));
                return BadRequest(new GenericResponse { code = "500", message = ex.Message, success = false });
            }
        }
    }
}
