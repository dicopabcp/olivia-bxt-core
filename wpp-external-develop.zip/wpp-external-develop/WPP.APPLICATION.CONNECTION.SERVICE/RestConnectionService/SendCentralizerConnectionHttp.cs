﻿using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;

namespace WPP.APPLICATION.CONNECTION.SERVICE.RestConnectionService
{
    public enum Authentication { None, Header, Basic, Complete, WhatsApp, PassiveLifeTest, GushupFlow }
    public interface ISendCentralizerConnectionHttp
    {
        Task<T> PostAsync<T>(string urlBase, string method, object request, Authentication authentication, string usuario = "", string password = "", string _channel = "", string _publicToken = "", string _appUserid = "", CancellationToken cancellationToken = default);
    }
    public class SendCentralizerConnectionHttp : ISendCentralizerConnectionHttp
    {
        private readonly HttpClient _httpClient;
        public SendCentralizerConnectionHttp(HttpClient httpClient)  { _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient)); _httpClient.Timeout = TimeSpan.FromSeconds(60); }

        public async Task<T> PostAsync<T>(string urlBase, string method, object request, Authentication authentication, string usuario = "", string password = "", string channel = "", string publicToken = "", string appUserid = "", CancellationToken cancellationToken = default)
        {
            var url = BuildUri(urlBase, method);

            using var httpRequest = new HttpRequestMessage(HttpMethod.Post, url);
            AddAuthenticationHeaders(httpRequest, authentication, usuario, password, channel, publicToken, appUserid);
            httpRequest.Content = CreateJsonContent(request);

            try
            {
                using var response = await _httpClient.SendAsync(httpRequest, HttpCompletionOption.ResponseHeadersRead, cancellationToken);

                var content = await response.Content.ReadAsStringAsync(cancellationToken);

                ValidateResponse(response, content, url);

                return DeserializeResponse<T>(content);
            }
            catch (TaskCanceledException ex) when (!cancellationToken.IsCancellationRequested)
            {
                throw new TimeoutException($"Timeout en la llamada a: {url}", ex);
            }
            catch (HttpRequestException ex)
            {
                throw new HttpRequestException($"Error HTTP en: {url}", ex);
            }
        }

        private static Uri BuildUri(string baseUrl, string method)
        {
            if (string.IsNullOrWhiteSpace(baseUrl))
                throw new ArgumentException("urlBase es requerido");

            return new Uri(new Uri(baseUrl), method);
        }

        private static StringContent CreateJsonContent(object request)
        {
            var json = JsonConvert.SerializeObject(request ?? new { });
            return new StringContent(json, Encoding.UTF8, "application/json");
        }

        private static void ValidateResponse(HttpResponseMessage response, string content, Uri url)
        {
            if (!response.IsSuccessStatusCode) { throw new HttpRequestException($"ERROR => URL: {url}; STATUS: {(int)response.StatusCode}; CONTENT: {content}"); }

            if (string.IsNullOrWhiteSpace(content)) { throw new InvalidOperationException("La respuesta está vacía."); }
        }

        private static T DeserializeResponse<T>(string content)
        {
            try
            {
                return JsonConvert.DeserializeObject<T>(content) ?? throw new InvalidOperationException("Deserialización retornó null.");
            }
            catch (JsonException ex)
            {
                throw new InvalidOperationException("Error al deserializar la respuesta.", ex);
            }
        }

        private static void AddAuthenticationHeaders(HttpRequestMessage request, Authentication auth, string usuario, string password, string channel, string publicToken, string appUserid)
        {
            switch (auth)
            {
                case Authentication.None:
                    break;

                case Authentication.Header:
                    ValidateCredentials(usuario, password);
                    request.Headers.TryAddWithoutValidation("USUARIO", usuario);
                    request.Headers.TryAddWithoutValidation("PASSWORD", password);
                    break;

                case Authentication.Basic:
                    ValidateCredentials(usuario, password);
                    var basic = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes($"{usuario}:{password}"));
                    request.Headers.Authorization = new AuthenticationHeaderValue("Basic", basic);
                    break;

                case Authentication.Complete:
                    string _encodeComplete = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(usuario + ":" + password));
                    request.Headers.Authorization = new AuthenticationHeaderValue("Basic", _encodeComplete);
                    request.Headers.TryAddWithoutValidation("channel", channel);
                    request.Headers.TryAddWithoutValidation("publicToken", publicToken);
                    request.Headers.TryAddWithoutValidation("appUserId", appUserid);
                    break;

                case Authentication.WhatsApp:
                    request.Headers.TryAddWithoutValidation("username", usuario);
                    request.Headers.TryAddWithoutValidation("authenticationToken", password);
                    break;

                case Authentication.PassiveLifeTest:
                    request.Headers.TryAddWithoutValidation("ACCESS_KEY", usuario);
                    request.Headers.TryAddWithoutValidation("SECRET_KEY", password);
                    break;

                case Authentication.GushupFlow:
                    request.Headers.Authorization = new AuthenticationHeaderValue(password);
                    break;

                default:
                    throw new NotSupportedException($"Tipo de autenticación no soportado: {auth}");
            }
        }

        private static void ValidateCredentials(string usuario, string password)
        {
            if (string.IsNullOrWhiteSpace(usuario) || string.IsNullOrWhiteSpace(password)) { throw new ArgumentException("Usuario y password son requeridos para este tipo de autenticación."); }
        }
    }
}
