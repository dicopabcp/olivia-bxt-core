﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.ENTITIES.Authorization;
using WPP.ABSTRACTION.ENTITIES.IVRConnection;
using WPP.ABSTRACTION.ENTITIES.LifeTest;
using WPP.ABSTRACTION.ENTITIES.MobileBanking;
using WPP.ABSTRACTION.ENTITIES.OperatorWhatsApp;
using WPP.ABSTRACTION.ENTITIES.ReciveMessage;
using WPP.ABSTRACTION.ENTITIES.SendMessage;
using WPP.ABSTRACTION.ENTITIES.SendMessageApplication;
using WPP.ABSTRACTION.ENTITIES.SendWhatsApp;
using WPP.ABSTRACTION.LOGGER;
using WPP.ABSTRACTION.SECRYPT;
using WPP.APPLICATION.CONNECTION.SERVICE.RestConnectionService;

namespace WPP.APPLICATION.CONNECTION.SERVICE
{
    public class SentCentralizerConnection : ISentCentralizerConnection
    {
        private readonly ILoggerInfo _logger;
        private readonly ISendCentralizerConnectionHttp _httpConnection;

        private static readonly string _sectionNameEndpointAddessAuthenticationApi = "Authentication.Api";
        public readonly AuthenticationOptions _authenticationApi;

        private static readonly string _sectionNameEndpointAddressSendMessageWhatsApp = "Connection.SendMessage.Api";
        public readonly SendMessageWhatsApp _sendMessageWhatsApp;

        private static readonly string _sectionNameEndPointAddressSentCentralizerApi = "Sent.Centralizer.Api";
        public readonly SentCentralizerOptions _sentCentralizer;

        private static readonly string _sectionNameEndPointAddressPassiveLifeTestApi = "Passive.Life.Test.Api";
        public readonly PassiveLifeTestOptions _passiveLifeTest;

        private static readonly string _sectionNameEndPointAddressMobileBankingApi = "MobileBankingMain.Api";
        public readonly MobileBankingOptions _mobileBanking;

        private static readonly string _sectionNameEndPointAddressOperatorWhatsApp = "Operator.WhatsApp.Api";
        public readonly OperatorWhatsAppOptions _operatorWhatsApp;

        public readonly GushupWppFlowsConfig _gushupWppConfig;

        private readonly ManagerSecrypt _secrypt;
        private static readonly string _sectionNameSecryptValue = "segurinet";
        public readonly SecryptOptions _secryptOptions;
        public SentCentralizerConnection(IConfiguration configuration, ILoggerInfo logger, ISendCentralizerConnectionHttp httpConnection, IOptions<GushupWppFlowsConfig> _gushupWppConfig)
        {
            this._logger = logger;
            this._httpConnection = httpConnection;

            this._authenticationApi = new();
            configuration.GetSection(_sectionNameEndpointAddessAuthenticationApi).Bind(this._authenticationApi);

            this._sendMessageWhatsApp = new();
            configuration.GetSection(_sectionNameEndpointAddressSendMessageWhatsApp).Bind(this._sendMessageWhatsApp);

            this._sentCentralizer = new();
            configuration.GetSection(_sectionNameEndPointAddressSentCentralizerApi).Bind(this._sentCentralizer);

            this._passiveLifeTest = new();
            configuration.GetSection(_sectionNameEndPointAddressPassiveLifeTestApi).Bind(this._passiveLifeTest);

            this._mobileBanking = new();
            configuration.GetSection(_sectionNameEndPointAddressMobileBankingApi).Bind(this._mobileBanking);

            this._operatorWhatsApp = new();
            configuration.GetSection(_sectionNameEndPointAddressOperatorWhatsApp).Bind(this._operatorWhatsApp);

            this._secryptOptions = new();
            configuration.GetSection(_sectionNameSecryptValue).Bind(this._secryptOptions);

            this._gushupWppConfig = _gushupWppConfig.Value;

            this._secrypt = new ManagerSecrypt(_secryptOptions.semilla);

        }

        #region VALIDACION DE CREDENCIALES DE IAM
        public async Task<List<BasicAutorizacionModel>> getUserIN(string _user, string _password, AuthorizationRequest _authorization)
        {
            List<BasicAutorizacionModel> _response = new();
            _authorization.date = DateTime.Now.ToString("yyyyMMdd");
            var _responseAuthentication = await _httpConnection.PostAsync<AutorizacionResponse>(this._authenticationApi.urlAuthentication, this._authenticationApi.methodAuthentication, _authorization, Authentication.Basic, _user, _password);
            if (_responseAuthentication.state.Equals("00"))
            {
                _response.Add(new BasicAutorizacionModel { id = _responseAuthentication.data.id, userName = _responseAuthentication.data.username, password = "" });
            }
            return _response;
        }
        #endregion

        public async Task<SendMessageResponse> SendMessageWhatsApp(SendMessageRequest request, string Userwaby, string tokenwavy, string _operation)
        {
            SendMessageResponse responsewhatsapp = new();
            try
            {
                responsewhatsapp = await _httpConnection.PostAsync<SendMessageResponse>(this._sendMessageWhatsApp.urlSendMessage, this._sendMessageWhatsApp.methodSndMessage, request, Authentication.WhatsApp, Userwaby, tokenwavy);
            }
            catch (Exception ex)
            {
                _logger.Error("ERROR: {0}", ex.Message);
                throw ex;
            }
            return responsewhatsapp;
        }

        public async Task<GenericResponse> SendMessageApplication(SendMessageApplicationRequest request)
        {
            GenericResponse _response = new();
            try
            {
                request.destinationAccount = string.IsNullOrEmpty(request.destinationAccount) ? this._sentCentralizer.destinationAccount : request.destinationAccount;

                this._logger.Debug(string.Format("     URL: {0}", this._sentCentralizer.urlSentCentralizer + this._sentCentralizer.methodSentCentralizer));
                this._logger.Debug(string.Format(" REQUEST: {0}", JsonConvert.SerializeObject(request)));
                _response = await _httpConnection.PostAsync<GenericResponse>(this._sentCentralizer.urlSentCentralizer, this._sentCentralizer.methodSentCentralizer, request, Authentication.None);
                this._logger.Debug(string.Format("RESPONSE: {0}", JsonConvert.SerializeObject(_response)));
            }
            catch (Exception ex)
            {
                _logger.Error("ERROR: {0}", ex.Message);
                throw ex;
            }
            return _response;
        }

        public async Task<GenericResponse> SendMessageApplicationV2(SendMessageApplicationRequest request)
        {
            GenericResponse _response = new();
            try
            {

                this._logger.Debug(string.Format("     URL: {0}", this._sentCentralizer.urlSentCentralizer + this._sentCentralizer.methodSentCentralizer));
                this._logger.Debug(string.Format(" REQUEST: {0}", JsonConvert.SerializeObject(request)));
                _response = await _httpConnection.PostAsync<GenericResponse>(this._sentCentralizer.urlSentCentralizer, this._sentCentralizer.methodSentCentralizer, request, Authentication.None);
                this._logger.Debug(string.Format("RESPONSE: {0}", JsonConvert.SerializeObject(_response)));
            }
            catch (Exception ex)
            {
                _logger.Error("ERROR: {0}", ex.Message);
                throw ex;
            }
            return _response;
        }


        public async Task<CreateSessionResponse> PassiveLifeTest(CreateSessionRequest request, string channel)
        {
            CreateSessionResponse _response = new();
            try
            {
                this._logger.Debug(string.Format("     URL: {0}", this._passiveLifeTest.urlPasiveLifeTest + this._passiveLifeTest.methodPasiveLifeTest));
                this._logger.Debug(string.Format(" REQUEST: {0}", JsonConvert.SerializeObject(request)));
                string _accessKey = string.Empty; string _secretKey = string.Empty;
                if (channel.Equals("KIOSCO"))
                {
                    _accessKey = this._secrypt.Desencriptar(this._passiveLifeTest.accesKeyPasiveLifeTest);
                    _secretKey = this._secrypt.Desencriptar(this._passiveLifeTest.secreyKeyPasiveLifeTest);
                }
                else if (channel.Equals("KIOSKO_DIGITAL"))
                {
                    _accessKey = this._secrypt.Desencriptar(this._passiveLifeTest.accesKeyPassiveLifeTestDigital);
                    _secretKey = this._secrypt.Desencriptar(this._passiveLifeTest.secreyKeyPassiveLfeTestDigital);
                }
                _response = await _httpConnection.PostAsync<CreateSessionResponse>(this._passiveLifeTest.urlPasiveLifeTest, this._passiveLifeTest.methodPasiveLifeTest, request, Authentication.PassiveLifeTest, _accessKey, _secretKey);
                this._logger.Debug(string.Format("RESPONSE: {0}", JsonConvert.SerializeObject(_response)));
            }
            catch (Exception ex)
            {
                _logger.Error("ERROR: {0}", ex.Message);
                throw ex;
            }
            return _response;
        }

        public async Task<GenericResponse> UnlinkMobileBanking(UnlinkMobileBankingRequest request, string _usuario, string _password, string _publicToken, string _appUserid)
        {
            GenericResponse _response = new();
            try
            {
                this._logger.Debug(string.Format("     URL: {0}", this._mobileBanking.urlMobileBanking + this._mobileBanking.methodMobileBanking));
                this._logger.Debug(string.Format(" REQUEST: {0}", JsonConvert.SerializeObject(request)));
                _response = await _httpConnection.PostAsync<GenericResponse>(this._mobileBanking.urlMobileBanking, this._mobileBanking.methodMobileBanking, request, Authentication.Complete, _usuario, _password, this._mobileBanking.channel, _publicToken, _appUserid);
                this._logger.Debug(string.Format("RESPONSE: {0}", JsonConvert.SerializeObject(_response)));
            }
            catch (Exception ex)
            {
                _logger.Error("ERROR: {0}", ex.Message);
                throw ex;
            }
            return _response;
        }

        public async Task<GenericResponse> OperatorWhatsApp(ReciveMessageRequest request)
        {
            GenericResponse _response = new();
            try
            {
                request.campaignAlias = this._operatorWhatsApp.ssignedArea;
                this._logger.Debug(string.Format("     URL: {0}", this._operatorWhatsApp.urlOperator + this._operatorWhatsApp.methodOperator));
                this._logger.Debug(string.Format(" REQUEST: {0}", JsonConvert.SerializeObject(request)));
                _response = await _httpConnection.PostAsync<GenericResponse>(this._operatorWhatsApp.urlOperator, this._operatorWhatsApp.methodOperator, request, Authentication.None);
                this._logger.Debug(string.Format("RESPONSE: {0}", JsonConvert.SerializeObject(_response)));
            }
            catch (Exception ex)
            {
                _logger.Error("ERROR: {0}", ex.Message);
                throw ex;
            }
            return _response;
        }

        public async Task<GenericResponse> SendMessageFlowWpp(SendFlowRequest request, string _operation)
        {
            GenericResponse _response = new();
            try
            {
                this._logger.Debug(string.Format("[{0}]     URL: {1}", _operation, this._gushupWppConfig.Url + this._gushupWppConfig.MethodSendFlow));
                this._logger.Debug(string.Format("[{0}] REQUEST: {1}", _operation, JsonConvert.SerializeObject(request)));
                await _httpConnection.PostAsync<object>(this._gushupWppConfig.Url, this._gushupWppConfig.MethodSendFlow, request, Authentication.GushupFlow, string.Empty, this._secrypt.Desencriptar(_gushupWppConfig.Authorization));
                _response.success = true;
                _response.message = "Ejecutado correctamente";
                _response.code = "200";
            }
            catch (Exception ex)
            {
                _logger.Error("[{0}] ERROR: {1}", _operation, ex.Message);
                _response.code = "500";
                _response.message = ex.Message;
                _response.success = false;
            }
            return _response;
        }
    }
}