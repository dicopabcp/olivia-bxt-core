﻿using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.ENTITIES.Authorization;
using WPP.ABSTRACTION.ENTITIES.LifeTest;
using WPP.ABSTRACTION.ENTITIES.MobileBanking;
using WPP.ABSTRACTION.ENTITIES.ReciveMessage;
using WPP.ABSTRACTION.ENTITIES.SendMessage;
using WPP.ABSTRACTION.ENTITIES.SendMessageApplication;

namespace WPP.APPLICATION.CONNECTION.SERVICE
{
    public interface ISentCentralizerConnection
    {
        Task<List<BasicAutorizacionModel>> getUserIN(string _user, string _password, AuthorizationRequest _authorization);
        Task<SendMessageResponse> SendMessageWhatsApp(SendMessageRequest request, string Userwaby, string tokenwavy, string _operation);
        Task<GenericResponse> SendMessageApplication(SendMessageApplicationRequest request);
        Task<GenericResponse> SendMessageApplicationV2(SendMessageApplicationRequest request);
        Task<CreateSessionResponse> PassiveLifeTest(CreateSessionRequest request, string channel);
        Task<GenericResponse> UnlinkMobileBanking(UnlinkMobileBankingRequest request, string _usuario, string _password, string _publicToken, string _appUserid);
        Task<GenericResponse> OperatorWhatsApp(ReciveMessageRequest request);
        Task<GenericResponse> SendMessageFlowWpp(SendFlowRequest request, string _operation);
    }
}
