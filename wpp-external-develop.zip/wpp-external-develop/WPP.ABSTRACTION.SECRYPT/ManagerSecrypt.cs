﻿
namespace WPP.ABSTRACTION.SECRYPT
{
    public class ManagerSecrypt : IManagerSecrypt
    {
        private readonly string semilla;
        public ManagerSecrypt(string semilla)
        {
            this.semilla = semilla;
        }
        public string Encriptar(string value)
        {
            var SegCrypt = new SegCryptV2(semilla);
            var result = SegCrypt.FunctionEncryptDecrypt(true, value);
            return result;
        }
        public string Desencriptar(string value)
        {
            var SegCrypt = new SegCryptV2(semilla);
            var result = SegCrypt.FunctionEncryptDecrypt(false, value);
            return result;
        }
        public Tuple<bool, string> Check()
        {
            try
            {
                new SegCryptV2(semilla);
                return Tuple.Create(true, $"LA SEMILLA {semilla} FUE ENCONTRADA.");
            }
            catch (Exception ex)
            {
                return Tuple.Create(false, ex.Message);
            }
        }
    }
}
