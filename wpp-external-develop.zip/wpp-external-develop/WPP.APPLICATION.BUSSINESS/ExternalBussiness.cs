﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;
using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.ENTITIES.CoreAntiguo;
using WPP.ABSTRACTION.ENTITIES.IVRConnection;
using WPP.ABSTRACTION.ENTITIES.LifeTest;
using WPP.ABSTRACTION.ENTITIES.MobileBanking;
using WPP.ABSTRACTION.ENTITIES.ReciveMessage;
using WPP.ABSTRACTION.ENTITIES.SendMessageApplication;
using WPP.ABSTRACTION.ENTITIES.Transaction;
using WPP.ABSTRACTION.LOGGER;
using WPP.APPLICATION.CONNECTION.DATABASE;
using WPP.APPLICATION.CONNECTION.SERVICE;

namespace WPP.APPLICATION.BUSSINESS
{
    public interface IExternalBussiness
    {
        Task<GenericResponseKiosco> StartPassiveLifeTest(LifeTestKioscoRequest _request);
        Task<GenericResponse> StartPassiveLifeTestKiosk(PassiveLifeTestKioskRequest _request);
        Task<GenericResponse> SenddingMessageChannel(SendMessageExternalRequest _request);
        Task<GenericResponse> SenddingMessageTextChannel(SendMessageTextExternalRequest _request);
        Task<GenericResponse> SenddingMessageButtonChannel(SendMessageButtonExternalRequest _request);
        Task<GenericResponse> SenddingMessageListChannel(SendMessageListExternalRequest _request);
        Task<GenericResponse> IvrConnectionOpertor(IVRConnectionRequest request);
        Task<GenericResponse> BUnlinkMobileBankingWhatsApp(MobileBankingRequest request, string _usuario, string _password, string _publicToken, string _appUserid);
        Task<GenericResponse> SendMessageOTP(WhatsAppEnviadoRequest _request);
        Task<GenericResponse> SendMessageFlowChannel(SendMessageFlowExternalRequest _request, string _operation);
        string GetParameterOptain(string _tag);
    }
    public class ExternalBussiness : IExternalBussiness
    {
        private readonly ILoggerInfo _logger;
        private readonly IExternalConnectionDatabase _connectionDataBase;
        private readonly ISentCentralizerConnection _connectionService;
        private readonly IvrTemplateConfiguration _ivrConfig;
        private readonly SentCentralizerOptions _sentCentralizerOptions;

        public ExternalBussiness(IExternalConnectionDatabase connectionDataBase, ISentCentralizerConnection connectionService, ILoggerInfo loggerInfo, IOptions<IvrTemplateConfiguration> ivrConfig, IOptions<SentCentralizerOptions> sentCentralizerOptions)
        {
            this._connectionDataBase = connectionDataBase;
            this._connectionService = connectionService;
            this._logger = loggerInfo;
            this._ivrConfig = ivrConfig.Value;
            this._sentCentralizerOptions = sentCentralizerOptions.Value;
        }

        public async Task<GenericResponseKiosco> StartPassiveLifeTest(LifeTestKioscoRequest _request)
        {
            GenericResponseKiosco _response = new();
            try
            {
                PassiveLifeTestModel addPassiveLifeTest = new();
                addPassiveLifeTest.idcClient = _request.IDC.PadLeft(11, '0');
                addPassiveLifeTest.code = _request.ReferenceID;
                addPassiveLifeTest.cellphone = "591" + _request.cellphone;
                string _channel = GetParameterOptain("LIFE.TEST.CHANNEL");
                addPassiveLifeTest.channel = string.IsNullOrEmpty(_channel) ? "KIOSCO" : _channel;

                CreateSessionRequest _requestCreateSession = new();
                _requestCreateSession.idc = addPassiveLifeTest.idcClient + "00";
                _requestCreateSession.email = "NOTIENE@GMAIL.COM";
                _requestCreateSession.celular = _request.cellphone;
                _requestCreateSession.canal = addPassiveLifeTest.channel;
                CreateSessionResponse _responseCreateSession = await this._connectionService.PassiveLifeTest(_requestCreateSession, addPassiveLifeTest.channel);
                // ENVIAR MENSAJE DE TEMPLATE
                string palabaSinTildes = Regex.Replace(_responseCreateSession.instruccion.Normalize(NormalizationForm.FormD), @"[^a-zA-z0-9 ]+", "");
                SendMessageApplicationRequest _sendMessageApplicationRequest = new();
                _sendMessageApplicationRequest.typeMessage = "TEMPLATE";
                _sendMessageApplicationRequest.cellphone.Add(addPassiveLifeTest.cellphone);
                _sendMessageApplicationRequest.user = addPassiveLifeTest.channel;
                _sendMessageApplicationRequest.nameUser = addPassiveLifeTest.channel;
                string _messageStart = GetParameterOptain("MSG.START.LIFE.TEST");
                _sendMessageApplicationRequest.parameterMessage.Add(_messageStart + palabaSinTildes);
                string _templateDispenser = GetParameterOptain("TEMPLATE.DISPENSER.KIOSCO");
                _sendMessageApplicationRequest.nameHsmOfTemplate = _templateDispenser;
                _sendMessageApplicationRequest.campaignName = addPassiveLifeTest.channel;
                if (GetParameterOptain("ENVIAR.URL.INSTRUCCION.KIOKO") == "ON")
                    _sendMessageApplicationRequest.url = GetParameterOptain("URL.INSTRUCCION.KIOSKO");
                else
                    _sendMessageApplicationRequest.multimediaUrl = _responseCreateSession.imgInstruccion;

                _sendMessageApplicationRequest.classMultimedia = "JPG";
                _sendMessageApplicationRequest.identifyChatBot = true;
                _sendMessageApplicationRequest.campaignName = addPassiveLifeTest.channel;
                _sendMessageApplicationRequest.parametersTemplate.classMessageTemplate = "IMAGE";

                var _sendMessageApplicationResponse = await this._connectionService.SendMessageApplication(_sendMessageApplicationRequest);
                addPassiveLifeTest.sessionId = _responseCreateSession.sessionID;
                addPassiveLifeTest.instruction = _responseCreateSession.instruccion;
                addPassiveLifeTest.nameClient = _request.customerName;
                addPassiveLifeTest.attempts = 0;
                _response.code = _sendMessageApplicationResponse.code;
                _response.message = _sendMessageApplicationResponse.message;
                _response.success = _sendMessageApplicationResponse.success;
                _response.IDC = _request.IDC;
                _response.ReferenceID = _request.ReferenceID;
                this._connectionDataBase.InsertPassiveLifeValidationTest(addPassiveLifeTest);

                if (GetParameterOptain("TRANSACTION.KIOSKO") == "ON")
                {
                    NewTransactionModel transactionModel = new() { idSolicitud = addPassiveLifeTest.cellphone, fkCodMenu = "KIOSCO", celular = addPassiveLifeTest.cellphone, usuario = "BOT", tipoSolicitud = 1, estadoFlujo = 1, datosCliente = JsonConvert.SerializeObject(addPassiveLifeTest) };
                    this._connectionDataBase.InsertNewTransaction(transactionModel);
                }
            }
            catch (Exception ex)
            {
                _logger.Error("ERROR: {0}", ex.Message);
                throw ex;
            }
            return _response;
        }
        public async Task<GenericResponse> StartPassiveLifeTestKiosk(PassiveLifeTestKioskRequest _request)
        {
            GenericResponse _response = new();
            try
            {
                PassiveLifeTestFromKioskModel passiveLifeTestFromKioskModel = new();
                passiveLifeTestFromKioskModel.idcNumber = _request.idcNumber.PadLeft(8, '0');
                passiveLifeTestFromKioskModel.idcType = string.IsNullOrEmpty(_request.idcType) ? "Q" : _request.idcType.Trim().ToUpper();
                passiveLifeTestFromKioskModel.idcExtension = _request.idcExtension;
                passiveLifeTestFromKioskModel.idcSuppement = string.IsNullOrEmpty(_request.idcSupplement) ? "00" : _request.idcSupplement.Trim().ToUpper();

                passiveLifeTestFromKioskModel.nameClient = _request.nameClient.ToUpper();
                passiveLifeTestFromKioskModel.cellphone = _request.cellphone.Length == 8 ? "591" + _request.cellphone : _request.cellphone;
                passiveLifeTestFromKioskModel.email = string.IsNullOrEmpty(_request.email) ? "NO_TIENE@GMAIL.COM" : _request.email.Trim().ToUpper();

                passiveLifeTestFromKioskModel.referenceCode = _request.referenceCode.Trim().ToUpper();
                passiveLifeTestFromKioskModel.terminalCode = _request.terminalCode.Trim();

                passiveLifeTestFromKioskModel.channel = "KIOSKO_DIGITAL";
                passiveLifeTestFromKioskModel.digitalRecordSession = _request.digitalRecordSession ?? string.Empty;

                passiveLifeTestFromKioskModel.paternalSurnameClient = _request.paternalSurnameClient.ToUpper();
                passiveLifeTestFromKioskModel.maternalSurnameClient = _request.maternalSurnameClient.ToUpper();
                passiveLifeTestFromKioskModel.negativeFile = _request.negativeFile;
                passiveLifeTestFromKioskModel.enameCheker = _request.enameCheker;


                CreateSessionRequest createSessionRequest = new();
                createSessionRequest.idc = passiveLifeTestFromKioskModel.idcNumber + passiveLifeTestFromKioskModel.idcType + passiveLifeTestFromKioskModel.idcExtension + passiveLifeTestFromKioskModel.idcSuppement;
                createSessionRequest.email = passiveLifeTestFromKioskModel.email;
                createSessionRequest.celular = _request.cellphone;
                createSessionRequest.canal = passiveLifeTestFromKioskModel.channel;
                createSessionRequest.idResguardo = string.Empty;


                CreateSessionResponse _responseCreateSession = await this._connectionService.PassiveLifeTest(createSessionRequest, passiveLifeTestFromKioskModel.channel);

                passiveLifeTestFromKioskModel.selfieInstruccion = _responseCreateSession.instruccion;
                passiveLifeTestFromKioskModel.passiveLifeTestSession = _responseCreateSession.sessionID;


                SendMessageApplicationRequest sendMessageApplicationRequest = new();

                sendMessageApplicationRequest.message = string.Empty;
                sendMessageApplicationRequest.typeMessage = "TEMPLATE";
                sendMessageApplicationRequest.classMultimedia = string.Empty;
                sendMessageApplicationRequest.cellphone.Add(passiveLifeTestFromKioskModel.cellphone);
                sendMessageApplicationRequest.identifyChatBot = true;
                sendMessageApplicationRequest.multimediaUrl = string.Empty;
                sendMessageApplicationRequest.url = string.Empty;
                sendMessageApplicationRequest.nameMultimediaUrl = string.Empty;
                sendMessageApplicationRequest.user = passiveLifeTestFromKioskModel.channel;
                sendMessageApplicationRequest.nameUser = passiveLifeTestFromKioskModel.channel;
                sendMessageApplicationRequest.parameterMessage.Add(" 🚫 📸 No utilice una fotocopia de su carnet identidad");
                sendMessageApplicationRequest.parameterMessage.Add(" 🚫 💡 Tome la foto de su carnet sin reflejo de luz");
                sendMessageApplicationRequest.parameterMessage.Add(" 🚫 🔆 Asegúrese que la foto de su carnet no tenga brillo");
                sendMessageApplicationRequest.nameHsmOfTemplate = "aperturakiosco";
                sendMessageApplicationRequest.campaignName = passiveLifeTestFromKioskModel.channel;

                var _sendMessageApplicationResponse = await this._connectionService.SendMessageApplication(sendMessageApplicationRequest);

                // INSERTAR REGISTRO DENTRO DE LA TABLA DE PROCESOS 
                passiveLifeTestFromKioskModel.idClient = this._connectionDataBase.InsertPassiveLifeTestFromKiosk(passiveLifeTestFromKioskModel);
                passiveLifeTestFromKioskModel.attempts = 0;
                passiveLifeTestFromKioskModel.process = "INICIO";

                NewTransactionModel _newTransactionModel = new();
                _newTransactionModel.idSolicitud = passiveLifeTestFromKioskModel.cellphone;
                _newTransactionModel.fkCodMenu = "KIOSK_OPEI";
                _newTransactionModel.celular = passiveLifeTestFromKioskModel.cellphone;
                _newTransactionModel.usuario = passiveLifeTestFromKioskModel.channel;
                _newTransactionModel.tipoSolicitud = 1;
                _newTransactionModel.estadoFlujo = 1;
                _newTransactionModel.datosCliente = JsonConvert.SerializeObject(passiveLifeTestFromKioskModel);
                this._connectionDataBase.InsertNewTransaction(_newTransactionModel);

                _response = _sendMessageApplicationResponse;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _response;
        }
        public async Task<GenericResponse> SenddingMessageChannel(SendMessageExternalRequest _request)
        {
            try
            {
                if (_request.nameHsmOfTemplate.Equals("bcpnotificacion", StringComparison.OrdinalIgnoreCase))
                {
                    var templateOtp = string.IsNullOrWhiteSpace(_sentCentralizerOptions.nameTemplateOtpSend)
                        ? GetParameterOptain("NAME.TEMPLATE.NOTIFICATIONS.OTP")
                        : _sentCentralizerOptions.nameTemplateOtpSend;

                    if (!string.IsNullOrWhiteSpace(templateOtp))
                        _request.nameHsmOfTemplate = templateOtp;

                    var parametro = Regex.Replace(_request.parameterMessage?.LastOrDefault() ?? string.Empty, @"\D", string.Empty);
                    if (parametro.Length < 4)
                    {
                        return new GenericResponse
                        {
                            success = false,
                            code = "204",
                            message = "There are no parameters available for the submission."
                        };
                    }
                    _request.parameterMessage = [parametro];
                }
                var _sendMessageApplicationRequest = new SendMessageApplicationRequest()
                {
                    message = _request.message,
                    typeMessage = _request.typeMessage,
                    classMultimedia = _request.classMultimedia,
                    cellphone = _request.cellphone,
                    identifyChatBot = true,
                    multimediaUrl = _request.multimediaUrl,
                    url = _request.url,
                    nameMultimediaUrl = _request.nameMultimediaUrl,
                    user = _request.user,
                    nameUser = _request.nameUser,
                    parameterMessage = _request.parameterMessage ?? new List<string>(),
                    nameHsmOfTemplate = _request.nameHsmOfTemplate,
                    campaignName = _request.campaignName,
                    parametersTemplate = _request.parametersTemplate,
                    destinationAccount = _request.destinationAccount
                };
                return await this._connectionService.SendMessageApplication(_sendMessageApplicationRequest);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<GenericResponse> SenddingMessageTextChannel(SendMessageTextExternalRequest _request)
        {
            try
            {
                SendMessageApplicationRequest _sendMessageApplicationRequest = new();
                _sendMessageApplicationRequest.message = _request.message;
                _sendMessageApplicationRequest.typeMessage = "TEXT";
                _sendMessageApplicationRequest.classMultimedia = string.Empty;
                _sendMessageApplicationRequest.cellphone = new List<string> { _request.cellphone! };
                _sendMessageApplicationRequest.identifyChatBot = true;
                _sendMessageApplicationRequest.multimediaUrl = string.Empty;
                _sendMessageApplicationRequest.url = string.Empty;
                _sendMessageApplicationRequest.nameMultimediaUrl = string.Empty;
                _sendMessageApplicationRequest.user = _request.nameUser;
                _sendMessageApplicationRequest.nameUser = _request.nameUser;
                _sendMessageApplicationRequest.destinationAccount = _request.destinationAccount;

                _sendMessageApplicationRequest.parameterMessage = new List<string>();
                _sendMessageApplicationRequest.nameHsmOfTemplate = string.Empty;
                _sendMessageApplicationRequest.campaignName = string.Empty;

                return await this._connectionService.SendMessageApplicationV2(_sendMessageApplicationRequest);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<GenericResponse> SenddingMessageButtonChannel(SendMessageButtonExternalRequest _request)
        {
            try
            {
                SendMessageApplicationRequest _sendMessageApplicationRequest = new();
                _sendMessageApplicationRequest.typeMessage = "INTERACTIVE";
                _sendMessageApplicationRequest.classInteractive = "REPLY_BUTTON";
                _sendMessageApplicationRequest.classMultimedia = string.Empty;
                _sendMessageApplicationRequest.cellphone = new List<string> { _request.cellphone! };
                _sendMessageApplicationRequest.identifyChatBot = true;
                _sendMessageApplicationRequest.multimediaUrl = string.Empty;
                _sendMessageApplicationRequest.url = string.Empty;
                _sendMessageApplicationRequest.nameMultimediaUrl = string.Empty;
                _sendMessageApplicationRequest.user = _request.nameUser;
                _sendMessageApplicationRequest.nameUser = _request.nameUser;
                _sendMessageApplicationRequest.destinationAccount = _request.destinationAccount;

                _sendMessageApplicationRequest.parameterMessage = new List<string>();
                _sendMessageApplicationRequest.nameHsmOfTemplate = string.Empty;
                _sendMessageApplicationRequest.campaignName = string.Empty;

                _sendMessageApplicationRequest.parametersInteractive = new MessageInteractiveModel();

                _sendMessageApplicationRequest.parametersInteractive.body = _request.message!;
                _sendMessageApplicationRequest.parametersInteractive.classMessageInteractive = "TEXT";
                _sendMessageApplicationRequest.parametersInteractive.parameters = new();
                foreach (string item in _request.listButton)
                {
                    InteractiveParameterModel _button = new InteractiveParameterModel();
                    _button.title = item;
                    _button.description = item;
                    _button.identifier = item;

                    _sendMessageApplicationRequest.parametersInteractive.parameters.Add(_button);
                }

                return await this._connectionService.SendMessageApplicationV2(_sendMessageApplicationRequest);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<GenericResponse> SenddingMessageListChannel(SendMessageListExternalRequest _request)
        {
            try
            {
                SendMessageApplicationRequest _sendMessageApplicationRequest = new();
                _sendMessageApplicationRequest.typeMessage = "INTERACTIVE";
                _sendMessageApplicationRequest.classInteractive = "LIST_BUTTON";
                _sendMessageApplicationRequest.classMultimedia = string.Empty;
                _sendMessageApplicationRequest.cellphone = new List<string> { _request.cellphone! };
                _sendMessageApplicationRequest.identifyChatBot = true;
                _sendMessageApplicationRequest.multimediaUrl = string.Empty;
                _sendMessageApplicationRequest.url = string.Empty;
                _sendMessageApplicationRequest.nameMultimediaUrl = string.Empty;
                _sendMessageApplicationRequest.user = _request.nameUser;
                _sendMessageApplicationRequest.nameUser = _request.nameUser;
                _sendMessageApplicationRequest.destinationAccount = _request.destinationAccount;

                _sendMessageApplicationRequest.parameterMessage = new List<string>();
                _sendMessageApplicationRequest.nameHsmOfTemplate = string.Empty;
                _sendMessageApplicationRequest.campaignName = string.Empty;

                _sendMessageApplicationRequest.parametersInteractive = new MessageInteractiveModel();

                _sendMessageApplicationRequest.parametersInteractive.body = _request.message!;
                _sendMessageApplicationRequest.parametersInteractive.classMessageInteractive = "TEXT";
                _sendMessageApplicationRequest.parametersInteractive.nameSelectorButton = _request.button!;
                _sendMessageApplicationRequest.parametersInteractive.parameters = new();
                foreach (var item in _request.list)
                {
                    InteractiveParameterModel _button = new InteractiveParameterModel();
                    _button.title = item.title!;
                    _button.description = item.description!;
                    _button.identifier = item.identifier!;

                    _sendMessageApplicationRequest.parametersInteractive.parameters.Add(_button);
                }


                return await this._connectionService.SendMessageApplicationV2(_sendMessageApplicationRequest);
            }
            catch (Exception ex)
            {
                _logger.Error("ERROR: {0}", ex.Message);
                throw ex;
            }
        }
        public async Task<GenericResponse> IvrConnectionOpertor(IVRConnectionRequest request)
        {
            GenericResponse _response = new() { success = true, message = "Prosessing Complete.", code = "200" };
            try
            {
                string celular = $"591{request.cellphone}";
                string campaign = _ivrConfig.Campaign;
                string _parameterOne = GetParameterOptain("IVR.PARAMETER_1.MESSAGE");
                string _parameterTwo = GetParameterOptain("IVR.PARAMETER_2.MESSAGGE");
                string _parameterThree = GetParameterOptain("IVR.PARAMETER_3.MESSAGGE");
                SendMessageApplicationRequest _requestSendMenssageOperator = new()
                {
                    typeMessage = _ivrConfig.TypeTemplate,
                    nameHsmOfTemplate = _ivrConfig.NameTemplate,
                    cellphone = new() { celular },
                    identifyChatBot = true,
                    user = _ivrConfig.User,
                    nameUser = _ivrConfig.User,
                    parameterMessage = new() { _parameterOne, _parameterTwo, _parameterThree },
                    campaignName = campaign
                };

                await this._connectionService.SendMessageApplication(_requestSendMenssageOperator);

                ReciveMessageRequest _data = new();
                _data.message = new();
                _data.id = "0";
                _data.message.messageText = "En un momento un operador lo atenderá 😊";
                _data.message.type = "TEXT";
                _data.origin = "5912114141";
                _data.receivedAt = "1688734835000";
                _data.source = celular;
                _data.receivedDate = DateTime.Now.ToString();
                _data.campaignAlias = campaign;

                await this._connectionService.OperatorWhatsApp(_data);
            }
            catch (Exception ex)
            {
                _response.success = false;
                _response.message = ex.Message;
                _response.code = "500";
            }
            return _response;
        }
        public async Task<GenericResponse> BUnlinkMobileBankingWhatsApp(MobileBankingRequest request, string _usuario, string _password, string _publicToken, string _appUserid)
        {
            GenericResponse _response = new() { success = true, message = "Prosessing Complete.", code = "200" };
            try
            {
                TransactionProcessModel _respTransaccion = new();
                UnlinkMobileBankingWhatsApp? dhBancaCliente = new();
                _respTransaccion = VerifyTransactionProcessGuid(request.strGuid);

                if (string.IsNullOrEmpty(_respTransaccion.clientData))
                {

                    _response.message = "No existe ningun registro";
                    _response.success = false;
                    _response.code = "202";
                    return _response;
                }

                dhBancaCliente = string.IsNullOrEmpty(_respTransaccion.clientData) ? null : JsonConvert.DeserializeObject<UnlinkMobileBankingWhatsApp>(_respTransaccion.clientData);


                if (!request.success)
                {
                    _respTransaccion.stateEnd = "X";
                    this._connectionDataBase.UpdateNewTransaction(_respTransaccion);
                    _response.message = "No Completo Prueba de Vida";
                    _response.success = false;
                    _response.code = "201";

                    await SendOperator(_respTransaccion.cellphone);

                    return _response;
                }




                GenericResponse _responseUnlink = new();

                UnlinkMobileBankingRequest _requestUnlink = new();
                _requestUnlink.cic = dhBancaCliente?.InfoCliente?.Cic?.Trim() ?? string.Empty;

                _responseUnlink = await this._connectionService.UnlinkMobileBanking(_requestUnlink, _usuario, _password, _publicToken, _appUserid);

                dhBancaCliente?.BankingMobileResponse = _responseUnlink;
                _respTransaccion.clientData = JsonConvert.SerializeObject(dhBancaCliente);

                if (_responseUnlink.code != "200")
                {
                    _respTransaccion.stateEnd = "X";

                    this._connectionDataBase.UpdateNewTransaction(_respTransaccion);
                    _response.message = _responseUnlink.message;
                    _response.success = false;
                    _response.code = "203";
                    await SendOperator(_respTransaccion.cellphone);
                    return _response;
                }


                SendMessageApplicationRequest _requestSendMenssageOperator = new();
                _requestSendMenssageOperator.message = "Se completó su solicitud. Ya puedes ingresar a tu Banca Móvil en el nuevo equipo con el usuario y contraseña acostumbrados 😊";
                _requestSendMenssageOperator.typeMessage = "TEXT";
                _requestSendMenssageOperator.classMultimedia = string.Empty;
                _requestSendMenssageOperator.cellphone.Add(_respTransaccion.cellphone);
                _requestSendMenssageOperator.identifyChatBot = false;
                _requestSendMenssageOperator.multimediaUrl = string.Empty;
                _requestSendMenssageOperator.url = string.Empty;
                _requestSendMenssageOperator.nameMultimediaUrl = string.Empty;
                _requestSendMenssageOperator.user = "BOT";
                _requestSendMenssageOperator.nameUser = "BOT";
                _requestSendMenssageOperator.parameterMessage = new();
                _requestSendMenssageOperator.nameHsmOfTemplate = string.Empty;
                _requestSendMenssageOperator.campaignName = string.Empty;
                await this._connectionService.SendMessageApplication(_requestSendMenssageOperator);


                _respTransaccion.stateEnd = "C";
                this._connectionDataBase.UpdateNewTransaction(_respTransaccion);


            }
            catch (Exception ex)
            {
                _logger.Error("ERROR: {0}", ex.Message);
                throw ex;
            }
            return _response;
        }
        public async Task<GenericResponse> SendMessageOTP(WhatsAppEnviadoRequest _request)
        {
            try
            {
                var nameTemplateSendOtp = string.IsNullOrWhiteSpace(this._sentCentralizerOptions.nameTemplateOtpSend)
                    ? GetParameterOptain("NAME.TEMPLATE.NOTIFICATIONS.OTP")
                    : this._sentCentralizerOptions.nameTemplateOtpSend;
                string parametro = _request.parametroshsm?.LastOrDefault()?.ToString() ?? string.Empty;

                if (!string.IsNullOrEmpty(parametro))
                {
                    parametro = Regex.Replace(parametro, @"\D", "");
                    if (parametro.Length < 4)
                    {
                        return new GenericResponse
                        {
                            success = false,
                            code = "204",
                            message = "There are no parameters available for the submission."
                        };
                    }
                    var _requestEnvio = new SendMessageApplicationRequest()
                    {
                        message = string.Empty,
                        typeMessage = "TEMPLATE",
                        classMultimedia = string.Empty,
                        classInteractive = string.Empty,
                        cellphone = _request.destino!,
                        identifyChatBot = true,
                        multimediaUrl = string.Empty,
                        url = string.Empty,
                        nameMultimediaUrl = string.Empty,
                        user = _request.canal,
                        nameUser = _request.canal,
                        parameterMessage = new List<string>() { parametro },
                        nameHsmOfTemplate = nameTemplateSendOtp,
                        campaignName = string.Empty
                    };
                    return await this._connectionService.SendMessageApplication(_requestEnvio);
                }


                return new GenericResponse()
                {
                    success = false,
                    code = "204",
                    message = "There are no parameters available for the submission."
                };
                
            }
            catch (Exception ex)
            {
                _logger.Error("ERROR: {0}", ex.Message);
                throw ex;
            }
        }
        public async Task<GenericResponse> SendMessageFlowChannel(SendMessageFlowExternalRequest _request, string _operation)
        {
            SendFlowRequest requestFlow = new SendFlowRequest
            {
                flow_id = _request.nameFlow,
                user = new FlowUserInformation
                {
                    message = _request.message,
                    phone = _request.cellphone,
                    wppSesionId = _request.wppSesionId,
                    screen = _request.screen,
                    header = _request.header,
                    footer = _request.footer,
                }
            };

            return await this._connectionService.SendMessageFlowWpp(requestFlow, _operation);
        }
        public TransactionProcessModel VerifyTransactionProcessGuid(string _guid)
        {
            TransactionProcessModel _response = new();
            try
            {
                DataTable _table = this._connectionDataBase.GetProcessTransaction(_guid);
                if (_table.Rows.Count > 0)
                {
                    _response.idTransaction = Convert.ToInt32(_table.Rows[0]["PK_WPP"].ToString());
                    _response.idRequest = _table.Rows[0]["ID_SOLICITUD"].ToString()!;
                    _response.menuCode = _table.Rows[0]["FK_COD_MENU"].ToString()!;
                    _response.cellphone = _table.Rows[0]["CELULAR"].ToString()!;
                    _response.user = _table.Rows[0]["USUARIO"].ToString()!;
                    _response.typeRequest = _table.Rows[0]["TIPO_SOLICITUD"].ToString()!;
                    _response.stateTransaction = _table.Rows[0]["ESTADO_FLUJO"].ToString()!;
                    _response.stateEnd = _table.Rows[0]["ESTADO_FINAL"].ToString()!;
                    _response.serviceTransaction = _table.Rows[0]["SERVICIO_TRANSACCION"].ToString()!;
                    _response.request = _table.Rows[0]["REQUEST"].ToString()!;
                    _response.response = _table.Rows[0]["RESPONSE"].ToString()!;
                    _response.dateRequest = Convert.ToDateTime(_table.Rows[0]["FECHA_SOLICITUD_TXR"].ToString());
                    _response.dateResponse = Convert.ToDateTime(_table.Rows[0]["FECHA_RESPUESTA_TXR"].ToString());
                    _response.rootAccount = _table.Rows[0]["CUENTA_ORIGEN"].ToString()!;
                    _response.destinationAccount = _table.Rows[0]["CUENTA_DESTINO"].ToString()!;
                    _response.akaDestiny = _table.Rows[0]["ALIAS_DESTINO"].ToString()!;
                    _response.operationAmoun = _table.Rows[0]["MONTO_OPERACIO"].ToString()!;
                    _response.currencyOperation = _table.Rows[0]["MONEDA_OPERACION"].ToString()!;
                    _response.confirmation = Convert.ToInt32(_table.Rows[0]["CONFIRMACION"].ToString());
                    _response.codeOtp = _table.Rows[0]["CODIGO_OTP"].ToString()!;
                    _response.clientData = _table.Rows[0]["DATOS_CLIENTE"].ToString()!;
                    _response.service = _table.Rows[0]["SERVICIO"].ToString()!;
                    _response.botMenuValue = _table.Rows[0]["VAL_MENU_BOT"].ToString()!;
                    _response.accumulated = Convert.ToInt32(_table.Rows[0]["ACUMULADO"].ToString());
                }
            }
            catch (Exception ex)
            {
                _logger.Error("ERROR: {0}", ex.Message);
                throw ex;
            }
            return _response;
        }
        public string GetParameterOptain(string _tag)
        {
            try
            {
                DataTable _respose = this._connectionDataBase.GetObtParametricas(_tag);
                if (_respose.Rows.Count == 0)
                    return string.Empty;
                return _respose.Rows[0]["VALOR_TAG"].ToString()!;
            }
            catch (Exception ex)
            {
                this._logger.Error(string.Format("ERROR GET PARAMETER: {0}", ex.Message));
                return string.Empty;
            }
        }
        public async Task<bool> SendOperator(string celular)
        {
            try
            {
                SendMessageApplicationRequest _requestSendMenssageOperator = new();
                _requestSendMenssageOperator.message = "En un momento un operador lo atenderá 😊";
                _requestSendMenssageOperator.typeMessage = "TEXT";
                _requestSendMenssageOperator.classMultimedia = string.Empty;
                _requestSendMenssageOperator.cellphone.Add(celular);
                _requestSendMenssageOperator.identifyChatBot = false;
                _requestSendMenssageOperator.multimediaUrl = string.Empty;
                _requestSendMenssageOperator.url = string.Empty;
                _requestSendMenssageOperator.nameMultimediaUrl = string.Empty;
                _requestSendMenssageOperator.user = "BOT";
                _requestSendMenssageOperator.nameUser = "BOT";
                _requestSendMenssageOperator.parameterMessage = new();
                _requestSendMenssageOperator.nameHsmOfTemplate = string.Empty;
                _requestSendMenssageOperator.campaignName = string.Empty;
                await this._connectionService.SendMessageApplication(_requestSendMenssageOperator);
                ReciveMessageRequest _data = new();
                _data.message = new();
                _data.id = "0";
                _data.message.messageText = "En un momento un operador lo atenderá 😊";
                _data.message.type = "TEXT";
                _data.origin = "5912114141";
                _data.receivedAt = "1688734835000";
                _data.source = celular;
                _data.receivedDate = DateTime.Now.ToString();
                await this._connectionService.OperatorWhatsApp(_data);
            }
            catch (Exception ex)
            {
                _logger.Error("ERROR: {0}", ex.Message);
                throw ex;
            }
            return true;
        }
    }
}
