﻿using Microsoft.Data.SqlClient;
using System.Data;
using WPP.ABSTRACTION.DATAACCESS;
using WPP.ABSTRACTION.ENTITIES.LifeTest;
using WPP.ABSTRACTION.ENTITIES.Transaction;

namespace WPP.APPLICATION.CONNECTION.DATABASE
{
    public interface IExternalConnectionDatabase
    {
        int InsertPassiveLifeTestFromKiosk(PassiveLifeTestFromKioskModel _lifeTest);
        DataTable GetObtParametricas(string _tag);
        void InsertPassiveLifeValidationTest(PassiveLifeTestModel _lifetTest);
        DataTable ProcessRequest(string _request);
        bool InsertNewTransaction(NewTransactionModel _newTransactionModel);
        DataTable GetProcessTransaction(string _guid);
        bool UpdateNewTransaction(TransactionProcessModel _request);
    }
    public class ExternalConnectionDatabase : IExternalConnectionDatabase
    {
        public readonly IDataAccess _dataAccess;
        private static readonly string DATABASE_CONNECTION_NAME = "EXTERNAL";

        public ExternalConnectionDatabase(IDataAccess dataAccess) { this._dataAccess = dataAccess; }

        public int InsertPassiveLifeTestFromKiosk(PassiveLifeTestFromKioskModel _lifeTest)
        {
            List<SqlParameter> _parameter = new();
            _parameter.Add(new SqlParameter() { ParameterName = "@ID_CLIENT", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output, Value = _lifeTest.idClient });
            _parameter.Add(new SqlParameter("@IDC_NUMBER", _lifeTest.idcNumber));
            _parameter.Add(new SqlParameter("@IDC_TYPE", _lifeTest.idcType));
            _parameter.Add(new SqlParameter("@IDC_EXTENSION", _lifeTest.idcExtension));
            _parameter.Add(new SqlParameter("@IDC_SUPPLEMENT", _lifeTest.idcSuppement));
            _parameter.Add(new SqlParameter("@NAME_CLIENT", _lifeTest.nameClient));

            _parameter.Add(new SqlParameter("@PATERNAL_SURNAME_CLIENT", _lifeTest.paternalSurnameClient));
            _parameter.Add(new SqlParameter("@MATERNAL_SURNAME_CLIENT", _lifeTest.maternalSurnameClient));
            _parameter.Add(new SqlParameter("@NEGATIVE_FILE", _lifeTest.negativeFile));
            _parameter.Add(new SqlParameter("@ENAME_CHEKER", _lifeTest.enameCheker));

            _parameter.Add(new SqlParameter("@CELLPHONE", _lifeTest.cellphone));
            _parameter.Add(new SqlParameter("@EMAIL", _lifeTest.email));
            _parameter.Add(new SqlParameter("@REFERENCE_CODE", _lifeTest.referenceCode));
            _parameter.Add(new SqlParameter("@TERMINAL_CODE", _lifeTest.terminalCode));
            _parameter.Add(new SqlParameter("@CHANNEL", _lifeTest.channel));
            _parameter.Add(new SqlParameter("@PASSIVE_LIFE_TEST_SESSION", _lifeTest.passiveLifeTestSession));
            _parameter.Add(new SqlParameter("@SELFIE_INSTRUCCION", _lifeTest.selfieInstruccion));
            _parameter.Add(new SqlParameter("@DIGITAL_RECORD_SESSION", _lifeTest.digitalRecordSession));
            this._dataAccess.ExecuteStoredProcedure(DATABASE_CONNECTION_NAME, "[wpp].[WPP_PASSIVE_LIFE_TEST_FROM_KIOSK_INSERT]", _parameter);
            return Convert.ToInt32(_parameter.First(x => x.Direction == ParameterDirection.Output && x.ParameterName.Equals("@ID_CLIENT")).Value);
        }

        public DataTable GetObtParametricas(string _tag)
        {

            List<SqlParameter> _parameter = new();
            _parameter.Add(new SqlParameter("@TAG", _tag));
            return this._dataAccess.SelectStoredProcedure(DATABASE_CONNECTION_NAME, "[wpp].[WPP_GET_PARAMETROS]", _parameter);
        }
        public void InsertPassiveLifeValidationTest(PassiveLifeTestModel _lifetTest)
        {
            List<SqlParameter> _parameter = new();
            _parameter.Add(new SqlParameter("@IDC_CLIENT", _lifetTest.idcClient));
            _parameter.Add(new SqlParameter("@CELLPHONE", _lifetTest.cellphone));
            _parameter.Add(new SqlParameter("@CODE", _lifetTest.code));
            _parameter.Add(new SqlParameter("@CHANNEL", _lifetTest.channel));
            _parameter.Add(new SqlParameter("@INSTRUCTION", _lifetTest.instruction));
            _parameter.Add(new SqlParameter("@SESSION_ID", _lifetTest.sessionId));
            _parameter.Add(new SqlParameter("@NAME_CLIENT", _lifetTest.nameClient));
            this._dataAccess.ExecuteStoredProcedure(DATABASE_CONNECTION_NAME, "[wpp].[WPP_INSERT_PASSIVE_LIFE_TEST]", _parameter);
        }

        public DataTable ProcessRequest(string _request)
        {
            return this._dataAccess.Select(DATABASE_CONNECTION_NAME, _request);
        }

        public bool InsertNewTransaction(NewTransactionModel _newTransactionModel)
        {

            List<SqlParameter> _parameter = new();
            _parameter.Add(new SqlParameter("@APPLICATION_ID", _newTransactionModel.idSolicitud));
            _parameter.Add(new SqlParameter("@CODE_TRANSACTION", _newTransactionModel.fkCodMenu));
            _parameter.Add(new SqlParameter("@CELLPHONE", _newTransactionModel.celular));
            _parameter.Add(new SqlParameter("@USER", _newTransactionModel.usuario));
            _parameter.Add(new SqlParameter("@TYPE_REQUEST", _newTransactionModel.tipoSolicitud));
            _parameter.Add(new SqlParameter("@FLOW_STATUS", _newTransactionModel.estadoFlujo));
            _parameter.Add(new SqlParameter("@CLIENT_DATA", _newTransactionModel.datosCliente));
            return this._dataAccess.ExecuteStoredProcedure(DATABASE_CONNECTION_NAME, "[wpp].[INSERT_NEW_TRANSACTION]", _parameter);
        }

        public DataTable GetProcessTransaction(string _guid)
        {

            List<SqlParameter> _parameter = new();
            _parameter.Add(new SqlParameter("@GUID", _guid));
            return this._dataAccess.SelectStoredProcedure(DATABASE_CONNECTION_NAME, "[wpp].[WPP_GET_TRANS_PROCESO_X_GUID]", _parameter);
        }


        public bool UpdateNewTransaction(TransactionProcessModel _request)
        {

            List<SqlParameter> _parameters = new();
            _parameters.Add(new SqlParameter("@APPLICATION_ID", _request.idRequest));
            _parameters.Add(new SqlParameter("@CODE_MENU", _request.menuCode));
            _parameters.Add(new SqlParameter("@CELLPHONE", _request.cellphone));
            _parameters.Add(new SqlParameter("@ORIGIN_ACCOUNT", _request.rootAccount));
            _parameters.Add(new SqlParameter("@DESTINATION_ACCOUNT", _request.destinationAccount));
            _parameters.Add(new SqlParameter("@ALIAS_DESTINATION", _request.akaDestiny));
            _parameters.Add(new SqlParameter("@CURRENCY_OPERATION", string.Empty));
            _parameters.Add(new SqlParameter("@OPERATION_AMOUNT", _request.operationAmoun));
            _parameters.Add(new SqlParameter("@CONFIRMATION", _request.confirmation));
            _parameters.Add(new SqlParameter("@OTP_CODE", _request.codeOtp));
            _parameters.Add(new SqlParameter("@FINAL_STATE", _request.stateEnd));
            _parameters.Add(new SqlParameter("@CUSTOMER_DATA", _request.clientData));
            _parameters.Add(new SqlParameter("@PK_TRANSACTION", _request.idTransaction));
            _parameters.Add(new SqlParameter("@FLOW_STATUS", _request.stateTransaction));
            _parameters.Add(new SqlParameter("@SERVICE", _request.service));
            _parameters.Add(new SqlParameter("@MENU", _request.botMenuValue));
            return this._dataAccess.ExecuteStoredProcedure(DATABASE_CONNECTION_NAME, "[wpp].[WPP_TRANSACTION_IN_PROCESS]", _parameters);
        }
    }
}