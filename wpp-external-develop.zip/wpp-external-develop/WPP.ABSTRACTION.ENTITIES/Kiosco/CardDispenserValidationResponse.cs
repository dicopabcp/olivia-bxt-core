﻿
namespace WPP.ABSTRACTION.ENTITIES.Kiosco
{
    public class CardDispenserValidationResponse
    {
        public string DetailMessage { get; set; } = string.Empty;
        public string RespCode { get; set; } = string.Empty;
        public string OTP { get; set; } = string.Empty;
    }
}
