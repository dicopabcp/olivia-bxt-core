﻿
namespace WPP.ABSTRACTION.ENTITIES.Kiosco
{
    public class CardDispenserValidationRequest
    {
        public string IDC { get; set; } = string.Empty;
        public string ReferenceID { get; set; } = string.Empty;
        public string CellPhone { get; set; } = string.Empty;
        public string Imagen { get; set; } = string.Empty;
        public string ValidationStatus { get; set; } = string.Empty;
        public string Canal { get; set; } = string.Empty;
        public string User { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }
}
