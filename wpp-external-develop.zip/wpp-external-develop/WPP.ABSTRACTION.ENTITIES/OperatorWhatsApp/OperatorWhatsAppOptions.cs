﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPP.ABSTRACTION.ENTITIES.OperatorWhatsApp
{
    public class OperatorWhatsAppOptions
    {
        public string urlOperator { get; set; } = string.Empty;
        public string methodOperator { get; set; } = string.Empty;
        public string ssignedArea { get; set; } = string.Empty;
    }
}
