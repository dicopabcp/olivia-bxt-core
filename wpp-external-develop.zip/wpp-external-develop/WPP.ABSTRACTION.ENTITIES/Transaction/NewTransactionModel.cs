﻿namespace WPP.ABSTRACTION.ENTITIES.Transaction
{
    public class NewTransactionModel
    {
        public int pkWpp { get; set; }
        public string idSolicitud { get; set; } = string.Empty;
        public string fkCodMenu { get; set; } = string.Empty;
        public string celular { get; set; } = string.Empty;
        public string usuario { get; set; } = string.Empty;
        public int tipoSolicitud { get; set; }
        public int estadoFlujo { get; set; }
        public string estadoFinal { get; set; } = string.Empty;
        public string servicioTransaccion { get; set; } = string.Empty;
        public string request { get; set; } = string.Empty;
        public string response { get; set; } = string.Empty;
        public DateTime fechaSolicitudTXR { get; set; }
        public DateTime fechaRespuestaTXR { get; set; }
        public int confirmacion { get; set; }
        public string codigoOTP { get; set; } = string.Empty;
        public string cuentaOrigen { get; set; } = string.Empty;
        public string cuentaDestino { get; set; } = string.Empty;
        public string datosCliente { get; set; } = string.Empty;
        public string aliasDestino { get; set; } = string.Empty;
        public decimal montoOperacion { get; set; }
        public string monedaOperacion { get; set; } = string.Empty;
        public string servicio { get; set; } = string.Empty;
        public string valorMenuBot { get; set; } = string.Empty;
    }
}

