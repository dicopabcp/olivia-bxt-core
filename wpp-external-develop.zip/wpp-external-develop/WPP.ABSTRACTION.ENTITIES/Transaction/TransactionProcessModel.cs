﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPP.ABSTRACTION.ENTITIES.Transaction
{
    public class TransactionProcessModel
    {
        public int idTransaction { get; set; }  // ID PK_WPP
        public string idRequest { get; set; } = string.Empty;   // ID SOLICITUD 
        public string menuCode { get; set; } = string.Empty;    //  CODIGO DE LA TRANSACCION EN PROCESO 
        public string cellphone { get; set; } = string.Empty;   //  NUMERO DE CELULAR 
        public string user { get; set; } = string.Empty;    // USUARIO POR DEFECTO PROCESO BOT
        public string typeRequest { get; set; } = string.Empty; // TIPO DE SOLICITUD
        public string stateTransaction { get; set; } = string.Empty;    //  ESTADO DEL FLUJO
        public string stateEnd { get; set; } = string.Empty;    // ESTADO FINAL
        public string serviceTransaction { get; set; } = string.Empty;  //  SERVICIO TRANSACCION
        public string request { get; set; } = string.Empty; //  REQUEST
        public string response { get; set; } = string.Empty;    //  RESPONSE
        public DateTime dateRequest { get; set; }   // FECHA SOLICITUD TXR
        public DateTime dateResponse { get; set; }  // FECHA RESPUESTA TXR
        public int confirmation { get; set; }   //  CONFIRMACION
        public string codeOtp { get; set; } = string.Empty; // CODIGO OTP
        public string rootAccount { get; set; } = string.Empty; //  CUENTA ORIGEN 
        public string destinationAccount { get; set; } = string.Empty;  //  CUENTA DESTINO
        public string clientData { get; set; } = string.Empty;  //  DATOS CLIENTE
        public string akaDestiny { get; set; } = string.Empty;  // ALIAS DESTINO
        public string operationAmoun { get; set; } = string.Empty;  //  MONTO OPERACION
        public string currencyOperation { get; set; } = string.Empty;   //  MONEDA OPERACION
        public string service { get; set; } = string.Empty;    // SERVICIO
        public string botMenuValue { get; set; } = string.Empty;    // VAL MENU BOT
        public int accumulated { get; set; }    // MONTO ACUMULADO
    }
}
