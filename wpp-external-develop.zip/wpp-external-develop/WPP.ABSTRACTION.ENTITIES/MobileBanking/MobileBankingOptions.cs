﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPP.ABSTRACTION.ENTITIES.MobileBanking
{
    public class MobileBankingOptions
    {
        public string urlMobileBanking { get; set; } = string.Empty;
        public string methodMobileBanking { get; set; } = string.Empty;
        public string channel { get; set; } = string.Empty;
    }
}
