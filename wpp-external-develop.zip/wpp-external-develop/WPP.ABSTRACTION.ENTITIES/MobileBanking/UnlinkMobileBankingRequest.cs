﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPP.ABSTRACTION.ENTITIES.MobileBanking
{
    public class UnlinkMobileBankingRequest
    {
        public string cic { get; set; } = string.Empty;
    }
}
