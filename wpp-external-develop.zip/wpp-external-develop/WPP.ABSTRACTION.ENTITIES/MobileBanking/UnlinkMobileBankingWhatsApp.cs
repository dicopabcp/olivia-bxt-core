﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPP.ABSTRACTION.ENTITIES.MobileBanking
{
    public class UnlinkMobileBankingWhatsApp
    {
        public bool SolicitudIdc { get; set; } = false;

        public RekognitionSession? RekognitionSession { get; set; } = null;

        public RekognitionValidation? RekognitionValidation { get; set; } = null;

        public InfoCliente? InfoCliente { get; set; } = null;

        public InfoDatoAdicional? InfoDatoAdicional { get; set; } = null;

        public GenericResponse? BankingMobileResponse { get; set; } = null;

        public int IntentosIdc { get; set; }
    }

    public class InfoClienteResponse
    {
        public InfoCliente? InfoCliente { get; set; }

        public InfoDatoAdicional? InfoDatoAdicional { get; set; }
    }

    public class InfoDatoAdicional
    {
        public int DatoAdicionalId { get; set; }
        public int ClienteId { get; set; }
        public int CodTelefonoId { get; set; }
        public string Telefono { get; set; } = string.Empty;
        public string Celular { get; set; } = string.Empty;
        public string CorreoElectronico { get; set; } = string.Empty;
        public string Usuario { get; set; } = string.Empty;
        public DateTime FechaUltimaModificacion { get; set; }
        public DateTime FechaCreacion { get; set; }
        public string Canal { get; set; } = string.Empty;
    }
    public class InfoCliente
    {
        public int ClienteId { get; set; }
        public string Paterno { get; set; } = string.Empty;
        public string Materno { get; set; } = string.Empty;
        public string Nombre { get; set; } = string.Empty;
        public string Idc { get; set; } = string.Empty;
        public string Estado { get; set; } = string.Empty;
        public string Usuario { get; set; } = string.Empty;
        public DateTime FechaUltimaModificacion { get; set; }
        public DateTime FechaCreacion { get; set; }
        public string Canal { get; set; } = string.Empty;
        public string Origen { get; set; } = string.Empty;
        public string Complemento { get; set; } = string.Empty;
        public string Alias { get; set; } = string.Empty;
        public string Cic { get; set; } = string.Empty;
    }

    public class RekognitionSession
    {
        public string Url { get; set; } = string.Empty;

        public string SessionId { get; set; } = string.Empty;

        public string FechaHora { get; set; } = string.Empty;
    }

    public class RekognitionValidation
    {
        public string Idc { get; set; } = string.Empty;

        public string FinishedProcess { get; set; } = "false";

        public string Phase { get; set; } = "INITSTATE";

        public string SessionID { get; set; } = string.Empty;

        public string FechaHora { get; set; } = string.Empty;
    }

}
