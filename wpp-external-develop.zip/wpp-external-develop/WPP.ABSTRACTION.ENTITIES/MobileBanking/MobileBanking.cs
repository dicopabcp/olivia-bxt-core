﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPP.ABSTRACTION.ENTITIES.MobileBanking
{
    public class MobileBankingRequest
    {
        public string strGuid { get; set; } = string.Empty;
        public bool success { get; set; } = false;

    }
}
