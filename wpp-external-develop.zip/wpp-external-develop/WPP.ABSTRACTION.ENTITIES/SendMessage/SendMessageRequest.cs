﻿
namespace WPP.ABSTRACTION.ENTITIES.SendMessage
{
    public class SendMessageRequest
    {
        public List<SendMessageDestinations> destinations { get; set; } = new List<SendMessageDestinations>();
        public SendMessageData message { get; set; } = new SendMessageData();
        public string campaignAlias { get; set; } = string.Empty;
        public string defaultExtraInfo { get; set; } = string.Empty;
    }
    public class SendMessageDestinations
    {
        public string correlationId { get; set; } = string.Empty;
        public string destination { get; set; } = string.Empty;
    }
    public class SendMessageData
    {
        public string messageText { get; set; } = string.Empty;
        public SendMessageType image { get; set; } = new SendMessageType();
        public SendMessageType audio { get; set; } = new SendMessageType();
        public SendMessageType document { get; set; } = new SendMessageType();
        public List<SendMessageContact> contacts { get; set; } = new List<SendMessageContact>();
        public SendMessageLocation location { get; set; } = new SendMessageLocation();
        public SendMessageHsm hsm { get; set; } = new();
        public SendMessageTemplate template { get; set; } = new SendMessageTemplate();
    }
    public class SendMessageTemplate
    {
        public string @namespace { get; set; } = string.Empty;
        public string elementName { get; set; } = string.Empty;
        public SendMessageTemplateHeader header { get; set; } = new SendMessageTemplateHeader();
        public List<string> bodyParameters { get; set; } = new List<string>();
        public string languagePolicy { get; set; } = string.Empty;
        public string languageCode { get; set; } = string.Empty;
    }
    public class SendMessageTemplateHeader
    {
        public SendMessageUrl image { get; set; } = new SendMessageUrl();
    }
    public class SendMessageType
    {
        public string type { get; set; } = string.Empty;
        public string url { get; set; } = string.Empty;
        public string data { get; set; } = string.Empty;
        public string caption { get; set; } = string.Empty;
    }
    public class SendMessageHsm
    {
        public string @namespace { get; set; } = string.Empty;
        public string elementName { get; set; } = string.Empty;
        public List<string> parameters { get; set; } = new List<string>();
        public string languageCode { get; set; } = string.Empty;
    }
    public class SendMessageContact
    {
        public List<SendMessageAddress> addresses { get; set; } = new List<SendMessageAddress>();
        public string birthday { get; set; } = string.Empty;
        public List<SendMessageEmail> emails { get; set; } = new List<SendMessageEmail>();
        public SendMessageName name { get; set; } = new SendMessageName();
        public SendMessageOrg org { get; set; } = new SendMessageOrg();
        public List<SendMessagePhone> phones { get; set; } = new List<SendMessagePhone>();
        public List<SendMessageUrl> urls { get; set; } = new List<SendMessageUrl>();
    }
    public class SendMessageLocation
    {
        public string geoPoint { get; set; } = string.Empty;
        public string name { get; set; } = string.Empty;
        public string address { get; set; } = string.Empty;
    }
    public class SendMessageAddress
    {
        public string street { get; set; } = string.Empty;
        public string city { get; set; } = string.Empty;
        public string state { get; set; } = string.Empty;
        public string zip { get; set; } = string.Empty;
        public string country { get; set; } = string.Empty;
        public string country_code { get; set; } = string.Empty;
        public string type { get; set; } = string.Empty;
    }
    public class SendMessageEmail
    {
        public string email { get; set; } = string.Empty;
        public string type { get; set; } = string.Empty;
    }
    public class SendMessageName
    {
        public string first_name { get; set; } = string.Empty;
        public string last_name { get; set; } = string.Empty;
        public string formatted_name { get; set; } = string.Empty;
    }
    public class SendMessageOrg
    {
        public string company { get; set; } = string.Empty;
        public string department { get; set; } = string.Empty;
        public string title { get; set; } = string.Empty;
    }
    public class SendMessagePhone
    {
        public string phone { get; set; } = string.Empty;
        public string type { get; set; } = string.Empty;
    }
    public class SendMessageUrl
    {
        public string url { get; set; } = string.Empty;
        public string type { get; set; } = string.Empty;
    }
}
