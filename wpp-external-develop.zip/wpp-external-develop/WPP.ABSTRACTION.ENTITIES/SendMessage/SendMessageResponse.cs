﻿
namespace WPP.ABSTRACTION.ENTITIES.SendMessage
{
    public class SendMessageResponse : GenericResponse
    {
        public string id { get; set; } = string.Empty;
        public List<SendMessageDestinationsResponse> destinations { get; set; } = new List<SendMessageDestinationsResponse>();
        public int errorCode { get; set; }
        public string errorMessage { get; set; } = string.Empty;
    }
    public class SendMessageDestinationsResponse
    {
        public string id { get; set; } = string.Empty;
        public string correlationId { get; set; } = string.Empty;
        public string destination { get; set; } = string.Empty;

    }
}
