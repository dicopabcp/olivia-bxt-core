﻿
namespace WPP.ABSTRACTION.ENTITIES.IVRConnection
{
    public class IVRConnectionRequest
    {
        public string cellphone { get; set; } = string.Empty;
    }
    
    public class IvrTemplateConfiguration
    {
        public string Campaign { get; set; } = string.Empty;
        public string TypeTemplate { get; set; } = string.Empty;
        public string NameTemplate { get; set; } = string.Empty;
        public string User { get; set; } = string.Empty;
    }
}
