﻿
namespace WPP.ABSTRACTION.ENTITIES.IVRConnection
{
    public class GushupWppFlowsConfig
    {
        public string Url { get; set; } = string.Empty;
        public string MethodSendFlow { get; set; } = string.Empty;
        public string Authorization { get; set; } = string.Empty;
    }
}
