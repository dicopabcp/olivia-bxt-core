﻿
namespace WPP.ABSTRACTION.ENTITIES.SendMessageApplication
{
    public class SendMessageApplicationRequest
    {
        public string? message { get; set; } // MENSAJE DE TEXTO A ENVIAR 
        public string? typeMessage { get; set; }  // TIPO DE MENSAJE EJ: TEXT, IMAGE, AUDIO, VIDEO, DOCUMENT, LOCATION, CONTACTS, HSM, TEMPLATE, INTERACTIVE, STICKER
        public string? classMultimedia { get; set; }  // EXTENSION DEL ARCHIVO MULTIMEDIA EJ: IMAGE (JPG, JPEG, PNG) AUDIO (ACC, AMR, MP3(MPEG), OGG) : VIDEO (MP4) : DOCUMENT (PDF) 
        public string? classInteractive { get; set; }  // INTERACTIVE (LIST, REPLY_BUTTON)
        public List<string> cellphone { get; set; } = new List<string>(); // LISTA DE CELULARES PARA ENVIAR EL MENSAJE EJ: 59175806163
        public string? destinationAccount { get; set; } = string.Empty; // NUMERO DE CELULAR DE LA CUENTA AL QUE VA EL MENSAJE EJ: 
        public bool identifyChatBot { get; set; }   // IDENTIFICADOR DE SI EL MENSAJE ES DEL OPERADOR O DEL BOT
        public string? multimediaUrl { get; set; }    //  BASE 64 ARCHIVO MULTIMEDIA DE TIPO: IMAGEN, AUDIO, VIDEO, DOCUMENTO
        public string? url { get; set; }    // URL DEL ARCHIVO MULTIMEDIA DE TIPO: IMAGEN, AUDIO, VIDEO, DOCUMENTO
        public string? nameMultimediaUrl { get; set; }    // NOMBRE CON EL QUE SE ENVIARA EL ARVHIVO MULTIMEDIA (IMAGE, VIDEO, DOCUMENT)
        public string? user { get; set; }  // USUARIO QUE REALIZA EL ENVIO DEL MENSAJE
        public string? nameUser { get; set; }  // NOMBRE DEL USUARIO QUE REALIZA EL ENVIO DEL MENSAJE
        public List<string> parameterMessage { get; set; } = new List<string>();    //  LISTA DE PARAMETROS PARA LA CLASE DE MENSAJE DE TIPO HSM, TEMPLATE, LOCATION, 
        public string nameHsmOfTemplate { get; set; } = string.Empty;    //  NOMBRE DE LA CLASE DE MENSAJE HSM, TEMPLATE
        public string? campaignName { get; set; }     //  NOMBRE DE LA CAMPAÑA PARA EL ENVIO DEL MENSAJE
        public MessageInteractiveModel parametersInteractive { get; set; } = new MessageInteractiveModel(); // PARAMETROS PARA EL ENVIO DE MENSAJES INTERACTIVOS 
        public MessageTemplateModel parametersTemplate { get; set; } = new MessageTemplateModel();
    }

    public class MessageInteractiveModel
    {
        public string nameSelectorButton { get; set; } = string.Empty;
        public string classMessageInteractive { get; set; } = string.Empty;
        public string header { get; set; } = string.Empty;
        public string body { get; set; } = string.Empty;
        public string footer { get; set; } = string.Empty;
        public List<InteractiveParameterModel> parameters { get; set; } = new List<InteractiveParameterModel>();
        public string alternativeText { get; set; } = string.Empty;
    }

    public class InteractiveParameterModel
    {
        public string title { get; set; } = string.Empty;
        public string description { get; set; } = string.Empty;
        public string identifier { get; set; } = string.Empty;
    }

    public class MessageTemplateModel
    {
        public string classMessageTemplate { get; set; } = string.Empty;
    }

    public class SendMessageExternalRequest
    {
        public int messageId { get; set; } // ID DEL MENSAJE INSERTADO A NIVEL BASE DE DATOS 
        public string? destinationAccount { get; set; } // MENSAJE DE TEXTO A ENVIAR 
        public string? message { get; set; } // MENSAJE DE TEXTO A ENVIAR 
        public string? typeMessage { get; set; }  // TIPO DE MENSAJE EJ: TEXT, IMAGE, AUDIO, VIDEO, DOCUMENT, LOCATION, CONTACTS, HSM, TEMPLATE, INTERACTIVE, STICKER
        public string? classMultimedia { get; set; }  // EXTENSION DEL ARCHIVO MULTIMEDIA EJ: IMAGE (JPG, JPEG, PNG) AUDIO (ACC, AMR, MP3(MPEG), OGG) : VIDEO (MP4) : DOCUMENT (PDF) 
        public string? classInteractive { get; set; }  // INTERACTIVE (LIST, REPLY_BUTTON)
        public List<string> cellphone { get; set; } = new List<string>(); // LISTA DE CELULARES PARA ENVIAR EL MENSAJE EJ: 59175806163
        public bool identifyChatBot { get; set; }   // IDENTIFICADOR DE SI EL MENSAJE ES DEL OPERADOR O DEL BOT
        public string? multimediaUrl { get; set; }    //  BASE 64 ARCHIVO MULTIMEDIA DE TIPO: IMAGEN, AUDIO, VIDEO, DOCUMENTO
        public string? url { get; set; }    // URL DEL ARCHIVO MULTIMEDIA DE TIPO: IMAGEN, AUDIO, VIDEO, DOCUMENTO
        public string? nameMultimediaUrl { get; set; }    // NOMBRE CON EL QUE SE ENVIARA EL ARVHIVO MULTIMEDIA (IMAGE, VIDEO, DOCUMENT)
        public string? user { get; set; }  // USUARIO QUE REALIZA EL ENVIO DEL MENSAJE
        public string? nameUser { get; set; }  // NOMBRE DEL USUARIO QUE REALIZA EL ENVIO DEL MENSAJE
        public List<string> parameterMessage { get; set; } = new List<string>();    //  LISTA DE PARAMETROS PARA LA CLASE DE MENSAJE DE TIPO HSM, TEMPLATE, LOCATION, 
        public string nameHsmOfTemplate { get; set; } = string.Empty;    //  NOMBRE DE LA CLASE DE MENSAJE HSM, TEMPLATE
        public string? campaignName { get; set; }     //  NOMBRE DE LA CAMPAÑA PARA EL ENVIO DEL MENSAJE
        public MessageInteractiveModel parametersInteractive { get; set; } = new MessageInteractiveModel(); // PARAMETROS PARA EL ENVIO DE MENSAJES INTERACTIVOS 
        public MessageTemplateModel parametersTemplate { get; set; } = new MessageTemplateModel();
    }

    public class SendMessageTextExternalRequest
    {
        public string? cellphone { get; set; } // LISTA DE CELULARES PARA ENVIAR EL MENSAJE EJ: 59175806163
        public string? message { get; set; } // MENSAJE DE TEXTO A ENVIAR 
        public string? nameUser { get; set; }  // NOMBRE DEL USUARIO QUE REALIZA EL ENVIO DEL MENSAJE
        public string? destinationAccount { get; set; } = string.Empty;

    }
    public class SendMessageButtonExternalRequest
    {
        public string? cellphone { get; set; } // LISTA DE CELULARES PARA ENVIAR EL MENSAJE EJ: 59175806163
        public string? message { get; set; } // MENSAJE DE TEXTO A ENVIAR 
        public string? nameUser { get; set; }  // NOMBRE DEL USUARIO QUE REALIZA EL ENVIO DEL MENSAJE
        public string? destinationAccount { get; set; } = string.Empty;
        public List<string> listButton { get; set; }

    }

    public class SendMessageListExternalRequest
    {
        public string? cellphone { get; set; } // LISTA DE CELULARES PARA ENVIAR EL MENSAJE EJ: 59175806163
        public string? message { get; set; } // MENSAJE DE TEXTO A ENVIAR 
        public string? nameUser { get; set; }  // NOMBRE DEL USUARIO QUE REALIZA EL ENVIO DEL MENSAJE
        public string? destinationAccount { get; set; } = string.Empty;
        public string? button { get; set; } = string.Empty;
        public List<MessageListItem> list { get; set; } = new List<MessageListItem>();
    }

    public class MessageListItem
    {
        public string? title { get; set; }
        public string? description { get; set; }
        public string? identifier { get; set; }
    }

}
