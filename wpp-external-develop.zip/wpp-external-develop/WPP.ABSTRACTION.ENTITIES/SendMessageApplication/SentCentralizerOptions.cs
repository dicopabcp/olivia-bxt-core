﻿namespace WPP.ABSTRACTION.ENTITIES.SendMessageApplication
{
    public class SentCentralizerOptions
    {
        public string urlSentCentralizer { get; set;} = string.Empty;
        public string methodSentCentralizer { get; set; } = string.Empty;
        public string destinationAccount { get; set; } = string.Empty;
        public string nameTemplateOtpSend { get; set; } = string.Empty;
    }
}