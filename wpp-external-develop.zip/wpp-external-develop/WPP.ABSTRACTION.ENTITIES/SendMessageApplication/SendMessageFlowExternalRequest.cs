﻿
namespace WPP.ABSTRACTION.ENTITIES.SendMessageApplication
{
    public class SendMessageFlowExternalRequest
    {
        public string cellphone { get; set; } = string.Empty;
        
        public string message { get; set; } = string.Empty;

        public string nameFlow { get; set; } = string.Empty;
        
        public string wppSesionId { get; set; } = string.Empty;

        // Pantalla inicial del Flow (ej: CSM_DATOS_CI, CSM_LOGIN_CLAVE); vacio = pantalla por defecto del Flow.
        public string? screen { get; set; }

        // Cabecera y pie de pagina opcionales del mensaje del Flow.
        public string? header { get; set; }

        public string? footer { get; set; }
    }

    public class SendFlowRequest
    {
        public string flow_id { get; set; } = string.Empty;

        public DateTime event_time { get; set; } = DateTime.Now;

        public FlowUserInformation user { get; set; } = new FlowUserInformation();
    }

    public class FlowUserInformation
    {
        public string message { get; set; } = string.Empty;
        
        public string phone { get; set; } = string.Empty;
        
        public string wppSesionId { get; set; } = string.Empty;

        public string? screen { get; set; }

        public string? header { get; set; }

        public string? footer { get; set; }
    }
}
