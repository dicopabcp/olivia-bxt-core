﻿namespace WPP.ABSTRACTION.ENTITIES.CoreAntiguo
{
    public class WhatsAppEnviadoRequest
    {
        public string? Mensaje { get; set; }
        
        public List<string>? destino { get; set; }
        
        public string? type { get; set; }
        
        public string? arrayBase64 { get; set; }

        public string? idcampania { get; set; }
        
        public string? namehsm { get; set; }
        
        public List<string>? parametroshsm { get; set; }
        
        public string? url { get; set; }
        
        public string? typeUrl { get; set; }
        
        public string? canal { get; set; }
        
        public string? passcanal { get; set; }
        
        public WhatsAppEnviadoRequest()
        {
            this.Mensaje = string.Empty;
            this.type = string.Empty;
            this.arrayBase64 = string.Empty;
        }
    }
}
