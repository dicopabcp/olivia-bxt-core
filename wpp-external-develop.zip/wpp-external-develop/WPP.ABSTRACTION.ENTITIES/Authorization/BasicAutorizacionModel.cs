﻿
namespace WPP.ABSTRACTION.ENTITIES.Authorization
{
    public class BasicAutorizacionModel
    {
        public int id { get; set; }
        public string userName { get; set; } = string.Empty;
        public string password { get; set; } = string.Empty;
    }
}
