﻿

namespace WPP.ABSTRACTION.ENTITIES.LifeTest
{
    public class CreateSessionResponse
    {
        public string instruccion { get; set; } = string.Empty;
        public string imgInstruccion { get; set; } = string.Empty;
        public string sessionID { get; set; } = string.Empty;
        public string fechaHora { get; set; } = string.Empty;
    }
}
