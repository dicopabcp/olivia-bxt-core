﻿namespace WPP.ABSTRACTION.ENTITIES.LifeTest
{
    public class PassiveLifeTestOptions
    {
        public string urlPasiveLifeTest { get; set; } = string.Empty;
        public string methodPasiveLifeTest { get; set;} = string.Empty;
        public string accesKeyPasiveLifeTest { get; set; } = string.Empty;
        public string secreyKeyPasiveLifeTest { get; set; }= string.Empty;
        public string accesKeyPassiveLifeTestDigital { get; set; } = string.Empty;
        public string secreyKeyPassiveLfeTestDigital { get; set; } = string.Empty;
    }
}
