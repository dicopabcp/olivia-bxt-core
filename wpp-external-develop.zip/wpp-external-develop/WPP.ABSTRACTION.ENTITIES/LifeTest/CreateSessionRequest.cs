﻿
namespace WPP.ABSTRACTION.ENTITIES.LifeTest
{
    public class CreateSessionRequest
    {
        public string idc { get; set; } = string.Empty;
        public string email { get; set; } = string.Empty;
        public string celular { get; set; } = string.Empty;
        public string canal { get; set; } = string.Empty;
        public string idResguardo { get; set; } = string.Empty;
    }
}
