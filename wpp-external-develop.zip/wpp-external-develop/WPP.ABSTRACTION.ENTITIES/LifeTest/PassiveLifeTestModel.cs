﻿namespace WPP.ABSTRACTION.ENTITIES.LifeTest
{
    public class PassiveLifeTestModel
    {
        public int idClient { get; set; }
        public string idcClient { get; set; } = string.Empty;
        public string cellphone { get; set; } = string.Empty;
        public string code { get; set; } = string.Empty;
        public string channel { get; set; } = string.Empty;
        public string instruction { get; set; } = string.Empty;
        public bool completed { get; set; }
        public DateTime registrationDate { get; set; } 
        public DateTime modificationDate { get; set; }
        public string sessionId { get; set; } = string.Empty;
        public string nameClient { get; set; } = string.Empty;
        public int attempts { get; set; }
    }

    public class PassiveLifeTestFromKioskModel
    {
        public int idClient { get; set; }
        public string idcNumber { get; set; } = string.Empty;
        public string idcType { get; set; } = string.Empty;
        public string idcExtension { get; set; } = string.Empty;
        public string idcSuppement { get; set; } = string.Empty;
        public string nameClient { get; set; } = string.Empty;
        public string paternalSurnameClient { get; set; } = string.Empty;
        public string maternalSurnameClient { get; set; } = string.Empty;
        public bool negativeFile { get; set; }
        public bool enameCheker { get; set; }
        public string cellphone { get; set; } = string.Empty;
        public string email { get; set; } = string.Empty;
        public string referenceCode { get; set; } = string.Empty;
        public string terminalCode { get; set; } = string.Empty;
        public string channel { get; set; } = string.Empty;
        public DateTime registrationDate { get; set; }
        public DateTime modificationDate { get; set; }
        public string digitalRecordSession { get; set; } = string.Empty;
        public string passiveLifeTestSession { get; set; } = string.Empty;
        public int attempts { get; set; }
        public string selfieInstruccion { get; set; } = string.Empty;
        public bool completed { get; set; }
        public string process { get; set; } = string.Empty;
        public URLIdentityCard identityCard { get; set; } = new URLIdentityCard();
        public Urlselfie selfie { get; set; } = new Urlselfie();
    }

    public class URLIdentityCard
    {
        public string obverse { get; set; } = string.Empty;
        public string reverse { get; set; } = string.Empty;
    }
    public class Urlselfie
    {
        public string selfie { get; set; } = string.Empty;
    }
}
