﻿
namespace WPP.ABSTRACTION.ENTITIES.LifeTest
{
    public class LifeTestKioscoRequest 
    {
        public string IDC { get; set; } = string.Empty;
        public string ReferenceID { get; set; } = string.Empty;
        public string cellphone { get; set; } = string.Empty;
        public string customerName { get; set; } = string.Empty;
    }

    public class PassiveLifeTestKioskRequest
    {
        public string idcNumber { get; set; } = string.Empty;
        public string idcType { get; set; } = string.Empty;
        public string idcExtension { get; set; } = string.Empty;
        public string idcSupplement { get; set; } = string.Empty;
        public string nameClient { get; set; } = string.Empty;
        public string paternalSurnameClient { get; set; } = string.Empty;
        public string maternalSurnameClient { get; set; } = string.Empty;
        public string? digitalRecordSession { get; set; } = string.Empty;
        public bool negativeFile { get; set; }
        public bool enameCheker { get; set; }
        public string cellphone { get; set; } = string.Empty;
        public string referenceCode { get; set; } = string.Empty;
        public string terminalCode { get; set; } = string.Empty;
        public string email { get; set; } = string.Empty;
    }
}
