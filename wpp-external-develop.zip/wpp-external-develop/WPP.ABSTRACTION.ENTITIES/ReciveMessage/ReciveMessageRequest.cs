﻿namespace WPP.ABSTRACTION.ENTITIES.ReciveMessage
{
    public class ReciveMessageRequest
    {
        public string id { get; set; } = string.Empty;
        public string source { get; set; } = string.Empty;
        public string origin { get; set; } = string.Empty;
        public int campaignId { get; set; }
        public string correlationId { get; set; } = string.Empty;
        public string campaignAlias { get; set; } = string.Empty;
        public string flowId { get; set; } = string.Empty;
        public string extraInfo { get; set; } = string.Empty;
        public MensajeWhatsapp message { get; set; } = new();
        public string receivedAt { get; set; } = string.Empty;
        public string receivedDate { get; set; } = string.Empty;
    }

    public class MensajeWhatsapp
    {
        public string type { get; set; } = string.Empty;
        public string messageText { get; set; } = string.Empty;

        public string waGroupId { get; set; } = string.Empty;

        public string mediaUrl { get; set; } = string.Empty;

        public string mimeType { get; set; } = string.Empty;

        public string caption { get; set; } = string.Empty;

        public ReceiveMessageLocation location { get; set; } = new();

        public List<ReceiveMessageContact> contacts { get; set; } = new List<ReceiveMessageContact>();

    }

    public class ReceiveMessageLocation
    {
        public string geoPoint { get; set; } = string.Empty;
        public string name { get; set; } = string.Empty;
        public string address { get; set; } = string.Empty;

    }

    public class ReceiveMessageContact
    {
        public List<ReceiveMessageAddress> addresses { get; set; } = new List<ReceiveMessageAddress>();
        public string birthday { get; set; } = string.Empty;
        public List<ReceiveMessageEmail> emails { get; set; } = new List<ReceiveMessageEmail>();
        public ReceiveMessageName name { get; set; } = new();
        public ReceiveMessageOrg org { get; set; } = new();
        public List<ReceiveMessagePhone> phones { get; set; } = new List<ReceiveMessagePhone>();
        public List<ReceiveMessageUrl> urls { get; set; } = new List<ReceiveMessageUrl>();

    }

    public class ReceiveMessageAddress
    {
        public string street { get; set; } = string.Empty;
        public string city { get; set; } = string.Empty;
        public string state { get; set; } = string.Empty;
        public string zip { get; set; } = string.Empty;
        public string country { get; set; } = string.Empty;
        public string country_code { get; set; } = string.Empty;
        public string type { get; set; } = string.Empty;

    }

    public class ReceiveMessageEmail
    {
        public string email { get; set; } = string.Empty;
        public string type { get; set; } = string.Empty;

    }

    public class ReceiveMessageName
    {
        public string first_name { get; set; } = string.Empty;
        public string last_name { get; set; } = string.Empty;
        public string formatted_name { get; set; } = string.Empty;

    }

    public class ReceiveMessageOrg
    {
        public string company { get; set; } = string.Empty;
        public string department { get; set; } = string.Empty;
        public string title { get; set; } = string.Empty;

    }

    public class ReceiveMessagePhone
    {
        public string phone { get; set; } = string.Empty;
        public string type { get; set; } = string.Empty;
        public string wa_id { get; set; } = string.Empty;


    }

    public class ReceiveMessageUrl
    {
        public string url { get; set; } = string.Empty;
        public string type { get; set; } = string.Empty;

    }
}
