﻿namespace WPP.ABSTRACTION.ENTITIES
{
    public class GenericResponse
    {
        public bool success { get; set; }
        public string message { get; set; } = string.Empty;
        public string code { get; set; } = string.Empty;
    }

    public class GenericResponseKiosco
    {
        public string IDC { get; set; } = string.Empty;
        public string ReferenceID{ get; set; } = string.Empty;
        public bool success { get; set; }
        public string message { get; set; } = string.Empty;
        public string code { get; set; } = string.Empty;
    }
    public class ProcessRequest
    {
        public string process { get; set; } = String.Empty;
    }
}