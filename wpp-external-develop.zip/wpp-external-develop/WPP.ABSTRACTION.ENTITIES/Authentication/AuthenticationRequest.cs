﻿
namespace WPP.ABSTRACTION.ENTITIES.Authentication
{
    public class AuthenticationRequest
    {
        public string username_waby { get; set; } = string.Empty;
        public string authenticationToken_waby { get; set; } = string.Empty;
        public string canal { get; set; } = string.Empty;
        public string passcanal { get; set; } = string.Empty;
    }
}
