﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;
using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.ENTITIES.CoreAntiguo;
using WPP.ABSTRACTION.ENTITIES.IVRConnection;
using WPP.ABSTRACTION.ENTITIES.LifeTest;
using WPP.ABSTRACTION.ENTITIES.MobileBanking;
using WPP.ABSTRACTION.ENTITIES.SendMessageApplication;
using WPP.ABSTRACTION.LOGGER;
using WPP.APPLICATION.BUSSINESS;

namespace Wpp.Api.External.Controllers
{
    /// <summary>
    /// Controlador para el envio de mensajes de WhatsApp para diferentes canales
    /// </summary>
    [Route("api/v1/[controller]")]
    [ApiController]
    public class ExternalController : ControllerBase
    {
        private readonly ILoggerInfo _logger;
        private readonly IExternalBussiness _externalBussiness;
        public ExternalController(ILoggerInfo logger, IExternalBussiness externalBussiness) { this._logger = logger; this._externalBussiness = externalBussiness; }

        /// <summary>
        /// Se envia mensaje template para prueba de vida desde Kiosko
        /// </summary>
        /// <param name="_request">Informacion del cliente para el envio de mensaje template</param>
        /// <remarks>
        /// Request example:
        /// ```json
        ///{
        ///  "idc": "7086114LPXX",
        ///  "referenceID": "GENERADO",
        ///  "cellphone": "59160128357",
        ///  "customerName": "OLIVIA"
        ///}
        /// ```
        /// </remarks>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Envio de mensaje satisfactorio</returns>
        [ApiExplorerSettings(GroupName = "v1")]
        [HttpPost("InitializePassiveLifeTest")]
        [ProducesResponseType(typeof(GenericResponseKiosco), 200)]
        public async Task<IActionResult> InitializePassiveLifeTest(LifeTestKioscoRequest _request)
        {
            GenericResponseKiosco _response = new();
            try
            {
                this._logger.Debug(string.Format(" REQUEST: {0}", JsonConvert.SerializeObject(_request)));
                _response = await this._externalBussiness.StartPassiveLifeTest(_request);
                this._logger.Debug(string.Format("RESPONSE: {0}", JsonConvert.SerializeObject(_response)));

            }
            catch (Exception ex)
            {
                this._logger.Error(string.Format("   ERROR: {0}", ex.Message));
            }
            return Ok(_response);
        }

        /// <summary>
        /// Se envia mensaje template para prueba de vida pasiva desde Kiosko
        /// </summary>
        /// <param name="_request">Informacion del cliente para el envio de mensaje template</param>
        /// <remarks>
        /// Request example:
        /// ```json
        ///{
        ///  "idcNumber": "07086114",
        ///  "idcType": "Q",
        ///  "idcExtension": "XX",
        ///  "idcSupplement": "00",
        ///  "nameClient": "Dan",
        ///  "paternalSurnameClient": "Copa",
        ///  "maternalSurnameClient": "Lupe",
        ///  "digitalRecordSession": "generado",
        ///  "negativeFile": true,
        ///  "enameCheker": true,
        ///  "cellphone": "59160128357",
        ///  "referenceCode": "generado",
        ///  "terminalCode": "154875",
        ///  "email": "example@bcp.com.bo"
        ///}
        /// ```
        /// </remarks>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Envio de mensaje con el estado de la solcilitud</returns>
        [ApiExplorerSettings(GroupName = "v1")]
        [HttpPost("InitializePassiveLifeTest/Kiosk")]
        [ProducesResponseType(typeof(GenericResponse), 200)]
        public async Task<IActionResult> InitializePassiveLifeTest(PassiveLifeTestKioskRequest _request)
        {
            GenericResponse _response = new();
            try
            {
                this._logger.Debug(string.Format(" REQUEST: {0}", JsonConvert.SerializeObject(_request)));
                _response = await this._externalBussiness.StartPassiveLifeTestKiosk(_request);
                this._logger.Debug(string.Format("RESPONSE: {0}", JsonConvert.SerializeObject(_response)));

            }
            catch (Exception ex)
            {
                this._logger.Error(string.Format("   ERROR: {0}", ex.Message));
            }
            return Ok(_response);
        }

        /// <summary>
        /// Se envia un mensaje hacia WhatsApp estos pueden ser TEXT, INTERACTIVE, IMAGE, VIDEO, AUDIO
        /// </summary>
        /// <param name="_request">Informacion del mensaje a enviar</param>
        /// <remarks>
        /// Request example:
        /// ```json
        ///{
        ///  "messageId": 0,
        ///  "destinationAccount": "59122114141",
        ///  "message": "Este es mensaje de prueba",
        ///  "typeMessage": "TEXT",
        ///  "classMultimedia": "",
        ///  "classInteractive": "",
        ///  "cellphone": [
        ///    "59160128357"
        ///  ],
        ///  "identifyChatBot": true,
        ///  "multimediaUrl": "",
        ///  "url": "",
        ///  "nameMultimediaUrl": "",
        ///  "user": "OLIVIA",
        ///  "nameUser": "OLIVIA",
        ///  "parameterMessage": [
        ///  ],
        ///  "nameHsmOfTemplate": "",
        ///  "campaignName": "",
        ///  "parametersInteractive": {
        ///    "nameSelectorButton": "",
        ///    "classMessageInteractive": "",
        ///    "header": "",
        ///    "body": "",
        ///    "footer": "",
        ///    "parameters": [
        ///      {
        ///        "title": "",
        ///        "description": "",
        ///        "identifier": ""
        ///      }
        ///    ],
        ///    "alternativeText": ""
        ///  },
        ///  "parametersTemplate": {
        ///    "classMessageTemplate": ""
        ///  }
        ///}
        /// ```
        /// </remarks>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Envio de mensaje con el estado de la solcilitud</returns>
        [ApiExplorerSettings(GroupName = "v1")]
        [HttpPost("SendingMessagesByChannel")]
        [ProducesResponseType(typeof(GenericResponse), 200)]
        public async Task<IActionResult> SendingMessagesByChannel(SendMessageExternalRequest _request)
        {
            GenericResponse _response = new();
            try
            {
                this._logger.Debug(string.Format(" REQUEST: {0}", JsonConvert.SerializeObject(_request)));
                _response = await this._externalBussiness.SenddingMessageChannel(_request);
                this._logger.Debug(string.Format("RESPONSE: {0}", JsonConvert.SerializeObject(_response)));
            }
            catch (Exception ex)
            {
                this._logger.Error(string.Format("   ERROR: {0}", ex.Message));
            }
            return Ok(_response);
        }

        /// <summary>
        /// Se envia un mensaje de texto normal hacia WhatsApp
        /// </summary>
        /// <param name="_request">Informacion del mensaje a enviar</param>
        /// <remarks>
        /// Request example:
        /// ```json
        ///{
        ///  "cellphone": "59160128357",
        ///  "message": "Esta es un mensaje de texto",
        ///  "nameUser": "OLIVIA",
        ///  "destinationAccount": "59122114141"
        ///}
        /// ```
        /// </remarks>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Envio de mensaje con el estado de la solcilitud</returns>
        [ApiExplorerSettings(GroupName = "v1")]
        [HttpPost("SendingMessagesTextByChannel")]
        [ProducesResponseType(typeof(GenericResponse), 200)]
        public async Task<IActionResult> SendingMessagesTextByChannel(SendMessageTextExternalRequest _request)
        {
            GenericResponse _response = new();
            try
            {
                this._logger.Debug(string.Format(" REQUEST: {0}", JsonConvert.SerializeObject(_request)));
                _response = await this._externalBussiness.SenddingMessageTextChannel(_request);
                this._logger.Debug(string.Format("RESPONSE: {0}", JsonConvert.SerializeObject(_response)));
            }
            catch (Exception ex)
            {
                this._logger.Error(string.Format("   ERROR: {0}", ex.Message));
            }
            return Ok(_response);
        }

        /// <summary>
        /// Se envia un mensaje de texto con botones hacia WhatsApp
        /// </summary>
        /// <param name="_request">Informacion del mensaje a enviar</param>
        /// <remarks>
        /// Request example:
        /// ```json
        ///{
        ///  "cellphone": "59160128357",
        ///  "message": "¿Quiere cerrar la sesion?",
        ///  "nameUser": "Olivia",
        ///  "destinationAccount": "59122114141",
        ///  "listButton": [
        ///    "SI",
        ///    "NO"
        ///  ]
        ///}
        /// ```
        /// </remarks>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Envio de mensaje con el estado de la solcilitud</returns>
        [ApiExplorerSettings(GroupName = "v1")]
        [HttpPost("SendingMessagesButtonByChannel")]
        [ProducesResponseType(typeof(GenericResponse), 200)]
        public async Task<IActionResult> SendingMessagesButtonByChannel(SendMessageButtonExternalRequest _request)
        {
            GenericResponse _response = new();
            try
            {
                this._logger.Debug(string.Format(" REQUEST: {0}", JsonConvert.SerializeObject(_request)));
                _response = await this._externalBussiness.SenddingMessageButtonChannel(_request);
                this._logger.Debug(string.Format("RESPONSE: {0}", JsonConvert.SerializeObject(_response)));
            }
            catch (Exception ex)
            {
                this._logger.Error(string.Format("   ERROR: {0}", ex.Message));
            }
            return Ok(_response);
        }

        /// <summary>
        /// Se envia un mensaje de texto con una lista hacia WhatsApp
        /// </summary>
        /// <param name="_request">Informacion del mensaje a enviar</param>
        /// <remarks>
        /// Request example:
        /// ```json
        ///{
        ///  "cellphone": "59160128635",
        ///  "message": "Selecciona una opcion de la lista",
        ///  "nameUser": "Olivia",
        ///  "destinationAccount": "59122114141",
        ///  "button": "Seleccionar",
        ///  "list": [
        ///    {
        ///      "title": "BCP",
        ///      "description": "Banco de Credito",
        ///      "identifier": "BCP"
        ///    },
        ///    {
        ///      "title": "YAPE",
        ///      "description": "Yape",
        ///      "identifier": "YAPE"
        ///    }
        ///  ]
        ///}
        /// ```
        /// </remarks>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Envio de mensaje con el estado de la solcilitud</returns>
        [ApiExplorerSettings(GroupName = "v1")]
        [HttpPost("SendingMessagesListByChannel")]
        [ProducesResponseType(typeof(GenericResponse), 200)]
        public async Task<IActionResult> SendingMessagesListByChannel(SendMessageListExternalRequest _request)
        {
            GenericResponse _response = new();
            try
            {
                this._logger.Debug(string.Format(" REQUEST: {0}", JsonConvert.SerializeObject(_request)));
                _response = await this._externalBussiness.SenddingMessageListChannel(_request);
                this._logger.Debug(string.Format("RESPONSE: {0}", JsonConvert.SerializeObject(_response)));
            }
            catch (Exception ex)
            {
                this._logger.Error(string.Format("   ERROR: {0}", ex.Message));
            }
            return Ok(_response);
        }

        /// <summary>
        /// Se envia mensaje desde IVR
        /// </summary>
        /// <param name="_request">Informacion del mensaje a enviar</param>
        /// <remarks>
        /// Request example:
        /// ```json
        ///{
        ///  "cellphone": "59160128635"
        ///}
        /// ```
        /// </remarks>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Envio de mensaje con el estado de la solcilitud</returns>
        [ApiExplorerSettings(GroupName = "v1")]
        [HttpPost("SendMessageIVROperator")]
        [Authorize]
        [ProducesResponseType(typeof(GenericResponse), 200)]
        public async Task<IActionResult> SendMessageIVROperator(IVRConnectionRequest _request)
        {
            GenericResponse _response = new();
            try
            {
                await Task.Factory.StartNew(async delegate 
                {
                    string _operation = DateTime.Now.ToString("yyyyMMddhhmmssff");
                    try
                    {
                        this._logger.Debug(string.Format("[ {0} ]  REQUEST: {1}", _operation, JsonConvert.SerializeObject(_request)));
                        _response = await this._externalBussiness.IvrConnectionOpertor(_request);
                        this._logger.Debug(string.Format("[ {0} ] RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
                    }
                    catch (Exception ex)
                    {
                        this._logger.Debug(string.Format("[ {0} ]    ERROR: {1}", _operation, ex.Message));
                    }
                });
            }
            catch (Exception ex)
            {
                this._logger.Error(string.Format("   ERROR: {0}", ex.Message));
            }
            return Ok(new GenericResponse() { success = true, code = "200", message = "Prosessing Complete." });
        }

        /// <summary>
        /// Validacion de prueba de vida y desvinculacion de dispositivo
        /// </summary>
        /// <param name="_request">Informacion del estado de prueba de vida</param>
        /// <remarks>
        /// Request example:
        /// ```json
        ///{
        ///  "strGuid": "123123123123",
        ///  "success": true
        ///}
        /// ```
        /// </remarks>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Envio de mensaje con el estado de la solcilitud</returns>
        [ApiExplorerSettings(GroupName = "v1")]
        [HttpPost("UnlinkMobileBankingWhatsApp")]
        [Authorize]
        [ProducesResponseType(typeof(GenericResponse), 200)]
        public async Task<IActionResult> UnlinkMobileBankingWhatsApp(MobileBankingRequest _request)
        {
            GenericResponse _response = new();
            try
            {
                if (!Request.Headers.TryGetValue("Authorization", out var authorizationHeader) || string.IsNullOrWhiteSpace(authorizationHeader))
                {
                    return Unauthorized(new GenericResponse { success = false, code = "401", message = "Authorization header is required." });
                }

                if (!AuthenticationHeaderValue.TryParse(authorizationHeader.ToString(), out var authHeader) || !string.Equals(authHeader.Scheme, "Basic", StringComparison.OrdinalIgnoreCase) || string.IsNullOrWhiteSpace(authHeader.Parameter))
                {
                    return Unauthorized(new GenericResponse { success = false, code = "401", message = "Invalid Authorization header format." });
                }

                byte[] credentialBytes;
                try
                {
                    credentialBytes = Convert.FromBase64String(authHeader.Parameter);
                }
                catch (FormatException)
                {
                    return Unauthorized(new GenericResponse { success = false, code = "401", message = "Invalid base64 credentials." });
                }

                var credentials = Encoding.UTF8.GetString(credentialBytes).Split(new[] { ':' }, 2);
                if (credentials.Length != 2)
                {
                    return Unauthorized(new GenericResponse { success = false, code = "401", message = "Invalid credentials format." });
                }

                var _username = credentials[0];
                var _password = credentials[1];

                string _publicToken = Request.Headers.TryGetValue("publicToken", out var publicTokenHeader) ? publicTokenHeader.ToString() : string.Empty;

                string _appUserId = Request.Headers.TryGetValue("appUserId", out var appUserIdHeader) ? appUserIdHeader.ToString() : string.Empty;

                this._logger.Debug(string.Format(" REQUEST: {0}", JsonConvert.SerializeObject(_request)));
                _response = await this._externalBussiness.BUnlinkMobileBankingWhatsApp(_request, _username, _password, _publicToken, _appUserId);
                this._logger.Debug(string.Format("RESPONSE: {0}", JsonConvert.SerializeObject(_response)));

            }
            catch (Exception ex)
            {
                this._logger.Error(string.Format("   ERROR: {0}", ex.Message));
            }
            return Ok(_response);
        }

        /// <summary>
        /// Envio de mensajes otp para canales
        /// </summary>
        /// <param name="_request">Informacion del mensaje para envio de OTP</param>
        /// <remarks>
        /// Request example:
        /// ```json
        ///{
        ///  "mensaje": "Codigo de seguridad",
        ///  "destino": [
        ///    "59160128357"
        ///  ],
        ///  "type": "TEXT",
        ///  "arrayBase64": "",
        ///  "idcampania": "12333",
        ///  "namehsm": "opt_template",
        ///  "parametroshsm": [
        ///    "123123"
        ///  ],
        ///  "url": "",
        ///  "typeUrl": "",
        ///  "canal": "OLIVIA",
        ///  "passcanal": "********"
        ///}
        /// ```
        /// </remarks>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Envio de mensaje con el estado de la solcilitud</returns>
        [ApiExplorerSettings(GroupName = "v1")]
        [HttpPost("SendMessageOTP")]
        [ProducesResponseType(typeof(GenericResponse), 200)]
        public async Task<IActionResult> SendMessageOTP(WhatsAppEnviadoRequest _request)
        {
            GenericResponse _response = new();
            try
            {
                await Task.Factory.StartNew(async delegate
                {
                    string _operation = DateTime.Now.ToString("yyyyMMddhhmmssff");
                    try
                    {
                        this._logger.Debug(string.Format("[ {0} ]  REQUEST: {1}", _operation, JsonConvert.SerializeObject(_request)));
                        _response = await this._externalBussiness.SendMessageOTP(_request);
                        this._logger.Debug(string.Format("[ {0} ] RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
                    }
                    catch (Exception ex)
                    {
                        this._logger.Debug(string.Format("[ {0} ]    ERROR: {1}", _operation, ex.Message));
                    }
                });
            }
            catch (Exception ex)
            {
                this._logger.Error(string.Format("   ERROR: {0}", ex.Message));
            }
            return Ok(new GenericResponse() { success = true, code = "200", message = "Prosessing Complete." });
        }

        /// <summary>
        /// Envio de mensajes tipo flow desde WhatsApp
        /// </summary>
        /// <param name="_request">Informacion del mensaje flow a enviar</param>
        /// <remarks>
        /// Request example:
        /// ```json
        ///{
        ///  "cellphone": "59160128357",
        ///  "message": "Por favor completa el formulario",
        ///  "nameFlow": "TEST",
        ///  "wppSesionId": "12323",
        ///  "screen": "",
        ///  "header": "",
        ///  "footer": ""
        ///}
        /// ```
        /// </remarks>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Envio de mensaje con el estado de la solcilitud</returns>
        [ApiExplorerSettings(GroupName = "v1")]
        [HttpPost("SendingMessagesFlowByChannel")]
        [ProducesResponseType(typeof(GenericResponse), 200)]
        public async Task<IActionResult> SendMessageFlow(SendMessageFlowExternalRequest _request)
        {
            GenericResponse _response = new();
            string _operation = DateTime.Now.ToString("yyyyMMddhhmmssff");
            try
            {
                this._logger.Debug(string.Format("[{0}]  REQUEST: {1}", _operation, JsonConvert.SerializeObject(_request)));
                _response = await this._externalBussiness.SendMessageFlowChannel(_request, _operation);
                this._logger.Debug(string.Format("[{0}] RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
                return StatusCode(int.Parse(_response.code), _response);
            }
            catch (Exception ex)
            {
                this._logger.Debug(string.Format("[{0}]    ERROR: {1}", _operation, ex.Message));
                _response.message = ex.Message;
                _response.code = "500";
                _response.success = false;
                return StatusCode(500, _response);
            }
        }
    }
}
