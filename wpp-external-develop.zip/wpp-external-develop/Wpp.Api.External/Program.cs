using Microsoft.AspNetCore.Authentication;
using Microsoft.OpenApi;
using WPP.ABSTRACTION.AUTHORIZATION;
using WPP.ABSTRACTION.DATAACCESS;
using WPP.ABSTRACTION.ENTITIES.IVRConnection;
using WPP.ABSTRACTION.ENTITIES.SendMessageApplication;
using WPP.ABSTRACTION.LOGGER;
using WPP.ABSTRACTION.SECRYPT;
using WPP.APPLICATION.BUSSINESS;
using WPP.APPLICATION.CONNECTION.DATABASE;
using WPP.APPLICATION.CONNECTION.SERVICE;
using WPP.APPLICATION.CONNECTION.SERVICE.RestConnectionService;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Api Externa WhatsApp para canales.",
        Version = "v1",
        Description = "Api para canales que haran uso de WhatsApp",
        Contact = new OpenApiContact
        {
            Name = "Canales Presenciales",
            Email = "BolCanPres@bancred.com.bo",
            Url = new Uri("http://intranetbcp/"),
        }
    });
    c.OperationFilter<CustomHeaderSwaggerAttribute>();
    c.AddSecurityDefinition("basic", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "basic",
        In = ParameterLocation.Header,
        Description = "Basic Authorization header using the Bearer scheme."
    });
    c.SupportNonNullableReferenceTypes();
});
builder.Services.AddAuthentication("BasicAuthentication").AddScheme<AuthenticationSchemeOptions, BasicAuthenticationHandler>("BasicAuthentication", null);

builder.Services.AddSingleton<IExternalConnectionDatabase, ExternalConnectionDatabase>();
builder.Services.AddSingleton<IExternalBussiness, ExternalBussiness>();
builder.Services.AddSingleton<ISentCentralizerConnection, SentCentralizerConnection>();
builder.Services.AddScoped<IManagerUserService, ManagerUserService>();
builder.Services.AddHttpClient<ISendCentralizerConnectionHttp, SendCentralizerConnectionHttp>();

builder.Services.Configure<IvrTemplateConfiguration>(options => builder.Configuration.GetSection("IvrTemplateConfiguration").Bind(options));
builder.Services.Configure<GushupWppFlowsConfig>(options => builder.Configuration.GetSection("Gushup.WhatsAppFlows.Api").Bind(options));
builder.Services.Configure<SentCentralizerOptions>(options => builder.Configuration.GetSection("Sent.Centralizer.Api").Bind(options));

builder.Services.AddLogger();
builder.Services.AddDataBase();
builder.Services.AddSecrypt();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Configuration.GetValue<bool>("Application:produccion"))
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.Run();
