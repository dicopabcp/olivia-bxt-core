﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using System.Data;

namespace WPP.ABSTRACTION.DATAACCESS
{
    public interface IDataAccess
    {
        HealthCheckResult Check(string name);
        DataTable SelectStoredProcedure(string _name, string _query, List<SqlParameter> _parameter);
        bool ExecuteStoredProcedure(string _name, string _query, List<SqlParameter> _parameter);
        DataTable Select(string _name, string _query);
    }
}
