﻿using WPP.ABSTRACTION.ENTITIES.Authorization;
using WPP.APPLICATION.CONNECTION.SERVICE;

namespace WPP.ABSTRACTION.AUTHORIZATION
{
    public interface IManagerUserService
    {
        Task<List<BasicAutorizacionModel>> _userA(string _usuario, string _password, AuthorizationRequest _authorization);
        Task<BasicAutorizacionModel> Authenticate(string _usuario, string _password, AuthorizationRequest _authorization);
        Task<IEnumerable<BasicAutorizacionModel>> GetAll();
    }
    public class ManagerUserService : IManagerUserService
    {
        private readonly ISentCentralizerConnection _connectionService;
        private List<BasicAutorizacionModel> _users = null;
        public ManagerUserService(ISentCentralizerConnection connectionService)
        {
            this._connectionService = connectionService;
        }
        public async Task<List<BasicAutorizacionModel>> _userA(string _usuario, string _password, AuthorizationRequest _authorization)
        {
            return await this._connectionService.getUserIN(_usuario, _password, _authorization);
        }
        public async Task<BasicAutorizacionModel> Authenticate(string _usuario, string _password, AuthorizationRequest _authorization)
        {
            this._users = await _userA(_usuario, _password, _authorization);
            var user = await Task.Run(() => _users.SingleOrDefault(x => x.userName == _usuario));
            if (user == null)
                return null;
            return user.WithoutPassword();
        }
        public async Task<IEnumerable<BasicAutorizacionModel>> GetAll()
        {
            return await Task.Run(() => this._users.WithoutPasswords());
        }
    }
    public static class ExtensionMethods
    {
        public static IEnumerable<BasicAutorizacionModel> WithoutPasswords(this IEnumerable<BasicAutorizacionModel> users)
        {
            return users.Select(x => x.WithoutPassword());
        }

        public static BasicAutorizacionModel WithoutPassword(this BasicAutorizacionModel user)
        {
            user.password = null;
            return user;
        }
    }
}
