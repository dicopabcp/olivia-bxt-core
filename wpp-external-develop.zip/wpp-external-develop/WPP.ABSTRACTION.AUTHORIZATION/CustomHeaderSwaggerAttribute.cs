﻿using Microsoft.OpenApi;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace WPP.ABSTRACTION.AUTHORIZATION
{
    public class CustomHeaderSwaggerAttribute : IOperationFilter
    {
        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            if (operation.Parameters == null)
                operation.Parameters = new List<IOpenApiParameter>();

            operation.Parameters.Add(new OpenApiParameter
            {
                Name = "PublicToken",
                In = ParameterLocation.Header,
                Required = true,
                Description = "PublicToken generado por el Api de Autorizacion de Arquitectura.",
                Schema = new OpenApiSchema()
            });
            operation.Parameters.Add(new OpenApiParameter
            {
                Name = "AppUserId",
                In = ParameterLocation.Header,
                Required = true,
                Description = "AppUserId generado por el Api de Autorizacion de Arquitectura.",
                Schema = new OpenApiSchema()
            });
            operation.Parameters.Add(new OpenApiParameter
            {
                Name = "Channel",
                In = ParameterLocation.Header,
                Required = true,
                Description = "Nombre de la aplicacion que consume el API.",
                Schema = new OpenApiSchema()
            });
        }
    }
}
