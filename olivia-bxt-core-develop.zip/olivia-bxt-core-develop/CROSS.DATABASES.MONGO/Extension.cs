using CROSS.DATABASES.REDDIS;
using Microsoft.Extensions.DependencyInjection;

namespace CROSS.DATABASE
{

    public static class Extension
    {
        public static IServiceCollection AddDataBaseMongo(this IServiceCollection services)
        {
            services.AddSingleton<IManagerDataBaseMongo, ManagerDataBaseMongo>();
            return services;
        }
    }
}
