namespace CROSS.DATABASES.REDDIS
{
    public interface IManagerDataBaseMongo
    {
        public Task InsertDocument<T>(string collectionName, T document);

        public Task<T> GetDocumentById<T>(string collectionName, string id);

        public Task<T> UpdateDocumentById<T>(string collection, string idSesion, T nuevoDocuemnto) where T : class;

        public Task DeleteDocumentById<T>(string collection, string filter, object value);


    }
}
