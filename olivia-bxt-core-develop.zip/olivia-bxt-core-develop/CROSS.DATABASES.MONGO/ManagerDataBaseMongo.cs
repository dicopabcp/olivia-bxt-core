using CROSS.DATABASES.MONGO;
using Microsoft.Extensions.Configuration;
using MongoDB.Bson;
using MongoDB.Driver;
namespace CROSS.DATABASES.REDDIS
{

    public class ManagerDataBaseMongo : IManagerDataBaseMongo
    {
        private readonly IMongoDatabase mongoDatabase;

        public ManagerDataBaseMongo(IConfiguration configuration)
        {
            DBOptions dBOption = new();
            configuration.GetSection("database").Bind(dBOption);
            DBOptionItems item = dBOption.Connections.First(x => x.Name == "OLIVIA_BXT_MONGO");
            MongoClient client = new($"mongodb://{item.Server}:{item.Port}/");
            this.mongoDatabase = client.GetDatabase($"{item.DataBase}");
        }

        public async Task InsertDocument<T>(string collectionName, T document)
        {
            IMongoCollection<T> collection = mongoDatabase.GetCollection<T>(collectionName);
            await collection.InsertOneAsync(document);
        }

        public async Task<T> GetDocumentById<T>(string collectionName, string id)
        {
            IMongoCollection<T> collection = mongoDatabase.GetCollection<T>(collectionName);
            ObjectId _id = new (id);
            FilterDefinition<T> filter = Builders<T>.Filter.Eq("_id", _id);
            IAsyncCursor<T> aux = await collection.FindAsync<T>(filter);

            return aux.FirstOrDefault();
        }

        public async Task<T> UpdateDocumentById<T>(string collection, string idSesion, T nuevoDocuemnto) where T : class
        {
            IMongoCollection<T> collectionMongo = mongoDatabase.GetCollection<T>(collection);
            FilterDefinition<T> filterMongo = Builders<T>.Filter.Eq("_id", new ObjectId(idSesion));
            await collectionMongo.ReplaceOneAsync(filterMongo, nuevoDocuemnto);
            return nuevoDocuemnto;
        }

        public async Task DeleteDocumentById<T>(string collection,string filter, object value)
        {
            IMongoCollection<T> collectionMongo = mongoDatabase.GetCollection<T>(collection);
            FilterDefinition<T> filterMongo = Builders<T>.Filter.Eq(filter, value);
            await collectionMongo.DeleteOneAsync(filterMongo);
        }
    }
}
