using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CROSS.APIREST
{
    public interface IApiRest
    {
        public Task<T> PostAsync<T>(string url, object request, bool authorization = false, string userName = "", string password = "", List<Tuple<string, string>>? header = default);

        public Task<T> GetAsync<T>(string url, bool authorization = false, string userName = "", string password = "", List<Tuple<string, string>>? header = default);
    }
}
