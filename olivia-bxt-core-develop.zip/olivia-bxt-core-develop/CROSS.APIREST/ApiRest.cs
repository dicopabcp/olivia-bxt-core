using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace CROSS.APIREST
{
    public class ApiRest(HttpClient httpClient) : IApiRest
    {

        public async Task<T> PostAsync<T>(string url, object request, bool authorization = false, string userName = "", string password = "", List<Tuple<string, string>>? header = default)
        {
            string _response = string.Empty;
            string myContent = JsonConvert.SerializeObject(request);
            byte[] buffer = Encoding.UTF8.GetBytes(myContent);
            ByteArrayContent byteContent = new(buffer);
            byteContent.Headers.ContentType = new("application/json");
            httpClient.DefaultRequestHeaders.Clear();
            if (authorization)
            {
                string authenticationString = $"{userName}:{password}";
                string base64EncodedAuthenticationString = Convert.ToBase64String(Encoding.UTF8.GetBytes(authenticationString));
                httpClient.DefaultRequestHeaders.Add($"Authorization", $"Basic {base64EncodedAuthenticationString}");
            }
            if (header != null)
            {
                foreach (Tuple<string, string> item in header)
                {
                    httpClient.DefaultRequestHeaders.Add(item.Item1, item.Item2);
                }
            }
            HttpResponseMessage data = await httpClient.PostAsync(url, byteContent);
            _response = await data.Content.ReadAsStringAsync();
            if (data.StatusCode == HttpStatusCode.Unauthorized)
            {
                throw new UnauthorizedAccessException(string.Format("No Autorizado en el servicio {0}", url));
            }
            if (data.StatusCode == HttpStatusCode.NoContent)
            {
                throw new HttpRequestException("NoContent");
            }

            if (data.StatusCode != HttpStatusCode.InternalServerError)
            {
                return JsonConvert.DeserializeObject<T>(_response) ?? throw new FormatException(string.Format("El servicio {0} devuelve un formato invalido", url));
            }
            throw new HttpRequestException(string.Format("Problemas en el servicio {0}", url));
        }

        public async Task<T> GetAsync<T>(string url, bool authorization = false, string userName = "", string password = "", List<Tuple<string, string>>? header = default)
        {
            string _response = string.Empty;
            httpClient.DefaultRequestHeaders.Clear();
            if (authorization)
            {
                string authenticationString = $"{userName}:{password}";
                string base64EncodedAuthenticationString = Convert.ToBase64String(Encoding.UTF8.GetBytes(authenticationString));
                httpClient.DefaultRequestHeaders.Add($"Authorization", $"Basic {base64EncodedAuthenticationString}");
            }
            if (header != null)
            {
                foreach (Tuple<string, string> item in header)
                {
                    httpClient.DefaultRequestHeaders.Add(item.Item1, item.Item2);
                }
            }
            HttpResponseMessage data = await httpClient.GetAsync(url);
            _response = await data.Content.ReadAsStringAsync();
            if (data.StatusCode == HttpStatusCode.Unauthorized)
            {
                throw new UnauthorizedAccessException(string.Format("No Autorizado en el servicio {0}", url));
            }
            if (data.StatusCode == HttpStatusCode.NoContent)
            {
                throw new HttpRequestException("NoContent");
            }
            if (data.StatusCode != HttpStatusCode.InternalServerError)
            {
                return JsonConvert.DeserializeObject<T>(_response) ?? throw new FormatException(string.Format("El servicio {0} devuelve un formato invalido", url));
            }

            throw new HttpRequestException(string.Format("Problemas en el servicio {0}", url));
        }
    }
}
