using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Net.Http;


namespace CROSS.APIREST
{
    public static class Extension
    {
        public static IServiceCollection AddApiRest(this IServiceCollection services, IConfiguration configuration)
        {
            bool dev = configuration.GetValue<bool>("dev");
            services.AddTransient<ApiLoggingHandler>();
            services.AddHttpClient("ExternalApi")
                .ConfigurePrimaryHttpMessageHandler(() =>
                {
                    return dev ? new HttpClientHandler
                    {
                        ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; }
                    } : new HttpClientHandler();
                })
                .AddHttpMessageHandler<ApiLoggingHandler>();
            services.AddTransient<IApiRest, ApiRest>(serviceProvider =>
            {
                var httpClientFactory = serviceProvider.GetRequiredService<IHttpClientFactory>();
                var httpClient = httpClientFactory.CreateClient("ExternalApi");
                return new ApiRest(httpClient);
            });
            return services;
        }
    }
}
