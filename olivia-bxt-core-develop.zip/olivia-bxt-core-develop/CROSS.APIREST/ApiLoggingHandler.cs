using Microsoft.AspNetCore.Http;
using Serilog;
using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace CROSS.APIREST
{
    public class ApiLoggingHandler : DelegatingHandler
    {

        private readonly IHttpContextAccessor _httpContextAccessor;

        public ApiLoggingHandler(IHttpContextAccessor _httpContextAccessor)
        {
            this._httpContextAccessor = _httpContextAccessor;
        }

        protected override async Task<HttpResponseMessage> SendAsync(
            HttpRequestMessage request,
            CancellationToken cancellationToken)
        {
            var startTime = DateTime.UtcNow;


            var correlationId =
                    _httpContextAccessor.HttpContext?.Items["X-Correlation-ID"]?.ToString()
                    ?? Guid.NewGuid().ToString();

            // ---------- REQUEST ----------
            string requestBody = null;

            if (request.Content != null)
            {
                requestBody = await request.Content.ReadAsStringAsync();
            }

            Log.Information(
                "API OUT | {CorrelationId} | {Method} {Url} | Body: {RequestBody}",
                correlationId,
                request.Method,
                request.RequestUri,
                requestBody);

            try
            {
                // LLAMADA REAL A LA API

                if (!request.Headers.Contains("X-Correlation-Id"))
                {
                    request.Headers.Add("X-Correlation-Id", correlationId);
                }

                var response = await base.SendAsync(request, cancellationToken);

                var durationMs = (DateTime.UtcNow - startTime).TotalMilliseconds;

                // ---------- RESPONSE ----------
                string responseBody = null;

                if (response.Content != null)
                {
                    responseBody = await response.Content.ReadAsStringAsync();
                }

                Log.Information(
                    "API IN | {CorrelationId} | Status: {StatusCode} | Time: {Duration}ms | Body: {ResponseBody}",
                    correlationId,
                    (int)response.StatusCode,
                    durationMs,
                    responseBody);

                return response;
            }
            catch (Exception ex)
            {
                var durationMs = (DateTime.UtcNow - startTime).TotalMilliseconds;

                Log.Error(
                    ex,
                    "API EXCEPTION | {CorrelationId} | Time: {Duration}ms | {Method} {Url}",
                    correlationId,
                    durationMs,
                    request.Method,
                    request.RequestUri);

                throw;
            }
        }
    }

}
