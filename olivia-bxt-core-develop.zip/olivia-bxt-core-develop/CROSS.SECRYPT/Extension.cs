﻿namespace CROSS.SECRYPT
{
    using Microsoft.Extensions.DependencyInjection;

    public static class Extension
    {
        public static IServiceCollection AddSecrypt(this IServiceCollection services)
        {
            services.AddSingleton<IManagerSecrypt, ManagerSecrypt>();
            return services;
        }
    }
}
