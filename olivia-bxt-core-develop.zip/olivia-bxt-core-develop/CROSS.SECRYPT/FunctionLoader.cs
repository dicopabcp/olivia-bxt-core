using System;
using System.Runtime.InteropServices;

namespace CROSS.SECRYPT
{
    public static class FunctionLoader
    {
        public static Delegate LoadFunction<T>(string dllPath, string functionName)
        {
            IntPtr hModule = LoadLibrary(dllPath);
            IntPtr functionAddress = GetProcAddress(hModule, functionName);
            return Marshal.GetDelegateForFunctionPointer(functionAddress, typeof(T));
        }

        [DllImport("Kernel32.dll")]
        private static extern IntPtr LoadLibrary(string path);

        [DllImport("Kernel32.dll")]
        private static extern IntPtr GetProcAddress(IntPtr hModule, string procName);
    }
}