using System;
using System.Runtime.InteropServices;
using System.Security;
using System.Text;

namespace CROSS.SECRYPT
{
    [SuppressUnmanagedCodeSecurity]
    internal static class SegCrypt
    {
        private const string Str = @"SegCryptBancSeg.dll";

        [DllImport(
            Str,
            CallingConvention = CallingConvention.StdCall,
            CharSet = CharSet.Ansi,
            ExactSpelling = true,
            SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool EncryptDecrypt([MarshalAs(UnmanagedType.Bool)] bool fEncrypt, string lpszInBuffer, StringBuilder sOut, [MarshalAs(UnmanagedType.I4)] ref int dsize);

        public static string EncryptDecrypt(bool encrypt, string text)
        {
            string process = Environment.Is64BitProcess ? "64Bits" : "32Bits";
            string res = string.Empty;
            if (string.IsNullOrWhiteSpace(text))
            {
                return res;
            }

            try
            {
                int nSize = (text.Length * 2) + 1;
                StringBuilder outString = new StringBuilder(nSize);
                EncryptDecrypt(encrypt, text, outString, ref nSize);
                res = outString.ToString();
                return res;
            }
            catch (Exception ex)
            {
                throw new ArgumentException("Error en EncryptDecrypt, " + ex.Message + " Proceso: " + process);
            }
        }
    }
}
