﻿namespace CROSS.SECRYPT
{
    using System;
    using Microsoft.Extensions.Configuration;

    public class ManagerSecrypt : IManagerSecrypt
    {
        private readonly string semilla;

        public ManagerSecrypt(IConfiguration configuration)
        {
            SecryptOptions options = new SecryptOptions();
            configuration.GetSection("segurinet").Bind(options);
            this.semilla = options.Semilla;
        }

        public string Encriptar(string value)
        {
            SegCryptV2 segCrypt = new SegCryptV2(semilla);
            string result = segCrypt.FunctionEncryptDecrypt(true, value);
            return result;
        }

        public string Desencriptar(string value)
        {
            SegCryptV2 segCrypt = new SegCryptV2(semilla);
            string result = segCrypt.FunctionEncryptDecrypt(false, value);
            return result;
        }

        public Tuple<bool, string> Check()
        {
            try
            {
                return Tuple.Create(true, $"LA SEMILLA {semilla} FUE ENCONTRADA.");
            }
            catch (Exception ex)
            {
                return Tuple.Create(false, ex.Message);
            }
        }
    }
}