﻿namespace CROSS.SECRYPT
{
    using System;
    using System.IO;
    using System.Runtime.InteropServices;
    using System.Text;

    public class SegCryptV2
    {
        private static EncryptDecryptDelegate encryptDecryptReader;

        public SegCryptV2(string semilla)
        {
            if (string.IsNullOrEmpty(semilla))
            {
                semilla = "SegCrypt64";
            }

            string file = $"C:\\Windows\\System32\\{semilla}.dll";
            if (!File.Exists($"C:\\Windows\\System32\\{semilla}.dll"))
            {
                throw new ArgumentException($"LA SEMILLA {semilla} NO EXISTE EN EL SERVIDOR.");
            }

            encryptDecryptReader = (EncryptDecryptDelegate)FunctionLoader.LoadFunction<EncryptDecryptDelegate>(
                    file, "EncryptDecrypt");
        }

        private delegate bool EncryptDecryptDelegate([MarshalAs(UnmanagedType.Bool)] bool fEncrypt, string lpszInBuffer, StringBuilder sOut, [MarshalAs(UnmanagedType.I4)] ref int dsize);

        public string FunctionEncryptDecrypt(bool encrypt, string text)
        {
            string res = string.Empty;
            if (string.IsNullOrWhiteSpace(text))
            {
                return res;
            }

            try
            {
                int nSize = (text.Length * 2) + 1;
                StringBuilder outString = new StringBuilder(nSize);
                _ = encryptDecryptReader(encrypt, text, outString, ref nSize);
                res = outString.ToString();
                return res;
            }
            catch (Exception ex)
            {
                throw new ArgumentException("Error en EncryptDecrypt, " + ex.Message);
            }
        }
    }
}
