﻿namespace CROSS.SECRYPT
{
    using System;

    public interface IManagerSecrypt
    {
        string Encriptar(string value);

        string Desencriptar(string value);

        Tuple<bool, string> Check();
    }
}