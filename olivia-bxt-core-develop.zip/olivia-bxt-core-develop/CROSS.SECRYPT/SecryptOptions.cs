﻿namespace CROSS.SECRYPT
{
    public class SecryptOptions
    {
        public string Semilla { get; set; }
    }
}
