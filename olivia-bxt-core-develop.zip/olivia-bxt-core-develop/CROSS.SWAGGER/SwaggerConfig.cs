using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;

namespace CROSS.SWAGGER
{
    public static class SwaggerConfig
    {
        public static void ConfigureSwagger(this IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "OLIVIA BXT CORE",
                    Version = "v1",
                    Description = "Entrada principal para Olivia ChatBotBxT",
                    Contact = new OpenApiContact
                    {
                        Name = "Canales Presenciales",
                        Email = "BolCanPres@bancred.com.bo",
                        Url = new Uri("http://intranetbcp/"),
                    },
                });
                c.ResolveConflictingActions(apiDescriptions => apiDescriptions.First());
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Name = "Authorization",
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer",
                    BearerFormat = "Basic",
                    In = ParameterLocation.Header,
                    Description = "Basic Authorization header using the Bearer scheme.",
                });
                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer",
                            },
                        },
                        Array.Empty<string>()
                    },
                });
                c.OperationFilter<CustomHeaderSwaggerAttribute>();
            });
        }
    }
}