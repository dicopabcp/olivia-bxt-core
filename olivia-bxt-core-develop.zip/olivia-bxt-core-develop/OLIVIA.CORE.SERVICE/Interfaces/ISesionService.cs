using OLIVIA.CORE.MODEL;

namespace OLIVIA.CORE.SERVICE
{
    public interface ISesionService
    {
        public Task<SesionEntity?> ReadSesion(string usuario);
        public Task<SesionEntity?> GetSesion(string sesionId);
        public Task<SesionEntity> CreateSesion(string usuario);
        public Task<bool> UpdateSesion(SesionEntity sesion);
    }
}
