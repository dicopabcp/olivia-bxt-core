using OLIVIA.CORE.MODEL;

namespace OLIVIA.CORE.SERVICE
{
    public interface IRagService
    {
        public Task<bool> SearchInRag(SesionEntity sesion);
    }
}
