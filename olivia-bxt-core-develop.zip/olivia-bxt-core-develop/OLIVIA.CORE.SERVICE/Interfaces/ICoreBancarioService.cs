using OLIVIA.CORE.MODEL.DTO.CoreBancario;
using OLIVIA.CORE.REPOSITORY;

namespace OLIVIA.CORE.SERVICES
{
    public interface ICoreBancarioService
    {
        public Task<CoreBancarioClienteResponse?> ConsultarCliente(string carnet, string complemento);

        public Task<bool> ValidarOtp(string destino, string codigo);

        public Task<List<CoreBancarioCuentaResponse>> ConsultarCuentas(string cic);

        public Task<bool> ValidarClaveBancaMovil(string cic, string clave);

        public Task<bool> CrearUsuarioBancaMovil(string cic, string usuarioBm, string claveBm);

        public Task<CoreBancarioCrearCuentaResponse> CrearCuenta(string carnet, string propositoCuenta);
    }
}
