using OLIVIA.CORE.MODEL;
using OLIVIA.CORE.MODEL.DTO.WppFlows;

namespace OLIVIA.CORE.SERVICE
{
    public interface IMetaDataService
    {
        public Task<bool> SearchCarnet(SesionEntity sesion);
        public Task<bool> SearchTarjeta(SesionEntity sesion);
        public Task<bool> SearchCuenta(SesionEntity sesion);
        public Task<bool> SearchCuentaUnica(SesionEntity sesion);
        public Task<bool> SearchOtp(SesionEntity sesion);
        public Task<bool> SearchDaysInternet(SesionEntity sesion);
        public Task<bool> SearchDaysExterior(SesionEntity sesion);
        public Task<bool> SearchMonto(SesionEntity sesion);
        public Task<bool> RekognitionFlow(SesionEntity sesion);
        public Task<bool> SearchPais(SesionEntity sesion);
        public Task<bool> SearchMotivoBloqueo(SesionEntity sesion);
        public Task<bool> SearchTipoACH(SesionEntity sesion);
        public Task<bool> SearchDireccionACH(SesionEntity sesion);
        public Task<bool> SearchACH(SesionEntity sesion);
        public Task<bool> SearchBanco(SesionEntity sesion);
        public Task<bool> SearchImporteACH(SesionEntity sesion);
        public Task<bool> SearchHoraACH(SesionEntity sesion);
        public Task<bool> SearchCuentaBancoExterno(SesionEntity sesion);

        // WhatsApp Flows
        public Task<bool> SendRekognitionWppFlow(SesionEntity sesion);
        
        public Task<WppFlowResponse> SearchCarnetFlow(SesionEntity sesion, WppFlowIdcCliente dataFlow);

        public Task<WppFlowResponse> RekognitionWppFlow(SesionEntity sesion, WppFlowSelfi dataSelfi);

    }
}
