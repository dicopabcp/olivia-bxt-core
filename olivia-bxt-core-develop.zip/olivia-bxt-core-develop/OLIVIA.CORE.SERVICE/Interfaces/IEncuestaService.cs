using OLIVIA.CORE.MODEL;

namespace OLIVIA.CORE.SERVICE
{
    public interface IEncuestaService
    {
        public Task UpdateEncuesta(SesionEntity sesion);
        public Task CreateEncuesta(SesionEntity sesion);
        public Task FlujoEncuesta(SesionEntity sesion);

    }
}
