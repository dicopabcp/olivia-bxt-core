using OLIVIA.CORE.MODEL.DB_MODEL.PARAMETRO;
using OLIVIA.CORE.MODEL.DTO.Cache;

namespace OLIVIA.CORE.SERVICE.Interfaces
{
    public interface ICacheService
    {
        Task<List<ParametroEntitie>?> ParametroGetListAsync();
        Task<ParametroEntitie?> ParametroGetByNombreAsync(string nombre);
        Task<bool> ParametroUpdateAsync(ParametroDto request);
    }
}
