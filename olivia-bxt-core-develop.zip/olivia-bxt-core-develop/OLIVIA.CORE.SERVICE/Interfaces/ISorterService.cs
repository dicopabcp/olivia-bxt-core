using OLIVIA.CORE.MODEL;

namespace OLIVIA.CORE.SERVICE
{
    public interface ISorterService
    {
        public Task<string?> RequestToSorterBxT(SesionEntity sesion);
        Task RequestToSorterBxT(SesionEntity sesion, string res);
    }
}
