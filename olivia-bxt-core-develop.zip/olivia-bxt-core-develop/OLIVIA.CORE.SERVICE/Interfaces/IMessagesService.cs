using OLIVIA.CORE.MODEL;
using OLIVIA.CORE.MODEL.CONFIG;

namespace OLIVIA.CORE.SERVICE
{
    public interface IMessagesService
    {
        public List<MultimediaMessage> GetMultimediaByKey(string key);
        public ConfigMessages GetMessageByKey(string key);
        public Task<bool> SaveMessages(MessagesSesionEntity messagesSesionEntity, SesionEntity sesion, MessagesSesionEntity? messagesSesionBefore = null);
    }
}
