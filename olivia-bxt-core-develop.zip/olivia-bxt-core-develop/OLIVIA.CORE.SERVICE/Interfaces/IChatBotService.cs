namespace OLIVIA.CORE.SERVICE
{
    public interface IChatBotService
    {
        public Task<(string answer, bool flag)> ChatBotMain(string user, string text);
    }
}
