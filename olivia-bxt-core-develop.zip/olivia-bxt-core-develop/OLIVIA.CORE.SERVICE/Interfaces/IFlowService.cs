using OLIVIA.CORE.MODEL;

namespace OLIVIA.CORE.SERVICE
{
    public interface IFlowService
    {
        public Task RouteFlow(SesionEntity sesion);
        public Task CreateFlow(SesionEntity sesion);
        public Task UpdateFlow(Flow flow);

    }
}
