using OLIVIA.CORE.MODEL.CONST;
using OLIVIA.CORE.MODEL.DTO.Genesys;
using OLIVIA.CORE.MODEL.DTO.Genesys.ACCL;

namespace OLIVIA.CORE.SERVICES
{
    public interface IGenesysService
    {
        public Task<ClienteConsultaResponse?> GetClienteConsulta(string idOperacion, string idc, string complemento);

        public Task<TarjetaResponse?> GetTarjetasByCic(string idOperacion, string cic);

        public Task<bool> DesbloqueoByCic(string idOperacion, string cic);

        public Task<bool> DesvinculacionByCic(string idOperacion, string cic);

        public Task<bool> HabilitacionComprasXInternet(string idOperacion, string cic, string complemento, string duracion, string idc, string limite, string tarjeta);

        public Task<bool> HabilitacionTarjetaExterior(string idOperacion, string cic, string complemento, string duracion, string idc, string limite, string tarjeta);

        public Task<PruebaVidaGenerarResponse> PruebaVidaGenerar(string idOperacion, string idc, string celular);

        public Task<bool> PruebaVidaValidar(string idOperacion, string idc, string sessionId);

        public Task<PruebaVidaGenerarPasivaResponse?> PruebaVidaGenerarPasiva(string idOperacion, string idc, string celular);

        public Task<PruebaVidaValidarPasivaResponse?> PruebaVidaValidarPasiva(string idOperacion, string idc, string sessionId, string selfi);

        public Task<bool> OtpValidar(string idOperacion, string idc, string codigo);

        public Task<bool> OtpGenerar(string idOperacion, string celular, string idc, string correo);

        public Task<bool> RecordarUsuario(string idOperacion, string cic, string correo);

        public Task<List<string>> GetCuentas(string idOperacion, string cic);

        public Task<SaldoResponse> GetSaldo(string idOperacion, string cic, string cuenta);

        public Task<List<MovimientoResponse>> GetMovimientos(string idOperacion, string cic, string cuenta);

        public Task<bool> RecordarCuenta(string idOperacion, string cic, string correo, string cuenta);

        public Task<bool> BloquearTarjeta(string idOperacion, string cic, string tarjeta, TipoBloqueo tipoBloqueo);

        public Task<bool> DesbloquearToken(string idOperacion, string cic);

        public Task<List<ResponseTransferNumber>> AchStateTransfer(string idOperacion, string cic, string amount, string type, string direction, string transferTime, BankEntity origin, BankEntity destiny);

        public Task<List<ResponseBankList>> AchStateBankList(string idOperacion);

        public Task<ResponseTransferNumber?> AchStateTransferNumber(string idOperacion, string transferNumberm, string type, string direction);
    }
}
