using OLIVIA.CORE.MODEL;
using OLIVIA.CORE.MODELS.CONFIG;

namespace OLIVIA.CORE.SERVICE
{
    public interface IWhatsappService
    {
        public Task SendButton(SesionEntity sesion, string message, string rol = "olivia", params string[] arg);
        public Task SendMessageFlow(SesionEntity sesion, string message, string nameFlow, bool enableCacheMessage = false, string rol = "olivia", string screen = "", string? header = null, string? footer = null, params string[] arg);
        public Task SendList(SesionEntity sesion, string message, List<ListMessage> listMessages, string rol = "olivia", params string[] arg);
        public Task SendMessage(SesionEntity sesion, string message, string rol = "olivia", params string[] arg);
        public Task SendMessageDirect(SesionEntity sesion, string message, string rol = "olivia");
        public Task SendMessageFromRag(SesionEntity sesion, string message);
        public Task SaveMessage(SesionEntity sesion, string message);
    }
}
