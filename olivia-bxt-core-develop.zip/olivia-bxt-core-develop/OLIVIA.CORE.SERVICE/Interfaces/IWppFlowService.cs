using OLIVIA.CORE.MODEL.DTO.WppFlows;

namespace OLIVIA.CORE.SERVICE
{
    public interface IWppFlowService
    {
        Task<WppFlowResponse> ProcessRekognitionWppFlow(WppFlowRequest request);

        Task<WppFlowResponse> ProcessValidacionClienteWppFlow(WppFlowRequest request);
        
        Task<WppFlowResponse> ProcessAperturaCuentaNoClienteWppFlow(WppFlowRequest request);

        Task<WppFlowResponse> ProcessAperturaCuentaYaClienteConBMWppFlow(WppFlowRequest request);

        Task<WppFlowResponse> ProcessAperturaCuentaYaClienteSinBMWppFlow(WppFlowRequest request);

        // Consulta de saldos y movimientos (Fase 3, Plan Maestro v3 seccion 7.9.5): 2 Flows nativos separados.
        Task<WppFlowResponse> ProcessValidacionIdentidadWppFlow(WppFlowRequest request);

        Task<WppFlowResponse> ProcessConsultaMovimientosWppFlow(WppFlowRequest request);
    }
}
