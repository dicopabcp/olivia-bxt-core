using Microsoft.Extensions.Configuration;
using OLIVIA.CORE.MODEL;
using OLIVIA.CORE.MODEL.CONST;
using OLIVIA.CORE.MODEL.DB_MODEL.REGISTROPRUEBAVIDA;
using OLIVIA.CORE.MODEL.DTO.Genesys;
using OLIVIA.CORE.MODEL.DTO.Genesys.ACCL;
using OLIVIA.CORE.MODELS.CONFIG;
using OLIVIA.CORE.REPOSITORY.Interfaces;
using OLIVIA.CORE.SERVICE.Interfaces;
using OLIVIA.CORE.SERVICES;

namespace OLIVIA.CORE.SERVICE
{
    public class FlowService : IFlowService
    {
        private readonly IMetaDataService metaDataService;
        private readonly IWhatsappService whatsappService;
        private readonly IEncuestaService encuestaService;
        private readonly IGenesysService genesysService;
        private readonly IFlowRepository flowRepository;
        private readonly IRagService ragService;
        private readonly ICacheService cache;
        private readonly IRegistroPruebaVidaRepository registroPruebaVidaRepository;
        private readonly OliviaConfig oliviaConfig;

        public FlowService(IConfiguration configuration, IMetaDataService metaDataService, IEncuestaService encuestaService, IWhatsappService whatsappService, IGenesysService genesysService, IFlowRepository flowRepository, IRagService ragService, ICacheService cache, IRegistroPruebaVidaRepository registroPruebaVidaRepository)
        {
            this.metaDataService = metaDataService;
            this.whatsappService = whatsappService;
            this.genesysService = genesysService;
            this.encuestaService = encuestaService;
            this.flowRepository = flowRepository;
            this.ragService = ragService;
            this.cache = cache;
            this.registroPruebaVidaRepository = registroPruebaVidaRepository;
            OliviaConfig olivia = new();
            configuration.GetSection("OliviaConfig").Bind(olivia);
            this.oliviaConfig = olivia;
        }

        public async Task CreateFlow(SesionEntity sesion)
        {
            await this.flowRepository.CreateFlow(sesion, sesion.ActiveFlow!);
        }

        public async Task UpdateFlow(Flow flow)
        {
            await this.flowRepository.UpdateFlow(flow);
        }

        public async Task RouteFlow(SesionEntity sesion)
        {
            switch (sesion.Topic)
            {
                //BANCA_MOVIL
                case "DESBLOQUEO":
                    await this.Desbloqueo(sesion);
                    break;
                case "DESVINCULACION":
                    if (oliviaConfig.FlagWppFlowGS)
                    {
                        await this.DesvinculacionFlowGS(sesion);
                    }
                    else
                    {
                        await this.Desvinculacion(sesion);
                    }
                    break;
                case "OLVIDO USUARIO":
                    await this.OlvidoUsuario(sesion);
                    break;
                case "OLVIDO CONTRASEÑA":
                    await this.OlvidoContraseña(sesion);
                    break;
                case "SINCRONIZACION TOKEN":
                    await this.DesbloquearToken(sesion);
                    break;

                //ATM
                case "CAJEROS PROBLEMAS" or "PROBLEMAS":
                    await this.CajerosProblemas(sesion);
                    break;
                case "CAJEROS DIRECCIONES" or "DIRECCIONES":
                    await this.CajerosDirecciones(sesion);
                    break;

                //CUENTA
                case "SALDO" or "CONSULTA SALDO":
                    if (!await this.TryDispararFlowValidacionIdentidad(sesion))
                    {
                        await this.Saldo(sesion);
                    }
                    break;
                case "MOVIMIENTOS":
                    if (!await this.TryDispararFlowValidacionIdentidad(sesion))
                    {
                        await this.Movimientos(sesion);
                    }
                    break;
                case "OLVIDO CUENTA":
                    await this.Olividocuenta(sesion);
                    break;
                case "CUENTA BLOQUEADA":
                    await this.CuentaBloqueada(sesion);
                    break;
                case "CONSUMO NO RECONOCIDO" or "NO_RECONOCIDO":
                    await this.ConsumoNoReconocido(sesion);
                    break;

                //TARJETA
                case "COMPRAS X INTERNET" or "INTERNET":
                    await this.ComprasxInternet(sesion);
                    break;
                case "COMPRAS EXTERIOR" or "EXTERIOR":
                    await this.ComprasExterior(sesion);
                    break;
                case "BLOQUEO TARJETA" or "EXTRAVIO":
                    await this.BloqueoTarjeta(sesion);
                    break;
                case "RECHAZOS TARJETA" or "RECHAZOS":
                    await this.RechazosTarjeta(sesion);
                    break;
                case "NEGOCIOS":
                    await this.Negocio(sesion);
                    break;

                //TARIFARIO
                case "TARIFARIO TASAS":
                    await this.TarifarioTasas(sesion);
                    break;
                case "TARIFARIO COMISIONES":
                    await this.TarifarioComisiones(sesion);
                    break;
                case "LIMITE TRANSACCIONES":
                    await this.LimiteTransacciones(sesion);
                    break;

                //TRANSACCIONES
                case "ESTADO": //FLUJO ACH
                    await this.EstadoTransacciones(sesion);
                    break;

                //VARIOS
                case "OFICINAS DIRECCIONES": //este valor puede ser sacado de la SUBINTENCION UNKNOWN, DIRECCION 
                    await this.OficinasDirecciones(sesion);
                    break;
                case "PAGO SERVICIOS":
                    await this.PagoServicios(sesion);
                    break;
                case "ADELANTO SUELDO":
                    await this.AdelantoSueldo(sesion);
                    break;
                case "GENESYS AGENTE" or "AGENTE":
                    await this.Agente(sesion);
                    break;
                case "DERIVACION YAPE":
                    await this.DerivacionYape(sesion);
                    break;

                //OTROS
                case "RAG":
                    await this.RAG(sesion);
                    break;
                case "SALUDO":
                    Saludo(sesion);
                    break;
                case "FINALIZAR":
                    await this.Despedida(sesion);
                    break;
                case "SIN_SENTIDO":
                    //Sin sentido igual a despedida
                    //await this.Despedida(sesion);
                    sesion.Estado = EstadoSesion.SIN_TOPICO;
                    sesion.ActiveFlow!.State = "COMPLETADO";
                    break;
                case "DEFLEXION":
                    Deflexion(sesion);
                    break;
                default:
                    break;
            }
            await this.UpdateFlow(sesion.ActiveFlow!);
        }

        private async Task SendFinalMessage(SesionEntity sesion, string message, bool isSuccess, params string[] args)
        {
            if (args.Length == 0)
                await this.whatsappService.SendMessage(sesion, message);
            else
                await this.whatsappService.SendMessage(sesion, message, "olivia", args);
            if (isSuccess)
            {
                await this.whatsappService.SendButton(sesion, "MENSAJE-ENCUESTA-INICIO");
                await this.encuestaService.CreateEncuesta(sesion);
                //AGREGAR TTL DE ENCUESTA
                sesion.Estado = EstadoSesion.ENCUESTA;
                sesion.ActiveFlow!.State = "COMPLETADO";
                sesion.ActiveFlow.CurrentStep = "";
                sesion.ActiveFlow.DetailsStep = "";
            }
            else
            {
                sesion.Estado = EstadoSesion.AGENTE;
                sesion.AgenteDate = DateTime.Now;
                sesion.ActiveFlow!.State = "ERROR";
                sesion.ActiveFlow.DetailsStep = "API";
                sesion.ActiveFlow.CurrentStep = "FINAL";
            }
            sesion.ActiveFlow.FinishDate = DateTime.Now;
        }

        private async Task DesbloquearToken(SesionEntity sesion)
        {
            if (!await this.metaDataService.SearchCarnet(sesion))
                return;

            if (this.oliviaConfig.ActivarTarjeta && !await this.metaDataService.SearchTarjeta(sesion))
                return;

            if (!await this.metaDataService.SearchOtp(sesion))
                return;

            string operation = DateTime.Now.ToString("yyyyMMddHHmmss");


            bool aux = await this.genesysService.DesbloquearToken(operation, sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CIC") == 0)!.Valor);
            string text = aux ? "DESBLOQUEO-TOKEN-OK" : "DESBLOQUEO-TOKEN-ERROR";
            await this.SendFinalMessage(sesion, text, aux);
        }

        private async Task Desbloqueo(SesionEntity sesion)
        {
            if (!await this.metaDataService.SearchCarnet(sesion))
                return;

            if (this.oliviaConfig.ActivarTarjeta && !await this.metaDataService.SearchTarjeta(sesion))
                return;

            if (!await this.metaDataService.SearchOtp(sesion))
                return;

            //LLAMADA A LA API PARA DESBLOQUEAR LA CUENTA

            bool aux = await this.genesysService.DesbloqueoByCic(sesion._id.ToString(), sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CIC") == 0)!.Valor);
            string text = aux ? "DESBLOQUEO-OK" : "DESBLOQUEO-ERROR";
            await this.SendFinalMessage(sesion, text, aux);
        }
        private async Task ComprasxInternet(SesionEntity sesion)
        {
            if (!await this.metaDataService.SearchCarnet(sesion))
                return;

            if (!await this.metaDataService.SearchTarjeta(sesion))
                return;
            Metadata? metadataTar = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("TAR") == 0);
            if (metadataTar!.Tipo.CompareTo("DEBITO") != 0)
            {
                sesion.Estado = EstadoSesion.AGENTE;
                sesion.AgenteDate = DateTime.Now;
                await this.whatsappService.SendMessage(sesion, "TARJETAS-COMPRAS-ERROR-DEBITO");
                return;
            }

            if (!await this.metaDataService.SearchOtp(sesion))
                return;

            if (!await this.metaDataService.SearchDaysInternet(sesion))
                return;

            if (!await this.metaDataService.SearchMonto(sesion))
                return;

            bool auxTar = await this.genesysService.HabilitacionComprasXInternet("",
                sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CIC") == 0)!.Valor,
                "00",
                sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("DIAS") == 0)!.Valor,
                sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("IDC") == 0)!.Valor,
                "002",
                sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("TAR") == 0)!.Valor);
            string textTar = auxTar ? "TARJETAS-COMPRAS-OK" : "TARJETAS-COMPRAS-ERROR";
            await this.SendFinalMessage(sesion, textTar, auxTar);

        }

        private async Task Desvinculacion(SesionEntity sesion)
        {
            if (!await this.metaDataService.SearchCarnet(sesion))
                return;

            if (!await this.metaDataService.RekognitionFlow(sesion))
                return;

            //LLAMADA A LA API DESVINCULAR LA CUENTA
            bool aux2 = await this.genesysService.DesvinculacionByCic("", sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CIC") == 0)!.Valor);
            string text2 = aux2 ? "DESVINCULACION-OK" : "DESVINCULACION-ERROR";
            await this.SendFinalMessage(sesion, text2, aux2);
            return;
        }

        private async Task DesvinculacionFlowGS(SesionEntity sesion)
        {
            await this.metaDataService.SendRekognitionWppFlow(sesion);
        }

        private async Task OlvidoUsuario(SesionEntity sesion)
        {
            if (!await this.metaDataService.SearchCarnet(sesion))
                return;
            if (!await this.metaDataService.SearchOtp(sesion))
                return;
            if (this.oliviaConfig.ActivarTarjeta && !await this.metaDataService.SearchTarjeta(sesion))
                return;

            string cic = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CIC") == 0)!.Valor;
            string correo = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("EMAIL") == 0)!.Valor;
            bool aux = await this.genesysService.RecordarUsuario("", cic, correo);
            if (aux)
                await this.SendFinalMessage(sesion, "OLVIDO-USUARIO-OK", aux, ObfuscateEmail(correo));
            else
                await this.SendFinalMessage(sesion, "OLVIDO-USUARIO-ERROR", aux);
        }

        // Alterna el flujo conversacional de Saldo/Movimientos por el WhatsApp Flow nativo segun el parametro CONSULTA_SALDOS.MODO.ENVIO (Enabled=false por defecto).
        private async Task<bool> TryDispararFlowValidacionIdentidad(SesionEntity sesion)
        {
            var parametroSaldos = await this.cache.ParametroGetByNombreAsync("WPP-FLOW_VALIDACION_ONBOARDING");
            if (parametroSaldos != null && parametroSaldos.Enabled)
            {
                // WhatsApp/Gupshup no permite 2 pantallas de entrada distintas para el mismo flow_id, asi que el gating de
                // 2 niveles (EstaRegistradoWhatsapp/EstaAutenticado) ahora elige entre 2 Flows separados en vez de forzar
                // una pantalla inicial dentro del mismo Flow: fila 10 (ya registrado/autenticado) usa el Flow de una sola
                // pantalla "FlowValidacionIdentidadClave" (CSM_LOGIN_CLAVE); fila 10a (nunca registrado) usa el Flow
                // completo "FlowValidacionIdentidad" (CSM_DATOS_CI -> CSM_SELFIE -> CSM_DOCUMENTO_ID -> CSM_LOGIN_CLAVE).
                RegistroPruebaVidaEntity? registro = await this.registroPruebaVidaRepository.GetByCelularAsync(sesion.Usuario);
                bool yaRegistrado = sesion.Autenticado || (registro is not null && registro.Registrado);
                string nameFlow = yaRegistrado ? "FlowValidacionIdentidadClave" : "FlowValidacionIdentidad";
                string screen = yaRegistrado ? "CSM_LOGIN_CLAVE" : "CSM_DATOS_CI";
                await this.whatsappService.SendMessageFlow(sesion, parametroSaldos.Mensaje, nameFlow, true, screen: screen);
                return true;
            }

            return false;
        }

        private async Task Saldo(SesionEntity sesion)
        {
            if (!await this.metaDataService.SearchCarnet(sesion))
                return;

            if (!await this.metaDataService.SearchOtp(sesion))
                return;

            if (!await this.metaDataService.SearchCuentaUnica(sesion))
                return;

            string cic = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CIC") == 0)!.Valor;
            string cta = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CTA") == 0)!.Valor;
            SaldoResponse saldoResponse = await this.genesysService.GetSaldo("", cic, cta);
            bool aux = saldoResponse != null;
            if (aux)
            {
                await this.SendFinalMessage(sesion, "SALDO-OK", aux, saldoResponse!.Saldo.ToString(), saldoResponse!.Moneda);
            }
            else
            {
                await this.SendFinalMessage(sesion, "SALDO-ERROR", aux);
            }
        }
        private async Task Movimientos(SesionEntity sesion)
        {
            if (!await this.metaDataService.SearchCarnet(sesion))
                return;

            if (!await this.metaDataService.SearchOtp(sesion))
                return;

            if (!await this.metaDataService.SearchCuentaUnica(sesion))
                return;

            string cic = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CIC") == 0)!.Valor;
            string cta = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CTA") == 0)!.Valor;
            List<MovimientoResponse>? saldoResponse = await this.genesysService.GetMovimientos("", cic, cta);
            if (saldoResponse == null)
                await this.SendFinalMessage(sesion, "MOVIMIENTOS-ERROR", false);
            else if (saldoResponse.Count != 0)
                await this.SendFinalMessage(sesion, "MOVIMIENTOS-OK", true, string.Join('\n', saldoResponse.Select((item) => string.Format("{0} {1} {2}", FormaterDate(item.Fecha), item.Glosa, item.Monto))));
            else
                await this.SendFinalMessage(sesion, "MOVIMIENTOS-SIN-MOV", true);
        }

        private async Task Olividocuenta(SesionEntity sesion)
        {
            if (!await this.metaDataService.SearchCarnet(sesion))
                return;

            if (!await this.metaDataService.SearchOtp(sesion))
                return;

            if (this.oliviaConfig.ActivarTarjeta && !await this.metaDataService.SearchTarjeta(sesion))
                return;

            string cic = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CIC") == 0)!.Valor;
            string correo = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("EMAIL") == 0)!.Valor;
            List<string> list = await this.genesysService.GetCuentas("", cic);
            bool aux = await this.genesysService.RecordarCuenta("", cic, correo, string.Join("\n", list));
            if (aux)
                await this.SendFinalMessage(sesion, "OLVIDO-CUENTA-OK", aux, ObfuscateEmail(correo));
            else
                await this.SendFinalMessage(sesion, "OLVIDO-CUENTA-ERROR", aux);
        }

        private async Task ComprasExterior(SesionEntity sesion)
        {
            if (!await this.metaDataService.SearchCarnet(sesion))
                return;

            if (!await this.metaDataService.SearchTarjeta(sesion))
                return;

            Metadata? metadataTar = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("TAR") == 0);
            if (metadataTar!.Tipo.CompareTo("DEBITO") != 0)
            {
                sesion.Estado = EstadoSesion.AGENTE;
                sesion.AgenteDate = DateTime.Now;
                await this.whatsappService.SendMessage(sesion, "TARJETAS-EXTERIOR-ERROR-DEBITO");
                return;
            }

            if (!await this.metaDataService.SearchOtp(sesion))
                return;

            if (!await this.metaDataService.SearchDaysExterior(sesion))
                return;

            if (!await this.metaDataService.SearchPais(sesion))
                return;

            bool auxTar = await this.genesysService.HabilitacionTarjetaExterior("",
                sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CIC") == 0)!.Valor,
                "00",
                sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("DIAS") == 0)!.Valor,
                sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("IDC") == 0)!.Valor,
                "005",
                sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("TAR") == 0)!.Valor);
            string textTar = auxTar ? "TAJETA-EXTERIOR-CORRECTO" : "TAJETA-EXTERIOR-ERROR";
            await this.SendFinalMessage(sesion, textTar, auxTar);
        }
        private async Task BloqueoTarjeta(SesionEntity sesion)
        {
            if (!await this.metaDataService.SearchCarnet(sesion))
                return;

            if (!await this.metaDataService.SearchOtp(sesion))
                return;

            if (!await this.metaDataService.SearchMotivoBloqueo(sesion))
                return;

            if (!await this.metaDataService.SearchTarjeta(sesion))
                return;
            Metadata? metadataTar = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("TAR") == 0);
            if (metadataTar!.Tipo.CompareTo("DEBITO") != 0)
            {
                sesion.Estado = EstadoSesion.AGENTE;
                sesion.AgenteDate = DateTime.Now;
                await this.whatsappService.SendMessage(sesion, "TARJETAS-BLOQUEO-ERROR-DEBITO");
                return;
            }
            bool auxTar = await this.genesysService.BloquearTarjeta("",
                sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CIC") == 0)!.Valor,
                sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("TAR") == 0)!.Valor,
                ((TipoBloqueo)int.Parse(sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("BLOQ") == 0)!.Tipo)));
            string textTar = auxTar ? "BLOQUEO-TARJETA-OK" : "BLOQUEO-TARJETA-ERROR";
            await this.SendFinalMessage(sesion, textTar, auxTar);

        }
        private async Task Negocio(SesionEntity sesion)
        {
            await this.SendFinalMessage(sesion, "NEGOCIOS-HABILITADOS", true);
        }
        private async Task TarifarioTasas(SesionEntity sesion)
        {
            await this.SendFinalMessage(sesion, "TARIFARIO-TASAS", true);
        }
        private async Task LimiteTransacciones(SesionEntity sesion)
        {
            await this.SendFinalMessage(sesion, "LIMITE-TRANSACCIONES", true);
        }
        private async Task TarifarioComisiones(SesionEntity sesion)
        {
            await this.SendFinalMessage(sesion, "TARIFARIO-COMISIONES", true);
        }
        private async Task OlvidoContraseña(SesionEntity sesion)
        {
            await this.SendFinalMessage(sesion, "OLVIDO-CONTRASEÑA", true);
        }
        private async Task CajerosProblemas(SesionEntity sesion)
        {
            await this.SendFinalMessage(sesion, "CAJEROS-PROBLEMAS", true);
        }
        private async Task CajerosDirecciones(SesionEntity sesion)
        {
            await this.SendFinalMessage(sesion, "CAJEROS-DIRECCIONES", true);
        }
        private async Task OficinasDirecciones(SesionEntity sesion)
        {
            await this.SendFinalMessage(sesion, "OFICINAS-DIRECCIONES", true);
        }

        private async Task EstadoTransacciones(SesionEntity sesion)
        {
            if (!await this.metaDataService.SearchCarnet(sesion))
                return;

            if (!await this.metaDataService.SearchOtp(sesion))
                return;

            if (!await this.metaDataService.SearchTipoACH(sesion)) //QR???
                return;

            if (!await this.metaDataService.SearchDireccionACH(sesion)) //ENTRANTE O SALIENTE???
                return;

            if (!await this.metaDataService.SearchACH(sesion))//NUMERO DE ACH
                return;

            if (!string.IsNullOrEmpty(sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_NUM") == 0)!.Valor))
            {
                string ACH_DIR = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_DIR") == 0)!.Valor;
                string ACH_NUM = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_NUM") == 0)!.Valor;
                string ACH_TYPE = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_TYPE") == 0)!.Valor;
                //buscar ACH por el numero
                ResponseTransferNumber? responseTN = await this.genesysService.AchStateTransferNumber(
                    "",
                    ACH_NUM,
                    ACH_TYPE,
                    ACH_DIR);
                if (responseTN is not null)
                {
                    string messageCode = "";
                    switch (responseTN.ResponseCodeAch)
                    {
                        case "ACEPTADO":
                            messageCode = ACH_DIR.CompareTo("OUTGOING") == 0 ? "ACH-OK-BCP-EXTERNO" : "ACH-OK-EXTERNO-BCP";
                            await this.SendFinalMessage(sesion, messageCode, true, ACH_NUM);
                            break;
                        case "TRANSITO":
                            messageCode = ACH_DIR.CompareTo("OUTGOING") == 0 ? "ACH-TRANS-BCP-EXTERNO" : "ACH-TRANS-EXTERNO-BCP";
                            await this.SendFinalMessage(sesion, messageCode, true, ACH_NUM);
                            break;
                        case "RECHAZADO":
                            if (ACH_DIR.CompareTo("OUTGOING") == 0)
                                await this.SendFinalMessage(sesion, "ACH-RECHAZO-BCP-EXTERNO", true);
                            else
                                await this.SendFinalMessage(sesion, "ACH-RECHAZO-EXTERNO-BCP", false);
                            break;
                        case "NO ENCONTRADO":
                            await this.SendFinalMessage(sesion, "ACH-NO_ENCONTRADO", false);
                            break;
                        default:
                            await this.SendFinalMessage(sesion, "ACH-NO_ENCONTRADO", false);
                            break;
                    }
                }
                else
                {
                    await this.SendFinalMessage(sesion, "ACH-NO_ENCONTRADO", false);
                }
                return;
            }

            if (!await this.metaDataService.SearchCuentaUnica(sesion))//CUENTA BCP
                return;

            if (!await this.metaDataService.SearchBanco(sesion))//CUENTA OTRO BANCO
                return;

            if (!await this.metaDataService.SearchCuentaBancoExterno(sesion))//CUENTA OTRO BANCO
                return;

            if (!await this.metaDataService.SearchImporteACH(sesion))//Busca el importe del ACH
                return;

            if (!await this.metaDataService.SearchHoraACH(sesion))//Busca la Hora
                return;

            //CONSUMIR LA API PARA BUSCAR EL ACCL
            string CIC_TRANS = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CIC") == 0)!.Valor;
            string ACH_DIR_TRANS = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_DIR") == 0)!.Valor;
            string ACH_TYPE_TRANS = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_TYPE") == 0)!.Valor;
            string ACH_TIME_TRANS = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_TIME") == 0)!.Valor;
            string ACH_AMOUNT_TRANS = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_AMOUNT") == 0)!.Valor;
            string ACH_BANCO_EXTERNO_CTA_TRANS = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_BANCO_EXTERNO_CTA") == 0)!.Valor;
            string ACH_BANCO_EXTERNO_CODE_TRANS = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_BANCO_EXTERNO_CODE") == 0)!.Valor;
            string CTA_TRANS = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CTA") == 0)!.Valor;

            BankEntity origin = new()
            {
                Account = ACH_DIR_TRANS.CompareTo("OUTGOING") == 0 ? CTA_TRANS : ACH_BANCO_EXTERNO_CTA_TRANS,
                Bank = ACH_DIR_TRANS.CompareTo("OUTGOING") == 0 ? this.oliviaConfig.IdBCP : ACH_BANCO_EXTERNO_CODE_TRANS
            };
            BankEntity destiny = new()
            {
                Account = ACH_DIR_TRANS.CompareTo("OUTGOING") != 0 ? CTA_TRANS : ACH_BANCO_EXTERNO_CTA_TRANS,
                Bank = ACH_DIR_TRANS.CompareTo("OUTGOING") != 0 ? this.oliviaConfig.IdBCP : ACH_BANCO_EXTERNO_CODE_TRANS
            };

            List<ResponseTransferNumber> response = await this.genesysService.AchStateTransfer("", CIC_TRANS, ACH_AMOUNT_TRANS, ACH_TYPE_TRANS, ACH_DIR_TRANS, ACH_TIME_TRANS, origin, destiny);
            if (response.Count == 0)
            {
                await this.SendFinalMessage(sesion, "ACH-NO_ENCONTRADO", false);
                return;
            }
            if (response.Count == 1)
            {
                //Solo encontro una
                ResponseTransferNumber responseTransfer = response[0];
                string messageCode = "";
                switch (responseTransfer.ResponseCodeAch)
                {
                    case "ACEPTADO":
                        messageCode = ACH_DIR_TRANS.CompareTo("OUTGOING") == 0 ? "ACH-OK-BCP-EXTERNO" : "ACH-OK-EXTERNO-BCP";
                        await this.SendFinalMessage(sesion, messageCode, true, responseTransfer.SenderTransferNumber);
                        break;
                    case "TRANSITO":
                        messageCode = ACH_DIR_TRANS.CompareTo("OUTGOING") == 0 ? "ACH-TRANS-BCP-EXTERNO" : "ACH-TRANS-EXTERNO-BCP";
                        await this.SendFinalMessage(sesion, messageCode, true, responseTransfer.SenderTransferNumber);
                        break;
                    case "RECHAZADO":
                        if (ACH_DIR_TRANS.CompareTo("OUTGOING") == 0)
                            await this.SendFinalMessage(sesion, "ACH-RECHAZO-BCP-EXTERNO", true);
                        else
                            await this.SendFinalMessage(sesion, "ACH-RECHAZO-EXTERNO-BCP", false);
                        break;
                    case "NO ENCONTRADO":
                        await this.SendFinalMessage(sesion, "ACH-NO_ENCONTRADO", false);
                        break;
                    default:
                        await this.SendFinalMessage(sesion, "ACH-NO_ENCONTRADO", false);
                        break;
                }
                return;
            }
            //cualquiero otro caso
            await this.SendFinalMessage(sesion, "ACH-NO_ENCONTRADO", false);
        }

        private async Task DerivacionYape(SesionEntity sesion)
        {
            await this.SendFinalMessage(sesion, "DERIVACION-YAPE", true);
        }
        private async Task PagoServicios(SesionEntity sesion)
        {
            await this.FlowToAgent(sesion, "PAGO-SERVICIOS");
        }
        private async Task Agente(SesionEntity sesion)
        {
            await this.FlowToAgent(sesion, "AGENTE-DERIVACION");
        }
        private static void Deflexion(SesionEntity sesion)
        {
            sesion.Estado = EstadoSesion.DEFLEXION;
            sesion.AgenteDate = DateTime.Now;
            sesion.ActiveFlow!.FinishDate = DateTime.Now;
            sesion.ActiveFlow.State = "DERIVADO";
        }
        private async Task CuentaBloqueada(SesionEntity sesion)
        {
            await this.FlowToAgent(sesion, "CUENTA-BLOQUEADA");
        }
        private async Task ConsumoNoReconocido(SesionEntity sesion)
        {
            await this.FlowToAgent(sesion, "CONSUMO-NO-RECONOCIDO");
        }
        private async Task AdelantoSueldo(SesionEntity sesion)
        {
            await this.FlowToAgent(sesion, "ADELANTO-SUELDO");
        }
        private async Task RechazosTarjeta(SesionEntity sesion)
        {
            await this.SendFinalMessage(sesion, "RECHAZO-TARJETA", true);
        }
        private static void Saludo(SesionEntity sesion)
        {
            sesion.Estado = EstadoSesion.SIN_TOPICO;
            sesion.ActiveFlow!.State = "COMPLETADO";
        }
        private async Task Despedida(SesionEntity sesion)
        {
            sesion.ActiveFlow!.State = "COMPLETADO";
            await this.SendFinalMessage(sesion, "MENSAJE-DESPEDIDA", true);
        }

        private static string ObfuscateEmail(string email)
        {
            // Dividir el correo en partes antes y después del '@'
            int atIndex = email.IndexOf('@');
            if (atIndex < 0)
                atIndex = email.Length;
            string localPart = email.Substring(0, atIndex);
            string domainPart = email.Substring(atIndex);

            // Mantener los primeros dos caracteres y el dominio
            string obfuscatedLocalPart = localPart.Substring(0, 2) + new string('X', localPart.Length - 2);

            // Reconstruir el correo ofuscado
            return obfuscatedLocalPart + domainPart;
        }

        private static string FormaterDate(string date)
        {
            return new DateTime(int.Parse(date.Substring(0, 4)), int.Parse(date.Substring(4, 2)), int.Parse(date.Substring(6, 2))).ToString("dd/MM/yyyy");
        }

        private async Task RAG(SesionEntity sesion)
        {
            bool isSuccess = await this.ragService.SearchInRag(sesion);
            if (isSuccess)
            {
                sesion.Estado = EstadoSesion.CERRADO;
            }
            else
            {
                sesion.Estado = EstadoSesion.AGENTE;
                sesion.AgenteDate = DateTime.Now;

            }
            sesion.ActiveFlow!.FinishDate = DateTime.Now;
        }

        private async Task FlowToAgent(SesionEntity sesion, string mensage)
        {
            await this.whatsappService.SendMessage(sesion, mensage);
            sesion.Estado = EstadoSesion.AGENTE;
            sesion.AgenteDate = DateTime.Now;
            sesion.ActiveFlow!.FinishDate = DateTime.Now;
            sesion.ActiveFlow.State = "DERIVADO";
        }
    }
}
