using OLIVIA.CORE.MODEL;
using OLIVIA.CORE.REPOSITORY;

namespace OLIVIA.CORE.SERVICE
{
    public class SesionService : ISesionService
    {
        private readonly ISesionRepository sesionRepository;
        public SesionService(ISesionRepository sesionRepository)
        {
            this.sesionRepository = sesionRepository;
        }

        public async Task<SesionEntity> CreateSesion(string usuario)
        {
            SesionEntity? sesion = await this.sesionRepository.CreateMongoSesion(usuario)!;
            await this.sesionRepository.CreateSqlSesion(sesion!);
            await this.sesionRepository.CreateRedisSesion(usuario, sesion!._id.ToString());
            return sesion;
        }

        public async Task<SesionEntity?> GetSesion(string sesionId)
        {
            SesionEntity? sesion = await this.sesionRepository.ReadMongoSesion(sesionId);
            return sesion;
        }

        public async Task<SesionEntity?> ReadSesion(string usuario)
        {
            string? idSesion = await this.sesionRepository.ReadRedisSesion(usuario)!;
            SesionEntity? sesion = await this.sesionRepository.ReadMongoSesion(idSesion!);
            return sesion;
        }
        public async Task<bool> UpdateSesion(SesionEntity sesion)
        {
            await this.sesionRepository.UpdateMongoSesion(sesion);
            await this.sesionRepository.UpdateRedisSesion(sesion);
            await this.sesionRepository.UpdateSqlSesion(sesion);
            return true;
        }
    }
}
