using Microsoft.Extensions.Configuration;
using OLIVIA.CORE.MODEL;
using OLIVIA.CORE.MODEL.CONST;
using OLIVIA.CORE.MODEL.DB_MODEL.REGISTROPRUEBAVIDA;
using OLIVIA.CORE.MODEL.DTO.CoreBancario;
using OLIVIA.CORE.MODEL.DTO.Genesys;
using OLIVIA.CORE.MODEL.DTO.WppFlows;
using OLIVIA.CORE.MODELS.CONFIG;
using OLIVIA.CORE.REPOSITORY;
using OLIVIA.CORE.REPOSITORY.Interfaces;
using OLIVIA.CORE.SERVICES;
using Serilog;
using System.Text.Json;

namespace OLIVIA.CORE.SERVICE
{
    public class WppFlowService : IWppFlowService
    {
        private const string TopicoAperturaNoCliente = "APERTURA_CUENTA_NO_CLIENTE";
        private const string TopicoAperturaYaClienteConBM = "APERTURA_CUENTA_YA_CLIENTE_CON_BM";
        private const string TopicoAperturaYaClienteSinBM = "APERTURA_CUENTA_YA_CLIENTE_SIN_BM";
        // Fase 3 (Plan Maestro v3, seccion 7.9.5): consulta de saldos y movimientos, 2 Flows nativos separados.
        private const string TopicoValidacionIdentidad = "CONSULTA_SALDOS_VALIDACION_IDENTIDAD";
        private const string TopicoConsultaMovimientos = "CONSULTA_SALDOS_MOVIMIENTOS";
        // Unico tipo de cliente relevante para este flujo (fila 10/10a de la matriz 7.4: requisito previo "ya cliente CON BM").
        private const string TipoClienteYaClienteConBM = "Ya cliente CON BM";

        private readonly IMetaDataService metaDataService;
        private readonly IWhatsappService whatsappService;
        private readonly IGenesysService genesysService;
        private readonly IEncuestaService encuestaService;
        private readonly ISesionService sesionService;
        private readonly IMessagesService messagesService;
        private readonly IFlowService flowService;
        private readonly IWhatsAppRepository whatsAppRepository;
        private readonly ICoreBancarioService coreBancarioService;
        private readonly IRegistroPruebaVidaRepository registroPruebaVidaRepository;
        private readonly OliviaConfig oliviaConfig;

        public WppFlowService(IConfiguration configuration, IMetaDataService metaDataService, IWhatsappService whatsappService, IGenesysService genesysService, IEncuestaService encuestaService, ISesionService sesionService, IMessagesService messagesService, IFlowService flowService, IWhatsAppRepository whatsAppRepository, ICoreBancarioService coreBancarioService, IRegistroPruebaVidaRepository registroPruebaVidaRepository)
        {
            this.metaDataService = metaDataService;
            this.whatsappService = whatsappService;
            this.genesysService = genesysService;
            this.encuestaService = encuestaService;
            this.sesionService = sesionService;
            OliviaConfig olivia = new();
            configuration.GetSection("OliviaConfig").Bind(olivia);
            this.oliviaConfig = olivia;
            this.messagesService = messagesService;
            this.flowService = flowService;
            this.whatsAppRepository = whatsAppRepository;
            this.coreBancarioService = coreBancarioService;
            this.registroPruebaVidaRepository = registroPruebaVidaRepository;
        }

        public async Task<WppFlowResponse> ProcessRekognitionWppFlow(WppFlowRequest request)
        {
            WppFlowResponse response = new();
            SesionEntity? sesion = await this.sesionService.GetSesion(request.SesionId);
            string errorCode = string.Empty;
            try
            {
                if (sesion is null || !(sesion.Estado.CompareTo(EstadoSesion.CON_TOPICO) == 0 && sesion.Topic == "DESVINCULACION"))
                {
                    if (sesion is null)
                    {
                        errorCode = "WPP-FLOW_EXPIRADO";
                    }
                    else if (sesion.Estado == EstadoSesion.ENCUESTA || sesion.Estado == EstadoSesion.CERRADO)
                    {
                        errorCode = string.Empty;
                    }
                    else
                    {
                        errorCode = "WPP-FLOW_ERROR_TOPIC";
                    }

                    response.Mensaje = errorCode;
                    response.Expired = true;
                    response.Success = false;
                    response.EnviarGenesys = false;

                    _ = Task.Run(async () =>
                    {
                        await Task.Delay(TimeSpan.FromSeconds(oliviaConfig.DelayWppFlowsGS));
                        if (string.IsNullOrEmpty(errorCode))
                            return;

                        if (sesion is not null)
                        {
                            await this.whatsappService.SendMessage(sesion, errorCode);
                        }
                        else
                        {
                            string mensaje = this.messagesService.GetMessageByKey(errorCode).Value;
                            await this.whatsAppRepository.SendMessage(request.Usuario, mensaje);
                        }
                    });
                }
                else
                {
                    switch (request.Flow)
                    {
                        case "REKOGNITION_INIT":
                            WppFlowIdcCliente dataFlow = JsonSerializer.Deserialize<WppFlowIdcCliente>(request.Data!)!;
                            response = await this.metaDataService.SearchCarnetFlow(sesion, dataFlow);
                            break;
                        case "SELFIE":
                            WppFlowSelfi dataSelfi = JsonSerializer.Deserialize<WppFlowSelfi>(request.Data!)!;
                            response = await this.metaDataService.RekognitionWppFlow(sesion, dataSelfi);

                            //LLAMADA A LA API DESVINCULAR LA CUENTA
                            if (response.Success)
                            {
                                bool aux2 = await this.genesysService.DesvinculacionByCic("", sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CIC") == 0)!.Valor);
                                response.Mensaje = aux2 ? "DESVINCULACION-OK" : "DESVINCULACION-ERROR";
                                response.Success = aux2;
                                response.EnviarGenesys = !aux2;

                                _ = Task.Run(async () =>
                                {
                                    await Task.Delay(TimeSpan.FromSeconds(oliviaConfig.DelayWppFlowsGS));
                                    string text2 = aux2 ? "DESVINCULACION-OK" : "DESVINCULACION-ERROR";
                                    await this.SendFinalMessage(sesion, text2, aux2);
                                    await this.sesionService.UpdateSesion(sesion);
                                });
                            }
                            break;
                        default:
                            break;
                    }

                    errorCode = response.Mensaje ?? string.Empty;
                    if (errorCode.Equals("LIMITE-INTENTOS") || errorCode.Equals("WPP-FLOW_REKOGNITION-ERROR-GENERAR-PASIVA"))
                    {
                        _ = Task.Run(async () =>
                        {
                            await Task.Delay(TimeSpan.FromSeconds(oliviaConfig.DelayWppFlowsGS));
                            await this.whatsappService.SendMessage(sesion, errorCode);
                            await this.sesionService.UpdateSesion(sesion);
                        });
                    }

                    await this.flowService.UpdateFlow(sesion.ActiveFlow!);
                    await this.sesionService.UpdateSesion(sesion);
                }
                response.Mensaje = string.IsNullOrEmpty(response.Mensaje) ? string.Empty : this.messagesService.GetMessageByKey(response.Mensaje).Value;
                return response;
            }
            catch (Exception ex)
            {
                Log.Error("", ex);
                response.Success = false;
                response.EnviarGenesys = true;
                response.Expired = true;
                response.Mensaje = "WPP-FLOW_ERROR_EX";
                _ = Task.Run(async () =>
                {
                    await Task.Delay(TimeSpan.FromSeconds(oliviaConfig.DelayWppFlowsGS));
                    if (sesion is not null)
                    {
                        await this.SendFinalMessage(sesion, response.Mensaje, false);
                        await this.sesionService.UpdateSesion(sesion);
                    }
                    else
                    {
                        string mensaje = this.messagesService.GetMessageByKey(response.Mensaje).Value;
                        await this.whatsAppRepository.SendMessage(request.Usuario, mensaje);
                    }
                });
                return response;
            }
        }
        private async Task SendFinalMessage(SesionEntity sesion, string message, bool isSuccess, params string[] args)
        {
            if (args.Length == 0)
                await this.whatsappService.SendMessage(sesion, message);
            else
                await this.whatsappService.SendMessage(sesion, message, "olivia", args);
            if (isSuccess)
            {
                await this.whatsappService.SendButton(sesion, "MENSAJE-ENCUESTA-INICIO");
                await this.encuestaService.CreateEncuesta(sesion);
                //AGREGAR TTL DE ENCUESTA
                sesion.Estado = EstadoSesion.ENCUESTA;
                sesion.ActiveFlow!.State = "COMPLETADO";
                sesion.ActiveFlow.CurrentStep = "";
                sesion.ActiveFlow.DetailsStep = "";
            }
            else
            {
                sesion.Estado = EstadoSesion.AGENTE;
                sesion.AgenteDate = DateTime.Now;
                sesion.ActiveFlow!.State = "ERROR";
                sesion.ActiveFlow.DetailsStep = "API";
                sesion.ActiveFlow.CurrentStep = "FINAL";
            }
            sesion.ActiveFlow.FinishDate = DateTime.Now;
        }

        public async Task<WppFlowResponse> ProcessAperturaCuentaNoClienteWppFlow(WppFlowRequest request)
        {
            return await this.ProcessAperturaCuentaFlow(request, TopicoAperturaNoCliente, this.ProcesarPantallaAperturaNoCliente);
        }

        public async Task<WppFlowResponse> ProcessAperturaCuentaYaClienteConBMWppFlow(WppFlowRequest request)
        {
            return await this.ProcessAperturaCuentaFlow(request, TopicoAperturaYaClienteConBM, this.ProcesarPantallaAperturaYaClienteConBM);
        }

        public async Task<WppFlowResponse> ProcessAperturaCuentaYaClienteSinBMWppFlow(WppFlowRequest request)
        {
            return await this.ProcessAperturaCuentaFlow(request, TopicoAperturaYaClienteSinBM, this.ProcesarPantallaAperturaYaClienteSinBM);
        }

        // Esqueleto comun a los 3 escenarios de apertura de cuenta (gate de sesion/topico + try-catch), igual patron que ProcessRekognitionWppFlow.
        private async Task<WppFlowResponse> ProcessAperturaCuentaFlow(WppFlowRequest request, string topicoEsperado, Func<SesionEntity, WppFlowRequest, Task<WppFlowResponse>> procesarPantalla)
        {
            WppFlowResponse response = new();
            SesionEntity? sesion = await this.sesionService.GetSesion(request.SesionId);
            try
            {
                if (sesion is null || !(sesion.Estado.CompareTo(EstadoSesion.CON_TOPICO) == 0 && sesion.Topic == "MOVIMIENTOS"))
                {
                    response.Mensaje = sesion is null ? "WPP-FLOW_EXPIRADO" : "WPP-FLOW_ERROR_TOPIC";
                    response.Expired = true;
                    response.Success = false;
                    response.EnviarGenesys = false;
                }
                else
                {
                    response = await procesarPantalla(sesion, request);
                    await this.sesionService.UpdateSesion(sesion);
                }
                response.Mensaje = string.IsNullOrEmpty(response.Mensaje) ? string.Empty : this.messagesService.GetMessageByKey(response.Mensaje).Value;
                return response;
            }
            catch (Exception ex)
            {
                Log.Error("", ex);
                response.Success = false;
                response.EnviarGenesys = true;
                response.Expired = true;
                response.Mensaje = this.messagesService.GetMessageByKey("WPP-FLOW_ERROR_EX").Value;
                return response;
            }
        }

        // Escenario #1 (Flow mas completo, 19 pantallas): persona que NO es cliente aun.
        private async Task<WppFlowResponse> ProcesarPantallaAperturaNoCliente(SesionEntity sesion, WppFlowRequest request)
        {
            WppFlowResponse response = new() { Success = true };
            switch (request.Flow)
            {
                case "APC_DATOS_CI":
                    WppFlowIdcCliente datosCi = JsonSerializer.Deserialize<WppFlowIdcCliente>(request.Data!)!;
                    // MOCK Core Bancario: si el carnet ya pertenece a un cliente, este Flow (persona que NO es cliente) no aplica.
                    CoreBancarioClienteResponse? clienteExistente = await this.coreBancarioService.ConsultarCliente(datosCi.Carnet, datosCi.Complemento);
                    if (clienteExistente is not null)
                    {
                        response.Success = false;
                        response.Mensaje = "WPP-FLOW_APERTURA_YA_ES_CLIENTE";
                    }
                    else
                    {
                        UpsertMetadataFlow(sesion, "IDC", datosCi.Carnet);
                    }
                    break;
                case "APC_SELFIE":
                    // MOCK: valida prueba de vida/selfie, pendiente de integracion real de biometria.
                    WppFlowSelfi selfie = JsonSerializer.Deserialize<WppFlowSelfi>(request.Data!)!;
                    response.Success = !string.IsNullOrWhiteSpace(selfie.Base64);
                    response.Mensaje = response.Success ? string.Empty : "WPP-FLOW_REKOGNITION-ERROR";
                    break;
                case "APC_DOCUMENTO_ID":
                    // MOCK: valida OCR/legibilidad del Documento de identidad, pendiente de integracion real.
                    WppFlowDocumentoId documento = JsonSerializer.Deserialize<WppFlowDocumentoId>(request.Data!)!;
                    response.Success = !string.IsNullOrWhiteSpace(documento.Base64);
                    break;
                case "APC_CONTACTO_CORREO":
                    WppFlowContactoCorreo correo = JsonSerializer.Deserialize<WppFlowContactoCorreo>(request.Data!)!;
                    UpsertMetadataFlow(sesion, "EMAIL", correo.Correo);
                    break;
                case "APC_OTP_CORREO":
                    WppFlowOtpCorreo otp = JsonSerializer.Deserialize<WppFlowOtpCorreo>(request.Data!)!;
                    string correoDestino = sesion.Metadata.FirstOrDefault(item => item.Clave == "EMAIL")?.Valor ?? string.Empty;
                    // MOCK: valida el OTP enviado por correo, pendiente de integracion real.
                    response.Success = await this.coreBancarioService.ValidarOtp(correoDestino, otp.Otp);
                    response.Mensaje = response.Success ? string.Empty : "WPP-FLOW_APERTURA_OTP_INVALIDO";
                    break;
                case "APC_CLAVE_BM":
                    WppFlowClaveBm claveBm = JsonSerializer.Deserialize<WppFlowClaveBm>(request.Data!)!;
                    if (claveBm.ClaveBm != claveBm.ConfirmarClaveBm)
                    {
                        response.Success = false;
                        response.Mensaje = "WPP-FLOW_APERTURA_CLAVES_NO_COINCIDEN";
                    }
                    else
                    {
                        UpsertMetadataFlow(sesion, "CLAVE_BM", claveBm.ClaveBm);
                    }
                    break;
                case "APC_USUARIO_BM":
                    WppFlowUsuarioBm usuarioBm = JsonSerializer.Deserialize<WppFlowUsuarioBm>(request.Data!)!;
                    string idcCreacion = sesion.Metadata.FirstOrDefault(item => item.Clave == "IDC")?.Valor ?? string.Empty;
                    string claveBmGuardada = sesion.Metadata.FirstOrDefault(item => item.Clave == "CLAVE_BM")?.Valor ?? string.Empty;
                    // MOCK: crea el usuario/clave de Banca Movil, pendiente de integracion real con Core Bancario.
                    response.Success = await this.coreBancarioService.CrearUsuarioBancaMovil(idcCreacion, usuarioBm.UsuarioBm, claveBmGuardada);
                    if (response.Success)
                    {
                        UpsertMetadataFlow(sesion, "USUARIO_BM", usuarioBm.UsuarioBm);
                    }
                    break;
                case "APC_RESUMEN":
                    string carnetFinal = sesion.Metadata.FirstOrDefault(item => item.Clave == "IDC")?.Valor ?? string.Empty;
                    string propositoFinal = sesion.Metadata.FirstOrDefault(item => item.Clave == "PROPOSITO_CUENTA")?.Valor ?? string.Empty;
                    // MOCK: crea la cuenta de ahorros (y emite tarjeta de debito) en Core Bancario, pendiente de integracion real.
                    response.Data = await this.coreBancarioService.CrearCuenta(carnetFinal, propositoFinal);
                    break;
                case "APC_VERIFICACION_WEBVIEW":
                    WppFlowPropositoCuenta proposito = JsonSerializer.Deserialize<WppFlowPropositoCuenta>(request.Data!)!;
                    UpsertMetadataFlow(sesion, "PROPOSITO_CUENTA", proposito.PropositoCuenta);
                    break;
                default:
                    // Pantallas de solo consentimiento/datos informativos (consentimientos, seguro, referencia, PEP/FATCA,
                    // estado civil, conyuge, situacion laboral): no requieren validacion de Core Bancario en esta Fase 1.
                    break;
            }
            return response;
        }

        // Escenario #2 (Flow mas corto, 6 pantallas): persona que ya es cliente y ya tiene Banca Movil.
        private async Task<WppFlowResponse> ProcesarPantallaAperturaYaClienteConBM(SesionEntity sesion, WppFlowRequest request)
        {
            WppFlowResponse response = new() { Success = true };
            switch (request.Flow)
            {
                case "ACBM_DATOS_CI":
                    WppFlowIdcCliente datosCi = JsonSerializer.Deserialize<WppFlowIdcCliente>(request.Data!)!;
                    // MOCK Core Bancario: en este Flow la persona afirma ya ser cliente, debe existir en el mock.
                    CoreBancarioClienteResponse? cliente = await this.coreBancarioService.ConsultarCliente(datosCi.Carnet, datosCi.Complemento);
                    if (cliente is null)
                    {
                        response.Success = false;
                        response.Mensaje = "WPP-FLOW_APERTURA_CLIENTE_NO_ENCONTRADO";
                    }
                    else
                    {
                        UpsertMetadataFlow(sesion, "IDC", datosCi.Carnet);
                        UpsertMetadataFlow(sesion, "CIC", cliente.Cic);
                    }
                    break;
                case "ACBM_SELFIE":
                    // MOCK: valida prueba de vida/selfie, pendiente de integracion real de biometria.
                    WppFlowSelfi selfie = JsonSerializer.Deserialize<WppFlowSelfi>(request.Data!)!;
                    response.Success = !string.IsNullOrWhiteSpace(selfie.Base64);
                    response.Mensaje = response.Success ? string.Empty : "WPP-FLOW_REKOGNITION-ERROR";
                    break;
                case "ACBM_DOCUMENTO_ID":
                    // MOCK: valida OCR/legibilidad del Documento de identidad, pendiente de integracion real.
                    WppFlowDocumentoId documento = JsonSerializer.Deserialize<WppFlowDocumentoId>(request.Data!)!;
                    response.Success = !string.IsNullOrWhiteSpace(documento.Base64);
                    break;
                case "ACBM_VALIDAR_CLAVE":
                    WppFlowValidarClaveBm validarClave = JsonSerializer.Deserialize<WppFlowValidarClaveBm>(request.Data!)!;
                    string cicValidacion = sesion.Metadata.FirstOrDefault(item => item.Clave == "CIC")?.Valor ?? string.Empty;
                    // MOCK: valida la clave de Banca Movil ya existente, pendiente de integracion real con Core Bancario.
                    response.Success = await this.coreBancarioService.ValidarClaveBancaMovil(cicValidacion, validarClave.ClaveBm);
                    response.Mensaje = response.Success ? string.Empty : "WPP-FLOW_APERTURA_CLAVE_INVALIDA";
                    break;
                default:
                    // ACBM_VERIFICACION_WEBVIEW (informativa) y ACBM_RESUMEN (cierre, sin llamada adicional).
                    break;
            }
            return response;
        }

        // Escenario #3 (Flow intermedio, 10 pantallas): persona que ya es cliente pero nunca creo Banca Movil.
        private async Task<WppFlowResponse> ProcesarPantallaAperturaYaClienteSinBM(SesionEntity sesion, WppFlowRequest request)
        {
            WppFlowResponse response = new() { Success = true };
            switch (request.Flow)
            {
                case "ACSBM_DATOS_CI":
                    WppFlowIdcCliente datosCi = JsonSerializer.Deserialize<WppFlowIdcCliente>(request.Data!)!;
                    // MOCK Core Bancario: en este Flow la persona afirma ya ser cliente, debe existir en el mock.
                    CoreBancarioClienteResponse? cliente = await this.coreBancarioService.ConsultarCliente(datosCi.Carnet, datosCi.Complemento);
                    if (cliente is null)
                    {
                        response.Success = false;
                        response.Mensaje = "WPP-FLOW_APERTURA_CLIENTE_NO_ENCONTRADO";
                    }
                    else
                    {
                        UpsertMetadataFlow(sesion, "IDC", datosCi.Carnet);
                        UpsertMetadataFlow(sesion, "CIC", cliente.Cic);
                    }
                    break;
                case "ACSBM_SELFIE":
                    // MOCK: valida prueba de vida/selfie, pendiente de integracion real de biometria.
                    WppFlowSelfi selfie = JsonSerializer.Deserialize<WppFlowSelfi>(request.Data!)!;
                    response.Success = !string.IsNullOrWhiteSpace(selfie.Base64);
                    response.Mensaje = response.Success ? string.Empty : "WPP-FLOW_REKOGNITION-ERROR";
                    break;
                case "ACSBM_DOCUMENTO_ID":
                    // MOCK: valida OCR/legibilidad del Documento de identidad, pendiente de integracion real.
                    WppFlowDocumentoId documento = JsonSerializer.Deserialize<WppFlowDocumentoId>(request.Data!)!;
                    response.Success = !string.IsNullOrWhiteSpace(documento.Base64);
                    break;
                case "ACSBM_CUENTAS":
                    string cicCuentas = sesion.Metadata.FirstOrDefault(item => item.Clave == "CIC")?.Valor ?? string.Empty;
                    // MOCK: consulta las cuentas de ahorro ya existentes del cliente, pendiente de integracion real.
                    response.Data = await this.coreBancarioService.ConsultarCuentas(cicCuentas);
                    break;
                case "ACSBM_USUARIO_BM":
                    WppFlowUsuarioBm usuarioBm = JsonSerializer.Deserialize<WppFlowUsuarioBm>(request.Data!)!;
                    UpsertMetadataFlow(sesion, "USUARIO_BM", usuarioBm.UsuarioBm);
                    break;
                case "ACSBM_CLAVE_BM":
                    WppFlowClaveBm claveBm = JsonSerializer.Deserialize<WppFlowClaveBm>(request.Data!)!;
                    if (claveBm.ClaveBm != claveBm.ConfirmarClaveBm)
                    {
                        response.Success = false;
                        response.Mensaje = "WPP-FLOW_APERTURA_CLAVES_NO_COINCIDEN";
                    }
                    else
                    {
                        string cicCreacion = sesion.Metadata.FirstOrDefault(item => item.Clave == "CIC")?.Valor ?? string.Empty;
                        string usuarioBmGuardado = sesion.Metadata.FirstOrDefault(item => item.Clave == "USUARIO_BM")?.Valor ?? string.Empty;
                        // MOCK: crea el usuario/clave de Banca Movil, pendiente de integracion real con Core Bancario.
                        response.Success = await this.coreBancarioService.CrearUsuarioBancaMovil(cicCreacion, usuarioBmGuardado, claveBm.ClaveBm);
                    }
                    break;
                case "ACSBM_CONTACTO_CORREO":
                    WppFlowContactoCorreo correo = JsonSerializer.Deserialize<WppFlowContactoCorreo>(request.Data!)!;
                    UpsertMetadataFlow(sesion, "EMAIL", correo.Correo);
                    break;
                case "ACSBM_OTP_CORREO":
                    WppFlowOtpCorreo otp = JsonSerializer.Deserialize<WppFlowOtpCorreo>(request.Data!)!;
                    string correoDestino = sesion.Metadata.FirstOrDefault(item => item.Clave == "EMAIL")?.Valor ?? string.Empty;
                    // MOCK: valida el OTP enviado por correo, pendiente de integracion real.
                    response.Success = await this.coreBancarioService.ValidarOtp(correoDestino, otp.Otp);
                    response.Mensaje = response.Success ? string.Empty : "WPP-FLOW_APERTURA_OTP_INVALIDO";
                    break;
                default:
                    // ACSBM_VERIFICACION_WEBVIEW (informativa) y ACSBM_RESUMEN (cierre, sin llamada adicional).
                    break;
            }
            return response;
        }

        private static void UpsertMetadataFlow(SesionEntity sesion, string clave, string valor)
        {
            Metadata? metadata = sesion.Metadata.FirstOrDefault(item => item.Clave == clave);
            if (metadata is null)
            {
                sesion.Metadata.Add(new Metadata { Clave = clave, Valor = valor, Estado = "COMPLETO" });
            }
            else
            {
                metadata.Valor = valor;
                metadata.Estado = "COMPLETO";
            }
        }

        public Task<WppFlowResponse> ProcessValidacionClienteWppFlow(WppFlowRequest request)
        {
            throw new NotImplementedException();
        }

        // ===== Plan Maestro v3, seccion 7.9.5: Consulta de saldos y movimientos (2 Flows nativos separados) =====

        public async Task<WppFlowResponse> ProcessValidacionIdentidadWppFlow(WppFlowRequest request)
        {
            return await this.ProcessAperturaCuentaFlow(request, TopicoValidacionIdentidad, this.ProcesarPantallaValidacionIdentidad);
        }

        public async Task<WppFlowResponse> ProcessConsultaMovimientosWppFlow(WppFlowRequest request)
        {
            return await this.ProcessAperturaCuentaFlow(request, TopicoConsultaMovimientos, this.ProcesarPantallaConsultaMovimientos);
        }

        // Helpers de gating (Plan Maestro v3, seccion 7.2/7.3). Reutilizables por la capa de ruteo NLP (FlowService)
        // cuando se implemente el envio del CTA inicial de este Flow (fuera del alcance de esta implementacion).
        private async Task<bool> EstaRegistradoWhatsapp(string celular)
        {
            RegistroPruebaVidaEntity? registro = await this.registroPruebaVidaRepository.GetByCelularAsync(celular);
            return registro is not null && registro.Registrado;
        }

        private static bool EstaAutenticado(SesionEntity sesion) => sesion.Autenticado;

        private static bool DebePedirClaveBm(string tipoCliente, bool estaAutenticado) => tipoCliente == TipoClienteYaClienteConBM && !estaAutenticado;

        // Flow 1 (CSM_DATOS_CI -> CSM_SELFIE -> CSM_DOCUMENTO_ID -> CSM_LOGIN_CLAVE), dividido en 2 Flows nativos separados
        // porque WhatsApp/Gupshup no permite 2 pantallas de entrada para un mismo flow_id: "FlowValidacionIdentidad"
        // (consulta_saldos_validacion_identidad.json, fila 10a: nunca registrado) y "FlowValidacionIdentidadClave"
        // (consulta_saldos_validacion_clave.json, fila 10: ya registrado/autenticado, solo pantalla CSM_LOGIN_CLAVE).
        // Este endpoint es unico para ambos Flows: wpp-distributor siempre reenvia por pantalla (request.Flow), nunca por nombre de Flow.
        private async Task<WppFlowResponse> ProcesarPantallaValidacionIdentidad(SesionEntity sesion, WppFlowRequest request)
        {
            WppFlowResponse response = new() { Success = true };
            switch (request.Flow)
            {
                case "CSM_DATOS_CI":
                    WppFlowIdcClienteCelular datosCi = JsonSerializer.Deserialize<WppFlowIdcClienteCelular>(request.Data!)!;
                    // MOCK Core Bancario: este Flow asume que la persona ya es cliente con Banca Movil (fila 10a: nunca registrada en WhatsApp).
                    CoreBancarioClienteResponse? cliente = await this.coreBancarioService.ConsultarCliente(datosCi.Carnet, datosCi.Complemento);
                    if (cliente is null)
                    {
                        response.Success = false;
                        response.Mensaje = "WPP-FLOW_SALDOS_CLIENTE_NO_ENCONTRADO";
                    }
                    else
                    {
                        UpsertMetadataFlow(sesion, "IDC", datosCi.Carnet);
                        UpsertMetadataFlow(sesion, "COMPLEMENTO", datosCi.Complemento);
                        UpsertMetadataFlow(sesion, "CIC", cliente.Cic);
                        UpsertMetadataFlow(sesion, "EMAIL", cliente.Correo);
                    }
                    break;
                case "CSM_SELFIE":
                    // MOCK: valida prueba de vida/selfie, pendiente de integracion real de biometria.
                    WppFlowSelfi selfie = JsonSerializer.Deserialize<WppFlowSelfi>(request.Data!)!;
                    response.Success = !string.IsNullOrWhiteSpace(selfie.Base64);
                    response.Mensaje = response.Success ? string.Empty : "WPP-FLOW_REKOGNITION-ERROR";
                    break;
                case "CSM_DOCUMENTO_ID":
                    // MOCK: valida OCR/legibilidad del Documento de identidad, pendiente de integracion real.
                    WppFlowDocumentoId documento = JsonSerializer.Deserialize<WppFlowDocumentoId>(request.Data!)!;
                    response.Success = !string.IsNullOrWhiteSpace(documento.Base64);
                    break;
                case "CSM_LOGIN_CLAVE":
                    WppFlowValidarClaveBm claveBm = JsonSerializer.Deserialize<WppFlowValidarClaveBm>(request.Data!)!;
                    string idc = sesion.Metadata.FirstOrDefault(item => item.Clave == "IDC")?.Valor ?? string.Empty;
                    string complemento = sesion.Metadata.FirstOrDefault(item => item.Clave == "COMPLEMENTO")?.Valor ?? "00";
                    string cic = sesion.Metadata.FirstOrDefault(item => item.Clave == "CIC")?.Valor ?? string.Empty;
                    string correo = sesion.Metadata.FirstOrDefault(item => item.Clave == "EMAIL")?.Valor ?? string.Empty;
                    if (string.IsNullOrEmpty(cic))
                    {
                        // Fila 10 (entrada directa en CSM_LOGIN_CLAVE, sin pasar por CSM_DATOS_CI): recupera IDC/CIC/correo
                        // desde el registro persistente WPP_REGISTRO_PRUEBA_VIDA (celular = numero de WhatsApp de la sesion).
                        RegistroPruebaVidaEntity? registro = await this.registroPruebaVidaRepository.GetByCelularAsync(sesion.Usuario);
                        idc = registro?.Idc ?? string.Empty;
                        complemento = registro?.Complemento ?? "00";
                        CoreBancarioClienteResponse? clienteRegistrado = string.IsNullOrEmpty(idc) ? null : await this.coreBancarioService.ConsultarCliente(idc, complemento);
                        cic = clienteRegistrado?.Cic ?? string.Empty;
                        correo = clienteRegistrado?.Correo ?? string.Empty;
                        UpsertMetadataFlow(sesion, "IDC", idc);
                        UpsertMetadataFlow(sesion, "COMPLEMENTO", complemento);
                        UpsertMetadataFlow(sesion, "CIC", cic);
                        UpsertMetadataFlow(sesion, "EMAIL", correo);
                    }

                    if (string.IsNullOrEmpty(cic))
                    {
                        response.Success = false;
                        response.Mensaje = "WPP-FLOW_SALDOS_CLIENTE_NO_ENCONTRADO";
                        break;
                    }

                    // MOCK: valida la clave de Banca Movil existente, pendiente de integracion real con Core Bancario (DebePedirClaveBm=true, fila 10/10a).
                    response.Success = await this.coreBancarioService.ValidarClaveBancaMovil(cic, claveBm.ClaveBm);
                    if (!response.Success)
                    {
                        response.Mensaje = "WPP-FLOW_SALDOS_CLAVE_INVALIDA";
                        break;
                    }

                    sesion.Autenticado = true;
                    sesion.FechaAutenticacion = DateTime.Now;
                    await this.registroPruebaVidaRepository.InsertUpdateAsync(new RegistroPruebaVidaUpsertRequest
                    {
                        Idc = idc,
                        Complemento = complemento,
                        Celular = sesion.Usuario,
                        IdCliente = cic,
                        Registrado = true,
                        WppSesionId = sesion._id.ToString(),
                    });

                    // Flow 1 completado: no hay encadenamiento nativo entre Flows de WhatsApp, se envia un mensaje nuevo con el CTA del Flow 2.
                    sesion.Topic = TopicoConsultaMovimientos;
                    await this.whatsappService.SendMessageFlow(sesion, "WPP-FLOW_SALDOS_CTA_MOVIMIENTOS", "FlowConsultaMovimientos");
                    if (!string.IsNullOrEmpty(correo))
                    {
                        // MOCK/SUPUESTO: genera el OTP que se valida en la primera pantalla (CSM_OTP_CORREO) del Flow 2.
                        // Pendiente confirmar con Negocio/Genesys el disparador exacto de OtpGenerarGenesys para este flujo.
                        await this.genesysService.OtpGenerar("", sesion.Usuario, idc, correo);
                    }
                    break;
                default:
                    break;
            }
            return response;
        }

        // Flow 2 ("FlowConsultaMovimientos", consulta_saldos_movimientos.json): CSM_OTP_CORREO -> CSM_ELEGIR_CUENTA -> CSM_DETALLE_SALDO
        // -> (CSM_ELEGIR_MOVIMIENTO -> CSM_DETALLE_MOVIMIENTO | CSM_COMPARTIR_DATOS). Enviado como mensaje nuevo recien al completarse
        // exitosamente el Flow 1 (ver ProcesarPantallaValidacionIdentidadSaldos); reutiliza IDC/CIC/EMAIL ya guardados en la
        // metadata de la misma sesion (el topico cambia, pero la sesion/documento Mongo es la misma).
        private async Task<WppFlowResponse> ProcesarPantallaConsultaMovimientos(SesionEntity sesion, WppFlowRequest request)
        {
            WppFlowResponse response = new() { Success = true };
            string cic = sesion.Metadata.FirstOrDefault(item => item.Clave == "CIC")?.Valor ?? string.Empty;
            switch (request.Flow)
            {
                case "CSM_OTP_CORREO":
                    WppFlowOtpCorreo otp = JsonSerializer.Deserialize<WppFlowOtpCorreo>(request.Data!)!;
                    string idc = sesion.Metadata.FirstOrDefault(item => item.Clave == "IDC")?.Valor ?? string.Empty;
                    response.Success = await this.genesysService.OtpValidar("", idc, otp.Otp);
                    response.Mensaje = response.Success ? string.Empty : "WPP-FLOW_SALDOS_OTP_INVALIDO";
                    break;
                case "CSM_ELEGIR_CUENTA":
                    WppFlowCuentaSeleccionada cuentaSeleccionada = JsonSerializer.Deserialize<WppFlowCuentaSeleccionada>(request.Data!)!;
                    UpsertMetadataFlow(sesion, "CUENTA", cuentaSeleccionada.CuentaReferencial);
                    response.Data = await this.genesysService.GetSaldo("", cic, cuentaSeleccionada.CuentaReferencial);
                    break;
                case "CSM_DETALLE_SALDO":
                    // Pantalla de bifurcacion (ver movimientos vs. compartir datos): sin llamada adicional, el ruteo lo decide el routing_model del Flow JSON.
                    break;
                case "CSM_ELEGIR_MOVIMIENTO":
                    string cuentaMovimientos = sesion.Metadata.FirstOrDefault(item => item.Clave == "CUENTA")?.Valor ?? string.Empty;
                    response.Data = await this.genesysService.GetMovimientos("", cic, cuentaMovimientos);
                    break;
                case "CSM_DETALLE_MOVIMIENTO":
                case "CSM_COMPARTIR_DATOS":
                    // Pantallas de cierre (accion "complete" en el Flow JSON): sin llamada adicional.
                    break;
                default:
                    break;
            }
            return response;
        }
    }
}
