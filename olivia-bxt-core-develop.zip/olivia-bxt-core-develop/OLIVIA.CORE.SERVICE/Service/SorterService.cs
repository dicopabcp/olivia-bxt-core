using Microsoft.Extensions.Configuration;
using OLIVIA.CORE.MODEL;
using OLIVIA.CORE.MODEL.CONFIG;
using OLIVIA.CORE.REPOSITORY;

namespace OLIVIA.CORE.SERVICE
{
    public class SorterService : ISorterService
    {
        private readonly ISorterRepository sorterRepository;
        private readonly IFlowService flowService;
        private readonly IWhatsappService whatsappService;
        private readonly List<string> flujoAgente;
        private readonly List<ConfigMessages> listConfigMessages;

        public SorterService(ISorterRepository sorterRepository, IWhatsappService whatsappService, IConfiguration configuration, IFlowService flowService)
        {
            this.sorterRepository = sorterRepository;
            this.flowService = flowService;
            this.whatsappService = whatsappService;
            this.listConfigMessages = new();
            configuration.GetSection("NombresFlujos").Bind(this.listConfigMessages);
            this.flujoAgente = new List<string>() { "ESTADO","CONSULTA SALDO", "EXTRAVIO", "EXTERIOR", "INTERNET", "DESVINCULACION", "DESBLOQUEO", "OLVIDO USUARIO", "SALDO", "MOVIMIENTOS", "OLVIDO CUENTA", "COMPRAS X INTERNET", "COMPRAS EXTERIOR", "BLOQUEO TARJETA", "DESBLOQUEO TOKEN", "SINCRONIZACION TOKEN" };
        }

        public async Task<string?> RequestToSorterBxT(SesionEntity sesion)
        {
            string text = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message;
            string res = "";
            sesion.ActiveFlow = new Flow();
            sesion.ActiveFlow.CreateDate = DateTime.Now;
            sesion.ActiveFlow.State = "EN PROGRESO";
            if (text.Contains("listo", StringComparison.OrdinalIgnoreCase))
            {
                res = "DEFLEXION";
                sesion.ActiveFlow.State = "COMPLETADO";
            }
            else
            {
                res = await this.sorterRepository.RequestToSorterBxT(text);
            }
            await this.MensjaeInicioFlujo(sesion, res);
            sesion.ActiveFlow.Topic = res;
            await this.flowService.CreateFlow(sesion);
            await this.sorterRepository.SaveReport(text, res, "", sesion._id.ToString());
            return res;
        }

        public async Task RequestToSorterBxT(SesionEntity sesion, string res)
        {
            string text = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message;
            sesion.ActiveFlow = new Flow
            {
                CreateDate = DateTime.Now,
                State = "EN PROGRESO"
            };
            await this.MensjaeInicioFlujo(sesion, res);
            sesion.ActiveFlow.Topic = res;
            await this.flowService.CreateFlow(sesion);
            await this.sorterRepository.SaveReport(text, res, "", sesion._id.ToString());
        }

        private async Task MensjaeInicioFlujo(SesionEntity sesion, string label)
        {
            if (this.flujoAgente.Contains(label))
                await this.whatsappService.SendMessage(sesion, "MENSAJE-INICIO-FLUJO", rol: "olivia", arg: [ConvertFlow(label)]);
        }

        private string ConvertFlow(string flow)
        {
            ConfigMessages? configMessages = this.listConfigMessages.FirstOrDefault(item => item.Key.CompareTo(flow) == 0);
            return configMessages is null ? flow : configMessages.Value;
        }

    }
}
