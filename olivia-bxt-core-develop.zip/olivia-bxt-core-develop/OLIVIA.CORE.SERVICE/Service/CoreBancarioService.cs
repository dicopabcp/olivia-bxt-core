using OLIVIA.CORE.MODEL.DTO.CoreBancario;
using OLIVIA.CORE.REPOSITORY;

namespace OLIVIA.CORE.SERVICES
{
    public class CoreBancarioService : ICoreBancarioService
    {
        private readonly ICoreBancarioRepository coreBancarioRepository;

        public CoreBancarioService(ICoreBancarioRepository coreBancarioRepository)
        {
            this.coreBancarioRepository = coreBancarioRepository;
        }

        public Task<CoreBancarioClienteResponse?> ConsultarCliente(string carnet, string complemento)
        {
            return this.coreBancarioRepository.ConsultarCliente(carnet, complemento);
        }

        public Task<bool> ValidarOtp(string destino, string codigo)
        {
            return this.coreBancarioRepository.ValidarOtp(destino, codigo);
        }

        public Task<List<CoreBancarioCuentaResponse>> ConsultarCuentas(string cic)
        {
            return this.coreBancarioRepository.ConsultarCuentas(cic);
        }

        public Task<bool> ValidarClaveBancaMovil(string cic, string clave)
        {
            return this.coreBancarioRepository.ValidarClaveBancaMovil(cic, clave);
        }

        public Task<bool> CrearUsuarioBancaMovil(string cic, string usuarioBm, string claveBm)
        {
            return this.coreBancarioRepository.CrearUsuarioBancaMovil(cic, usuarioBm, claveBm);
        }

        public Task<CoreBancarioCrearCuentaResponse> CrearCuenta(string carnet, string propositoCuenta)
        {
            return this.coreBancarioRepository.CrearCuenta(carnet, propositoCuenta);
        }
    }
}
