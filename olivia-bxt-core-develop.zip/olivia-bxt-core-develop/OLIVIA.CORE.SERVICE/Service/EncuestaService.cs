using Microsoft.Extensions.Configuration;
using OLIVIA.CORE.MODEL;
using OLIVIA.CORE.MODEL.CONST;
using OLIVIA.CORE.MODELS.CONFIG;
using OLIVIA.CORE.REPOSITORY;

namespace OLIVIA.CORE.SERVICE
{

    public class EncuestaService : IEncuestaService
    {
        private readonly IWhatsappService whatsAppService;
        private readonly IEncuestaRepository encuestaRepository;
        private readonly ISesionService sesionService;
        private readonly int delayMultimensajesInicial;
        private readonly int delayMultimensajes;
        public EncuestaService(IConfiguration configuration, IWhatsappService whatsAppService, IEncuestaRepository encuestaRepository, ISesionService sesionService)
        {
            this.whatsAppService = whatsAppService;
            this.encuestaRepository = encuestaRepository;
            this.sesionService = sesionService;
            OliviaConfig oliviaConfig = configuration.GetSection("OliviaConfig").Get<OliviaConfig>() ?? new OliviaConfig();
            this.delayMultimensajesInicial = oliviaConfig.DelayMultimensajesInicial;
            this.delayMultimensajes = oliviaConfig.DelayMultimensajes;
        }

        public async Task FlujoEncuesta(SesionEntity sesion)
        {
            switch (sesion.Encuesta!.Estado)
            {
                case EstadoEncuesta.ERROR:
                    break;
                case EstadoEncuesta.CREADA:
                    await this.FlowEncuestaCreada(sesion);
                    break;
                case EstadoEncuesta.RECHAZADA:
                    break;
                case EstadoEncuesta.ACTIVA:
                    await this.FlowEncuestaActiva(sesion);
                    break;
                case EstadoEncuesta.ESPERA_RESPUESTA_TEXTO:
                    await this.FlowEncuestaRespuestaEnEspera(sesion);
                    break;
                case EstadoEncuesta.CERRADA:
                    break;
                case EstadoEncuesta.COMPLETADA:
                    break;
                default:
                    break;
            }
            await this.UpdateEncuesta(sesion);

        }

        private async Task FlowEncuestaRespuestaEnEspera(SesionEntity sesion)
        {
            int contadorMultimensajeIni = 0;
            int contadorMultimensajeAct;
            int c = 0;
            int indice = sesion.Messages.Select((valor, index) => new { valor, index }).Last(item => item.valor.Role.Equals("user")).index;
            SesionEntity? sesionMM;
            bool repetir = true;
            while (repetir)
            {
                await Task.Delay(1000 * (c == 0 ? delayMultimensajesInicial : delayMultimensajes));
                sesionMM = await this.sesionService.ReadSesion(sesion.Usuario);
                if (sesionMM is null)
                {
                    repetir = false;
                }
                else
                {
                    contadorMultimensajeAct = sesionMM!.Multimensaje;

                    if (contadorMultimensajeIni != contadorMultimensajeAct)
                    {
                        string mensajeNuevo = string.Join("\n", sesionMM!.Messages.Where(item => item.Class.Equals("MULTIMENSAJE")).Select(item => item.Message));
                        sesion.Messages[indice].Message = mensajeNuevo;
                        contadorMultimensajeIni = contadorMultimensajeAct;
                        c++;
                    }
                    else
                    {
                        repetir = false;
                    }
                }
            }

            sesion.Encuesta!.Error = sesion.Messages[indice].Message;
            await this.CerraSesion(sesion);
        }

        private async Task FlowEncuestaCreada(SesionEntity sesion)
        {
            MessagesSesionEntity? message = sesion.Messages.LastOrDefault(x => x.Role == "user");
            switch (message!.Message)
            {
                case "SI":
                    await this.whatsAppService.SendMessage(sesion, "MENSAJE-ENCUESTA-PREGUNTA", "encuesta");
                    sesion.Encuesta!.Estado = EstadoEncuesta.ACTIVA;
                    sesion.Estado = EstadoSesion.ENCUESTA;
                    break;
                case "NO":
                    await this.whatsAppService.SendMessage(sesion, "MENSAJE-ENCUESTA-RECHAZO", "encuesta");
                    sesion.Encuesta!.Estado = EstadoEncuesta.RECHAZADA;
                    sesion.Estado = EstadoSesion.CERRADO;
                    break;
                default:
                    //CERRAR SESSION
                    sesion.Estado = EstadoSesion.CERRADO;
                    sesion.Encuesta!.Estado = EstadoEncuesta.ABANDONADO;
                    await this.encuestaRepository.Update(sesion);
                    await this.sesionService.UpdateSesion(sesion);
                    SesionEntity newSesion = await this.sesionService.CreateSesion(sesion.Usuario);
                    sesion.Estado = EstadoSesion.SIN_TOPICO;
                    sesion._id = newSesion._id;
                    break;
            }
        }

        private async Task FlowEncuestaActiva(SesionEntity sesion)
        {
            MessagesSesionEntity? message = sesion.Messages.LastOrDefault(x => x.Role == "user");

            if (int.TryParse(message!.Message, out int resultado))
            {
                sesion.Encuesta!.Respuesta = (resultado > 10) ? 10 : (resultado < 0) ? 0 : resultado;
                switch (sesion.Encuesta.Respuesta)
                {
                    case int n when (n >= 0 && n <= 5):
                        //RETRACTOR
                        sesion.Estado = EstadoSesion.ENCUESTA;
                        sesion.Encuesta.Estado = EstadoEncuesta.ESPERA_RESPUESTA_TEXTO;
                        await this.whatsAppService.SendMessage(sesion, "ENCUESTA-PREGUNA-1-A-3", "encuesta");
                        break;
                    case int n when (n >= 6 && n <= 8):
                        //INDIFERENTE
                        sesion.Estado = EstadoSesion.ENCUESTA;
                        sesion.Encuesta.Estado = EstadoEncuesta.ESPERA_RESPUESTA_TEXTO;
                        await this.whatsAppService.SendMessage(sesion, "ENCUESTA-PREGUNA-4-A-8", "encuesta");
                        break;
                    case int n when (n == 9 || n == 10):
                        //POSITIVO
                        await this.CerraSesion(sesion);
                        break;
                    default:
                        // Código para manejar valores fuera del rango permitido
                        break;
                }
            }
            else
            {
                sesion.Encuesta!.Estado = EstadoEncuesta.ERROR;
                sesion.Encuesta.Error = message.Message;
                sesion.Estado = EstadoSesion.CERRADO;
            }
        }

        private async Task CerraSesion(SesionEntity sesion)
        {
            sesion.Encuesta!.FinishDate = DateTime.Now;
            sesion.Encuesta.Estado = EstadoEncuesta.COMPLETADA;
            sesion.Estado = EstadoSesion.CERRADO;
            await this.whatsAppService.SendMessage(sesion, "MENSAJE-ENCUESTA-COMPLETA", "encuesta");
        }

        public async Task CreateEncuesta(SesionEntity sesion)
        {
            sesion.Encuesta = new Encuesta();
            sesion.Encuesta.Estado = EstadoEncuesta.CREADA;
            sesion.Encuesta.CreateDate = DateTime.Now;
            await this.encuestaRepository.Create(sesion);
        }
        public async Task UpdateEncuesta(SesionEntity sesion)
        {
            await this.encuestaRepository.Update(sesion);
        }

    }
}
