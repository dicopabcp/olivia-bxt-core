using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using Newtonsoft.Json;
using OLIVIA.CORE.MODEL;
using OLIVIA.CORE.MODEL.CONST;
using OLIVIA.CORE.MODEL.DTO.Genesys;
using OLIVIA.CORE.MODEL.DTO.Genesys.ACCL;
using OLIVIA.CORE.MODEL.DTO.WppFlows;
using OLIVIA.CORE.MODEL.UTILS;
using OLIVIA.CORE.MODELS.CONFIG;
using OLIVIA.CORE.SERVICES;
using System.Text.RegularExpressions;

namespace OLIVIA.CORE.SERVICE
{
    public class MetaDataService : IMetaDataService
    {
        private readonly IWhatsappService whatsappService;
        private readonly IGenesysService genesysService;
        private readonly OliviaConfig oliviaConfig;

        public MetaDataService(IWhatsappService whatsappService, IGenesysService genesysService, IConfiguration configuration)
        {
            this.whatsappService = whatsappService;
            this.genesysService = genesysService;
            this.oliviaConfig = new();
            configuration.GetSection("OliviaConfig").Bind(this.oliviaConfig);
        }


        public async Task<bool> SearchCarnet(SesionEntity sesion)
        {
            Metadata? metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("IDC") == 0);
            //REVISO SI ESTA ESTE CAMPO EN LA METADATA
            if (metadata == default)
            {
                //REVISO SI ME LLEGA EN EL MENSAJE
                await this.whatsappService.SendMessage(sesion, "CARNET-PREGUNTAR");
                CrearMetadata(sesion, "IDC");
                UpdateFlow(sesion, "IDC");
                return false;
            }

            if (metadata.Estado.CompareTo("COMPLETO") != 0)
            {
                //BUSCO EL PATRON
                string pattern = @"\b\d{5,8}\b";
                Regex regex = new(pattern);
                string lastMessage = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message;
                MatchCollection matches = regex.Matches(lastMessage);
                if (matches.Count == 0)
                {
                    //SI NO LO ENCUENTRO REVISO SI NO PASE LOS INTENTOS PERMITIDOS
                    if (metadata.Intentos <= 2)
                    {
                        //VUELVO A PEDIR EL DATO
                        await this.whatsappService.SendMessage(sesion, "CARNET-PREGUNTAR-NUEVAMENTE");
                        metadata.Intentos += 1;
                        NoValidFLow(sesion);
                        return false;
                    }
                    else
                    {
                        //LO MANDO A AGENTE
                        await this.whatsappService.SendMessage(sesion, "LIMITE-INTENTOS");
                        sesion.Estado = EstadoSesion.AGENTE;
                        sesion.AgenteDate = DateTime.Now;
                        metadata.Intentos += 1;
                        CloseFlowByIntent(sesion);
                        return false;
                    }
                }
                else
                {
                    //SI ENCONTRE EL PATRON
                    ClienteConsultaResponse? cliente = await this.genesysService.GetClienteConsulta("", matches[0].Value, "00");
                    if (cliente is null)
                    {
                        if (metadata.Intentos <= 2)
                        {
                            //VUELVO A PEDIR EL DATO
                            await this.whatsappService.SendMessage(sesion, "CARNET-ERROR-VALIDACION");
                            metadata.Intentos += 1;
                            NoExistFlow(sesion);
                            return false;
                        }
                        else
                        {
                            //LO MANDO A AGENTE
                            await this.whatsappService.SendMessage(sesion, "LIMITE-INTENTOS");
                            sesion.Estado = EstadoSesion.AGENTE;
                            sesion.AgenteDate = DateTime.Now;
                            metadata.Intentos += 1;
                            CloseFlowByIntent(sesion);
                            return false;
                        }
                    }
                    else
                    {
                        await this.whatsappService.SendMessage(sesion, "CARNET-CORRECTO");
                        CrearMetadata(sesion, "CIC", "COMPLETO", cliente.Cic);
                        CrearMetadata(sesion, "NOMBRE", "COMPLETO", cliente.Nombre);
                        CrearMetadata(sesion, "PATERNO", "COMPLETO", cliente.Paterno);
                        CrearMetadata(sesion, "CEL", "COMPLETO", cliente.Celular);
                        CrearMetadata(sesion, "EMAIL", "COMPLETO", cliente.Correo);
                        metadata.Estado = "COMPLETO";
                        metadata.Valor = matches[0].Value;
                        UpdateFlow(sesion);
                        return true;
                    }
                }
            }
            return true;
        }

        public async Task<bool> RekognitionFlow(SesionEntity sesion)
        {
            Metadata? metadataREK = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("REK") == 0);
            Metadata metadataIDC = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("IDC") == 0)!;
            Metadata metadataCEL = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CEL") == 0)!;
            //REVISO SI ESTA ESTE CAMPO EN LA METADATA
            if (metadataREK == default)
            {
                PruebaVidaGenerarResponse rekognitionSession = await this.genesysService.PruebaVidaGenerar("", metadataIDC!.Valor, metadataCEL!.Valor);
                await this.whatsappService.SendButton(sesion, "REKOGNITION-PREGUNTA", rol: "olivia", rekognitionSession.Url);
                CrearMetadata(sesion, "REK", valor: rekognitionSession.SessionId);
                UpdateFlow(sesion, "REKOGNITION");
                return false;
            }

            if (metadataREK.Estado.CompareTo("ESPERA") == 0)
            {
                if (metadataREK.Intentos < 2)
                {
                    string lastMessage = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message;
                    switch (lastMessage)
                    {
                        case "Ok":
                            bool rekognitioResult = await this.genesysService.PruebaVidaValidar("", metadataIDC!.Valor, metadataREK.Valor);
                            if (rekognitioResult)
                            {
                                await this.whatsappService.SendMessage(sesion, "REKOGNITION-CORRECTO");
                                sesion.ActiveFlow!.State = "EN PROGRESO";
                                metadataREK.Estado = "COMPLETO";
                                UpdateFlow(sesion);
                                return true;
                            }
                            else
                            {
                                await this.whatsappService.SendMessage(sesion, $"REKOGNITION-ERROR");
                                sesion.Estado = EstadoSesion.AGENTE;
                                sesion.AgenteDate = DateTime.Now;
                                CloseFlowByIntent(sesion);
                                return false;
                            }
                            break;
                        case "Validacion Fallida":
                            PruebaVidaGenerarResponse rekognitionSession = await this.genesysService.PruebaVidaGenerar("", metadataIDC!.Valor, metadataCEL!.Valor);
                            await this.whatsappService.SendButton(sesion, "REKOGNITION-PREGUNTAR-NUEVAMENTE", "olivia", rekognitionSession.Url);
                            metadataREK.Intentos += 1;
                            metadataREK.Valor = rekognitionSession.SessionId;
                            UpdateFlow(sesion, details: "VALIDACION FALLIDA", state: "ERROR");
                            return false;
                        default:
                            metadataREK.Intentos += 1;
                            await this.whatsappService.SendMessage(sesion, "REKOGNITION-RESPUESTA-DEFAULT");
                            UpdateFlow(sesion, details: "OPCION FUERA DE RANGO", state: "ERROR");
                            return false;
                    }
                }
                else
                {
                    //LO MANDO A AGENTE PORQUE EXEDIO LOS INTENTOS
                    await this.whatsappService.SendMessage(sesion, "LIMITE-INTENTOS");
                    sesion.Estado = EstadoSesion.AGENTE;
                    sesion.AgenteDate = DateTime.Now;
                    metadataREK.Intentos += 1;
                    CloseFlowByIntent(sesion);
                    return false;
                }
            }
            return true;
        }

        public async Task<bool> SearchOtp(SesionEntity sesion)
        {
            Metadata? metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("OTP") == 0);
            Metadata? metadataIDC = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("IDC") == 0);
            Metadata? metadataCEL = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CEL") == 0);
            Metadata? metadataMAIL = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("EMAIL") == 0);
            //REVISO SI ESTA ESTE CAMPO EN LA METADATA
            if (metadata == default)
            {
                int i = 0;
                while (i <= 2)
                {
                    bool otpCorrect = await this.genesysService.OtpGenerar("", metadataCEL!.Valor, metadataIDC!.Valor, metadataMAIL!.Valor);
                    if (otpCorrect)
                        break;
                    i++;
                }
                if (i >= 2)
                {
                    await this.whatsappService.SendMessage(sesion, "OTP-REINTENTOS");
                    sesion.Estado = EstadoSesion.AGENTE;
                    sesion.AgenteDate = DateTime.Now;
                    UpdateFlow(sesion, state: "ERROR", details: "NO GENERA", isComplete: true);
                    return false;
                }
                await this.whatsappService.SendMessage(sesion, "OTP-ENVIADO", "olivia", UtilsOlivia.ReemplazarCaracteres(metadataCEL!.Valor, 0, 5), UtilsOlivia.ReemplazarCaracteres(metadataMAIL!.Valor, 4, 8));
                CrearMetadata(sesion, "OTP");
                UpdateFlow(sesion, "OTP");
                return false;
            }

            if (metadata.Estado.CompareTo("ESPERA") == 0)
            {
                //BUSCO EL PATRON

                string pattern = @"\b\d{6}\b";
                Regex regex = new(pattern);
                string lastMessage = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message;
                MatchCollection matches = regex.Matches(lastMessage);
                if (matches.Count == 0)
                {
                    //SI NO LO ENCUENTRO REVISO SI NO PASE LOS INTENTOS PERMITIDOS
                    if (metadata.Intentos <= 2)
                    {
                        //VUELVO A PEDIR EL DATO
                        await this.whatsappService.SendMessage(sesion, "OTP-ENVIADO", "olivia", UtilsOlivia.ReemplazarCaracteres(metadataCEL!.Valor, 0, 5), UtilsOlivia.ReemplazarCaracteres(metadataMAIL!.Valor, 4, 8));
                        metadata.Intentos += 1;
                        NoValidFLow(sesion);
                        return false;
                    }
                    else
                    {
                        //LO MANDO A AGENTE
                        sesion.Estado = EstadoSesion.AGENTE;
                        sesion.AgenteDate = DateTime.Now;
                        metadata.Intentos += 1;
                        CloseFlowByIntent(sesion);
                        return false;
                    }
                }
                else
                {
                    //VALIDAR SI EL OTP ES VALIDO
                    bool validateOtp = await this.genesysService.OtpValidar("", metadataIDC!.Valor, matches[0].Value);
                    if (validateOtp)
                    {
                        metadata.Estado = "COMPLETO";
                        await this.whatsappService.SendMessage(sesion, "OTP-CORRECTO");
                        metadata.Valor = matches[0].Value;
                        UpdateFlow(sesion);
                        return true;
                    }
                    else
                    {
                        metadata.Intentos += 1;
                        if (metadata.Intentos > 3)
                        {
                            await this.whatsappService.SendMessage(sesion, "LIMITE-INTENTOS");
                            sesion.Estado = EstadoSesion.AGENTE;
                            sesion.AgenteDate = DateTime.Now;
                            CloseFlowByIntent(sesion);
                            return false;
                        }
                        int i = 0;
                        while (i <= 2)
                        {
                            bool otpCorrect = await this.genesysService.OtpGenerar("", metadataCEL!.Valor, metadataIDC!.Valor, metadataMAIL!.Valor);
                            if (otpCorrect)
                                break;
                            i++;
                        }
                        if (i >= 2)
                        {
                            await this.whatsappService.SendMessage(sesion, "OTP-REINTENTOS");
                            sesion.Estado = EstadoSesion.AGENTE;
                            sesion.AgenteDate = DateTime.Now;
                            UpdateFlow(sesion, state: "ERROR", details: "LA API NO GENERA OTP", isComplete: true);
                            return false;
                        }
                        await this.whatsappService.SendMessage(sesion, "OTP-ENVIADO", "olivia", UtilsOlivia.ReemplazarCaracteres(metadataCEL!.Valor, 0, 5), UtilsOlivia.ReemplazarCaracteres(metadataMAIL!.Valor, 4, 8));
                        CrearMetadata(sesion, "OTP");
                        UpdateFlow(sesion);
                        return false;
                    }
                }
            }
            return true;
        }

        public async Task<bool> SearchTarjeta(SesionEntity sesion)
        {
            Metadata? metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("TAR") == 0);
            //REVISO SI ESTA ESTE CAMPO EN LA METADATA
            if (metadata == default)
            {
                //REVISO SI ME LLEGA EN EL MENSAJE
                await this.whatsappService.SendMessage(sesion, "TARJETA-PREGUNTA");
                CrearMetadata(sesion, "TAR");
                UpdateFlow(sesion, "TARJETA");
                return false;
            }

            if (metadata.Estado.CompareTo("ESPERA") == 0)
            {

                //BUSCO EL PATRON
                string pattern = @"\b\d{4}\b";
                Regex regex = new(pattern);
                string lastMessage = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message;
                if (lastMessage.CompareTo("Hablar con un agente") == 0)
                {
                    await this.whatsappService.SendMessage(sesion, "AGENTE-DERIVACION");
                    sesion.Estado = EstadoSesion.AGENTE;
                    sesion.AgenteDate = DateTime.Now;
                    sesion.DetalleFlujo = "SIN TARJETA";
                    UpdateFlow(sesion, details: "SIN TARJETA", state: "ERROR", isComplete: true);
                    return false;
                }
                MatchCollection matches = regex.Matches(lastMessage);
                if (matches.Count == 0)
                {
                    //SI NO LO ENCUENTRO REVISO SI NO PASE LOS INTENTOS PERMITIDOS
                    if (metadata.Intentos <= 2)
                    {
                        //VUELVO A PEDIR EL DATO
                        await this.whatsappService.SendMessage(sesion, "TARJETA-PREGUNTA");
                        metadata.Intentos += 1;
                        NoValidFLow(sesion);
                        return false;
                    }
                    else
                    {
                        //LO MANDO A AGENTE
                        await this.whatsappService.SendMessage(sesion, "LIMITE-INTENTOS");
                        sesion.Estado = EstadoSesion.AGENTE;
                        sesion.AgenteDate = DateTime.Now;
                        metadata.Intentos += 1;
                        CloseFlowByIntent(sesion);
                        return false;
                    }
                }
                else
                {
                    string tarjeta = matches[0].Value;
                    Metadata? metadataCIC = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CIC") == 0);
                    TarjetaResponse? listTarjeta = await this.genesysService.GetTarjetasByCic("", metadataCIC!.Valor);
                    string? tarjetaOfuscada = string.Empty;
                    if (listTarjeta!.Debito.Exists(item => item.EndsWith(tarjeta)))
                    {
                        metadata.Tipo = "DEBITO";
                        tarjetaOfuscada = listTarjeta.Debito.FirstOrDefault(item => item.EndsWith(tarjeta))!;
                    }
                    else if (listTarjeta.Credito.Exists(item => item.EndsWith(tarjeta)))
                    {
                        metadata.Tipo = "CREDITO";
                        tarjetaOfuscada = listTarjeta.Credito.FirstOrDefault(item => item.EndsWith(tarjeta))!;
                    }

                    if (string.IsNullOrEmpty(metadata.Tipo))
                    {
                        metadata.Intentos += 1;
                        if (metadata.Intentos <= 2)
                        {
                            await this.whatsappService.SendMessage(sesion, "TARJETAS-VALIDACION-ERROR");
                            NoExistFlow(sesion);
                            return false;
                        }
                        else
                        {
                            await this.whatsappService.SendMessage(sesion, "LIMITE-INTENTOS");
                            sesion.Estado = EstadoSesion.AGENTE;
                            sesion.AgenteDate = DateTime.Now;
                            CloseFlowByIntent(sesion);
                            return false;
                        }
                    }
                    else
                    {
                        await this.whatsappService.SendMessage(sesion, "TARJETAS-VALIDACION-COMPLETO");
                        metadata.Estado = "COMPLETO";
                        metadata.Valor = tarjetaOfuscada;
                        UpdateFlow(sesion);
                        return true;
                    }
                }
            }
            return true;
        }

        public async Task<bool> SearchDaysInternet(SesionEntity sesion)
        {
            Metadata? metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("DIAS") == 0);
            //REVISO SI ESTA ESTE CAMPO EN LA METADATA
            if (metadata == default)
            {
                await this.whatsappService.SendMessage(sesion, "DIAS-PREGUNTA-COMPRA");
                CrearMetadata(sesion, "DIAS");
                UpdateFlow(sesion, "DIAS");
                return false;
            }

            if (metadata.Estado.CompareTo("ESPERA") == 0)
            {
                //BUSCO EL PATRON
                string pattern = @"\b[1-5]\b";
                Regex regex = new(pattern);
                string lastMessage = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message;
                MatchCollection matches = regex.Matches(lastMessage);
                if (matches.Count == 0)
                {
                    //SI NO LO ENCUENTRO REVISO SI NO PASE LOS INTENTOS PERMITIDOS
                    if (metadata.Intentos <= 2)
                    {
                        //VUELVO A PEDIR EL DATO
                        await this.whatsappService.SendMessage(sesion, "DIAS-PREGUNTA-COMPRA-NUEVAMENTE");
                        metadata.Intentos += 1;
                        NoValidFLow(sesion);
                        return false;
                    }
                    else
                    {
                        //LO MANDO A AGENTE
                        await this.whatsappService.SendMessage(sesion, "LIMITE-INTENTOS");
                        sesion.Estado = EstadoSesion.AGENTE;
                        sesion.AgenteDate = DateTime.Now;
                        metadata.Intentos += 1;
                        CloseFlowByIntent(sesion);
                        return false;
                    }
                }
                else
                {
                    await this.whatsappService.SendMessage(sesion, "DIAS-COMPLETO", "olivia", matches[0].Value);
                    metadata.Estado = "COMPLETO";
                    metadata.Valor = matches[0].Value;
                    UpdateFlow(sesion);
                    return true;
                }
            }
            return true;
        }
        public async Task<bool> SearchDaysExterior(SesionEntity sesion)
        {
            Metadata? metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("DIAS") == 0);
            //REVISO SI ESTA ESTE CAMPO EN LA METADATA
            if (metadata == default)
            {
                await this.whatsappService.SendMessage(sesion, "DIAS-PREGUNTA-EXTERIOR");
                CrearMetadata(sesion, "DIAS");
                UpdateFlow(sesion, "DIAS");
                return false;
            }

            if (metadata.Estado.CompareTo("ESPERA") == 0)
            {
                //BUSCO EL PATRON
                string pattern = @"\b(1[0-5]|[1-9])\b";
                Regex regex = new(pattern);
                string lastMessage = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message;
                MatchCollection matches = regex.Matches(lastMessage);
                if (matches.Count == 0)
                {
                    //SI NO LO ENCUENTRO REVISO SI NO PASE LOS INTENTOS PERMITIDOS
                    if (metadata.Intentos <= 2)
                    {
                        //VUELVO A PEDIR EL DATO
                        await this.whatsappService.SendMessage(sesion, "DIAS-PREGUNTA-EXTERIOR-NUEVAMENTE");
                        metadata.Intentos += 1;
                        NoValidFLow(sesion);
                        return false;
                    }
                    else
                    {
                        //LO MANDO A AGENTE
                        await this.whatsappService.SendMessage(sesion, "LIMITE-INTENTOS");
                        sesion.Estado = EstadoSesion.AGENTE;
                        sesion.AgenteDate = DateTime.Now;
                        metadata.Intentos += 1;
                        CloseFlowByIntent(sesion);
                        return false;
                    }
                }
                else
                {
                    await this.whatsappService.SendMessage(sesion, "DIAS-COMPLETO", "olivia", matches[0].Value);
                    metadata.Estado = "COMPLETO";
                    metadata.Valor = matches[0].Value;
                    UpdateFlow(sesion);
                    return true;
                }
            }
            return true;
        }
        public async Task<bool> SearchMonto(SesionEntity sesion)
        {
            Metadata? metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("MONTO") == 0);
            //REVISO SI ESTA ESTE CAMPO EN LA METADATA
            if (metadata == default)
            {
                await this.whatsappService.SendMessage(sesion, "TARJETA-MONTO-PREGUNTA", "olivia", this.oliviaConfig.LimiteDolares);
                CrearMetadata(sesion, "MONTO");
                UpdateFlow(sesion, "MONTO");
                return false;
            }

            if (metadata.Estado.CompareTo("ESPERA") == 0)
            {
                //BUSCO EL PATRON
                string pattern = GeneratePattern(int.Parse(this.oliviaConfig.LimiteDolares));
                Regex regex = new(pattern);
                string lastMessage = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message;
                MatchCollection matches = regex.Matches(lastMessage);
                if (matches.Count == 0 || int.Parse(matches[0].Value) > int.Parse(this.oliviaConfig.LimiteDolares))
                {
                    //SI NO LO ENCUENTRO REVISO SI NO PASE LOS INTENTOS PERMITIDOS
                    if (metadata.Intentos < 2)
                    {
                        //VUELVO A PEDIR EL DATO
                        await this.whatsappService.SendMessage(sesion, "TARJETA-MONTO-PREGUNTA", "olivia", this.oliviaConfig.LimiteDolares);
                        metadata.Intentos += 1;
                        NoValidFLow(sesion);
                        return false;
                    }
                    else
                    {
                        //LO MANDO A AGENTE
                        await this.whatsappService.SendMessage(sesion, "LIMITE-INTENTOS");
                        sesion.Estado = EstadoSesion.AGENTE;
                        sesion.AgenteDate = DateTime.Now;
                        metadata.Intentos += 1;
                        CloseFlowByIntent(sesion);
                        return false;
                    }
                }
                else
                {
                    await this.whatsappService.SendMessage(sesion, "TARJETA-MONTO-CORRECTO", "olivia", matches[0].Value);
                    metadata.Estado = "COMPLETO";
                    metadata.Valor = matches[0].Value;
                    UpdateFlow(sesion);
                    return true;
                }
            }
            return true;

        }

        public async Task<bool> SearchCuenta(SesionEntity sesion)
        {
            Metadata? metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CTA") == 0);
            //REVISO SI ESTA ESTE CAMPO EN LA METADATA
            if (metadata == default)
            {
                //REVISO SI ME LLEGA EN EL MENSAJE, UNA MEJORA SERIA INCRUSTAR EL FLUJO DE RECORDAR CUENTA AQUI
                await this.whatsappService.SendMessage(sesion, "CUENTA-PREGUNTA");
                CrearMetadata(sesion, "CTA");
                UpdateFlow(sesion, "CUENTA");
                return false;
            }

            if (metadata.Estado.CompareTo("ESPERA") == 0)
            {
                //BUSCO EL PATRON
                string pattern = @"\b\d{4}\b";
                Regex regex = new(pattern);
                string lastMessage = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message;
                MatchCollection matches = regex.Matches(lastMessage);
                if (matches.Count == 0)
                {
                    //SI NO LO ENCUENTRO REVISO SI NO PASE LOS INTENTOS PERMITIDOS
                    if (metadata.Intentos < 2)
                    {
                        //VUELVO A PEDIR EL DATO
                        await this.whatsappService.SendMessage(sesion, "CUENTA-PREGUNTA");
                        metadata.Intentos += 1;
                        NoValidFLow(sesion);
                        return false;
                    }
                    else
                    {
                        //LO MANDO A AGENTE
                        await this.whatsappService.SendMessage(sesion, "LIMITE-INTENTOS");
                        sesion.Estado = EstadoSesion.AGENTE;
                        sesion.AgenteDate = DateTime.Now;
                        metadata.Intentos += 1;
                        CloseFlowByIntent(sesion);
                        return false;
                    }
                }
                else
                {
                    Metadata? metadataCIC = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CIC") == 0);
                    List<string> listTarjeta = await this.genesysService.GetCuentas("", metadataCIC!.Valor);
                    string cuenta = listTarjeta.FirstOrDefault(item => item.EndsWith(matches[0].Value)) ?? string.Empty;
                    if (string.IsNullOrEmpty(cuenta))
                    {
                        if (metadata.Intentos > 2)
                        {
                            await this.whatsappService.SendMessage(sesion, "LIMITE-INTENTOS");
                            sesion.Estado = EstadoSesion.AGENTE;
                            sesion.AgenteDate = DateTime.Now;
                            metadata.Intentos += 1;
                            CloseFlowByIntent(sesion);
                            return false;
                        }
                        await this.whatsappService.SendMessage(sesion, "CUENTA-VALIDACION-ERROR");
                        NoValidFLow(sesion);
                        return false;
                    }
                    else
                    {
                        await this.whatsappService.SendMessage(sesion, "CUENTA-VALIDACION-COMPLETO");
                        metadata.Estado = "COMPLETO";
                        metadata.Valor = cuenta;
                        UpdateFlow(sesion);
                        return true;
                    }
                }
            }
            return true;
        }

        public async Task<bool> SearchPais(SesionEntity sesion)
        {
            Metadata? metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("PAIS") == 0);
            //REVISO SI ESTA ESTE CAMPO EN LA METADATA
            if (metadata == default)
            {
                await this.whatsappService.SendMessage(sesion, "PAIS-PREGUNTA");
                CrearMetadata(sesion, "PAIS");
                UpdateFlow(sesion, "PAIS");
                return false;
            }

            if (metadata.Estado.CompareTo("ESPERA") == 0)
            {
                string lastMessage = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message;
                await this.whatsappService.SendMessage(sesion, "PAIS-COMPLETO");
                metadata.Estado = "COMPLETO";
                metadata.Valor = lastMessage;
                UpdateFlow(sesion);
                return true;
            }
            return true;
        }

        public async Task<bool> SearchMotivoBloqueo(SesionEntity sesion)
        {
            Metadata? metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("BLOQ") == 0);
            //REVISO SI ESTA ESTE CAMPO EN LA METADATA
            if (metadata == default)
            {
                await this.whatsappService.SendButton(sesion, "BLOQUEO-PREGUNTA-1");
                CrearMetadata(sesion, "BLOQ");
                UpdateFlow(sesion, "MOTIVO BLOQUEO");
                return false;
            }

            if (metadata.Estado.CompareTo("ESPERA") == 0)
            {
                string lastMessage = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message;
                TipoBloqueo tipoBloqueo;
                switch (lastMessage)
                {
                    case "ROBO/EXTRAVIO":
                        tipoBloqueo = TipoBloqueo.EXTRAVIO_ROBO;
                        break;
                    case "RETENCION CAJERO":
                        tipoBloqueo = TipoBloqueo.RETENCION_CAJERO;
                        break;
                    case "FRAUDE":
                        tipoBloqueo = TipoBloqueo.FRAUDE;
                        break;
                    case "ASESOR":
                        await this.whatsappService.SendMessage(sesion, "MOTIVO-ASESOR");
                        sesion.Estado = EstadoSesion.AGENTE;
                        sesion.AgenteDate = DateTime.Now;
                        UpdateFlow(sesion, details: "ASESOR", state: "DERIVADO", isComplete: true);
                        return false;
                        break;
                    default:
                        metadata.Valor = lastMessage;
                        tipoBloqueo = TipoBloqueo.NINGUNO;
                        break;
                }
                await this.whatsappService.SendMessage(sesion, "MOTIVO-COMPLETO");
                metadata.Estado = "COMPLETO";
                metadata.Tipo = ((int)tipoBloqueo).ToString();
                UpdateFlow(sesion);
                return true;
            }
            return true;
        }
        public async Task<bool> SearchCuentaUnica(SesionEntity sesion)
        {
            Metadata? metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CTA") == 0);
            //REVISO SI ESTA ESTE CAMPO EN LA METADATA
            if (metadata == default)
            {
                CrearMetadata(sesion, "CTA");
                metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CTA") == 0);
                Metadata? metadataCIC = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CIC") == 0);
                List<string> listTarjeta = await this.genesysService.GetCuentas("", metadataCIC!.Valor);
                if (listTarjeta.Count == 1)
                {
                    metadata!.Estado = "COMPLETO";
                    metadata.Valor = listTarjeta.FirstOrDefault()!;
                    UpdateFlow(sesion);
                    return true;
                }
                await this.whatsappService.SendMessage(sesion, "ACH_BANCO_BCP_CTA-PREGUNTA");
                UpdateFlow(sesion, "CUENTA");
                return false;
            }

            if (metadata.Estado.CompareTo("ESPERA") == 0)
            {
                //BUSCO EL PATRON
                string pattern = @"\b\d{4}\b";
                Regex regex = new(pattern);
                string lastMessage = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message;
                MatchCollection matches = regex.Matches(lastMessage);
                if (matches.Count == 0)
                {
                    //SI NO LO ENCUENTRO REVISO SI NO PASE LOS INTENTOS PERMITIDOS
                    if (metadata.Intentos < 2)
                    {
                        //VUELVO A PEDIR EL DATO
                        await this.whatsappService.SendMessage(sesion, "ACH_BANCO_BCP_CTA-PREGUNTA");
                        metadata.Intentos += 1;
                        NoValidFLow(sesion);
                        return false;
                    }
                    else
                    {
                        //LO MANDO A AGENTE
                        await this.whatsappService.SendMessage(sesion, "LIMITE-INTENTOS");
                        sesion.Estado = EstadoSesion.AGENTE;
                        sesion.AgenteDate = DateTime.Now;
                        metadata.Intentos += 1;
                        CloseFlowByIntent(sesion);
                        return false;
                    }
                }
                else
                {
                    Metadata? metadataCIC = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CIC") == 0);
                    List<string> listTarjeta = await this.genesysService.GetCuentas("", metadataCIC!.Valor);
                    string cuenta = listTarjeta.FirstOrDefault(item => item.EndsWith(matches[0].Value)) ?? string.Empty;
                    if (string.IsNullOrEmpty(cuenta))
                    {
                        if (metadata.Intentos > 2)
                        {
                            await this.whatsappService.SendMessage(sesion, "LIMITE-INTENTOS");
                            sesion.Estado = EstadoSesion.AGENTE;
                            sesion.AgenteDate = DateTime.Now;
                            metadata.Intentos += 1;
                            CloseFlowByIntent(sesion);
                            return false;
                        }
                        await this.whatsappService.SendMessage(sesion, "CUENTA-VALIDACION-ERROR");
                        NoValidFLow(sesion);
                        return false;
                    }
                    else
                    {
                        await this.whatsappService.SendMessage(sesion, "CUENTA-VALIDACION-COMPLETO");
                        metadata.Estado = "COMPLETO";
                        metadata.Valor = cuenta;
                        UpdateFlow(sesion);
                        return true;
                    }
                }
            }
            return true;
        }

        public async Task<bool> SearchDireccionACH(SesionEntity sesion)
        {
            Metadata? metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_DIR") == 0);
            //REVISO SI ESTA ESTE CAMPO EN LA METADATA
            if (metadata == default)
            {
                await this.whatsappService.SendButton(sesion, "ACH_DIR-PREGUNTA");
                CrearMetadata(sesion, "ACH_DIR");
                UpdateFlow(sesion, "ACH_DIR");
                return false;
            }

            if (metadata.Estado.CompareTo("ESPERA") == 0)
            {
                string lastMessage = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message;
                switch (lastMessage)
                {
                    case "Enviada a otro banco":
                        metadata.Estado = "COMPLETO";
                        metadata.Valor = "OUTGOING";
                        UpdateFlow(sesion);
                        return true;
                        break;
                    case "De otro banco":
                        metadata.Estado = "COMPLETO";
                        metadata.Valor = "INCOMING";
                        UpdateFlow(sesion);
                        return true;
                        break;
                    default:
                        if (metadata.Intentos <= 2)
                        {
                            metadata.Intentos++;
                            await this.whatsappService.SendButton(sesion, "ACH_DIR-PREGUNTA");
                            NoValidFLow(sesion);
                            return false;
                        }
                        else
                        {
                            await this.whatsappService.SendMessage(sesion, "LIMITE-INTENTOS");
                            sesion.Estado = EstadoSesion.AGENTE;
                            sesion.AgenteDate = DateTime.Now;
                            metadata.Intentos += 1;
                            CloseFlowByIntent(sesion);
                            return false;
                        }
                        break;
                }
            }
            return true;
        }

        public async Task<bool> SearchACH(SesionEntity sesion)
        {
            Metadata? metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_NUM") == 0);
            //REVISO SI ESTA ESTE CAMPO EN LA METADATA
            if (metadata == default)
            {
                await this.whatsappService.SendButton(sesion, "ACH_NUM-PREGUNTA");
                CrearMetadata(sesion, "ACH_NUM");
                UpdateFlow(sesion, "ACH_NUM");
                return false;
            }

            if (metadata.Estado.CompareTo("ESPERA") == 0)
            {
                string lastMessage = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message;
                if (lastMessage.CompareTo("No tengo el número") == 0)
                {
                    metadata.Estado = "COMPLETO";
                    metadata.Valor = "";
                    UpdateFlow(sesion);
                    return true;
                }
                //BUSCO EL PATRON
                string pattern = @"\b\d{20}\b";
                Regex regex = new(pattern);
                MatchCollection matches = regex.Matches(lastMessage);
                if (matches.Count == 1)
                {
                    metadata.Estado = "COMPLETO";
                    metadata.Valor = matches[0].Value;
                    UpdateFlow(sesion);
                    return true;
                }
                else
                {
                    if (metadata.Intentos <= 2)
                    {
                        metadata.Intentos++;
                        await this.whatsappService.SendButton(sesion, "ACH_NUM-PREGUNTA");
                        NoValidFLow(sesion);
                        return false;
                    }
                    else
                    {
                        await this.whatsappService.SendMessage(sesion, "LIMITE-INTENTOS");
                        sesion.Estado = EstadoSesion.AGENTE;
                        sesion.AgenteDate = DateTime.Now;
                        metadata.Intentos += 1;
                        CloseFlowByIntent(sesion);
                        return false;
                    }
                }
            }
            return true;
        }
        public async Task<bool> SearchTipoACH(SesionEntity sesion)
        {
            Metadata? metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_TYPE") == 0);
            //REVISO SI ESTA ESTE CAMPO EN LA METADATA
            if (metadata == default)
            {
                await this.whatsappService.SendButton(sesion, "ACH_TYPE-PREGUNTA");
                CrearMetadata(sesion, "ACH_TYPE");
                UpdateFlow(sesion, "ACH_TYPE");
                return false;
            }

            if (metadata.Estado.CompareTo("ESPERA") == 0)
            {
                //BUSCO EL PATRON
                string lastMessage = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message;
                switch (lastMessage)
                {
                    case "SI":
                        metadata.Estado = "COMPLETO";
                        metadata.Valor = "QR";
                        UpdateFlow(sesion);
                        return true;
                        break;
                    case "NO":
                        metadata.Estado = "COMPLETO";
                        metadata.Valor = "NORMAL";
                        UpdateFlow(sesion);
                        return true;
                        break;
                    default:
                        if (metadata.Intentos <= 2)
                        {
                            metadata.Intentos++;
                            await this.whatsappService.SendButton(sesion, "ACH_TYPE-PREGUNTA");
                            NoValidFLow(sesion);
                            return false;
                        }
                        else
                        {
                            await this.whatsappService.SendMessage(sesion, "LIMITE-INTENTOS");
                            sesion.Estado = EstadoSesion.AGENTE;
                            sesion.AgenteDate = DateTime.Now;
                            metadata.Intentos += 1;
                            CloseFlowByIntent(sesion);
                            return false;
                        }
                        break;
                }
            }
            return true;
        }

        public async Task<bool> SearchBanco(SesionEntity sesion)
        {
            Metadata? metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_BANCO_EXTERNO") == 0);
            Metadata? metadataCode = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_BANCO_EXTERNO_CODE") == 0);
            Metadata? metadataList = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_BANCO_LIST") == 0);
            Metadata? metadataDir = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_DIR") == 0);
            //REVISO SI ESTA ESTE CAMPO EN LA METADATA
            if (metadata == default)
            {
                CrearMetadata(sesion, "ACH_BANCO_EXTERNO");
                CrearMetadata(sesion, "ACH_BANCO_EXTERNO_CODE");
                CrearMetadata(sesion, "ACH_BANCO_LIST");
                metadataList = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_BANCO_LIST") == 0);
                string direccion = metadataDir!.Valor.CompareTo("OUTGOING") == 0 ? "destino" : "origen";

                List<ResponseBankList> listBancos = await this.genesysService.AchStateBankList(string.Empty);
                List<ListMessage> list = this.oliviaConfig.AchBankList.Select(banco =>
                {
                    ResponseBankList? bancoDescription = listBancos.FirstOrDefault(b => b.KeyName.Equals(banco.Identifier));
                    banco.Description = bancoDescription!.Name;
                    return banco;
                }).ToList();
                List<ListMessage> listFilter = list.Where(b => b.Visible).ToList();

                await this.whatsappService.SendList(sesion, "ACH_BANCO_EXTERNO-PREGUNTA", listFilter, "olivia", direccion);

                metadataList!.Valor = JsonConvert.SerializeObject(list);
                UpdateFlow(sesion, "ACH_BANCO_EXTERNO");
                return false;
            }

            if (metadata.Estado.CompareTo("ESPERA") == 0)
            {
                string lastMessage = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message.ToUpper();
                List<ListMessage> listBanks = JsonConvert.DeserializeObject<List<ListMessage>>(metadataList!.Valor!)!;

                ListMessage? bank = listBanks.FirstOrDefault(b => b.Identifier.Equals(lastMessage));

                if (bank is not null)
                {
                    metadata.Estado = "COMPLETO";
                    metadataCode!.Estado = "COMPLETO";
                    metadata.Valor = bank.Description;
                    metadataCode.Valor = bank.Identifier;
                    UpdateFlow(sesion);
                    return true;
                }

                ListMessage? objetosCoincidentes = listBanks.FirstOrDefault(b =>
                            (b.Title != null && (lastMessage.Contains(b.Title) || b.Title.Contains(lastMessage))) ||
                            (b.Description != null && (lastMessage.Contains(b.Description.ToUpper()) || b.Description.ToUpper().Contains(lastMessage))) ||
                            (b.Tags != null && b.Tags.Any(tag => lastMessage.Contains(tag) || tag.Contains(lastMessage)))
                );

                if (objetosCoincidentes is not null)
                {
                    metadata.Estado = "COMPLETO";
                    metadataCode!.Estado = "COMPLETO";
                    metadata.Valor = objetosCoincidentes.Description;
                    metadataCode.Valor = objetosCoincidentes.Identifier;
                    UpdateFlow(sesion);
                    return true;
                }
                else
                {
                    if (metadata.Intentos <= 2)
                    {
                        //VUELVO A PEDIR EL DATO
                        string direccion = metadataDir!.Valor.CompareTo("OUTGOING") == 0 ? "destino" : "origen";
                        await this.whatsappService.SendMessage(sesion, "ACH_BANCO_EXTERNO-PREGUNTA", direccion);
                        metadata.Intentos += 1;
                        NoValidFLow(sesion);
                        return false;
                    }
                    else
                    {
                        //LO MANDO A AGENTE
                        await this.whatsappService.SendMessage(sesion, "LIMITE-INTENTOS");
                        sesion.Estado = EstadoSesion.AGENTE;
                        sesion.AgenteDate = DateTime.Now;
                        metadata.Intentos += 1;
                        CloseFlowByIntent(sesion);
                        return false;
                    }
                }
            }
            return true;
        }

        public async Task<bool> SearchImporteACH(SesionEntity sesion)
        {
            Metadata? metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_AMOUNT") == 0);
            //REVISO SI ESTA ESTE CAMPO EN LA METADATA
            if (metadata == default)
            {
                await this.whatsappService.SendMessage(sesion, "ACH_AMOUNT-PREGUNTA");
                CrearMetadata(sesion, "ACH_AMOUNT");
                UpdateFlow(sesion, "ACH_AMOUNT");
                return false;
            }

            if (metadata.Estado.CompareTo("ESPERA") == 0)
            {
                //BUSCO EL PATRON
                string pattern = @"\b\d{1,10}[.,]\d{1,2}\b";
                Regex regex = new(pattern);
                string lastMessage = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message;
                MatchCollection matches = regex.Matches(lastMessage);
                if (matches.Count == 0)
                {
                    if (metadata.Intentos <= 2)
                    {
                        //VUELVO A PEDIR EL DATO
                        await this.whatsappService.SendMessage(sesion, "ACH_AMOUNT-PREGUNTA");
                        metadata.Intentos += 1;
                        NoValidFLow(sesion);
                        return false;
                    }
                    else
                    {
                        //LO MANDO A AGENTE
                        await this.whatsappService.SendMessage(sesion, "LIMITE-INTENTOS");
                        sesion.Estado = EstadoSesion.AGENTE;
                        sesion.AgenteDate = DateTime.Now;
                        metadata.Intentos += 1;
                        CloseFlowByIntent(sesion);
                        return false;
                    }
                }
                else
                {
                    metadata.Estado = "COMPLETO";
                    metadata.Valor = matches[0].Value;
                    UpdateFlow(sesion);
                    return true;
                }
            }
            return true;
        }

        public async Task<bool> SearchHoraACH(SesionEntity sesion)
        {
            Metadata? metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_TIME") == 0);
            //REVISO SI ESTA ESTE CAMPO EN LA METADATA
            if (metadata == default)
            {
                await this.whatsappService.SendButton(sesion, "ACH_TIME-PREGUNTA", "olivia", DateTime.Now.ToString("dd/MM/yyyy"));
                CrearMetadata(sesion, "ACH_TIME");
                UpdateFlow(sesion, "ACH_TIME");
                return false;
            }

            if (metadata.Estado.CompareTo("ESPERA") == 0)
            {
                string lastMessage = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message;
                if (lastMessage.CompareTo("Agente") == 0)
                {
                    sesion.Estado = EstadoSesion.AGENTE;
                    sesion.AgenteDate = DateTime.Now;
                    UpdateFlow(sesion, "ACH_TIME", "FUERA DE FECHA", "ERROR", true);
                    return false;
                }
                //BUSCO EL PATRON
                string pattern = @"\b([01]?\d|2[0-3]):[0-5]\d\b";
                Regex regex = new(pattern);
                MatchCollection matches = regex.Matches(lastMessage);
                if (matches.Count == 0)
                {
                    if (metadata.Intentos < 2)
                    {
                        await this.whatsappService.SendButton(sesion, "ACH_TIME-PREGUNTA", "olivia", DateTime.Now.ToString("dd/MM/yyyy"));
                        metadata.Intentos += 1;
                        NoValidFLow(sesion);
                        return false;
                    }
                    else
                    {
                        await this.whatsappService.SendMessage(sesion, "LIMITE-INTENTOS");
                        sesion.Estado = EstadoSesion.AGENTE;
                        sesion.AgenteDate = DateTime.Now;
                        metadata.Intentos += 1;
                        CloseFlowByIntent(sesion);
                        return false;
                    }
                }
                else
                {
                    metadata.Estado = "COMPLETO";
                    metadata.Valor = matches[0].Value;
                    UpdateFlow(sesion);
                    return true;
                }
            }
            return true;
        }

        public async Task<bool> SearchCuentaBancoExterno(SesionEntity sesion)
        {
            Metadata? metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_BANCO_EXTERNO_CTA") == 0);
            Metadata? metadataDir = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("ACH_DIR") == 0);
            //REVISO SI ESTA ESTE CAMPO EN LA METADATA
            if (metadata == default)
            {
                string direccion = metadataDir!.Valor.CompareTo("OUTGOING") == 0 ? "destino" : "origen";
                await this.whatsappService.SendButton(sesion, "ACH_BANCO_EXTERNO_CTA-PREGUNTA", "olivia", direccion);
                CrearMetadata(sesion, "ACH_BANCO_EXTERNO_CTA");
                UpdateFlow(sesion, "ACH_BANCO_EXTERNO_CTA");
                return false;
            }

            if (metadata.Estado.CompareTo("ESPERA") == 0)
            {
                string lastMessage = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message.Replace("-", "").Replace("/", "");
                if (lastMessage.CompareTo("Agente") == 0)
                {
                    sesion.Estado = EstadoSesion.AGENTE;
                    sesion.AgenteDate = DateTime.Now;
                    UpdateFlow(sesion, "ACH_BANCO_EXTERNO_CTA", "SIN CUENTA EXTERNA", "ERROR", true);
                    return false;
                }
                string pattern = @"\b\d{8,20}\b";
                Regex regex = new(pattern);
                MatchCollection matches = regex.Matches(lastMessage);
                if (matches.Count == 1)
                {
                    metadata.Estado = "COMPLETO";
                    metadata.Valor = matches[0].Value;
                    UpdateFlow(sesion);
                    return true;
                }
                else
                {
                    if (metadata.Intentos <= 2)
                    {
                        metadata.Intentos++;
                        string direccion = metadataDir!.Valor.CompareTo("OUTGOING") == 0 ? "destino" : "origen";
                        await this.whatsappService.SendButton(sesion, "ACH_BANCO_EXTERNO_CTA-PREGUNTA", "olivia", direccion);
                        NoValidFLow(sesion);
                        return false;
                    }
                    else
                    {
                        await this.whatsappService.SendMessage(sesion, "LIMITE-INTENTOS");
                        sesion.Estado = EstadoSesion.AGENTE;
                        sesion.AgenteDate = DateTime.Now;
                        metadata.Intentos += 1;
                        CloseFlowByIntent(sesion);
                        return false;
                    }
                }

                metadata.Estado = "COMPLETO";
                metadata.Valor = lastMessage;
                UpdateFlow(sesion);
                return true;
            }
            return true;
        }
        private static void CrearMetadata(SesionEntity sesion, string clave, string estado = "ESPERA", string valor = "")
        {
            Metadata metadata = new() { Clave = clave, Valor = valor, Estado = estado, Intentos = 1 };
            sesion.Metadata.Add(metadata);
        }

        private static void UpsertMetadata(SesionEntity sesion, string clave, string estado = "ESPERA", string valor = "")
        {
            Metadata metadata = sesion.Metadata.FirstOrDefault(d => d.Clave == clave)!;

            if (metadata != null)
            {
                metadata.Estado = estado;
                metadata.Valor = valor;
                metadata.Intentos += 1;
            }
            else
            {
                metadata = new Metadata
                {
                    Clave = clave,
                    Estado = estado,
                    Valor = valor,
                    Intentos = 1
                };

                sesion.Metadata.Add(metadata);
            }
        }

        private static string GeneratePattern(int N)
        {
            if (N < 10)
            {
                return $@"\b[1-{N}]\b";
            }
            else if (N < 100)
            {
                return $@"\b([1-9]|[1-9][0-9]|{N})\b";
            }
            else
            {
                return $@"\b([1-9]|[1-9][0-9]|[1-9][0-9][0-9]|{N})\b";
            }
        }

        private static void RekognitionBlocked(SesionEntity sesion)
        {
            UpdateFlow(sesion, details: "REKOGNITION-BLOQUEADO", state: "ERROR", isComplete: true);
        }

        private static void CloseFlowByIntent(SesionEntity sesion)
        {
            UpdateFlow(sesion, details: "LIMITE-INTENTOS", state: "ERROR", isComplete: true);
        }

        private static void NoValidFLow(SesionEntity sesion)
        {
            UpdateFlow(sesion, details: "NO VALIDO", state: "ERROR");
        }

        private static void NoExistFlow(SesionEntity sesion)
        {
            UpdateFlow(sesion, state: "ERROR", details: "NO EXISTE");
        }

        private static void UpdateFlow(SesionEntity sesion, string step = "", string details = "", string state = "EN PROGRESO", bool isComplete = false)
        {
            sesion.ActiveFlow!.State = state;
            sesion.ActiveFlow.DetailsStep = string.IsNullOrEmpty(details) ? sesion.ActiveFlow.DetailsStep : details;
            sesion.ActiveFlow.CurrentStep = string.IsNullOrEmpty(step) ? sesion.ActiveFlow.CurrentStep : step;
            if (isComplete)
            {
                sesion.ActiveFlow.FinishDate = DateTime.Now;
            }
        }

        public async Task<WppFlowResponse> SearchCarnetFlow(SesionEntity sesion, WppFlowIdcCliente dataFlow)
        {
            WppFlowResponse response = new();
            Metadata? metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("IDC") == 0);
            //REVISO SI ESTA ESTE CAMPO EN LA METADATA
            if (metadata == default)
            {
                CrearMetadata(sesion, "IDC");
                UpdateFlow(sesion, "IDC");
            }
            else
            {
                UpsertMetadata(sesion, "IDC", "COMPLETO", dataFlow.Carnet);
            }

            metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("IDC") == 0);

            ClienteConsultaResponse? cliente = await this.genesysService.GetClienteConsulta("", dataFlow.Carnet, dataFlow.Complemento);
            if (cliente is null)
            {
                if (metadata!.Intentos <= 2)
                {
                    //VUELVO A PEDIR EL DATO
                    metadata.Intentos += 1;
                    NoExistFlow(sesion);

                    response.EnviarGenesys = false;
                    response.Success = false;
                    response.Mensaje = "WPP-FLOW_CARNET_ERROR";
                    return response;
                }
                else
                {
                    //LO MANDO A AGENTE
                    sesion.Estado = EstadoSesion.AGENTE;
                    sesion.AgenteDate = DateTime.Now;
                    metadata.Intentos += 1;
                    CloseFlowByIntent(sesion);

                    response.EnviarGenesys = true;
                    response.Success = false;
                    response.Mensaje = "LIMITE-INTENTOS";
                    return response;
                }
            }
            else
            {
                UpsertMetadata(sesion, "CIC", "COMPLETO", cliente.Cic);
                UpsertMetadata(sesion, "NOMBRE", "COMPLETO", cliente.Nombre);
                UpsertMetadata(sesion, "PATERNO", "COMPLETO", cliente.Paterno);
                UpsertMetadata(sesion, "CEL", "COMPLETO", cliente.Celular);
                UpsertMetadata(sesion, "EMAIL", "COMPLETO", cliente.Correo);
                metadata!.Estado = "COMPLETO";
                metadata.Valor = dataFlow.Carnet;
                UpdateFlow(sesion);
                response.EnviarGenesys = false;
                response.Success = true;
                response.Mensaje = "CARNET-CORRECTO";
                return response;
            }
            return response;
        }

        public async Task<WppFlowResponse> RekognitionWppFlow(SesionEntity sesion, WppFlowSelfi dataSelfi)
        {
            WppFlowResponse response = new();
            Metadata? metadataREK = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("REK") == 0);
            Metadata metadataIDC = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("IDC") == 0)!;
            Metadata metadataCEL = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("CEL") == 0)!;
            //REVISO SI ESTA ESTE CAMPO EN LA METADATA 
            if (metadataREK == default)
            {
                PruebaVidaGenerarPasivaResponse? rekognitionSession = await this.genesysService.PruebaVidaGenerarPasiva("", metadataIDC!.Valor, metadataCEL!.Valor);
                if (rekognitionSession is not null)
                {
                    CrearMetadata(sesion, "REK", valor: rekognitionSession.SessionID);
                    UpdateFlow(sesion, "REKOGNITION");
                }
                else
                {
                    sesion.Estado = EstadoSesion.AGENTE;
                    sesion.AgenteDate = DateTime.Now;
                    RekognitionBlocked(sesion);
                    response.Success = false;
                    response.EnviarGenesys = true;
                    response.Mensaje = "WPP-FLOW_REKOGNITION-ERROR-GENERAR-PASIVA";
                    return response;
                }
            }

            metadataREK = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("REK") == 0);

            if (metadataREK!.Estado.CompareTo("ESPERA") == 0)
            {
                if (metadataREK.Intentos <= 2)
                {
                    metadataREK.Intentos += 1;
                    PruebaVidaValidarPasivaResponse? rekognitioResult = await this.genesysService.PruebaVidaValidarPasiva("", metadataIDC!.Valor, metadataREK.Valor, dataSelfi.Base64);
                    if (rekognitioResult is not null && rekognitioResult.Success)
                    {
                        sesion.ActiveFlow!.State = "EN PROGRESO";
                        metadataREK.Estado = "COMPLETO";
                        response.Success = true;
                        response.EnviarGenesys = false;
                        response.Mensaje = "REKOGNITION-CORRECTO";
                        UpdateFlow(sesion);
                        return response;
                    }
                    else
                    {
                        sesion.Estado = EstadoSesion.AGENTE;
                        sesion.AgenteDate = DateTime.Now;
                        UpdateFlow(sesion, details: "VALIDACION FALLIDA", state: "ERROR");
                        response.Success = false;
                        response.EnviarGenesys = false;
                        response.Mensaje = "WPP-FLOW_REKOGNITION-ERROR";
                        return response;
                    }
                }
                else
                {
                    //LO MANDO A AGENTE PORQUE EXEDIO LOS INTENTOS
                    sesion.Estado = EstadoSesion.AGENTE;
                    sesion.AgenteDate = DateTime.Now;
                    metadataREK.Intentos += 1;
                    CloseFlowByIntent(sesion);
                    response.EnviarGenesys = true;
                    response.Success = false;
                    response.Mensaje = "LIMITE-INTENTOS";
                    return response;
                }
            }
            else
            {
                response.Mensaje = string.Empty;
                response.Success = false;
                response.Expired = true;
                response.EnviarGenesys = false;
            }
            return response;
        }

        public async Task<bool> SendRekognitionWppFlow(SesionEntity sesion)
        {
            Metadata? metadata = sesion.Metadata.FirstOrDefault(item => item.Clave.CompareTo("WPP_FLOW") == 0);

            //REVISO SI ESTA ESTE CAMPO EN LA METADATA
            if (metadata == default)
            {
                await this.whatsappService.SendMessageFlow(sesion, "WPP-FLOW_MENSAJE_REKOGNITION", "flow_event", false, "olivia");
                CrearMetadata(sesion, "WPP_FLOW");
                UpdateFlow(sesion, "WPP_FLOW");
                return false;
            }

            if (metadata.Estado.CompareTo("ESPERA") == 0)
            {
                await this.whatsappService.SendButton(sesion, "WPP-FLOW_INFORMACION", "olivia");
            }

            return false;
        }
    }
}
