using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using OLIVIA.CORE.MODEL.CONFIG;
using OLIVIA.CORE.MODEL.DB_MODEL.PARAMETRO;
using OLIVIA.CORE.MODEL.DTO.Cache;
using OLIVIA.CORE.REPOSITORY.Interfaces;
using OLIVIA.CORE.SERVICE.Interfaces;

namespace OLIVIA.CORE.SERVICE.Service
{
    public class CacheService(IMemoryCache cache, IParametroRepository repository, IOptions<CacheConfig> options) : ICacheService
    {
        public async Task<bool> ParametroUpdateAsync(ParametroDto request)
        {
            var response = await repository.UpdateParametroAsync(request.Nombre, request.Mensaje, request.Enabled, request.Usuario);
            if (response)
                cache.Remove("PARAMETRO");
            return response;
        }
        public async Task<List<ParametroEntitie>?> ParametroGetListAsync()
        {
            if (!cache.TryGetValue("PARAMETRO", out List<ParametroEntitie>? parametros))
            {
                parametros = await repository.GetParametroListAsync();
                var cacheEntryOptions = new MemoryCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(options.Value.AbsoluteExpirationRelativeToNowMinutes),
                    SlidingExpiration = TimeSpan.FromMinutes(options.Value.SlidingExpirationMinutes)
                };
                cache.Set("PARAMETRO", parametros, cacheEntryOptions);
            }
            return parametros;
        }
        public async Task<ParametroEntitie?> ParametroGetByNombreAsync(string nombre)
        {
            if (!cache.TryGetValue("PARAMETRO", out List<ParametroEntitie>? parametros))
            {
                parametros = await repository.GetParametroListAsync();
                var cacheEntryOptions = new MemoryCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(options.Value.AbsoluteExpirationRelativeToNowMinutes),
                    SlidingExpiration = TimeSpan.FromMinutes(options.Value.SlidingExpirationMinutes)
                };
                cache.Set("PARAMETRO", parametros, cacheEntryOptions);
            }
            return parametros!.FirstOrDefault(x => x.Nombre.Equals(nombre, StringComparison.OrdinalIgnoreCase));
        }
    }
}
