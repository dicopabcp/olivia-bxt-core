using OLIVIA.CORE.MODEL;
using OLIVIA.CORE.MODEL.CONFIG;
using OLIVIA.CORE.MODELS.CONFIG;
using OLIVIA.CORE.REPOSITORY;
using Serilog;

namespace OLIVIA.CORE.SERVICE
{
    public class WhatsappService : IWhatsappService
    {
        private readonly IWhatsAppRepository whatsAppRepository;
        private readonly IMessagesService messagesService;

        public WhatsappService(IWhatsAppRepository whatsAppRepository, IMessagesService messagesService)
        {
            this.whatsAppRepository = whatsAppRepository;
            this.messagesService = messagesService;
        }

        public async Task SaveMessage(SesionEntity sesion, string message)
        {
            MessagesSesionEntity? lastMessage = sesion.Messages.LastOrDefault() ?? null;
            MessagesSesionEntity newMesage = new() { Message = message, Role = "user" };
            sesion.Messages.Add(newMesage);
            await this.messagesService.SaveMessages(newMesage, sesion, lastMessage!);
        }

        public async Task SendMessage(SesionEntity sesion, string message, string rol = "olivia", params string[] arg)
        {
            try
            {
                MessagesSesionEntity? lastMessage = sesion.Messages.LastOrDefault() ?? null;
                string value = this.messagesService.GetMessageByKey(message).Value;
                string x = "";
                if (arg.Length != 0)
                    x = string.Format(value, arg);
                else
                    x = value;
                MessagesSesionEntity newMesage = new() { Message = x, Role = rol };
                sesion.Messages.Add(newMesage);

                await this.messagesService.SaveMessages(newMesage, sesion, lastMessage!);
                await this.whatsAppRepository.SendMessage(sesion.Usuario, x);

                //Enviamos informacion multimedia si es necesario
                List<MultimediaMessage> multimediaMessages = this.messagesService.GetMultimediaByKey(message);
                foreach (MultimediaMessage multimedia in multimediaMessages)
                {
                    await this.whatsAppRepository.SendMultimediaMessage(sesion.Usuario, multimedia.Caption, multimedia.Link);
                }
            }
            catch (Exception ex)
            {
                Log.Error("ERROR EN SERVICES", ex);
            }
        }

        public async Task SendMessageDirect(SesionEntity sesion, string message, string rol = "olivia")
        {
            try
            {
                MessagesSesionEntity? lastMessage = sesion.Messages.LastOrDefault() ?? null;
                MessagesSesionEntity newMesage = new() { Message = message, Role = rol };
                sesion.Messages.Add(newMesage);
                await this.messagesService.SaveMessages(newMesage, sesion, lastMessage!);
                await this.whatsAppRepository.SendMessage(sesion.Usuario, message);
            }
            catch (Exception ex)
            {
                Log.Error("ERROR EN SERVICES", ex);
            }
        }

        public async Task SendMessageFromRag(SesionEntity sesion, string message)
        {
            try
            {
                MessagesSesionEntity? lastMessage = sesion.Messages.LastOrDefault() ?? null;
                MessagesSesionEntity newMesage = new() { Message = message, Role = "rag" };
                sesion.Messages.Add(newMesage);

                await this.messagesService.SaveMessages(newMesage, sesion, lastMessage!);
                await this.whatsAppRepository.SendMessage(sesion.Usuario, message);
            }
            catch (Exception ex)
            {
                Log.Error("ERROR EN SERVICES", ex);
            }
        }

        public async Task SendButton(SesionEntity sesion, string message, string rol = "olivia", params string[] arg)
        {
            try
            {
                MessagesSesionEntity? lastMessage = sesion.Messages.LastOrDefault() ?? null;
                ConfigMessages configMessages = this.messagesService.GetMessageByKey(message);
                string x = "";
                if (arg.Length != 0)
                    x = string.Format(configMessages.Value, arg);
                else
                    x = configMessages.Value;

                MessagesSesionEntity newMesage = new() { Message = x, Role = rol };
                sesion.Messages.Add(newMesage);
                await this.messagesService.SaveMessages(newMesage, sesion, lastMessage!);
                await this.whatsAppRepository.SendButtons(sesion.Usuario, x, configMessages.Buttons);
            }
            catch (Exception ex)
            {
                Log.Error("ERROR EN SERVICES", ex);
            }
        }

        public async Task SendList(SesionEntity sesion, string message, List<ListMessage> listMessages, string rol = "olivia", params string[] arg)
        {
            try
            {
                MessagesSesionEntity? lastMessage = sesion.Messages.LastOrDefault() ?? null;
                ConfigMessages configMessages = this.messagesService.GetMessageByKey(message);
                string x = "";
                if (arg.Length != 0)
                    x = string.Format(configMessages.Value, arg);
                else
                    x = configMessages.Value;

                MessagesSesionEntity newMesage = new() { Message = x, Role = rol };
                sesion.Messages.Add(newMesage);

                await this.messagesService.SaveMessages(newMesage, sesion, lastMessage!);
                await this.whatsAppRepository.SendList(sesion.Usuario, x, listMessages);
            }
            catch (Exception ex)
            {
                Log.Error("ERROR EN SERVICES", ex);
            }
        }

        public async Task SendMessageFlow(SesionEntity sesion, string message, string nameFlow, bool enableCacheMessage = false, string rol = "olivia", string screen = "", string? header = null, string? footer = null, params string[] arg)
        {
            try
            {
                MessagesSesionEntity? lastMessage = sesion.Messages.LastOrDefault() ?? null;
                string value = string.Empty;
                if (!enableCacheMessage)
                {
                    value = this.messagesService.GetMessageByKey(message).Value;
                }
                else
                {
                    value = message;
                }
                string x = "";
                if (arg.Length != 0)
                    x = string.Format(value, arg);
                else
                    x = value;
                MessagesSesionEntity newMesage = new() { Message = x, Role = rol };
                sesion.Messages.Add(newMesage);

                await this.messagesService.SaveMessages(newMesage, sesion, lastMessage!);
                await this.whatsAppRepository.SendMessageFlow(sesion.Usuario, x, nameFlow, sesion._id.ToString(), screen, header, footer);
            }
            catch (Exception ex)
            {
                Log.Error("ERROR EN SERVICES", ex);
            }
        }
    }
}
