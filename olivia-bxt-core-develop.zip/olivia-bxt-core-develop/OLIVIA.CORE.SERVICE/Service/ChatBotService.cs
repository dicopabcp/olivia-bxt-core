using Microsoft.Extensions.Configuration;
using OLIVIA.CORE.MODEL;
using OLIVIA.CORE.MODEL.CONST;
using OLIVIA.CORE.MODELS.CONFIG;
using OLIVIA.CORE.SERVICE.Interfaces;
using Serilog;

namespace OLIVIA.CORE.SERVICE
{
    public class ChatBotService : IChatBotService
    {
        private readonly ISorterService sorterService;
        private readonly ISesionService sesionService;
        private readonly IFlowService flowService;
        private readonly IEncuestaService encuestaService;
        private readonly IWhatsappService whatsappService;
        private readonly ICacheService cache;
        private readonly OliviaConfig oliviaConfig;

        public ChatBotService(
            IConfiguration configuration,
            ISorterService sorterService,
            ISesionService sesionService,
            IFlowService flowService,
            IEncuestaService encuestaService,
            IWhatsappService whatsappService,
            ICacheService cache)
        {
            this.sorterService = sorterService;
            this.sesionService = sesionService;
            this.flowService = flowService;
            this.encuestaService = encuestaService;
            this.whatsappService = whatsappService;
            this.cache = cache;
            this.oliviaConfig = new OliviaConfig();
            configuration.GetSection("OliviaConfig").Bind(this.oliviaConfig);
        }

        public async Task<(string answer, bool flag)> ChatBotMain(string user, string text)
        {
            SesionEntity? sesion = await this.sesionService.ReadSesion(user);
            try
            {
                bool primerRegistro = sesion is null;
                bool mensajeDerivacionAgente = false;
                if (this.oliviaConfig.MensajeDerivacionAgente != null)
                    mensajeDerivacionAgente = this.oliviaConfig.MensajeDerivacionAgente.Contains(text.ToLower());
                if (sesion is null || sesion.Estado.CompareTo(EstadoSesion.CERRADO) == 0)
                {
                    //Creo una sesion nueva y añado el primer mensaje
                    sesion = await this.sesionService.CreateSesion(user);
                    //this.Log.Information($"SESION:{sesion._id.ToString()} - NUMERO:{user} - MENSAJE:{text}");
                    if (text.CompareTo(this.oliviaConfig.MensajeDeDeflexion) == 0)
                    {
                        text = "Hola";
                    }

                    await this.whatsappService.SaveMessage(sesion, text);
                    //En caso de que se necesite mandar mensajes de contingencia y mensaje de saludo
                    var parametros = await this.cache.ParametroGetByNombreAsync("CONTINGENCIA");
                    if (parametros!.Enabled)
                    {
                        await this.whatsappService.SendMessageDirect(sesion, parametros.Mensaje);
                    }
                    await this.whatsappService.SendMessage(sesion, "MENSAJE-INICIO");
                }
                else
                {
                    //this.Log.Information($"SESION:{sesion._id.ToString()} - NUMERO:{user} - MENSAJE:{text}");
                    EstadoSesion auxEstado = sesion.Estado;
                    if (mensajeDerivacionAgente && sesion.Estado != EstadoSesion.AGENTE)
                    {
                        sesion.Estado = EstadoSesion.AGENTE;
                    }

                    int multimensajeAuxiliar = sesion.Multimensaje;
                    //guardado temporal que al final del flujo se va a eliminar
                    sesion.Multimensaje++;
                    sesion.Messages.Add(new MessagesSesionEntity() { Message = text, Role = "user", Class = "MULTIMENSAJE" });
                    await this.sesionService.UpdateSesion(sesion);

                    //vuelta a la normalidad multimensaje                    
                    if (multimensajeAuxiliar == 0)
                    {
                        sesion.Multimensaje = multimensajeAuxiliar;
                        sesion.Messages.RemoveAt(sesion.Messages.Count - 1);
                    }

                    //vuelta a la normalidad 
                    if (mensajeDerivacionAgente)
                    {
                        sesion.Estado = auxEstado;
                    }

                    if (!mensajeDerivacionAgente && sesion.Messages.Count == 0)
                        sesion.Multimensaje++;

                    await this.whatsappService.SaveMessage(sesion, text);
                }

                if (mensajeDerivacionAgente && sesion.Estado != EstadoSesion.AGENTE)
                {
                    return await DerivacionAgente(sesion);
                }

                //Si el cliente quiere cerrar la sesion
                if (text.CompareTo("CERRAR SESION") == 0)
                {
                    //CERRAR SESSION
                    sesion.Estado = EstadoSesion.CERRADO;
                    await this.whatsappService.SendMessage(sesion, "MENSAJE-CIERRE-SESSION");
                    await this.sesionService.UpdateSesion(sesion);
                    return ("SESION CERRADA", sesion.Estado.CompareTo(EstadoSesion.AGENTE) == 0);
                }

                //SI EXISTEN NUEVOS MENSAJES DEVUELVO VACIO(quiere decir que este request no tiene el ultimo mensaje)
                if (sesion.Multimensaje > 0)
                    return ("", false);

                switch (sesion.Estado)
                {
                    //La sesion esta en agente?
                    case EstadoSesion.AGENTE or EstadoSesion.DEFLEXION:
                        return await this.AgenteFlow(sesion);

                    //La sesion esta en encuesta?
                    case EstadoSesion.ENCUESTA:
                        return await this.EncuestaFlow(sesion);

                    //La sesion esta en estados "sin topico" o "consulta topico"
                    case EstadoSesion.SIN_TOPICO:
                        return await this.ConsultaTopico(sesion, primerRegistro);

                    case EstadoSesion.CON_TOPICO:
                        //Se da el caso de que un cliente solo salude, entonces la intencion sera saludo, pero aun no se tiene una intencion clara.
                        if (sesion.Topic.CompareTo("SALUDO") == 0)
                            return await this.ConsultaTopico(sesion);
                        else
                            return await this.ConTopico(sesion);
                    default:
                        await this.sesionService.UpdateSesion(sesion);
                        return ($"SIN OPCIONES", false);

                }
            }
            catch (Exception ex)
            {
                //this.Log.Information($"ERROR EN LA SESION {sesion!._id}, DEL USUARIO {sesion.Usuario}");
                //this.Log.Error(ex);
                sesion.Estado = EstadoSesion.AGENTE;
                sesion.AgenteDate = DateTime.Now;
                if (sesion.ActiveFlow is null)
                {
                    sesion.ActiveFlow = sesion.ActiveFlow ?? new Flow() { Topic = "ERROR INESPERADO", CreateDate = DateTime.Now };
                    await this.flowService.CreateFlow(sesion);
                }
                sesion.ActiveFlow.FinishDate = DateTime.Now;
                sesion.ActiveFlow.DetailsStep = ex.Message;
                sesion.ActiveFlow.State = "ERROR";
                await this.flowService.UpdateFlow(sesion.ActiveFlow);
                await this.whatsappService.SendMessage(sesion, "AGENTE-DERIVACION");
                await this.sesionService.UpdateSesion(sesion);
                return ("ERROR EN LA SESION", true);
            }
        }

        public async Task<(string, bool)> ConTopico(SesionEntity sesion)
        {
            //Consumo el Router de Flujos
            await this.flowService.RouteFlow(sesion);
            await this.sesionService.UpdateSesion(sesion);
            return ($"TOPICO {sesion.Topic}", sesion.Estado.CompareTo(EstadoSesion.AGENTE) == 0);
        }

        public async Task<(string, bool)> ConsultaTopico(SesionEntity sesion, bool primerRegistro = false)
        {
            Log.Information($"VALIDACION MULTIMENSAJE {sesion._id} INICIO");
            int contadorMultimensajeIni = 0;
            int contadorMultimensajeAct;
            int c = 0;
            int indice = -1;
            string mensajeOriginal = string.Empty;
            SesionEntity? sesionMM;
            bool repetir = true;
            while (repetir)
            {
                await Task.Delay(1000 * (c == 0 ? this.oliviaConfig.DelayMultimensajesInicial : this.oliviaConfig.DelayMultimensajes));
                sesionMM = await this.sesionService.ReadSesion(sesion.Usuario);
                if (sesionMM is null)
                {
                    Log.Information($"SESION {sesion._id} NO ENCONTRADA");
                    repetir = false;
                }
                else
                {
                    contadorMultimensajeAct = sesionMM!.Multimensaje;
                    if (sesionMM!.Estado != EstadoSesion.SIN_TOPICO)
                    {
                        sesion.Estado = sesionMM!.Estado;
                        repetir = false;
                    }
                    else if (contadorMultimensajeIni != contadorMultimensajeAct)
                    {
                        string mensajeNuevo = string.Join("\n", sesionMM!.Messages.Where(item => item.Class.Equals("MULTIMENSAJE")).Select(item => item.Message));
                        if (c == 0)
                        {
                            indice = sesion.Messages.Select((valor, index) => new { valor, index }).Last(item => item.valor.Role.Equals("user")).index;
                            if (primerRegistro)
                                mensajeOriginal = sesion.Messages[indice].Message;
                        }

                        if (primerRegistro)
                            mensajeNuevo = mensajeOriginal + "\n" + mensajeNuevo;

                        sesion.Messages[indice].Message = mensajeNuevo;
                        contadorMultimensajeIni = contadorMultimensajeAct;
                        c++;
                    }
                    else
                    {
                        repetir = false;
                    }
                }
            }

            if (sesion.Estado == EstadoSesion.SIN_TOPICO)
            {
                //Consulto a SetFit
                string? HigherTopic = await this.sorterService.RequestToSorterBxT(sesion);
                //SetFit devuelve un topico??

                if (HigherTopic is null)
                {
                    await this.sesionService.UpdateSesion(sesion);
                    return ("PREGUNTANDO TOPICO", sesion.Estado.CompareTo(EstadoSesion.AGENTE) == 0 || sesion.Estado.CompareTo(EstadoSesion.DEFLEXION) == 0);
                }

                sesion.Topic = HigherTopic;
                sesion.Estado = EstadoSesion.CON_TOPICO;

                //Consumo el Router de Flujos
                await this.flowService.RouteFlow(sesion);
                await this.sesionService.UpdateSesion(sesion);
                return ($"TOPICO {HigherTopic}", sesion.Estado.CompareTo(EstadoSesion.AGENTE) == 0 || sesion.Estado.CompareTo(EstadoSesion.DEFLEXION) == 0);
            }
            else
            {
                return ("", false);
            }
        }

        public async Task<(string, bool)> EncuestaFlow(SesionEntity sesion)
        {
            //CONSUMO EL FLUJO DE ENCUESTAS
            await this.encuestaService.FlujoEncuesta(sesion);
            if (sesion.Estado.CompareTo(EstadoSesion.SIN_TOPICO) == 0)
                return await this.ConsultaTopico(sesion, true);
            await this.sesionService.UpdateSesion(sesion);
            return ("ENCUESTA", sesion.Estado.CompareTo(EstadoSesion.AGENTE) == 0);
        }

        public async Task<(string, bool)> AgenteFlow(SesionEntity sesion)
        {
            //actualizo la sesion y devuelvo una respuesta. mando false para que continue a GENESYS (NO MANDO WHATSAPPS)
            await this.sesionService.UpdateSesion(sesion);
            return (sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message, true);
        }

        private async Task<(string, bool)> DerivacionAgente(SesionEntity sesion)
        {
            Log.Information($"DEREIVACION DIRECTA AGENTE {sesion._id}");
            //Consulto a SetFit
            if (sesion.Estado == EstadoSesion.SIN_TOPICO)
            {

                string HigherTopic = "AGENTE";
                await this.sorterService.RequestToSorterBxT(sesion, HigherTopic);
                sesion.Topic = HigherTopic;
                await this.flowService.RouteFlow(sesion);
            }
            else
            {
                sesion.ActiveFlow!.State = "DERIVADO";
                sesion.ActiveFlow!.FinishDate = DateTime.Now;
                await this.flowService.UpdateFlow(sesion.ActiveFlow!);
                await this.whatsappService.SendMessage(sesion, "AGENTE-DERIVACION");
                sesion.Estado = EstadoSesion.AGENTE;
                sesion.AgenteDate = DateTime.Now;
            }

            await this.sesionService.UpdateSesion(sesion);
            return ($"TOPICO {sesion.Topic}", true);
        }
    }
}
