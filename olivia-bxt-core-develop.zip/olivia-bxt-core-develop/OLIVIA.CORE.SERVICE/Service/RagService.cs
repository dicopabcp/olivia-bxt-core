using OLIVIA.CORE.MODEL;
using OLIVIA.CORE.REPOSITORY;

namespace OLIVIA.CORE.SERVICE
{
    public class RagService : IRagService
    {
        private readonly IRagRepository ragRepository;
        private readonly IWhatsappService whatsappService;
        public RagService(IRagRepository ragRepository, IWhatsappService whatsappService)
        {
            this.ragRepository = ragRepository;
            this.whatsappService = whatsappService;
        }
        public async Task<bool> SearchInRag(SesionEntity sesion)
        {
            //CREAR UN OBJETO RAG
            try
            {
                string last_message = sesion.Messages.LastOrDefault(item => item.Role.CompareTo("user") == 0)!.Message;
                int minutosAtras = 10;
                DateTime limite = DateTime.Now.AddMinutes(-minutosAtras);
                WrapperResponseRag<AskToDocumentResponse> responseRag = await this.ragRepository.RequestToRag(sesion._id.ToString(), last_message, sesion.Messages.Where(item => item.CreateDate >= limite).Select(item => new HistoryItem() { Message = item.Message, Type = item.Role.CompareTo("user") == 0 ? MessageType.HumanMessage : MessageType.IaMessage }).ToList());
                if (responseRag.StatusCode != 200 || responseRag.Data.NeedAgent || string.IsNullOrEmpty(responseRag.Data.Answer))
                {
                    await this.whatsappService.SendMessage(sesion, "RAG-NO-INFO");
                    UpdateFlow(sesion, step: "SEARCH", details: "NO INFO", state: "ERROR");
                    return false;
                }
                else
                {
                    await this.whatsappService.SendMessageFromRag(sesion, responseRag.Data.Answer);
                    UpdateFlow(sesion, step: "", details: "", state: "COMPLETADO");
                    return true;
                }
            }
            catch (Exception ex)
            {
                await this.whatsappService.SendMessage(sesion, "RAG-ERROR-REQUEST", "rag");
                UpdateFlow(sesion, step: "SEARCH", details: ex.Message, state: "ERROR");
                return false;
            }

        }
        private static void UpdateFlow(SesionEntity sesion, string step = "", string details = "", string state = "EN PROGRESO")
        {
            sesion.ActiveFlow!.State = state;
            sesion.ActiveFlow.DetailsStep = string.IsNullOrEmpty(details) ? sesion.ActiveFlow.DetailsStep : details;
            sesion.ActiveFlow.CurrentStep = string.IsNullOrEmpty(step) ? sesion.ActiveFlow.CurrentStep : step;
            sesion.ActiveFlow.FinishDate = DateTime.Now;
        }
    }
}
