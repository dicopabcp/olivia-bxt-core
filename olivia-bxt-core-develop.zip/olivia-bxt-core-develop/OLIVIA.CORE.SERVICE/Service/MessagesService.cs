
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using OLIVIA.CORE.MODEL;
using OLIVIA.CORE.MODEL.CONFIG;
using OLIVIA.CORE.REPOSITORY;

namespace OLIVIA.CORE.SERVICE
{
    public class MessagesService : IMessagesService
    {
        private readonly List<ConfigMessages> configMessages;
        private readonly IMessageRepository messageRepository;

        public MessagesService(IConfiguration configuration, IMessageRepository messageRepository)
        {
            this.configMessages = new List<ConfigMessages>();
            configuration.GetSection("Messages").Bind(this.configMessages);
            this.messageRepository = messageRepository;
        }

        public ConfigMessages GetMessageByKey(string key)
        {
            return this.configMessages.FirstOrDefault(item => item.Key.CompareTo(key) == 0)!;
        }
        public List<MultimediaMessage> GetMultimediaByKey(string key)
        {
            return this.configMessages.FirstOrDefault(item => item.Key.CompareTo(key) == 0)!.Multimedia;
        }
        public async Task<bool> SaveMessages(MessagesSesionEntity messagesSesionEntity, SesionEntity sesion, MessagesSesionEntity? messagesSesionBefore = null)
        {
            return await this.messageRepository.SaveMessages(messagesSesionEntity, sesion, messagesSesionBefore);
        }
    }
}
