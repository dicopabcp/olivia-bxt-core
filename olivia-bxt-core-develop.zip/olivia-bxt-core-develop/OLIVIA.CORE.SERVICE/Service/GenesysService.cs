using OLIVIA.CORE.MODEL.CONST;
using OLIVIA.CORE.MODEL.DTO.Genesys;
using OLIVIA.CORE.MODEL.DTO.Genesys.ACCL;
using OLIVIA.CORE.REPOSITORY;
using Serilog;

namespace OLIVIA.CORE.SERVICES
{
    public class GenesysService : IGenesysService
    {
        private readonly IGenesysRepository genesysRepository;

        public GenesysService(IGenesysRepository genesysRepository)
        {
            this.genesysRepository = genesysRepository;
        }

        public async Task<ClienteConsultaResponse?> GetClienteConsulta(string idOperacion, string idc, string complemento)
        {
            ClienteConsultaResponse? response;
            AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
            WrapperGenesysResponse<ClienteConsultaResponse>? result = await this.genesysRepository.ClienteConsulta(idOperacion, idc, complemento, auth.Data.Token) ?? throw new Exception($"No se encontraron registros para {idc}");
            response = result.Data;
            return response;
        }

        public async Task<TarjetaResponse?> GetTarjetasByCic(string idOperacion, string cic)
        {
            AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
            WrapperGenesysResponse<TarjetaResponse> result = await this.genesysRepository.Tarjeta(idOperacion, cic, auth.Data.Token) ?? throw new Exception($"No se encontraron tarjetas para {cic}");
            TarjetaResponse? response = result.Data;
            return response;
        }

        public async Task<bool> DesbloqueoByCic(string idOperacion, string cic)
        {
            AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
            WrapperGenesysResponse<bool> result = await this.genesysRepository.BMDesbloqueo(idOperacion, cic, auth.Data.Token);

            bool response = result.Data;
            return response;
        }

        public async Task<bool> DesvinculacionByCic(string idOperacion, string cic)
        {
            AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
            WrapperGenesysResponse<bool> result = await this.genesysRepository.BMDesvinculacion(idOperacion, cic, auth.Data.Token);

            bool response = result.Data;
            return response;
        }

        public async Task<bool> HabilitacionComprasXInternet(string idOperacion, string cic, string complemento, string duracion, string idc, string limite, string tarjeta)
        {
            AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
            WrapperGenesysResponse<bool> result = await this.genesysRepository.HabilitacionComprasxInternet(idOperacion, cic, complemento, duracion, idc, limite, tarjeta, auth.Data.Token);

            bool response = result.Data;
            return response;
        }

        public async Task<bool> HabilitacionTarjetaExterior(string idOperacion, string cic, string complemento, string duracion, string idc, string limite, string tarjeta)
        {
            AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
            WrapperGenesysResponse<bool> result = await this.genesysRepository.HabilitacionComprasxInternet(idOperacion, cic, complemento, duracion, idc, limite, tarjeta, auth.Data.Token);

            bool response = result.Data;
            return response;
        }

        public async Task<PruebaVidaGenerarResponse> PruebaVidaGenerar(string idOperacion, string idc, string celular)
        {
            AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
            WrapperGenesysResponse<PruebaVidaGenerarResponse> result = await this.genesysRepository.RekognitionGenerarGenesys(idOperacion, celular, idc, auth.Data.Token);

            return result is null ? throw new Exception($"Error al generar prueba de vida") : result.Data!;
        }

        public async Task<PruebaVidaGenerarPasivaResponse?> PruebaVidaGenerarPasiva(string idOperacion, string idc, string celular)
        {
            try
            {
                AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
                WrapperGenesysResponse<PruebaVidaGenerarPasivaResponse> result = await this.genesysRepository.RekognitionGenerarPasivaGenesys(idOperacion, celular, idc, auth.Data.Token);
                return result.Data;
            }
            catch (Exception ex)
            {
                Log.Error("ERROR EN SERVICIO", ex);
                return null;
            }
        }


        public async Task<bool> PruebaVidaValidar(string idOperacion, string idc, string sessionId)
        {
            AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
            WrapperGenesysResponse<bool> result = await this.genesysRepository.RekognitionValidarGenesys(idOperacion, sessionId, auth.Data.Token);
            return result.Data;
        }

        public async Task<PruebaVidaValidarPasivaResponse?> PruebaVidaValidarPasiva(string idOperacion, string idc, string sessionId, string selfi)
        {
            AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
            WrapperGenesysResponse<PruebaVidaValidarPasivaResponse> result = await this.genesysRepository.RekognitionValidarPasivaGenesys(idOperacion, sessionId, selfi, auth.Data.Token);
            return result.Data;
        }

        public async Task<bool> OtpGenerar(string idOperacion, string celular, string idc, string correo)
        {
            AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
            WrapperGenesysResponse<string> result = await this.genesysRepository.OtpGenerarGenesys(idOperacion, celular, idc, correo, auth.Data.Token);

            if (result.StatusCode != 200)
            {
                throw new InvalidOperationException($"{idOperacion} - Error al generar el Otp");
            }

            return true;
        }

        public async Task<bool> OtpValidar(string idOperacion, string idc, string codigo)
        {
            AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
            WrapperGenesysResponse<bool> result = await this.genesysRepository.OtpValidarGenesys(idOperacion, idc, codigo, auth.Data.Token);

            return result.Data;
        }

        public async Task<bool> RecordarUsuario(string idOperacion, string cic, string correo)
        {
            AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
            WrapperGenesysResponse<bool> result = await this.genesysRepository.RecordarUsuario(idOperacion, cic, correo, auth.Data.Token);

            bool response = result.Data;
            return response;
        }

        public async Task<bool> RecordarCuenta(string idOperacion, string cic, string correo, string cuenta)
        {
            AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
            WrapperGenesysResponse<bool> result = await this.genesysRepository.RecordarCuenta(idOperacion, cic, correo, cuenta, auth.Data.Token);

            bool response = result.Data;
            return response;
        }

        public async Task<List<string>> GetCuentas(string idOperacion, string cic)
        {
            AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
            WrapperGenesysResponse<List<string>> result = await this.genesysRepository.GetCuentas(idOperacion, cic, auth.Data.Token);
            return result.Data;
        }

        public async Task<bool> BloquearTarjeta(string idOperacion, string cic, string tarjeta, TipoBloqueo tipoBloqueo)
        {
            AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
            WrapperGenesysResponse<bool> result = await this.genesysRepository.BloquearTarjeta(idOperacion, cic, tarjeta, tipoBloqueo, auth.Data.Token);
            return result.Data;
        }
        public async Task<SaldoResponse> GetSaldo(string idOperacion, string cic, string cuenta)
        {
            AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
            WrapperGenesysResponse<SaldoResponse> result = await this.genesysRepository.ConsultaSaldo(idOperacion, cic, cuenta, auth.Data.Token);
            return result.Data!;
        }

        public async Task<List<MovimientoResponse>> GetMovimientos(string idOperacion, string cic, string cuenta)
        {
            AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
            WrapperGenesysResponse<List<MovimientoResponse>> result = await this.genesysRepository.ConsultaMovimientos(idOperacion, cic, cuenta, auth.Data.Token);
            return result.Data!;
        }

        public async Task<bool> DesbloquearToken(string idOperacion, string cic)
        {
            try
            {
                WrapperBasS<ListTokensInformation> result = await this.genesysRepository.DesbloquearToken(idOperacion, cic);
                if (result.State == "000")
                    return true;
                return false;
            }
            catch (Exception ex)
            {
                Log.Error("ERROR EN SERVICIO", ex);
                return false;
            }
        }

        public async Task<List<ResponseTransferNumber>> AchStateTransfer(string idOperacion, string cic, string amount, string type, string direction, string transferTime, BankEntity origin, BankEntity destiny)
        {
            try
            {
                AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
                List<ResponseTransferNumber> response = await this.genesysRepository.AchStateTransfer("", cic, amount, type, direction, transferTime, origin, destiny, auth.Data.Token);
                return response;
            }
            catch (Exception e)
            {
                Log.Error("ERROR EN SERVICIO", e);
                return new();
            }
        }

        public async Task<List<ResponseBankList>> AchStateBankList(string idOperacion)
        {
            try
            {
                AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
                List<ResponseBankList> bankLists = await this.genesysRepository.AchStateBankList(idOperacion, auth.Data.Token);
                return bankLists;
            }
            catch (Exception e)
            {
                Log.Error("ERROR EN SERVICIO", e);
                return new();
            }
        }

        public async Task<ResponseTransferNumber?> AchStateTransferNumber(string idOperacion, string transferNumberm, string type, string direction)
        {
            try
            {
                AuthenticationResponse auth = await this.genesysRepository.AuthGenesys(idOperacion);
                ResponseTransferNumber? response = await this.genesysRepository.AchStateTransferNumber("", transferNumberm, type, direction, auth.Data.Token);
                return response;
            }
            catch (Exception e)
            {
                Log.Error("ERROR EN SERVICIO", e);
                return null;
            }
        }
    }
}
