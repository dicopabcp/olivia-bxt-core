using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using OLIVIA.CORE.MODELS.CONFIG;
using OLIVIA.CORE.REPOSITORY;
using OLIVIA.CORE.SERVICE.Interfaces;
using OLIVIA.CORE.SERVICE.Service;
using OLIVIA.CORE.SERVICES;


namespace OLIVIA.CORE.SERVICE
{
    public static class Extension
    {
        public static IServiceCollection AddServicesOliviaBxt(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IChatBotService, ChatBotService>();
            services.AddScoped<IEncuestaService, EncuestaService>();
            services.AddScoped<IMessagesService, MessagesService>();
            services.AddScoped<ISorterService, SorterService>();
            services.AddScoped<IMetaDataService, MetaDataService>();
            services.AddScoped<IFlowService, FlowService>();
            services.AddScoped<ISesionService, SesionService>();
            OliviaConfig oliviaConfig = new();
            configuration.GetSection("OliviaConfig").Bind(oliviaConfig);
            services.AddScoped<IGenesysService, GenesysService>();
            services.AddScoped<ICoreBancarioService, CoreBancarioService>();
            services.AddScoped<IEncuestaService, EncuestaService>();
            services.AddScoped<IWhatsappService, WhatsappService>();
            services.AddScoped<IRagService, RagService>();
            services.AddScoped<IWppFlowService, WppFlowService>();
            services.AddMemoryCache();
            services.AddScoped<ICacheService, CacheService>();
            services.AddRepositoryOliviaBxt();
            return services;
        }
    }
}
