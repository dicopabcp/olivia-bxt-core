namespace CROSS.DATABASES.REDDIS
{
    public interface IManagerDataBaseRedis
    {
        public Task<bool> SetHash(object obj, string collection, int ttl = 0);
        public Task<T> GetHash<T>(string key) where T : class;
        public Task RemoveAsync(string key);
        public Task<string> GetStringAsync(string key);
        public Task<bool> SetStringAsync(string key, string value, int expiry);
        public Task<bool> UpdateTtlStringAsync(string key, int expiry);


    }
}
