namespace CROSS.DATABASES.REDDIS
{
    public class DBOptionItems
    {
        public string Name { get; set; } = string.Empty;

        public string Server { get; set; } = string.Empty;

        public string DataBase { get; set; } = "0";

        public string Port { get; set; } = string.Empty;

        public string User { get; set; } = string.Empty;

        public string Password { get; set; } = string.Empty;
    }
}
