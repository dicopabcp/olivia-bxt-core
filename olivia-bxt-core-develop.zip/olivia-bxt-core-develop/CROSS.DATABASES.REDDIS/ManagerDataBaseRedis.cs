using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using StackExchange.Redis;
namespace CROSS.DATABASES.REDDIS
{

    public class ManagerDataBaseRedis :IManagerDataBaseRedis
    {
        private readonly IDatabase db;

        public ManagerDataBaseRedis(IConfiguration configuration)
        {
            DBOptions dBOption = new ();
            configuration.GetSection("database").Bind(dBOption);
            DBOptionItems item = dBOption.Connections.First(x => x.Name == "OLIVIA_BXT_REDIS");
            ConnectionMultiplexer redis = ConnectionMultiplexer.Connect($"{item.Server}:{item.Port},abortConnect=false");
            this.db = redis.GetDatabase(int.Parse(item.DataBase));

        }

        public async Task<string> GetStringAsync(string key)
        {
            try
            {
                RedisValue response = await db.StringGetAsync(key);
                return response == RedisValue.Null? string.Empty : response!;
            }
            catch (Exception)
            {
                return string.Empty;
            }

        }
        public async Task<bool> SetStringAsync(string key, string value, int expiry)
        {
            try
            {
                return await db.StringSetAsync(key, value, expiry: TimeSpan.FromSeconds(expiry));
            }
            catch (Exception)
            {
                return false;
            }

        }

        public async Task<bool> UpdateTtlStringAsync(string key, int expiry)
        {
            try
            {
                return await db.KeyExpireAsync(key, expiry: TimeSpan.FromSeconds(expiry));
            }
            catch (Exception)
            {
                return false;
            }

        }

        public async Task<bool> SetHash(object obj, string collection, int ttl = 0)
        {
            try
            {
                string data = JsonConvert.SerializeObject(obj);
                if(ttl>0)
                    return await db.StringSetAsync(collection, data, expiry: TimeSpan.FromSeconds(ttl));
                else
                    return await db.StringSetAsync(collection, data);
            }
            catch (Exception)
            {
                return false;
            }

        }

        public async Task<T?> GetHash<T>(string key) where T : class 
        {
            try
            {
                RedisValue response = await db.StringGetAsync(key);
                if (response == RedisValue.Null)
                    return null;
                return JsonConvert.DeserializeObject<T>(response!);
            }
            catch (Exception)
            {
                return default(T);
            }

        }
        public async Task RemoveAsync(string key)
        {
            await db.KeyDeleteAsync(key);
        }
    }
}
