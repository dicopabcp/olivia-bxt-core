using CROSS.DATABASES.REDDIS;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using StackExchange.Redis;

namespace CROSS.DATABASE
{

    public static class Extension
    {
        public static IServiceCollection AddDataBaseRedis(this IServiceCollection services)
        {
            services.AddSingleton<IManagerDataBaseRedis, ManagerDataBaseRedis>();
            return services;
        }
    }

}
