namespace OLIVIA.CORE.MODEL.CONFIG
{
    public class AzureOpenAiConfig
    {
        public string BaseUrl  { get; set; } = string.Empty;
        public string ApiKey { get; set; } = string.Empty;
        public List<Prompts> Prompts { get; set; } = new();
    }
    public class Prompts
    {
        public string Valor { get; set; } = string.Empty ;
        public string Clave { get; set; } = string.Empty ;
    }
}
