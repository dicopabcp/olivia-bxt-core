namespace OLIVIA.CORE.MODELS.CONFIG
{
    public class AppConfig
    {
        public string Name { get; set;}
        public int Document { get; set; }
        public int Area { get; set; }
    }
}
