namespace OLIVIA.CORE.MODELS.CONFIG
{
    public class AuthConfig
    {
        public string Name { get; set; } = string.Empty;
        public string Channel { get; set; } = string.Empty;
        public string User { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }
}
