namespace OLIVIA.CORE.MODEL.CONFIG
{
    public class ConfigMessages
    {
        public string Key { get; set; }
        public string Value { get; set; }
        public List<string> Buttons { get; set; } = new List<string>();
        public List<MultimediaMessage> Multimedia { get; set; } = new List<MultimediaMessage>();
    }

    public class MultimediaMessage
    {
        public string Caption { get; set; }

        public string Link { get; set; }
    }
}
