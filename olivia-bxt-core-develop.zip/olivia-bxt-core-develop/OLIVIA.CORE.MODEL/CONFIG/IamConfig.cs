namespace OLIVIA.CORE.MODEL.CONFIG
{
    public class IamConfig
    {
            public string User { get; set; } = string.Empty;

            public string Password { get; set; } = string.Empty;

            public string PublicToken { get; set; } = string.Empty;

            public string Channel { get; set; } = string.Empty;

            public string AppUserId { get; set; } = string.Empty;
    }
}
