namespace OLIVIA.CORE.MODEL.CONFIG
{
    public class ApiRestConfig
    {
        public string Name { get; set; }
        public string BaseUrl { get; set; }
        public List<Method> Methods { get; set; }
    }

    public class Method
    {
        public string Name { get; set; }
        public string Path { get; set; }
    }

}
