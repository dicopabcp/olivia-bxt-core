namespace OLIVIA.CORE.MODELS.CONFIG
{
    public class OliviaConfig
    {
        public int ALLOW_SURVEY_MONTH { get; set; }
        public int DAYS_WAITING_FOR_SENT_SURVEY { get; set; }
        public bool FlagWppFlowGS { get; set; }
        public int DelayWppFlowsGS { get; set; }
        public bool MockGenesys { get; set; }
        public bool NotificacionWpp { get; set; }
        public string DestinationAccount { get; set; }
        public string MensajeDeDeflexion { get; set; }
        public List<string> MensajeDerivacionAgente { get; set; }
        public int TTL_ENCUESTA { get; set; }
        public int TTL_SESION { get; set; }
        public int TTL_AGENTE { get; set; }
        public int DelayMultimensajesInicial { get; set; }
        public int DelayMultimensajes { get; set; }
        public string LimiteDolares { get; set; }
        public bool MensajeContingencia { get; set; }
        public bool Debug { get; set; }
        public string IpServer { get; set; }
        public bool ActivarTarjeta { get; set; }
        public string IdBCP { get; set; }
        public List<ListMessage> AchBankList { get; set; } = new List<ListMessage>();
    }

    public class ListMessage
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public string Identifier { get; set; }
        public bool Visible { get; set; }
        public List<string> Tags { get; set; } = new List<string>();
    }
}
