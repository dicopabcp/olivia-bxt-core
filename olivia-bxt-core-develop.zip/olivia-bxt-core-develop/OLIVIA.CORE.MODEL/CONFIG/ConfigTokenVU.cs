namespace OLIVIA.CORE.MODEL.CONFIG
{
    public class ConfigTokenVU
    {
        public string UsernameToken { get; set; } = string.Empty;
        public string PasswordToken { get; set; } = string.Empty;
        public string Channel { get; set; } = string.Empty;
        public string DomainUser { get; set; } = string.Empty;
        public string PublicToken { get; set; } = string.Empty;
        public string AppUserId { get; set; } = string.Empty;
        public string Identifier { get; set; } = string.Empty;
        public string Device { get; set; } = string.Empty;
        public string Identify { get; set; } = string.Empty;
    }
}
