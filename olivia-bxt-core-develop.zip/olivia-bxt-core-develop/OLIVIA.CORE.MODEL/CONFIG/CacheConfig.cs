namespace OLIVIA.CORE.MODEL.CONFIG
{
    public class CacheConfig
    {
        public int AbsoluteExpirationRelativeToNowMinutes { get; set; }
        public int SlidingExpirationMinutes { get; set; }
    }
}
