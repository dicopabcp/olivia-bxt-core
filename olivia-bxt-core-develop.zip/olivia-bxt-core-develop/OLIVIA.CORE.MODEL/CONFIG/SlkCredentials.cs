namespace OLIVIA.CORE.MODELS.CONFIG
{
    public class SlkCredentials
    {
        public string User { get; set; } = string.Empty;

        public string Password { get; set; } = string.Empty;

        public string IdModuleConsulta { get; set; } = string.Empty;

        public string IdModulePost { get; set; } = string.Empty;

        public string PublicToken { get; set; } = string.Empty;

        public string Channel { get; set; } = string.Empty;

        public string AppUserId { get; set; } = string.Empty;

        public string AccessKey { get; set; } = string.Empty;

        public string SecretKey { get; set; } = string.Empty;

        public string SourceChannel { get; set; } = string.Empty;

        public string TpkSource { get; set; } = string.Empty;

        public string Terminal { get; set; } = string.Empty;

        public bool Prod { get; set; } = true;
    }
}
