namespace OLIVIA.CORE.MODEL.DB_MODEL.REGISTROPRUEBAVIDA
{
    // Mapea el resultset de [wpp].[WPP_REGISTRO_PRUEBA_VIDA_GetByCelular] (BD_WHATSAPP). Ver Plan Maestro v3, seccion 7.1.
    public class RegistroPruebaVidaEntity
    {
        public string Idc { get; set; } = string.Empty;
        public string Complemento { get; set; } = string.Empty;
        public string Celular { get; set; } = string.Empty;
        public string? IdCliente { get; set; }
        public bool Registrado { get; set; }
        public string? CarnetAnversoRef { get; set; }
        public string? CarnetReversoRef { get; set; }
        public string? SelfieRef { get; set; }
        public string? WppSesionId { get; set; }
        public DateTime Fecha { get; set; }
        public TimeSpan Hora { get; set; }
    }

    // Parametros de [wpp].[WPP_REGISTRO_PRUEBA_VIDA_InsertUpdate]. Las propiedades nullable quedan en null
    // cuando no corresponde sobrescribirlas (el SP las conserva via COALESCE).
    public class RegistroPruebaVidaUpsertRequest
    {
        public string Idc { get; set; } = string.Empty;
        public string Complemento { get; set; } = "00";
        public string Celular { get; set; } = string.Empty;
        public string? IdCliente { get; set; }
        public bool? Registrado { get; set; }
        public string? CarnetAnversoRef { get; set; }
        public string? CarnetReversoRef { get; set; }
        public string? SelfieRef { get; set; }
        public string? WppSesionId { get; set; }
    }
}
