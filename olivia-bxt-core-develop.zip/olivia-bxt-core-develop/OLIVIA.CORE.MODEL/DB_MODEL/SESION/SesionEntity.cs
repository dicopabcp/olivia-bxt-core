using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using OLIVIA.CORE.MODEL.CONST;
namespace OLIVIA.CORE.MODEL
{
    public class SesionEntity
    {
        [BsonId]
        [BsonElement("_id")]
        public ObjectId _id { get; set; }
        [BsonElement("user")]
        public string Usuario { get; set; }
        [BsonElement("state")]
        public EstadoSesion Estado { get; set; }
        [BsonElement("topic")]
        public string Topic { get; set; }
        [BsonElement("attempt_topic")]
        public int IntentosTopico { get; set; } = 0;
        [BsonElement("subtopico")]
        public string SubTopic { get; set; }
        [BsonElement("reminder")]
        public bool Recordatorio { get; set; } = false;
        [BsonElement("messages")]
        public List<MessagesSesionEntity> Messages { get; set; }
        [BsonElement("metadata")]
        public List<Metadata> Metadata { get; set; }
        [BsonElement("current_rag")]
        public Rag ActiveRag { get; set; }
        [BsonElement("rags")]
        public List<Rag> Rags { get; set; }
        [BsonElement("list_rags")]
        public List<Rag> ListRags { get; set; }
        [BsonElement("survey")]
        public Encuesta? Encuesta { get; set; } = null;
        [BsonElement("create_date")]
        public DateTime CreateDate { get; set; } = DateTime.Now;
        [BsonElement("update_date")]
        public DateTime? UpdateDate { get; set; } = null;
        [BsonElement("agent_date")]
        public DateTime? AgenteDate { get; set; } = null;
        [BsonElement("sumary_flow")]
        public string DetalleFlujo { get; set; } = string.Empty;
        [BsonElement("sumary_sesion")]
        public string DetalleSesion { get; set; } = string.Empty;
        [BsonElement("current_flow")]
        public Flow? ActiveFlow { get; set; } = null;
        [BsonElement("list_flow")]
        public List<Flow> Flows { get; set; } = new ();

        [BsonElement("contador_multimensaje")]
        public int Multimensaje { get; set; } = 0;

        // Capa 2 del gating de identidad de 2 niveles (Plan Maestro v3, seccion 7.2): sesion ya autenticada
        // dentro de la ventana TTL_SESION (distinto de WPP_REGISTRO_PRUEBA_VIDA.REGISTRADO, que es persistente).
        [BsonElement("autenticado")]
        public bool Autenticado { get; set; } = false;
        [BsonElement("fecha_autenticacion")]
        public DateTime? FechaAutenticacion { get; set; } = null;
    }

    public class MessagesSesionEntity
    {
        [BsonElement("_id")]
        public ObjectId _id { get; set; } = ObjectId.GenerateNewId();
        [BsonElement("role")]
        public string Role { get; set; }
        [BsonElement("class")]
        public string Class { get; set; } = string.Empty;
        [BsonElement("message")]
        public string Message { get; set; }
        [BsonElement("create_date")]
        public DateTime CreateDate { get; set; } = DateTime.Now;
    }

    public class Metadata
    {
        [BsonElement("key")]
        public string Clave { get; set; } = string.Empty;
        [BsonElement("value")]
        public string Valor { get; set; } = string.Empty;
        [BsonElement("state")]
        public string Estado { get; set; } = string.Empty;
        [BsonElement("type")]
        public string Tipo { get; set; } = string.Empty;
        [BsonElement("attempt")]
        public int Intentos { get; set; } = 0;
    }

    public class Encuesta
    {
        [BsonElement("_id")]
        public ObjectId _id { get; set; } = ObjectId.GenerateNewId();
        [BsonElement("user")]
        public string Usuario { get; set; }
        [BsonElement("response")]
        public int Respuesta { get; set; } = 0;
        [BsonElement("survey")]
        public EstadoEncuesta Estado { get; set; } = EstadoEncuesta.CREADA;
        [BsonElement("error")]
        public string Error { get; set; } = "";
        [BsonElement("create_date")]
        public DateTime CreateDate { get; set; } = DateTime.Now;
        [BsonElement("finish_date")]
        public DateTime FinishDate { get; set; } = DateTime.Now;
    }

    public class Rag
    {
        [BsonElement("_id")]
        public ObjectId _id { get; set; } = ObjectId.GenerateNewId();
        [BsonElement("useful")]
        public bool? Util { get; set; } = null;
        [BsonElement("state")]
        public EstadoRag Estado { get; set; }
        [BsonElement("response")]
        public string Respuesta { get; set; } = string.Empty;
        [BsonElement("attempt")]
        public int Intentos { get; set; } = 0;

    }
    public class Flow
    {
        [BsonElement("_id")]
        public ObjectId _id { get; set; } = ObjectId.GenerateNewId();
        [BsonElement("topic")]
        public string Topic { get; set; } = string.Empty;
        [BsonElement("state")]
        public string State{ get; set; }
        [BsonElement("current_step")]
        public string CurrentStep { get; set; } = string.Empty;
        [BsonElement("details_step")]
        public string DetailsStep{ get; set; } = string.Empty;
        [BsonElement("create_date")]
        public DateTime CreateDate { get; set; } = DateTime.Now;
        [BsonElement("finish_date")]
        public DateTime FinishDate { get; set; } = DateTime.Now;
    }

}
