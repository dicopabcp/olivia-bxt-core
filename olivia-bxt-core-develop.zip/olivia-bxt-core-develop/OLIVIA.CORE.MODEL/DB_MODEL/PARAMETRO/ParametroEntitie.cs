namespace OLIVIA.CORE.MODEL.DB_MODEL.PARAMETRO
{
    public class ParametroEntitie
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Mensaje { get; set; } = string.Empty;
        public bool Enabled { get; set; }
        public string UsuarioRegistro { get; set; } = string.Empty;
        public DateTime FechaRegistro { get; set; }
        public string UsuarioModificacion { get; set; } = string.Empty;
        public DateTime FechaModificacion { get; set; }
    }
}
