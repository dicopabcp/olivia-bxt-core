namespace OLIVIA.CORE.MODEL.UTILS
{
    public static class UtilsOlivia
    {
        public static string ReemplazarCaracteres(string cadena, int a, int b)
        {
            // Verifica que los valores de a y b no excedan la longitud de la cadena
            if (a + b > cadena.Length)
            {
                return new string('X', cadena.Length);
            }

            // Reemplaza los caracteres intermedios con 'X'
            string parteInicial = cadena.Substring(0, a);
            string parteFinal = cadena.Substring(cadena.Length - b);
            string parteIntermedia = new string('X', cadena.Length - a - b);

            return parteInicial + parteIntermedia + parteFinal;
        }
    }
}
