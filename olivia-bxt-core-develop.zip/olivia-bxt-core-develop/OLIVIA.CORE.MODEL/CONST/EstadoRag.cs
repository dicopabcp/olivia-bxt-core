namespace OLIVIA.CORE.MODEL.CONST
{
    public enum EstadoRag
    {
        ACTIVO = 17,
        ENCUESTA = 18,
        SIN_DATA = 19,
        ERROR = 20,
        CERRADO = 21
    }
}
