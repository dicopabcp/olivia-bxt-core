namespace OLIVIA.CORE.MODEL.CONST
{
    public enum EstadoSesion
    {
        CERRADO = 1,
        AGENTE = 2,
        ENCUESTA = 3,
        SIN_TOPICO = 4,
        CON_TOPICO = 5,
        CONSULTA_TOPICO = 6,
        RAG = 7,
        ABANDONADO = 8,
        DEFLEXION = 23,
    }
}
