namespace OLIVIA.CORE.MODEL
{
    public enum MessageType
    {
        HumanMessage,
        IaMessage,
    }
}
