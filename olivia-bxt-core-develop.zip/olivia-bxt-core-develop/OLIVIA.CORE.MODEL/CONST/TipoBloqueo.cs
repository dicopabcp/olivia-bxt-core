namespace OLIVIA.CORE.MODEL.CONST
{
    public enum TipoBloqueo
    {
        NINGUNO = 0,
        /// <summary>Extravío o robo</summary>
        EXTRAVIO_ROBO = 1,

        /// <summary>Retención en cajero</summary>
        RETENCION_CAJERO = 2,

        /// <summary>Fraude</summary>
        FRAUDE = 3,
    }
}
