namespace OLIVIA.CORE.MODEL.CONST
{
    public enum EstadoEncuesta
    {
        ERROR = 9,
        CREADA = 10,
        RECHAZADA = 11,
        ACTIVA = 12,
        CERRADA = 13,
        COMPLETADA = 14,
        ABANDONADO = 15,
        POSPUESTA = 16,
        ESPERA_RESPUESTA_TEXTO = 22,
    }
}
