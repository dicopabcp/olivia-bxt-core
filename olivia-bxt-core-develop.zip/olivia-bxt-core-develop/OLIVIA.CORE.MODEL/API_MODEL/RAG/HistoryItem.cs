namespace OLIVIA.CORE.MODEL
{
    public class HistoryItem
    {
        public MessageType Type { get; set; }
        public string Message { get; set; } = string.Empty;
    }
}
