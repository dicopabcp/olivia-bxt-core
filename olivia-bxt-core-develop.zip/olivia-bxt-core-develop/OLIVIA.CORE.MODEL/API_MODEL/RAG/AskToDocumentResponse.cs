namespace OLIVIA.CORE.MODEL
{
    public class AskToDocumentResponse
    {
        public string Answer { get; set; }
        public bool NeedAgent { get; set; }
    }
}
