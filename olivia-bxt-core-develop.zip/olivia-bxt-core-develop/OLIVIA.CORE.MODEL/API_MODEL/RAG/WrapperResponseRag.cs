namespace OLIVIA.CORE.MODEL
{
    public class WrapperResponseRag<T>
    {
        public T Data { get; set; }

        public string Message { get; set; }

        public int StatusCode { get; set; }
    }
}
