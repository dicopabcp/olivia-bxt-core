namespace OLIVIA.CORE.MODEL
{
    public class AskToDocumentRequest
    {
        public string Question { get; set; } = string.Empty;
        public List<HistoryItem> History { get; set; } = new List<HistoryItem>();
    }


}
