namespace OLIVIA.CORE.MODEL.API_MODEL.SORTER
{
    public class WrapperResponseSorter<T>
    {
        public T Data { get; set; }

        public string Message { get; set; }

        public string StatusCode { get; set; }
    }
}
