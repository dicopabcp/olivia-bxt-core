namespace OLIVIA.CORE.MODEL.API_MODEL.SORTER
{
    public class ResponseSorter
    {
        public string Label { get; set; }
        public float Pred { get; set; }
    }
}
