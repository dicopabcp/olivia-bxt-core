namespace OLIVIA.CORE.MODEL.DTO.Azure
{
    public class Message
    {
        public string Content { get; set; }
        public string Role { get; set; }
    }
}
