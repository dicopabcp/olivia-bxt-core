namespace OLIVIA.CORE.MODEL.DTO.Azure
{
    public class Choice
    {
        public Message Message { get; set; }
    }
}
