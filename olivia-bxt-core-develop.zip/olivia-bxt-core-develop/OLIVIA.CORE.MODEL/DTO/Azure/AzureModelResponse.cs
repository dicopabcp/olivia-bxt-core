namespace OLIVIA.CORE.MODEL.DTO.Azure
{
    public class Azureresponse
    {
        public Choice[] Choices { get; set; }
    }
}
