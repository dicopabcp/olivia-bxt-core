namespace OLIVIA.CORE.MODEL
{
    public class ResponseChatBot
    {
        public string Respuesta { get; set; } = string.Empty;

        public bool EnviarGenesys { get; set; } = false;

    }
}
