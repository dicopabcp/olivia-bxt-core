using System.ComponentModel.DataAnnotations;

namespace OLIVIA.CORE.MODEL
{
    public class RequestChatBot
    {
        [Required]
        public string Usuario { get; set; }

        public string? Mensaje { get; set; }

    }
}
