namespace OLIVIA.CORE.MODEL.DTO.WppFlows
{
    public class WppFlowResponse
    {
        public string Mensaje { get; set; }
        public bool Expired { get; set; }
        public bool Success { get; set; }
        public bool EnviarGenesys { get; set; }

        // Datos de la siguiente pantalla del Flow (ej. cuentas consultadas, cuenta creada); null para flujos que no lo requieren (ej. Rekognition).
        public object? Data { get; set; }
    }
}
