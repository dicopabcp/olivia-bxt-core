namespace OLIVIA.CORE.MODEL.DTO.WppFlows
{
    public class WppFlowRequest
    {
        public string SesionId { get; set; }

        public string Usuario { get; set; }

        public string? Data { get; set; }

        public string Flow { get; set; }
    }

    public class WppFlowIdcCliente
    {
        public string Carnet { get; set; }
        public string Complemento { get; set; } = "00";
    }

    public class WppFlowEncuesta
    {
        public string score_survey { get; set; } = string.Empty;

        public string comments { get; set; } = string.Empty;

        public string celular { get; set; } = string.Empty;

        public string wppSesionId { get; set; } = string.Empty;
    }

    public class WppFlowSelfi
    {
        public string Base64 { get; set; }
    }

    public class WppFlowDocumentoId
    {
        public string Base64 { get; set; }
    }

    public class WppFlowPropositoCuenta
    {
        public string PropositoCuenta { get; set; }
    }

    public class WppFlowContactoCorreo
    {
        public string Correo { get; set; }
    }

    public class WppFlowOtpCorreo
    {
        public string Otp { get; set; }
    }

    public class WppFlowCuentaSeleccionada
    {
        public string CuentaReferencial { get; set; }
    }

    public class WppFlowUsuarioBm
    {
        public string UsuarioBm { get; set; }
    }

    public class WppFlowClaveBm
    {
        public string ClaveBm { get; set; }
        public string ConfirmarClaveBm { get; set; }
    }

    public class WppFlowValidarClaveBm
    {
        public string ClaveBm { get; set; }
    }

    // Pantalla CSM_DATOS_CI (consulta_saldos_validacion_identidad.json): a diferencia de WppFlowIdcCliente,
    // esta pantalla tambien captura/confirma el celular del cliente (ver Plan Maestro v3, ajuste 3 / seccion 7.1).
    public class WppFlowIdcClienteCelular
    {
        public string Carnet { get; set; }
        public string Complemento { get; set; } = "00";
        public string Celular { get; set; }
    }

    // Pantalla CSM_ELEGIR_MOVIMIENTO (consulta_saldos_movimientos.json).
    public class WppFlowMovimientoSeleccionado
    {
        public string Movimiento { get; set; }
    }
}
