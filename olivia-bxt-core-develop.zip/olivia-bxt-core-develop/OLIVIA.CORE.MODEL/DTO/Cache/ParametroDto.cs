using System.ComponentModel.DataAnnotations;

namespace OLIVIA.CORE.MODEL.DTO.Cache
{
    public class ParametroDto
    {
        [Required]
        public string Nombre { get; set; } = string.Empty;
        public string Mensaje { get; set; } = string.Empty;
        [Required]
        public bool Enabled { get; set; }
        [Required]
        public string Usuario { get; set; } = string.Empty;
    }
}
