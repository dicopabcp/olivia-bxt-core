namespace OLIVIA.CORE.MODEL.DTO.Genesys
{
    public class MovimientoResponse
    {
        public string Fecha { get; set; } = string.Empty;  
        public string Glosa { get; set; } = string.Empty;  
        public double Monto { get; set; } = 0.0;  
    }
}
