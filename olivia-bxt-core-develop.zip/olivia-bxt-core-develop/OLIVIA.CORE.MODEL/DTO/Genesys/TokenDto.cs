namespace OLIVIA.CORE.MODEL.DTO.Genesys
{
    public class WrapperBasS<T> where T : class
    {
        public string State { get; set; }
        public string Message { get; set; }
        public T Data { get; set; }
    }
    public class ListTokensInformation
    {
        public List<ItemTokensInformation> TokensInformation { get; set; }
    }

}
