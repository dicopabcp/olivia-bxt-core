namespace OLIVIA.CORE.MODEL.DTO.Genesys
{
    public class AuthenticationRequest
    {
        public string Canal { get; set; } = string.Empty;
        public string Contrasena { get; set; } = string.Empty;
        public string Token { get; set; } = string.Empty;
        public string Usuario { get; set; } = string.Empty;
    }
}