namespace OLIVIA.CORE.MODEL.DTO.Genesys
{
    public class WrapperGenesysResponse<T>
    {
        public T? Data { get; set; }

        public string Message { get; set; }

        public int StatusCode { get; set; }
        
        public string State { get; set; }
    }
}
