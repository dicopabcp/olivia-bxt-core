using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OLIVIA.CORE.MODEL.DTO.Genesys;

public class ItemTokensInformation
{
    public string OperatingSystem { get; set; } = string.Empty;
    public string IpLocation { get; set; } = string.Empty;
    public string Identifier { get; set; } = string.Empty;
    public string Device { get; set; } = string.Empty;
    public string Channel { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public MobileToken MobileToken { get; set; } = new MobileToken();
}
public class MobileToken
{
    public string Type { get; set; } = string.Empty;
    public string Serie { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string ExpirationDate { get; set; } = string.Empty;
    public string AffiliationDate { get; set; } = string.Empty;
    public bool IsPhysical { get; set; } = false;
}