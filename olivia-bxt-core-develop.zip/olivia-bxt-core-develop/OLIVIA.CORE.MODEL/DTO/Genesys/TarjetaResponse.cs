namespace OLIVIA.CORE.MODEL.DTO.Genesys
{
    public class TarjetaResponse
    {
        public List<string> Credito { get; set; } = new List<string>();

        public List<string> Debito { get; set; } = new List<string>();
    }
}
