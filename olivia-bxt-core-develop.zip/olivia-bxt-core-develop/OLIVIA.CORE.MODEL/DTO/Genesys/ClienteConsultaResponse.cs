namespace OLIVIA.CORE.MODEL.DTO.Genesys
{
    public class ClienteConsultaResponse
    {
        public string Idc { get; set; } = string.Empty;
        public string Cic { get; set; } = string.Empty;
        public string Nombre { get; set; } = string.Empty;
        public string Paterno { get; set; } = string.Empty;
        public string Materno { get; set; } = string.Empty;
        public string FechaNacimiento { get; set; } = string.Empty;
        public string ReferenciaPersonal { get; set; } = string.Empty;
        public string Celular { get; set; } = string.Empty;
        public string Correo { get; set; } = string.Empty;
    }
}
