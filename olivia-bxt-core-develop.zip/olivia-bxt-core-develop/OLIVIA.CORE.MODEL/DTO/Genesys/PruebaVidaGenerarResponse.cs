namespace OLIVIA.CORE.MODEL.DTO.Genesys
{
    public class PruebaVidaGenerarResponse
    {
        public string Url { get; set; } = string.Empty;
        public string SessionId { get; set; } = string.Empty;
        public string FechaHora { get; set; } = string.Empty;
    }

    public class PruebaVidaGenerarPasivaResponse
    {
        public string Instruccion { get; set; } = string.Empty;

        public string ImgInstruccion { get; set; } = string.Empty;

        public string SessionID { get; set; } = string.Empty;

        public string FechaHora { get; set; } = string.Empty;
    }

    public class PruebaVidaValidarPasivaResponse
    {
        public bool Success { get; set; }

        public string Message { get; set; } = string.Empty;
    }
}
