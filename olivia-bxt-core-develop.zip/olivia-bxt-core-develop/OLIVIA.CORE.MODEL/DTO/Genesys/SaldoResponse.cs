namespace OLIVIA.CORE.MODEL.DTO.Genesys
{
    public class SaldoResponse
    {
        public double Saldo { get; set; } = 0.0;
        public string Moneda { get; set; } = "";
    }
}
