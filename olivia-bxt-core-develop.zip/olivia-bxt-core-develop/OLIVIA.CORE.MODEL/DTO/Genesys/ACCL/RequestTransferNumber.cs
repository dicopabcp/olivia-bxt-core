namespace OLIVIA.CORE.MODEL.DTO.Genesys.ACCL
{
    public class RequestTransferNumber
    {
        public string TransferNumber { get; set; }
        public string Type { get; set; }
        public string Direction { get; set; }
    }
}