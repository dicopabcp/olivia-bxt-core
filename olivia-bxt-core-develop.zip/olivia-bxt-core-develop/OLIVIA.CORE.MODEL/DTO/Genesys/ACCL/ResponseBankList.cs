namespace OLIVIA.CORE.MODEL.DTO.Genesys.ACCL
{
    public class ResponseBankList
    {
        public string Name { get; set; }
        public string KeyName { get; set; }
    }
}