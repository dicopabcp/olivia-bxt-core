namespace OLIVIA.CORE.MODEL.DTO.Genesys.ACCL
{
    public class ResponseTransferNumber
    {
        public string SenderTransferNumber { get; set; }
        public string ResponseCodeAch { get; set; }
        public string ResponseCodeCamera { get; set; }
        public string OriginBank { get; set; }
        public string DestinyBank { get; set; }
    }
}