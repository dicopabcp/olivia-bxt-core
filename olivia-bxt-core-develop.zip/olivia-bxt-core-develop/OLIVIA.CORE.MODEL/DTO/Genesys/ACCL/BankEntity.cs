namespace OLIVIA.CORE.MODEL.DTO.Genesys.ACCL
{
    public class BankEntity
    {
        public string Account { get; set; }
        public string Bank { get; set; }
    }
}
