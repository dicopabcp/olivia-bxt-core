namespace OLIVIA.CORE.MODEL.DTO.Genesys.ACCL
{
    public class RequestTransferNumberExtended
    {
        public BankEntity Origin { get; set; }
        public BankEntity Destiny { get; set; }
        public float Amount { get; set; }
        public string Type { get; set; }
        public string Direction { get; set; }
        public string TransferTime { get; set; }

    }
}