namespace OLIVIA.CORE.MODEL.DTO.Genesys
{
    public class AuthenticationResponse
    {
        public DataModel Data { get; set; }
        public MetaModel Meta { get; set; }
    }

    public class DataModel
    {
        public string Token { get; set; }
        public DateTime Expiration { get; set; }
    }

    public class MetaModel
    {
        public string Message { get; set; }
        public int StatusCode { get; set; }
    }
}