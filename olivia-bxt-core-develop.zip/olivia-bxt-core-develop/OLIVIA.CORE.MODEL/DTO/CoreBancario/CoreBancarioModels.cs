namespace OLIVIA.CORE.MODEL.DTO.CoreBancario
{
    // MOCK: DTOs del futuro API de Core Bancario (Plan Maestro WhatsApp v3, pregunta 1 - aun no existe, se simula).
    public class CoreBancarioClienteResponse
    {
        public string Cic { get; set; } = string.Empty;
        public string Nombre { get; set; } = string.Empty;
        public string Paterno { get; set; } = string.Empty;
        public string Materno { get; set; } = string.Empty;
        public string Correo { get; set; } = string.Empty;
        public string Celular { get; set; } = string.Empty;
        public bool TieneBancaMovil { get; set; }
    }

    public class CoreBancarioCuentaResponse
    {
        public string NumeroCuenta { get; set; } = string.Empty;
        public string Tipo { get; set; } = string.Empty;
        public string Descripcion { get; set; } = string.Empty;
    }

    public class CoreBancarioCrearCuentaResponse
    {
        public string NumeroCuenta { get; set; } = string.Empty;
        public string NumeroTarjetaDebito { get; set; } = string.Empty;
        public bool ContratoFirmado { get; set; }
    }
}
