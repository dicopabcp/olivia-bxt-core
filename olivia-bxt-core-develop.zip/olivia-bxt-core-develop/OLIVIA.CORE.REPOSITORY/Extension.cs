using CROSS.DATABASE;
using CROSS.SECRYPT;
using Microsoft.Extensions.DependencyInjection;
using OLIVIA.CORE.REPOSITORY.Interfaces;
using OLIVIA.CORE.REPOSITORY.Repository;

namespace OLIVIA.CORE.REPOSITORY
{
    public static class Extension
    {
        public static IServiceCollection AddRepositoryOliviaBxt(this IServiceCollection services)
        {
            services.AddScoped<IFlowRepository, FlowRepository>();
            services.AddScoped<IEncuestaRepository, EncuestaRepository>();
            services.AddScoped<IMessageRepository, MessageRepository>();
            services.AddScoped<ISorterRepository, SorterGenerativeRepository>();
            services.AddScoped<ISesionRepository, SesionRepository>();
            services.AddScoped<IWhatsAppRepository, WhatsAppRepository>();
            services.AddScoped<IGenesysRepository, GenesysRepository>();
            services.AddScoped<ICoreBancarioRepository, CoreBancarioRepository>();
            services.AddScoped<IEventRepository, EventRepository>();
            services.AddScoped<IRagRepository, RagRepository>();
            services.AddScoped<IParametroRepository, ParametroRepository>();
            services.AddScoped<IRegistroPruebaVidaRepository, RegistroPruebaVidaRepository>();
            services.AddSecrypt();
            services.AddDataBaseRedis();
            services.AddDataBaseMongo();
            services.AddDataBase();
            return services;
        }
    }
}
