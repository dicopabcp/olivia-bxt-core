using CROSS.APIREST;
using CROSS.SECRYPT;
using Microsoft.Extensions.Configuration;
using OLIVIA.CORE.MODEL;
using OLIVIA.CORE.MODEL.CONFIG;

namespace OLIVIA.CORE.REPOSITORY
{
    public class RagRepository : IRagRepository
    {
        private readonly IApiRest apiRest;
        private readonly ApiRestConfig apiRestRagConfig;
        private readonly IamConfig iamConfig;

        public RagRepository(IConfiguration configuration, IManagerSecrypt secrypt, IApiRest apiRest)
        {
            this.apiRest = apiRest;

            List<ApiRestConfig> apiRestConfig = new();
            configuration.GetSection("ApiRest").Bind(apiRestConfig);
            this.apiRestRagConfig = apiRestConfig.FirstOrDefault(x => x.Name == "RAG")!;
            IamConfig iamConfigLocal = new();
            configuration.GetSection("IamCredentials").Bind(iamConfigLocal);
            this.iamConfig = iamConfigLocal;
            this.iamConfig.PublicToken = secrypt.Desencriptar(this.iamConfig.PublicToken);
            this.iamConfig.Password = secrypt.Desencriptar(this.iamConfig.Password);
        }
        public async Task<WrapperResponseRag<AskToDocumentResponse>> RequestToRag(string idOperation, string question, List<HistoryItem> history)
        {
            Method apiRagConfig = this.apiRestRagConfig.Methods.First(x => x.Name == "SEARCH_IN_RAG");
            var request = new
            {
                question,
                history,
            };
            string url = this.apiRestRagConfig.BaseUrl + apiRagConfig.Path;
            List<Tuple<string, string>> lstHeader = new();
            lstHeader.Add(new Tuple<string, string>("Channel", this.iamConfig.Channel));
            lstHeader.Add(new Tuple<string, string>("Token", this.iamConfig.PublicToken));
            lstHeader.Add(new Tuple<string, string>("AppUserId", this.iamConfig.AppUserId));
            WrapperResponseRag<AskToDocumentResponse> response = await apiRest.PostAsync<WrapperResponseRag<AskToDocumentResponse>>(url, request, true, this.iamConfig.User, this.iamConfig.Password, lstHeader);

            return response;
        }
    }
}
