using CROSS.DATABASE;
using CROSS.DATABASES.REDDIS;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using OLIVIA.CORE.MODEL;
using OLIVIA.CORE.MODELS.CONFIG;
using System.Data;
namespace OLIVIA.CORE.REPOSITORY
{
    public class EncuestaRepository : IEncuestaRepository
    {
        private readonly IManagerDataBaseRedis managerDataBaseRedis;
        private readonly IManagerDataBase managerDataBase;
        private readonly OliviaConfig oliviaConfig;
        public EncuestaRepository(IConfiguration configuration, IManagerDataBase managerDataBase, IManagerDataBaseRedis managerDataBaseRedis)
        {
            OliviaConfig olivia = new();
            configuration.GetSection("OliviaConfig").Bind(olivia);
            this.oliviaConfig = olivia;
            this.managerDataBaseRedis = managerDataBaseRedis;
            this.managerDataBase = managerDataBase;
        }

        public async Task<bool> Create(SesionEntity sesion)
        {
            await this.managerDataBaseRedis.UpdateTtlStringAsync($"sesion:{sesion.Usuario}", this.oliviaConfig.TTL_ENCUESTA);
            try
            {
                if (sesion.Encuesta is null) return true;
                List<SqlParameter> parametros = new();
                parametros.Add(new SqlParameter("@ID_VC", sesion.Encuesta._id.ToString()));
                parametros.Add(new SqlParameter("@SESION_IN", sesion._id.ToString()));
                DataTable datatable = await this.managerDataBase.SelectStoredProcedure("OLIVIA_BXT_SQL", "[olivia].[CREATE_ENCUESTA]", parametros);
                return (datatable != null);
            }
            catch (Exception ex)
            {
                //this.managerLogger.Warning("ERROR AL GUARDAR LA ENCUESTA");
                //this.managerLogger.Error(ex);
                return false;
            }
        }

        public async Task<bool> SendEncuesta(string user)
        {
            try
            {
                List<SqlParameter> parametros = new();
                parametros.Add(new("@USUARIO", user));
                parametros.Add(new("@CANTIDAD_ENCUESTAS_PERMITIDAS_MES", oliviaConfig.ALLOW_SURVEY_MONTH));
                parametros.Add(new("@DIAS_ESPERA", oliviaConfig.DAYS_WAITING_FOR_SENT_SURVEY));
                DataTable datatable = await this.managerDataBase.SelectStoredProcedure("OLIVIA_BXT_SQL", "[olivia].[ENVIAR_ENCUESTA]", parametros);
                if (datatable != null && datatable.Rows.Count > 0)
                {
                    int resultado = Convert.ToInt32(datatable.Rows[0]["RESULTADO"]);
                    return resultado == 1;
                }

                return false;
            }
            catch (Exception ex)
            {
                //this.managerLogger.Warning("ERROR AL GUARDAR LOS MENSAJES");
                //this.managerLogger.Error(ex);
                return false;
            }
        }

        public async Task<bool> Update(SesionEntity sesion)
        {
            try
            {
                if (sesion.Encuesta is null) return true;
                List<SqlParameter> parametros = new();
                parametros.Add(new SqlParameter("@ID_VC", sesion.Encuesta._id.ToString()));
                parametros.Add(new SqlParameter("@ESTADO_IN", sesion.Encuesta.Estado));
                parametros.Add(new SqlParameter("@DETALLE_VC", sesion.Encuesta.Error));
                parametros.Add(new SqlParameter("@RESPUESTA_IN", sesion.Encuesta.Respuesta));
                parametros.Add(new SqlParameter("@FECHA_RESPUESTA_DT", sesion.Encuesta.FinishDate));
                DataTable datatable = await this.managerDataBase.SelectStoredProcedure("OLIVIA_BXT_SQL", "[olivia].[UPDATE_ENCUESTA]", parametros);
                return (datatable != null);
            }
            catch (Exception ex)
            {
                //this.managerLogger.Warning("ERROR AL ACTUALIZAR LA ENCUESTA");
                //this.managerLogger.Error(ex);
                return false;
            }
        }
    }
}
