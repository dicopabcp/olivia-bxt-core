using OLIVIA.CORE.MODEL.DTO.CoreBancario;

namespace OLIVIA.CORE.REPOSITORY
{
    // MOCK: simula las respuestas de Core Bancario (crear cuenta, consultar cliente/cuentas, Banca Movil) mientras
    // no exista el API real (Plan Maestro WhatsApp v3, pregunta 1 - "por el momento usaremos un mockup de api").
    public class CoreBancarioRepository : ICoreBancarioRepository
    {
        private static readonly Dictionary<string, CoreBancarioClienteResponse> ClientesMock = new()
        {
            ["01234567"] = new CoreBancarioClienteResponse
            {
                Cic = "900000001",
                Nombre = "Juana",
                Paterno = "Perez",
                Materno = "Lopez",
                Correo = "juana.perez@mock.com",
                Celular = "70000001",
                TieneBancaMovil = true
            },
            ["07654321"] = new CoreBancarioClienteResponse
            {
                Cic = "900000002",
                Nombre = "Carlos",
                Paterno = "Gomez",
                Materno = "Mamani",
                Correo = "carlos.gomez@mock.com",
                Celular = "70000002",
                TieneBancaMovil = false
            }
        };

        public Task<CoreBancarioClienteResponse?> ConsultarCliente(string carnet, string complemento)
        {
            ClientesMock.TryGetValue(carnet, out CoreBancarioClienteResponse? cliente);
            return Task.FromResult(cliente);
        }

        public Task<bool> ValidarOtp(string destino, string codigo)
        {
            return Task.FromResult(!string.IsNullOrWhiteSpace(codigo) && codigo.Length == 6);
        }

        public Task<List<CoreBancarioCuentaResponse>> ConsultarCuentas(string cic)
        {
            List<CoreBancarioCuentaResponse> cuentas = new()
            {
                new CoreBancarioCuentaResponse { NumeroCuenta = "1-2345678-9-0", Tipo = "Cuenta de Ahorro Bs", Descripcion = "Nro. 1-2345678-9-0 (mock)" },
                new CoreBancarioCuentaResponse { NumeroCuenta = "1-2345679-0-1", Tipo = "Cuenta de Ahorro USD", Descripcion = "Nro. 1-2345679-0-1 (mock)" }
            };
            return Task.FromResult(cuentas);
        }

        public Task<bool> ValidarClaveBancaMovil(string cic, string clave)
        {
            return Task.FromResult(clave == "123456");
        }

        public Task<bool> CrearUsuarioBancaMovil(string cic, string usuarioBm, string claveBm)
        {
            return Task.FromResult(true);
        }

        public Task<CoreBancarioCrearCuentaResponse> CrearCuenta(string carnet, string propositoCuenta)
        {
            CoreBancarioCrearCuentaResponse response = new()
            {
                NumeroCuenta = "1-2345678-9-0",
                NumeroTarjetaDebito = "4556********1234",
                ContratoFirmado = true
            };
            return Task.FromResult(response);
        }
    }
}
