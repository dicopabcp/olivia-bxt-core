using CROSS.DATABASE;
using Microsoft.Data.SqlClient;
using OLIVIA.CORE.MODEL;
using System.Data;

namespace OLIVIA.CORE.REPOSITORY
{
    public class MessageRepository : IMessageRepository
    {
        private readonly IManagerDataBase managerDataBase;
        public MessageRepository(IManagerDataBase managerDataBase)
        {
            this.managerDataBase = managerDataBase;
        }
        public async Task<bool> SaveMessages(MessagesSesionEntity messagesSesionEntity, SesionEntity sesion, MessagesSesionEntity? messagesSesionBefore = null)
        {
            try
            {
                List<SqlParameter> parametros = new();
                parametros.Add(new SqlParameter("@ID_VC", messagesSesionEntity._id.ToString()));
                parametros.Add(new SqlParameter("@SESION_VC", sesion._id.ToString()));
                parametros.Add(new SqlParameter("@MENSAJES_VC", messagesSesionEntity.Message));
                parametros.Add(new SqlParameter("@ANTERIOR_MENSAJES_VC", messagesSesionBefore is null ? null : messagesSesionBefore._id.ToString()));
                parametros.Add(new SqlParameter("@ROL_VC", messagesSesionEntity.Role));
                parametros.Add(new SqlParameter("@FECHA_CREACION_DT", messagesSesionEntity.CreateDate));
                DataTable datatable = await this.managerDataBase.SelectStoredProcedure("OLIVIA_BXT_SQL", "[olivia].[CREATE_MENSAJE]", parametros);
                return (datatable != null);
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
