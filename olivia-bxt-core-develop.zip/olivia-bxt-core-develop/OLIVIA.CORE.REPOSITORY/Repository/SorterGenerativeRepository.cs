using CROSS.APIREST;
using CROSS.DATABASE;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using OLIVIA.CORE.MODEL.CONFIG;
using OLIVIA.CORE.MODEL.DTO.Azure;
using Serilog;
using System.Data;

namespace OLIVIA.CORE.REPOSITORY
{
    public class SorterGenerativeRepository : ISorterRepository
    {
        private readonly IManagerDataBase managerDataBase;
        private readonly IApiRest apiRest;
        private readonly Dictionary<PromptType, string> prompts;
        private readonly AzureOpenAiConfig azureConfig;


        public SorterGenerativeRepository(IManagerDataBase managerDataBase, IConfiguration configurationApp, IApiRest apiRest)
        {
            this.apiRest = apiRest;
            this.managerDataBase = managerDataBase;
            AzureOpenAiConfig azureOpenAiConfig = new();
            configurationApp.GetSection("AzureOpenAiConfig").Bind(azureOpenAiConfig);
            this.azureConfig = azureOpenAiConfig;
            this.prompts = azureOpenAiConfig.Prompts.Select(item =>
            {
                Enum.TryParse(item.Clave, out PromptType promptType);
                return new { promptType, item.Valor };
            }).ToDictionary(x => x.promptType, x => x.Valor);

        }

        public async Task<string> RequestToSorterBxT(string message)
        {
            try
            {
                string aiResponse = "";
                aiResponse = await this.SendRequest(message, this.prompts[PromptType.Root]);
                string response = "";
                switch (aiResponse)
                {
                    case string s when s.Contains("BANCA_MOVIL"):
                        response = await this.SendRequest(message, this.prompts[PromptType.BancaMovil]);
                        break;
                    case string s when s.Contains("TARJETAS"):
                        response = await this.SendRequest(message, this.prompts[PromptType.Tarjeta]);
                        break;
                    case string s when s.Contains("CUENTAS"):
                        response = await this.SendRequest(message, this.prompts[PromptType.Cuenta]);
                        break;
                    case string s when s.Contains("TARIFARIO"):
                        response = await this.SendRequest(message, this.prompts[PromptType.Tarifario]);
                        break;
                    case string s when s.Contains("YAPE"):
                        response = "DERIVACION YAPE";
                        break;
                    case string s when s.Contains("ATM"):
                        response = await this.SendRequest(message, this.prompts[PromptType.ATM]);
                        break;
                    case string s when s.Contains("TRANSFERENCIAS"):
                        response = await this.SendRequest(message, this.prompts[PromptType.Transacciones]);
                        break;
                    case string s when s.Contains("UNKNOWN"):
                        response = await this.SendRequest(message, this.prompts[PromptType.Varios]);
                        response = response.Contains("DIRECCIONES") ? "OFICINAS DIRECCIONES" : response;
                        break;
                    default:
                        response = "RAG";
                        break;
                }
                response = response.Contains("UNKNOWN") ? "RAG" : response;
                return ExtraerParte(response);
            }
            catch (Exception ex)
            {
                Log.Error("ERROR EN EL ", ex);
                return "RAG";
            }
        }

        public async Task<string> SendRequest(string request, string system)
        {
            try
            {
                var body = new
                {
                    messages = new List<object>
                    {
                        new {
                        role = "system",
                        content = system,
                        },
                        new {
                        role = "user",
                        content = $"User Input: {request}  Type: ",
                        }
                    },
                    max_tokens = 800,
                    temperature = 1,
                    frequency_penalty = 0,
                    presence_penalty = 0,
                    top_p = 0.95,
                    stop = null as string
                };
                List<Tuple<string, string>> headers = new() {
                    new("api-key", this.azureConfig.ApiKey),
                    new("Ocp-Apim-Subscription-Key", this.azureConfig.ApiKey)
                };
                Azureresponse response = await this.apiRest.PostAsync<Azureresponse>(this.azureConfig.BaseUrl, body, header: headers);
                return response.Choices[0].Message.Content;
            }
            catch (Exception ex)
            {
                Log.Error("ERROR EN EL ", ex);
                return "RAG";
            }
        }

        public async Task SaveReport(string input, string output, string details, string sesion)
        {
            List<SqlParameter> parametros = new();
            parametros.Add(new SqlParameter("@SESION_VC", sesion));
            parametros.Add(new SqlParameter("@INPUT_VC", input));
            parametros.Add(new SqlParameter("@OUTPUT_VC", output));
            parametros.Add(new SqlParameter("@DETAILS_VC", details));
            await this.managerDataBase.SelectStoredProcedure("OLIVIA_BXT_SQL", "[olivia].[CREATE_SORTER]", parametros);
        }
        public static string ExtraerParte(string input)
        {
            string prefix = "Type:";

            if (input.Contains(','))
            {
                input = input.Split(',').First();
            }

            if (input.StartsWith(prefix))
            {
                return input.Substring(prefix.Length).Trim();
            }

            return input;
        }

        public enum PromptType
        {
            Root,
            BancaMovil,
            ATM,
            Cuenta,
            Tarjeta,
            Transacciones,
            Tarifario,
            Yape,
            Varios
        }
    }
}
/*
 * BANCA MOVIL (OK)
    DESBLOQUEO
    DESVINCULACION
    OLVIDO USUARIO
    OLVIDO CONTRASEÑA
    SINCRONIZACION TOKEN 

 * ATM 
    CAJEROS PROBLEMAS
    CAJEROS DIRECCIONES
    
 * CUENTA
    SALDO
    MOVIMIENTOS
    CUENTA BLOQUEADA
    OLIVIDO CUENTA
    NO_RECONOCIDO

 * TARJETAS
    INTERNET
    EXTERIOR
    EXTRAVIO    
    RECHAZOS
    TARIFARIO TASAS
    TARIFARIO COMISIONES 
    LIMITE TRANSACCIONES 

  * TRANSACCIONES
    ERROR TRANSACCIONES
  
    
 * TARIFARIOS
    TARIFARIO TASAS
    TARIFARIO COMISIONES 
    LIMITE TRANSACCIONES 
 
 * YAPE
 
 * UNKNOWN
    OFICINAS DIRECCIONES
    PAGO SERVICIOS
    ADELANTO SUELDO
    GENESYS AGENTE
    SALUDO
    DESPEDIDA
    RAG
*/


