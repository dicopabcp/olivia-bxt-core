using CROSS.APIREST;
using CROSS.SECRYPT;
using Microsoft.Extensions.Configuration;
using OLIVIA.CORE.MODEL.CONFIG;
using OLIVIA.CORE.MODEL.CONST;
using OLIVIA.CORE.MODEL.DTO.Genesys;
using OLIVIA.CORE.MODEL.DTO.Genesys.ACCL;
using OLIVIA.CORE.MODELS.CONFIG;

namespace OLIVIA.CORE.REPOSITORY
{
    public class GenesysRepository : IGenesysRepository
    {
        private readonly IApiRest apiRest;
        private readonly ApiRestConfig apiRestConfig;
        private readonly IamConfig iamConfig;
        private readonly ConfigTokenVU configTokenVU;
        private readonly OliviaConfig oliviaConfig;

        public GenesysRepository(IConfiguration configuration, IManagerSecrypt secrypt, IApiRest apiRest)
        {
            this.apiRest = apiRest;

            List<ApiRestConfig> listApiRestConfig = new();
            configuration.GetSection("ApiRest").Bind(listApiRestConfig);
            this.apiRestConfig = listApiRestConfig.FirstOrDefault(x => x.Name == "GENESYS")!;
            IamConfig iamConfigLocal = new();
            configuration.GetSection("IamCredentials").Bind(iamConfigLocal);
            this.iamConfig = iamConfigLocal;
            this.iamConfig.Password = secrypt.Desencriptar(this.iamConfig.Password);
            this.iamConfig.PublicToken = secrypt.Desencriptar(this.iamConfig.PublicToken);

            ConfigTokenVU tokenUVconfig = new();
            configuration.GetSection("ConfigTokenVU").Bind(tokenUVconfig);
            this.configTokenVU = tokenUVconfig;
            this.configTokenVU.Identifier = secrypt.Desencriptar(this.configTokenVU.Identifier);
            this.configTokenVU.PublicToken = secrypt.Desencriptar(this.configTokenVU.PublicToken);
            this.configTokenVU.PasswordToken = secrypt.Desencriptar(this.configTokenVU.PasswordToken);

            this.oliviaConfig = new OliviaConfig();
            configuration.GetSection("OliviaConfig").Bind(this.oliviaConfig);
        }

        public async Task<WrapperGenesysResponse<ClienteConsultaResponse>> ClienteConsulta(string idOperacion, string idc, string complemento, string tokenGen)
        {
            Method apiGenesysConfig = this.apiRestConfig.Methods.First(x => x.Name == "GEN_CLIENTE_CONSULTA");
            var request = new
            {
                complemento = complemento,
                idc = idc
            };
            string url = this.apiRestConfig.BaseUrl + apiGenesysConfig.Path;
            string token = $"Bearer {tokenGen}";
            List<Tuple<string, string>> lstHeader = new();
            lstHeader.Add(new Tuple<string, string>("Authorization", token));
            lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
            WrapperGenesysResponse<ClienteConsultaResponse> response = await apiRest.PostAsync<WrapperGenesysResponse<ClienteConsultaResponse>>(url, request, false, string.Empty, string.Empty, lstHeader);

            return response;
        }

        public async Task<WrapperGenesysResponse<TarjetaResponse>> Tarjeta(string idOperacion, string cic, string tokenGen)
        {
            Method apiGenesysConfig = this.apiRestConfig.Methods.First(x => x.Name == "GEN_TARJETA");
            var request = new
            {
                cic = cic
            };
            string url = this.apiRestConfig.BaseUrl + apiGenesysConfig.Path;
            string token = $"Bearer {tokenGen}";
            List<Tuple<string, string>> lstHeader = new();
            lstHeader.Add(new Tuple<string, string>("Authorization", token));
            lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
            WrapperGenesysResponse<TarjetaResponse> response = await apiRest.PostAsync<WrapperGenesysResponse<TarjetaResponse>>(url, request, false, string.Empty, string.Empty, lstHeader);

            return response;
        }

        public async Task<WrapperGenesysResponse<bool>> BMDesbloqueo(string idOperacion, string cic, string tokenGen)
        {
            Method apiGenesysConfig = this.apiRestConfig.Methods.First(x => x.Name == "GEN_HABILITAR_USUARIO");
            var request = new
            {
                cic = cic
            };
            string url = this.apiRestConfig.BaseUrl + apiGenesysConfig.Path;
            string token = $"Bearer {tokenGen}";
            List<Tuple<string, string>> lstHeader = new();
            lstHeader.Add(new Tuple<string, string>("Authorization", token));
            lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
            WrapperGenesysResponse<bool?> res = await apiRest.PostAsync<WrapperGenesysResponse<bool?>>(url, request, false, string.Empty, string.Empty, lstHeader);
            WrapperGenesysResponse<bool> response = new() { Data = res.Data ?? false, Message = res.Message, StatusCode = res.StatusCode };
            return response;
        }

        public async Task<WrapperGenesysResponse<bool>> BMDesvinculacion(string idOperacion, string cic, string tokenGen)
        {
            Method apiGenesysConfig = this.apiRestConfig.Methods.FirstOrDefault(x => x.Name == "DESVINCULAR_USUARIO")!;
            var request = new
            {
                cic
            };
            string url = this.apiRestConfig.BaseUrl + apiGenesysConfig.Path;
            string token = $"Bearer {tokenGen}";
            List<Tuple<string, string>> lstHeader = new();
            lstHeader.Add(new Tuple<string, string>("Authorization", token));
            lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
            WrapperGenesysResponse<bool?> res = await apiRest.PostAsync<WrapperGenesysResponse<bool?>>(url, request, false, string.Empty, string.Empty, lstHeader);
            WrapperGenesysResponse<bool> response = new() { Data = res.Data ?? false, Message = res.Message, StatusCode = res.StatusCode };
            return response;
        }

        public async Task<WrapperGenesysResponse<bool>> HabilitacionComprasxInternet(string idOperacion, string cic, string complemento, string duracion, string idc, string limite, string tarjeta, string tokenGen)
        {
            Method apiGenesysConfig = this.apiRestConfig.Methods.FirstOrDefault(x => x.Name == "GEN_HABILITAR_COMPRAS_X_INTERNET")!;
            var request = new
            {
                cic,
                complemento,
                duracion,
                idc,
                limite,
                tarjeta
            };
            string url = this.apiRestConfig.BaseUrl + apiGenesysConfig.Path;
            string token = $"Bearer {tokenGen}";
            List<Tuple<string, string>> lstHeader = new();
            lstHeader.Add(new Tuple<string, string>("Authorization", token));
            lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
            WrapperGenesysResponse<bool?> res = await apiRest.PostAsync<WrapperGenesysResponse<bool?>>(url, request, false, string.Empty, string.Empty, lstHeader);
            WrapperGenesysResponse<bool> response = new() { Data = res.Data ?? false, Message = res.Message, StatusCode = res.StatusCode };
            return response;
        }

        public async Task<AuthenticationResponse> AuthGenesys(string idOperacion)
        {
            AuthenticationRequest request = new();
            request.Canal = this.iamConfig.Channel;
            request.Contrasena = this.iamConfig.Password;
            request.Token = this.iamConfig.PublicToken;
            request.Usuario = this.iamConfig.User;

            Method apiGenesysConfig = this.apiRestConfig.Methods.FirstOrDefault(x => x.Name == "AUTHENTICATION")!;
            string url = this.apiRestConfig.BaseUrl + apiGenesysConfig.Path;
            List<Tuple<string, string>> lstHeader = new();
            lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
            AuthenticationResponse response = await apiRest.PostAsync<AuthenticationResponse>(url, request, false, string.Empty, string.Empty, lstHeader);

            return response;
        }

        public async Task<WrapperGenesysResponse<PruebaVidaGenerarResponse>> RekognitionGenerarGenesys(string idOperacion, string celular, string idc, string tokenGen)
        {
            Method apiGenesysConfig = this.apiRestConfig.Methods.FirstOrDefault(x => x.Name == "PRUEBAVIDA_GENERAR")!;
            var request = new
            {
                celular,
                complemento = "00",
                idc
            };
            string url = this.apiRestConfig.BaseUrl + apiGenesysConfig.Path;
            string token = $"Bearer {tokenGen}";
            List<Tuple<string, string>> lstHeader = new();
            lstHeader.Add(new Tuple<string, string>("Authorization", token));
            lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
            WrapperGenesysResponse<PruebaVidaGenerarResponse> res = await apiRest.PostAsync<WrapperGenesysResponse<PruebaVidaGenerarResponse>>(url, request, false, string.Empty, string.Empty, lstHeader);
            return res;
        }

        public async Task<WrapperGenesysResponse<bool>> RekognitionValidarGenesys(string idOperacion, string sessionId, string tokenGen)
        {
            Method apiGenesysConfig = this.apiRestConfig.Methods.FirstOrDefault(x => x.Name == "PRUEBAVIDA_VALIDAR")!;
            var request = new
            {
                sessionId
            };
            string url = this.apiRestConfig.BaseUrl + apiGenesysConfig.Path;
            string token = $"Bearer {tokenGen}";
            List<Tuple<string, string>> lstHeader = new();
            lstHeader.Add(new Tuple<string, string>("Authorization", token));
            lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
            WrapperGenesysResponse<bool?> res = await apiRest.PostAsync<WrapperGenesysResponse<bool?>>(url, request, false, string.Empty, string.Empty, lstHeader);
            WrapperGenesysResponse<bool> response = new() { Data = res.Data ?? false, Message = res.Message, StatusCode = res.StatusCode };
            return response;
        }

        public async Task<WrapperGenesysResponse<string>> OtpGenerarGenesys(string idOperacion, string celular, string idc, string correo, string tokenGen)
        {
            Method apiGenesysConfig = this.apiRestConfig.Methods.FirstOrDefault(x => x.Name == "OTP_GENERAR")!;
            var request = new
            {
                celular,
                correo,
                idc
            };
            string url = this.apiRestConfig.BaseUrl + apiGenesysConfig.Path;
            string token = $"Bearer {tokenGen}";
            List<Tuple<string, string>> lstHeader = new();
            lstHeader.Add(new Tuple<string, string>("Authorization", token));
            lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
            WrapperGenesysResponse<string> res = await apiRest.PostAsync<WrapperGenesysResponse<string>>(url, request, false, string.Empty, string.Empty, lstHeader);
            return res;
        }

        public async Task<WrapperGenesysResponse<bool>> OtpValidarGenesys(string idOperacion, string idc, string codigo, string tokenGen)
        {
            Method apiGenesysConfig = this.apiRestConfig.Methods.FirstOrDefault(x => x.Name == "OTP_VALIDAR")!;
            var request = new
            {
                codigo,
                idc
            };
            string url = this.apiRestConfig.BaseUrl + apiGenesysConfig.Path;
            string token = $"Bearer {tokenGen}";
            List<Tuple<string, string>> lstHeader = new();
            lstHeader.Add(new Tuple<string, string>("Authorization", token));
            lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
            WrapperGenesysResponse<bool> res = await apiRest.PostAsync<WrapperGenesysResponse<bool>>(url, request, false, string.Empty, string.Empty, lstHeader);
            return res;
        }

        public async Task<WrapperGenesysResponse<bool>> RecordarUsuario(string idOperacion, string cic, string correo, string tokenGen)
        {
            Method apiGenesysConfig = this.apiRestConfig.Methods.First(x => x.Name == "RECORDAR_USUARIO_BM");
            var request = new
            {
                cic,
                correo
            };
            string url = this.apiRestConfig.BaseUrl + apiGenesysConfig.Path;
            string token = $"Bearer {tokenGen}";
            List<Tuple<string, string>> lstHeader = new();
            lstHeader.Add(new Tuple<string, string>("Authorization", token));
            lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
            WrapperGenesysResponse<bool?> res = await apiRest.PostAsync<WrapperGenesysResponse<bool?>>(url, request, false, string.Empty, string.Empty, lstHeader);
            WrapperGenesysResponse<bool> response = new() { Data = res.Data ?? false, Message = res.Message, StatusCode = res.StatusCode };
            return response;
        }
        public async Task<WrapperGenesysResponse<List<string>>> GetCuentas(string idOperacion, string cic, string tokenGen)
        {
            Method apiGenesysConfig = this.apiRestConfig.Methods.First(x => x.Name == "GET_CUENTAS");
            var request = new
            {
                cic
            };
            string url = this.apiRestConfig.BaseUrl + apiGenesysConfig.Path;
            string token = $"Bearer {tokenGen}";
            List<Tuple<string, string>> lstHeader = new();
            lstHeader.Add(new Tuple<string, string>("Authorization", token));
            lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
            WrapperGenesysResponse<List<string>> res = await apiRest.PostAsync<WrapperGenesysResponse<List<string>>>(url, request, false, string.Empty, string.Empty, lstHeader);
            return res;
        }
        public async Task<WrapperGenesysResponse<bool>> RecordarCuenta(string idOperacion, string cic, string correo, string cuenta, string tokenGen)
        {
            Method apiGenesysConfig = this.apiRestConfig.Methods.First(x => x.Name == "RECORDAR_CUENTA_BM");
            var request = new
            {
                cuenta,
                cic,
                correo
            };
            string url = this.apiRestConfig.BaseUrl + apiGenesysConfig.Path;
            string token = $"Bearer {tokenGen}";
            List<Tuple<string, string>> lstHeader = new();
            lstHeader.Add(new Tuple<string, string>("Authorization", token));
            lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
            WrapperGenesysResponse<bool?> res = await apiRest.PostAsync<WrapperGenesysResponse<bool?>>(url, request, false, string.Empty, string.Empty, lstHeader);
            WrapperGenesysResponse<bool> response = new() { Data = res.Data ?? false, Message = res.Message, StatusCode = res.StatusCode };
            return response;
        }
        public async Task<WrapperGenesysResponse<bool>> BloquearTarjeta(string idOperacion, string cic, string tarjeta, TipoBloqueo tipoBloqueo, string tokenGen)
        {
            Method apiGenesysConfig = this.apiRestConfig.Methods.First(x => x.Name == "BLOQUEAR_TARJETA");
            var request = new
            {
                cic,
                tarjeta,
                tipoBloqueo
            };
            string url = this.apiRestConfig.BaseUrl + apiGenesysConfig.Path;
            string token = $"Bearer {tokenGen}";
            List<Tuple<string, string>> lstHeader = new();
            lstHeader.Add(new Tuple<string, string>("Authorization", token));
            lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
            WrapperGenesysResponse<bool?> res = await apiRest.PostAsync<WrapperGenesysResponse<bool?>>(url, request, false, string.Empty, string.Empty, lstHeader);
            WrapperGenesysResponse<bool> response = new() { Data = res.Data ?? false, Message = res.Message, StatusCode = res.StatusCode };
            return response;
        }
        public async Task<WrapperGenesysResponse<SaldoResponse>> ConsultaSaldo(string idOperacion, string cic, string cuenta, string tokenGen)
        {
            Method apiGenesysConfig = this.apiRestConfig.Methods.First(x => x.Name == "SALDO");
            var request = new
            {
                cic,
                cuenta
            };
            string url = this.apiRestConfig.BaseUrl + apiGenesysConfig.Path;
            string token = $"Bearer {tokenGen}";
            List<Tuple<string, string>> lstHeader = new();
            lstHeader.Add(new Tuple<string, string>("Authorization", token));
            lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
            WrapperGenesysResponse<SaldoResponse> response = await apiRest.PostAsync<WrapperGenesysResponse<SaldoResponse>>(url, request, false, string.Empty, string.Empty, lstHeader);
            return response;
        }

        public async Task<WrapperGenesysResponse<List<MovimientoResponse>>> ConsultaMovimientos(string idOperacion, string cic, string cuenta, string tokenGen)
        {
            Method apiGenesysConfig = this.apiRestConfig.Methods.First(x => x.Name == "MOVIMIENTOS");
            var request = new
            {
                cic,
                cuenta
            };
            string url = this.apiRestConfig.BaseUrl + apiGenesysConfig.Path;
            string token = $"Bearer {tokenGen}";
            List<Tuple<string, string>> lstHeader = new();
            lstHeader.Add(new Tuple<string, string>("Authorization", token));
            lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
            WrapperGenesysResponse<List<MovimientoResponse>> response = await apiRest.PostAsync<WrapperGenesysResponse<List<MovimientoResponse>>>(url, request, false, string.Empty, string.Empty, lstHeader);
            return response;
        }

        public async Task<WrapperBasS<ListTokensInformation>> DesbloquearToken(string idOperacion, string cic)
        {

            Method apiGenesysConfig = this.apiRestConfig.Methods.First(x => x.Name == "TOKEN");

            var request = new
            {
                userName = string.Empty,
                cic = "    " + cic,
                identify = this.configTokenVU.Identify,
                ip = this.oliviaConfig.IpServer,
                identifier = this.configTokenVU.Identifier,
                device = this.configTokenVU.Device,
                browser = string.Empty,
                channel = this.configTokenVU.Channel,
                domainUser = this.configTokenVU.DomainUser,
                publicToken = this.configTokenVU.PublicToken,
                appUserId = this.configTokenVU.AppUserId,
            };
            string url = apiGenesysConfig.Path;
            string username = this.configTokenVU.UsernameToken;
            string password = this.configTokenVU.PasswordToken;
            WrapperBasS<ListTokensInformation> response = await apiRest.PostAsync<WrapperBasS<ListTokensInformation>>(url, request, true, username, password);
            return response;
        }

        public async Task<List<ResponseTransferNumber>> AchStateTransfer(string idOperacion, string cic, string amount, string type, string direction, string transferTime, BankEntity origin, BankEntity destiny, string tokenGen)
        {
            try
            {
                Method apiGenesysConfig = this.apiRestConfig.Methods.First(x => x.Name == "StateTransfer");

                var request = new
                {
                    cic,
                    origin,
                    destiny,
                    amount,
                    type,
                    direction,
                    transferTime,
                };
                string url = apiGenesysConfig.Path;
                string token = $"Bearer {tokenGen}";
                List<Tuple<string, string>> lstHeader = new();
                lstHeader.Add(new Tuple<string, string>("Authorization", token));
                lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
                List<ResponseTransferNumber> response = await apiRest.PostAsync<List<ResponseTransferNumber>>(url, request, false, string.Empty, string.Empty, lstHeader);
                return response;
            }
            catch (HttpRequestException e)
            {
                if (e.Message.CompareTo("NoContent") == 0)
                    return new();
                throw;
            }
        }

        public async Task<List<ResponseBankList>> AchStateBankList(string idOperacion, string tokenGen)
        {
            try
            {
                Method apiGenesysConfig = this.apiRestConfig.Methods.First(x => x.Name == "BankList");
                string url = apiGenesysConfig.Path;
                string token = $"Bearer {tokenGen}";
                List<Tuple<string, string>> lstHeader = new();
                lstHeader.Add(new Tuple<string, string>("Authorization", token));
                lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
                List<ResponseBankList> response = await apiRest.GetAsync<List<ResponseBankList>>(url, false, string.Empty, string.Empty, lstHeader);
                return response;
            }
            catch (HttpRequestException e)
            {
                if (e.Message.CompareTo("NoContent") == 0)
                    return new();
                throw;
            }
        }

        public async Task<ResponseTransferNumber?> AchStateTransferNumber(string idOperacion, string transferNumber, string type, string direction, string tokenGen)
        {
            try
            {
                Method apiGenesysConfig = this.apiRestConfig.Methods.First(x => x.Name == "StateNumberTransfer");

                var request = new
                {
                    transferNumber,
                    type,
                    direction,
                };
                string url = apiGenesysConfig.Path;
                string token = $"Bearer {tokenGen}";
                List<Tuple<string, string>> lstHeader = new();
                lstHeader.Add(new Tuple<string, string>("Authorization", token));
                lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
                ResponseTransferNumber? response = await apiRest.PostAsync<ResponseTransferNumber?>(url, request, false, string.Empty, string.Empty, lstHeader);
                return response;
            }
            catch (HttpRequestException e)
            {
                if (e.Message.CompareTo("NoContent") == 0)
                    return null;
                throw;
            }
        }

        public async Task<WrapperGenesysResponse<PruebaVidaGenerarPasivaResponse>> RekognitionGenerarPasivaGenesys(string idOperacion, string celular, string idc, string tokenGen)
        {
            Method apiGenesysConfig = this.apiRestConfig.Methods.FirstOrDefault(x => x.Name == "PRUEBAVIDA_GENERAR_PASIVA")!;
            var request = new
            {
                celular,
                complemento = "00",
                idc
            };
            string url = this.apiRestConfig.BaseUrl + apiGenesysConfig.Path;
            string token = $"Bearer {tokenGen}";
            List<Tuple<string, string>> lstHeader = new();
            lstHeader.Add(new Tuple<string, string>("Authorization", token));
            lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
            WrapperGenesysResponse<PruebaVidaGenerarPasivaResponse> res = await apiRest.PostAsync<WrapperGenesysResponse<PruebaVidaGenerarPasivaResponse>>(url, request, false, string.Empty, string.Empty, lstHeader);
            return res;
        }

        public async Task<WrapperGenesysResponse<PruebaVidaValidarPasivaResponse>> RekognitionValidarPasivaGenesys(string idOperacion, string sessionId, string selfi, string tokenGen)
        {
            WrapperGenesysResponse<PruebaVidaValidarPasivaResponse?> response = new WrapperGenesysResponse<PruebaVidaValidarPasivaResponse?>();
            try
            {
                Method apiGenesysConfig = this.apiRestConfig.Methods.FirstOrDefault(x => x.Name == "PRUEBAVIDA_VALIDAR_PASIVA")!;
                var request = new
                {
                    sessionId,
                    selfi
                };
                string url = this.apiRestConfig.BaseUrl + apiGenesysConfig.Path;
                string token = $"Bearer {tokenGen}";
                List<Tuple<string, string>> lstHeader = new();
                lstHeader.Add(new Tuple<string, string>("Authorization", token));
                lstHeader.Add(new Tuple<string, string>("Canal", this.iamConfig.Channel));
                response = await apiRest.PostAsync<WrapperGenesysResponse<PruebaVidaValidarPasivaResponse?>>(url, request, false, string.Empty, string.Empty, lstHeader);
                return response!;
            }
            catch (Exception)
            {
                response.Data = new PruebaVidaValidarPasivaResponse()
                {
                    Success = false,
                    Message = "Error en validacion de prueba de vida"
                };
                return response!;
            }
        }
    }
}
