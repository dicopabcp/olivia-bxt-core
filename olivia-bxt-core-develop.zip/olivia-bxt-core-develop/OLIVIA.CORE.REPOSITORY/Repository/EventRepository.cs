using CROSS.DATABASE;
using Microsoft.Data.SqlClient;
using System.Data;
using OLIVIA.CORE.MODEL.CONST;

namespace OLIVIA.CORE.REPOSITORY
{
    public class EventRepository : IEventRepository
    {
        private readonly IManagerDataBase managerDataBase;
        public EventRepository(IManagerDataBase managerDataBase)
        {
            this.managerDataBase = managerDataBase;
        }

        public async Task<bool> CreateSesion(string id, string usuario)
        {
            List<SqlParameter> parametros = new();
            parametros.Add(new SqlParameter("@ID_IN", id));
            parametros.Add(new SqlParameter("@USUARIO_VC", usuario));
            parametros.Add(new SqlParameter("@ESTADO_VC", EstadoSesion.SIN_TOPICO));
            parametros.Add(new SqlParameter("@FECHA_CREACION_DT", DateTime.Now));
            parametros.Add(new SqlParameter("@FECHA_CIERRE_DT", null));
            DataTable datatable = await this.managerDataBase.SelectStoredProcedure("OLIVIA_BXT_SQL", "[olivia].[CREATE_OR_UPDATE_SESION]", parametros);
            return (datatable != null && datatable.Rows.Count > 0);   

        }
        public async Task<bool> UpdateSesion(string id, EstadoSesion estado)
        {
            List<SqlParameter> parametros = new();
            parametros.Add(new SqlParameter("@ID_IN", id));
            parametros.Add(new SqlParameter("@USUARIO_VC", null));
            parametros.Add(new SqlParameter("@ESTADO_VC", estado));
            parametros.Add(new SqlParameter("@FECHA_CREACION_DT", null));
            parametros.Add(new SqlParameter("@FECHA_CIERRE_DT", (estado == EstadoSesion.CERRADO || estado == EstadoSesion.ABANDONADO) ? DateTime.Now : null));
            DataTable datatable = await this.managerDataBase.SelectStoredProcedure("OLIVIA_BXT_SQL", "[olivia].[UPDATE_SESSION]", parametros);
            return (datatable != null && datatable.Rows.Count > 0);

        }
        public async Task<bool> CreateMessage(string message_ant, string sesion, string message, DateTime date, string role)
        {
            List<SqlParameter> parametros = new();
            parametros.Add(new SqlParameter("@SESION_VC", sesion));
            parametros.Add(new SqlParameter("@MENSAJES_VC", message));
            parametros.Add(new SqlParameter("@ANTERIOR_MENSAJES_VC", message_ant));
            parametros.Add(new SqlParameter("@ROL_VC", role));
            parametros.Add(new SqlParameter("@FECHA_CREACION_DT", date));
            DataTable datatable = await this.managerDataBase.SelectStoredProcedure("OLIVIA_BXT_SQL", "[olivia].[CREATE_MENSAJE]", parametros);
            return (datatable != null && datatable.Rows.Count > 0);

        }

    }
}
