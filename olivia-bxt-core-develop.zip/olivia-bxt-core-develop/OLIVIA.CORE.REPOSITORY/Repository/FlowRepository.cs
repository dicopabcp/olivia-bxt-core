using CROSS.DATABASE;
using Microsoft.Data.SqlClient;
using OLIVIA.CORE.MODEL;
using OLIVIA.CORE.REPOSITORY.Interfaces;
using System.Data;

namespace OLIVIA.CORE.REPOSITORY.Repository
{
    public class FlowRepository : IFlowRepository
    {
        private readonly IManagerDataBase dataBase;
        public FlowRepository(IManagerDataBase dataBase)
        {
            this.dataBase = dataBase;
        }

        public async Task<bool> CreateFlow(SesionEntity sesion, Flow flow)
        {
            try
            {
                List<SqlParameter> parametros = new();
                parametros.Add(new SqlParameter("@SESION_VC", sesion._id.ToString()));
                parametros.Add(new SqlParameter("@ESTADO_IN", GetState(flow.State)));
                parametros.Add(new SqlParameter("@DETALLE_VC", flow.DetailsStep));
                parametros.Add(new SqlParameter("@NOMBRE_VC", flow.Topic));
                parametros.Add(new SqlParameter("@FLUJO_ID", flow._id.ToString()));
                parametros.Add(new SqlParameter("@PARAMTERO_VC", flow.CurrentStep));
                DataTable datatable = await this.dataBase.SelectStoredProcedure("OLIVIA_BXT_SQL", "[olivia].[CREATE_FLUJO]", parametros);
                return (datatable != null);
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public async Task<bool> UpdateFlow(Flow flow)
        {
            try
            {
                List<SqlParameter> parametros = new();
                parametros.Add(new SqlParameter("@FLUJO_ID", flow._id.ToString()));
                parametros.Add(new SqlParameter("@ESTADO_IN", GetState(flow.State)));
                parametros.Add(new SqlParameter("@DETALLE_VC", flow.DetailsStep));
                parametros.Add(new SqlParameter("@PARAMTERO_VC", flow.CurrentStep));
                parametros.Add(new SqlParameter("@FECHA_CIERRE_DT", flow.FinishDate));
                DataTable datatable = await this.dataBase.SelectStoredProcedure("OLIVIA_BXT_SQL", "[olivia].[UPDATE_FLUJO]", parametros);
                return (datatable != null);
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        private static int GetState(string state)
        {
            switch (state)
            {
                case "COMPLETADO": return 1;
                case "ERROR": return 9;
                case "DERIVADO": return 2;
                case "EN PROGRESO": return 3;
                case "ABONDANADO": return 8;
                default: return 8;
            }
        }
    }
}
