using CROSS.DATABASE;
using Microsoft.Data.SqlClient;
using OLIVIA.CORE.MODEL.DB_MODEL.REGISTROPRUEBAVIDA;
using OLIVIA.CORE.REPOSITORY.Interfaces;
using System.Data;

namespace OLIVIA.CORE.REPOSITORY.Repository
{
    public class RegistroPruebaVidaRepository(IManagerDataBase dataBase) : IRegistroPruebaVidaRepository
    {
        // Conexion a BD_WHATSAPP (DEVSSD01), distinta de "OLIVIA_BXT_SQL" (DB_OLIVIA_BXT en DEVSSE00) que ya usan los demas repositorios de este proyecto.
        private readonly string name = "BD_WHATSAPP_SQL";

        public async Task<RegistroPruebaVidaEntity?> GetByCelularAsync(string celular)
        {
            string query = "[wpp].[WPP_REGISTRO_PRUEBA_VIDA_GetByCelular]";
            List<SqlParameter> parametros = new()
            {
                new SqlParameter("@CELULAR", celular)
            };

            DataTable data = await dataBase.SelectStoredProcedure(name, query, parametros);
            if (data.Rows.Count == 0)
            {
                return null;
            }

            DataRow row = data.Rows[0];
            return new RegistroPruebaVidaEntity
            {
                Idc = row.Field<string>("IDC") ?? string.Empty,
                Complemento = row.Field<string>("COMPLEMENTO") ?? string.Empty,
                Celular = row.Field<string>("CELULAR") ?? string.Empty,
                IdCliente = row.Field<string>("ID_CLIENTE"),
                Registrado = row.Field<bool>("REGISTRADO"),
                CarnetAnversoRef = row.Field<string>("CARNET_ANVERSO_REF"),
                CarnetReversoRef = row.Field<string>("CARNET_REVERSO_REF"),
                SelfieRef = row.Field<string>("SELFIE_REF"),
                WppSesionId = row.Field<string>("WPP_SESION_ID"),
                Fecha = row.Field<DateTime>("FECHA"),
                Hora = row.Field<TimeSpan>("HORA")
            };
        }

        public async Task<bool> InsertUpdateAsync(RegistroPruebaVidaUpsertRequest request)
        {
            string query = "[wpp].[WPP_REGISTRO_PRUEBA_VIDA_InsertUpdate]";
            List<SqlParameter> parametros = new()
            {
                new SqlParameter("@IDC", request.Idc),
                new SqlParameter("@COMPLEMENTO", request.Complemento),
                new SqlParameter("@CELULAR", request.Celular),
                new SqlParameter("@ID_CLIENTE", request.IdCliente),
                new SqlParameter("@REGISTRADO", request.Registrado),
                new SqlParameter("@CARNET_ANVERSO_REF", request.CarnetAnversoRef),
                new SqlParameter("@CARNET_REVERSO_REF", request.CarnetReversoRef),
                new SqlParameter("@SELFIE_REF", request.SelfieRef),
                new SqlParameter("@WPP_SESION_ID", request.WppSesionId)
            };

            return await dataBase.ExecuteStoredProcedure(name, query, parametros);
        }
    }
}
