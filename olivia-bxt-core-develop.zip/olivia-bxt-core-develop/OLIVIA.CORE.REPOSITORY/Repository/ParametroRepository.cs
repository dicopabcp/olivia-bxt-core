using CROSS.DATABASE;
using Microsoft.Data.SqlClient;
using OLIVIA.CORE.MODEL.DB_MODEL.PARAMETRO;
using OLIVIA.CORE.REPOSITORY.Interfaces;
using System.Data;

namespace OLIVIA.CORE.REPOSITORY.Repository
{
    public class ParametroRepository(IManagerDataBase dataBase) : IParametroRepository
    {
        private readonly string name = "OLIVIA_BXT_SQL";
        public async Task<bool> UpdateParametroAsync(string nombre, string mensaje, bool enabled, string usuario)
        {
            string query = "olivia.PARAMETRO_MENSAJE_UPDATE";
            List<SqlParameter> lstParameters = new List<SqlParameter>
            {
                new SqlParameter("@NOMBRE_VC", nombre),
                new SqlParameter("@MENSAJE_VC", mensaje),
                new SqlParameter("@ENABLED_BT", enabled),
                new SqlParameter("@USUARIO_VC", usuario)
            };
            var data = await dataBase.ExecuteStoredProcedure(name, query, lstParameters);
            return data;
        }
        public async Task<List<ParametroEntitie>> GetParametroListAsync()
        {
            List<ParametroEntitie> lst = new List<ParametroEntitie>();
            string query = "olivia.PARAMETRO_MENSAJE_GET_LIST";
            var data = await dataBase.SelectStoredProcedure(name, query, new List<SqlParameter>());
            foreach (DataRow item in data.Rows)
            {
                lst.Add(new ParametroEntitie
                {
                    Id = item.Field<int>("ID_IN"),
                    Nombre = item.Field<string>("NOMBRE_VC") ?? string.Empty,
                    Mensaje = item.Field<string>("MENSAJE_VC") ?? string.Empty,
                    Enabled = item.Field<bool>("ENABLED_BT"),
                    UsuarioRegistro = item.Field<string>("USUARIO_REGISTRO_VC") ?? string.Empty,
                    FechaRegistro = item.Field<DateTime>("FECHA_REGISTRO_DT"),
                    UsuarioModificacion = item.Field<string>("USUARIO_MODIFICACION_VC") ?? string.Empty,
                    FechaModificacion = item.Field<DateTime>("FECHA_MODIFICACION_DT")
                });
            }
            return lst;
        }
    }
}
