using CROSS.APIREST;
using CROSS.SECRYPT;
using Microsoft.Extensions.Configuration;
using OLIVIA.CORE.MODEL.CONFIG;
using OLIVIA.CORE.MODELS.CONFIG;
using Serilog;

namespace OLIVIA.CORE.REPOSITORY
{
    public class WhatsAppRepository : IWhatsAppRepository
    {
        private readonly IApiRest apiRest;
        private readonly List<ApiRestConfig> configuration;
        private readonly IamConfig iamConfig;
        private readonly OliviaConfig oliviaConfig;


        public WhatsAppRepository(IApiRest apiRest, IConfiguration configuration, IManagerSecrypt secrypt)
        {
            this.apiRest = apiRest;
            List<ApiRestConfig> apiRestConfig = new();
            configuration.GetSection("ApiRest").Bind(apiRestConfig);
            IamConfig iamConfigLocal = new();
            configuration.GetSection("IamCredentials").Bind(iamConfigLocal);
            this.iamConfig = iamConfigLocal;
            this.iamConfig.PublicToken = secrypt.Desencriptar(this.iamConfig.PublicToken);
            this.iamConfig.Password = secrypt.Desencriptar(this.iamConfig.Password);

            OliviaConfig oliviaConfigLocal = new();
            configuration.GetSection("OliviaConfig").Bind(oliviaConfigLocal);
            this.oliviaConfig = oliviaConfigLocal;
            this.configuration = apiRestConfig;
        }

        public async Task SendMessage(string destino, string mensaje)
        {
            try
            {
                ApiRestConfig? confiApi = this.configuration.FirstOrDefault(x => x.Name == "API_WHATSAPP")!;
                var request = new
                {
                    cellphone = destino,
                    message = mensaje,
                    nameUser = "OLIVIA",
                    destinationAccount = this.oliviaConfig.DestinationAccount
                };
                string method = confiApi.Methods.FirstOrDefault(x => x.Name == "SEND_MESSAGE")!.Path;
                string url = confiApi.BaseUrl + method;
                List<Tuple<string, string>> header = new();
                header.Add(new("PublicToken", this.iamConfig.PublicToken));
                header.Add(new("AppUserId", this.iamConfig.AppUserId));
                header.Add(new("Channel", this.iamConfig.Channel));
                await this.apiRest.PostAsync<ResponseWpp>(url, request, true, this.iamConfig.User, this.iamConfig.Password, header);

            }
            catch (Exception ex)
            {
                Log.Error("ERROR", ex);
            }
        }

        public async Task SendMultimediaMessage(string destino, string mensaje, string urlMultimedia)
        {
            try
            {
                ApiRestConfig? confiApi = this.configuration.FirstOrDefault(x => x.Name == "API_WHATSAPP")!;
                var request = new SendMessageExternalRequest()
                {
                    typeMessage = urlMultimedia.EndsWith(".mp4") ? "VIDEO" : "IMAGE",
                    cellphone = new List<string> { destino },
                    nameMultimediaUrl = mensaje,
                    url = urlMultimedia,
                    destinationAccount = this.oliviaConfig.DestinationAccount
                };
                string method = confiApi.Methods.FirstOrDefault(x => x.Name == "SEND_GENERIC_MESSAGE")!.Path;
                string url = confiApi.BaseUrl + method;
                List<Tuple<string, string>> header = new();
                header.Add(new("PublicToken", this.iamConfig.PublicToken));
                header.Add(new("AppUserId", this.iamConfig.AppUserId));
                header.Add(new("Channel", this.iamConfig.Channel));
                await this.apiRest.PostAsync<ResponseWpp>(url, request, true, this.iamConfig.User, this.iamConfig.Password, header);

            }
            catch (Exception ex)
            {
                Log.Error("ERROR", ex);
            }
        }

        public async Task SendButtons(string destino, string mensaje, List<string> listButton)
        {
            try
            {
                ApiRestConfig? confiApi = this.configuration.FirstOrDefault(x => x.Name == "API_WHATSAPP")!;
                var request = new
                {
                    cellphone = destino,
                    message = mensaje,
                    nameUser = "OLIVIA",
                    destinationAccount = this.oliviaConfig.DestinationAccount,
                    listButton
                };
                string method = confiApi.Methods.FirstOrDefault(x => x.Name == "SEND_BUTTONS")!.Path;
                string url = confiApi.BaseUrl + method;
                List<Tuple<string, string>> header = new();
                header.Add(new("PublicToken", this.iamConfig.PublicToken));
                header.Add(new("AppUserId", this.iamConfig.AppUserId));
                header.Add(new("Channel", this.iamConfig.Channel));
                await this.apiRest.PostAsync<ResponseWpp>(url, request, true, this.iamConfig.User, this.iamConfig.Password, header);
            }
            catch (Exception ex)
            {
                Log.Error("ERROR", ex);
            }
        }

        public async Task SendList(string destino, string mensaje, List<ListMessage> listButton)
        {
            try
            {
                ApiRestConfig? confiApi = this.configuration.FirstOrDefault(x => x.Name == "API_WHATSAPP")!;
                var request = new
                {
                    cellphone = destino,
                    message = mensaje,
                    nameUser = "OLIVIA",
                    destinationAccount = this.oliviaConfig.DestinationAccount,
                    button = "Seleccionar banco",
                    list = listButton
                };
                string method = confiApi.Methods.FirstOrDefault(x => x.Name == "SEND_LIST")!.Path;
                string url = confiApi.BaseUrl + method;
                List<Tuple<string, string>> header = new();
                header.Add(new("PublicToken", this.iamConfig.PublicToken));
                header.Add(new("AppUserId", this.iamConfig.AppUserId));
                header.Add(new("Channel", this.iamConfig.Channel));
                await this.apiRest.PostAsync<ResponseWpp>(url, request, true, this.iamConfig.User, this.iamConfig.Password, header);
            }
            catch (Exception ex)
            {
                Log.Error("ERROR", ex);
                throw;
            }
        }

        public async Task SendMessageFlow(string destino, string mensaje, string nameFlow, string wppSesionId, string screen = "", string? header = null, string? footer = null)
        {
            try
            {
                ApiRestConfig? confiApi = this.configuration.FirstOrDefault(x => x.Name == "API_WHATSAPP")!;
                var request = new
                {
                    cellphone = destino,
                    message = mensaje,
                    nameFlow,
                    wppSesionId,
                    screen,
                    header,
                    footer,
                };
                string method = confiApi.Methods.FirstOrDefault(x => x.Name == "SEND_WPP_FLOW")!.Path;
                string url = confiApi.BaseUrl + method;
                List<Tuple<string, string>> headers = new();
                headers.Add(new("PublicToken", this.iamConfig.PublicToken));
                headers.Add(new("AppUserId", this.iamConfig.AppUserId));
                headers.Add(new("Channel", this.iamConfig.Channel));
                await this.apiRest.PostAsync<ResponseWpp>(url, request, true, this.iamConfig.User, this.iamConfig.Password, headers);
            }
            catch (Exception ex)
            {
                Log.Error("ERROR", ex);
            }
        }
    }

    public class ResponseWpp
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public string Code { get; set; }
    }

    public class SendMessageExternalRequest
    {
        public int messageId { get; set; } // ID DEL MENSAJE INSERTADO A NIVEL BASE DE DATOS 
        public string? message { get; set; } // MENSAJE DE TEXTO A ENVIAR 
        public string? typeMessage { get; set; }  // TIPO DE MENSAJE EJ: TEXT, IMAGE, AUDIO, VIDEO, DOCUMENT, LOCATION, CONTACTS, HSM, TEMPLATE, INTERACTIVE, STICKER
        public string? destinationAccount { get; set; }  // EXTENSION DEL ARCHIVO MULTIMEDIA EJ: IMAGE (JPG, JPEG, PNG) AUDIO (ACC, AMR, MP3(MPEG), OGG) : VIDEO (MP4) : DOCUMENT (PDF) 
        public string? classMultimedia { get; set; }  // EXTENSION DEL ARCHIVO MULTIMEDIA EJ: IMAGE (JPG, JPEG, PNG) AUDIO (ACC, AMR, MP3(MPEG), OGG) : VIDEO (MP4) : DOCUMENT (PDF) 
        public string? classInteractive { get; set; }  // INTERACTIVE (LIST, REPLY_BUTTON)
        public List<string> cellphone { get; set; } = new List<string>(); // LISTA DE CELULARES PARA ENVIAR EL MENSAJE EJ: 59175806163
        public bool identifyChatBot { get; set; }   // IDENTIFICADOR DE SI EL MENSAJE ES DEL OPERADOR O DEL BOT
        public string? multimediaUrl { get; set; }    //  BASE 64 ARCHIVO MULTIMEDIA DE TIPO: IMAGEN, AUDIO, VIDEO, DOCUMENTO
        public string? url { get; set; }    // URL DEL ARCHIVO MULTIMEDIA DE TIPO: IMAGEN, AUDIO, VIDEO, DOCUMENTO
        public string? nameMultimediaUrl { get; set; }    // NOMBRE CON EL QUE SE ENVIARA EL ARVHIVO MULTIMEDIA (IMAGE, VIDEO, DOCUMENT)
        public string? user { get; set; }  // USUARIO QUE REALIZA EL ENVIO DEL MENSAJE
        public string? nameUser { get; set; }  // NOMBRE DEL USUARIO QUE REALIZA EL ENVIO DEL MENSAJE
        public List<string> parameterMessage { get; set; } = new List<string>();    //  LISTA DE PARAMETROS PARA LA CLASE DE MENSAJE DE TIPO HSM, TEMPLATE, LOCATION, 
        public string nameHsmOfTemplate { get; set; } = string.Empty;    //  NOMBRE DE LA CLASE DE MENSAJE HSM, TEMPLATE
        public string? campaignName { get; set; }     //  NOMBRE DE LA CAMPAÑA PARA EL ENVIO DEL MENSAJE
        public MessageInteractiveModel parametersInteractive { get; set; } = new MessageInteractiveModel(); // PARAMETROS PARA EL ENVIO DE MENSAJES INTERACTIVOS 
        public MessageTemplateModel parametersTemplate { get; set; } = new MessageTemplateModel();
    }

    public class MessageInteractiveModel
    {
        public string nameSelectorButton { get; set; } = string.Empty;
        public string classMessageInteractive { get; set; } = string.Empty;
        public string header { get; set; } = string.Empty;
        public string body { get; set; } = string.Empty;
        public string footer { get; set; } = string.Empty;
        public List<InteractiveParameterModel> parameters { get; set; } = new List<InteractiveParameterModel>();
        public string alternativeText { get; set; } = string.Empty;
    }

    public class InteractiveParameterModel
    {
        public string title { get; set; } = string.Empty;
        public string description { get; set; } = string.Empty;
        public string identifier { get; set; } = string.Empty;
    }

    public class MessageTemplateModel
    {
        public string classMessageTemplate { get; set; } = string.Empty;
    }
}

