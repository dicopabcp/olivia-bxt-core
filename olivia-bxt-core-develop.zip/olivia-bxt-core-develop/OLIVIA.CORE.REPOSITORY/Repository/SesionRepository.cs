using CROSS.DATABASE;
using CROSS.DATABASES.REDDIS;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using MongoDB.Bson;
using OLIVIA.CORE.MODEL;
using OLIVIA.CORE.MODEL.CONST;
using OLIVIA.CORE.MODELS.CONFIG;
using System.Data;
namespace OLIVIA.CORE.REPOSITORY
{
    public class SesionRepository : ISesionRepository
    {
        private readonly IManagerDataBaseRedis managerDataBaseRedis;
        private readonly IManagerDataBaseMongo managerDataBaseMongo;
        private readonly IManagerDataBase managerDataBase;
        private readonly OliviaConfig oliviaConfig;



        public SesionRepository(IConfiguration configuration, IManagerDataBase managerDataBase, IManagerDataBaseRedis managerDataBaseRedis, IManagerDataBaseMongo managerDataBaseMongo)
        {
            OliviaConfig olivia = new();
            configuration.GetSection("OliviaConfig").Bind(olivia);
            this.oliviaConfig = olivia;
            this.managerDataBaseRedis = managerDataBaseRedis;
            this.managerDataBaseMongo = managerDataBaseMongo;
            this.managerDataBase = managerDataBase;
        }

        public async Task<bool> CreateRedisSesion(string usuario, string value)
        {
            try
            {
                return await this.managerDataBaseRedis.SetStringAsync($"sesion:{usuario}", value, this.oliviaConfig.TTL_SESION);
            }
            catch (Exception)
            {
                return false;
            }
        }

        public async Task<SesionEntity?> CreateMongoSesion(string usuario)
        {
            try
            {
                SesionEntity sesion = new()
                {
                    _id = ObjectId.GenerateNewId(),
                    Usuario = usuario,
                    Estado = EstadoSesion.SIN_TOPICO,
                    Topic = "",
                    SubTopic = "",
                    Messages = new List<MessagesSesionEntity>(),
                    Metadata = new List<Metadata>(),
                    Rags = new List<Rag>(),
                    Encuesta = null,
                    UpdateDate = DateTime.Now,
                    CreateDate = DateTime.Now,
                };
                await this.managerDataBaseMongo.InsertDocument($"sessions", sesion);
                return sesion;
            }
            catch (Exception)
            {
                return null;
            }
        }
        public async Task<bool> CreateSqlSesion(SesionEntity sesion)
        {
            try
            {
                List<SqlParameter> parametros = new();
                parametros.Add(new SqlParameter("@ID_VC", sesion._id.ToString()));
                parametros.Add(new SqlParameter("@USUARIO_VC", sesion.Usuario));
                DataTable datatable = await this.managerDataBase.SelectStoredProcedure("OLIVIA_BXT_SQL", "[olivia].[CREATE_SESION]", parametros);
                return (datatable != null);
            }
            catch (Exception ex)
            {
                //this.managerLogger.Warning($"ERROR AL GUARDAR LA SESION {sesion._id.ToString()} - {sesion.Usuario}");
                //this.managerLogger.Error(ex);
                return false;
            }

        }

        public async Task<bool> UpdateMongoSesion(SesionEntity sesion)
        {
            try
            {
                sesion.UpdateDate = DateTime.Now;
                await this.managerDataBaseMongo.UpdateDocumentById<SesionEntity>("sessions", sesion._id.ToString(), sesion);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public async Task<string?> ReadRedisSesion(string usuario)
        {
            try
            {
                return await this.managerDataBaseRedis.GetStringAsync($"sesion:{usuario}");
            }
            catch (Exception)
            {
                return null;
            }
        }

        public async Task<SesionEntity?> ReadMongoSesion(string idDocument)
        {
            try
            {
                return await this.managerDataBaseMongo.GetDocumentById<SesionEntity>("sessions", idDocument);
            }
            catch (Exception)
            {
                return null;
            }
        }

        public async Task<bool> UpdateRedisSesion(SesionEntity sesion)
        {
            int expiry = 1;
            switch (sesion.Estado)
            {
                case EstadoSesion.AGENTE:
                    expiry = this.oliviaConfig.TTL_AGENTE;
                    break;
                case EstadoSesion.ENCUESTA:
                    expiry = this.oliviaConfig.TTL_ENCUESTA;
                    break;
                case EstadoSesion.CERRADO:
                    expiry = 1;
                    break;
                default:
                    expiry = this.oliviaConfig.TTL_SESION;
                    break;
            }
            await this.managerDataBaseRedis.UpdateTtlStringAsync($"sesion:{sesion.Usuario}", expiry);
            return true;
        }
        public async Task<bool> UpdateRedisSesionForEncuesta(SesionEntity sesion)
        {
            await this.managerDataBaseRedis.UpdateTtlStringAsync($"sesion:{sesion.Usuario}", this.oliviaConfig.TTL_ENCUESTA);
            return true;
        }

        public async Task<bool> UpdateSqlSesion(SesionEntity sesion)
        {
            try
            {
                List<SqlParameter> parametros = new();
                parametros.Add(new SqlParameter("@ID_VC", sesion._id.ToString()));
                parametros.Add(new SqlParameter("@ESTADO_IN", (int)sesion.Estado));
                parametros.Add(new SqlParameter("@FECHA_CIERRE_DT", DateTime.Now));
                DataTable datatable = await this.managerDataBase.SelectStoredProcedure("OLIVIA_BXT_SQL", "[olivia].[UPDATE_SESION]", parametros);
                return (datatable != null);
            }
            catch (Exception ex)
            {
                //this.managerLogger.Warning($"ERROR AL GUARDAR LA SESION {sesion._id.ToString()} - {sesion.Usuario}");
                //this.managerLogger.Error(ex);
                return false;
            }
        }
    }
}
