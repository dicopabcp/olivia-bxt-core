using OLIVIA.CORE.MODEL;

namespace OLIVIA.CORE.REPOSITORY
{
    public interface IEncuestaRepository
    {

        public Task<bool> Create(SesionEntity sesion);
        public Task<bool> Update(SesionEntity sesion);
        public Task<bool> SendEncuesta(string user);

    }
}
