using OLIVIA.CORE.MODEL.DB_MODEL.PARAMETRO;

namespace OLIVIA.CORE.REPOSITORY.Interfaces
{
    public interface IParametroRepository
    {
        Task<List<ParametroEntitie>> GetParametroListAsync();
        Task<bool> UpdateParametroAsync(string nombre, string mensaje, bool enabled, string usuario);
    }
}
