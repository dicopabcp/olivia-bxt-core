using OLIVIA.CORE.MODEL;

namespace OLIVIA.CORE.REPOSITORY.Interfaces
{
    public interface IFlowRepository
    {
        public Task<bool> CreateFlow(SesionEntity sesion, Flow flow);
        public Task<bool> UpdateFlow(Flow flow);

    }
}
