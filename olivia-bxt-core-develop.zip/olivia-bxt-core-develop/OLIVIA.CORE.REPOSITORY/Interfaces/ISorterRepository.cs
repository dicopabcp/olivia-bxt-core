namespace OLIVIA.CORE.REPOSITORY
{
    public interface ISorterRepository
    {
        public Task<string> RequestToSorterBxT(string message);
        public Task SaveReport(string input, string output, string details, string sesion);

    }
}
