using OLIVIA.CORE.MODEL.CONST;

namespace OLIVIA.CORE.REPOSITORY
{
    public interface IEventRepository
    {
        public Task<bool> CreateSesion(string id, string usuario);
        public Task<bool> UpdateSesion(string id, EstadoSesion estado);
        public Task<bool> CreateMessage(string message_ant, string sesion, string message, DateTime date, string role);

    }
}
