using OLIVIA.CORE.MODEL;

namespace OLIVIA.CORE.REPOSITORY
{
    public interface ISesionRepository
    {
        //READ SESIONES
        public Task<SesionEntity?> ReadMongoSesion(string idDocument);
        public Task<string?> ReadRedisSesion(string usuario);


        //CREACION DE SESIONES
        public Task<bool> CreateSqlSesion(SesionEntity sesion);
        public Task<SesionEntity?> CreateMongoSesion(string usuario);
        public Task<bool> CreateRedisSesion(string usuario, string value);


        //UPDATE SESIONES
        public Task<bool> UpdateMongoSesion(SesionEntity sesion);
        public Task<bool> UpdateRedisSesion(SesionEntity sesion);
        public Task<bool> UpdateSqlSesion(SesionEntity sesion);
    }
}
