using OLIVIA.CORE.MODEL.CONST;
using OLIVIA.CORE.MODEL.DTO.Genesys;
using OLIVIA.CORE.MODEL.DTO.Genesys.ACCL;

namespace OLIVIA.CORE.REPOSITORY
{
    public interface IGenesysRepository
    {
        public Task<WrapperGenesysResponse<ClienteConsultaResponse>> ClienteConsulta(string idOperacion, string idc, string complemento, string tokenGen);

        public Task<WrapperGenesysResponse<TarjetaResponse>> Tarjeta(string idOperacion, string cic, string tokenGen);

        public Task<WrapperGenesysResponse<bool>> BMDesbloqueo(string idOperacion, string cic, string tokenGen);

        public Task<WrapperGenesysResponse<bool>> BMDesvinculacion(string idOperacion, string cic, string tokenGen);

        public Task<WrapperGenesysResponse<bool>> HabilitacionComprasxInternet(string idOperacion, string cic, string complemento, string duracion, string idc, string limite, string tarjeta, string tokenGen);

        public Task<AuthenticationResponse> AuthGenesys(string idOperacion);

        public Task<WrapperGenesysResponse<PruebaVidaGenerarResponse>> RekognitionGenerarGenesys(string idOperacion, string celular, string idc, string tokenGen);

        public Task<WrapperGenesysResponse<PruebaVidaGenerarPasivaResponse>> RekognitionGenerarPasivaGenesys(string idOperacion, string celular, string idc, string tokenGen);

        public Task<WrapperGenesysResponse<bool>> RekognitionValidarGenesys(string idOperacion, string sessionId, string tokenGen);

        public Task<WrapperGenesysResponse<PruebaVidaValidarPasivaResponse>> RekognitionValidarPasivaGenesys(string idOperacion, string sessionId, string selfi, string tokenGen);

        public Task<WrapperGenesysResponse<string>> OtpGenerarGenesys(string idOperacion, string celular, string idc, string correo, string tokenGen);

        public Task<WrapperGenesysResponse<bool>> OtpValidarGenesys(string idOperacion, string idc, string codigo, string tokenGen);

        public Task<WrapperGenesysResponse<bool>> RecordarUsuario(string idOperacion, string cic, string correo, string tokenGen);

        public Task<WrapperGenesysResponse<bool>> RecordarCuenta(string idOperacion, string cic, string correo, string cuenta, string tokenGen);

        public Task<WrapperGenesysResponse<bool>> BloquearTarjeta(string idOperacion, string cic, string tarjeta, TipoBloqueo tipoBloqueo, string tokenGen);

        //CUENTAS
        public Task<WrapperGenesysResponse<List<string>>> GetCuentas(string idOperacion, string cic, string tokenGen);

        public Task<WrapperGenesysResponse<SaldoResponse>> ConsultaSaldo(string idOperacion, string cic, string cuenta, string tokenGen);

        public Task<WrapperGenesysResponse<List<MovimientoResponse>>> ConsultaMovimientos(string idOperacion, string cic, string cuenta, string tokenGen);

        public Task<WrapperBasS<ListTokensInformation>> DesbloquearToken(string idOperacion, string cic);

        public Task<List<ResponseTransferNumber>> AchStateTransfer(string idOperacion, string cic, string amount, string type, string direction, string transferTime, BankEntity origin, BankEntity destiny, string tokenGen);

        public Task<List<ResponseBankList>> AchStateBankList(string idOperacion, string tokenGen);

        public Task<ResponseTransferNumber?> AchStateTransferNumber(string idOperacion, string transferNumber, string type, string direction, string tokenGen);
    }
}
