using OLIVIA.CORE.MODEL.DTO.CoreBancario;

namespace OLIVIA.CORE.REPOSITORY
{
    // MOCK: pendiente de reemplazo cuando exista el API real de Core Bancario (Plan Maestro WhatsApp v3, pregunta 1).
    public interface ICoreBancarioRepository
    {
        public Task<CoreBancarioClienteResponse?> ConsultarCliente(string carnet, string complemento);

        public Task<bool> ValidarOtp(string destino, string codigo);

        public Task<List<CoreBancarioCuentaResponse>> ConsultarCuentas(string cic);

        public Task<bool> ValidarClaveBancaMovil(string cic, string clave);

        public Task<bool> CrearUsuarioBancaMovil(string cic, string usuarioBm, string claveBm);

        public Task<CoreBancarioCrearCuentaResponse> CrearCuenta(string carnet, string propositoCuenta);
    }
}
