using OLIVIA.CORE.MODELS.CONFIG;

namespace OLIVIA.CORE.REPOSITORY
{
    public interface IWhatsAppRepository
    {
        public Task SendMessage(string destino, string mensaje);

        public Task SendMultimediaMessage(string destino, string mensaje, string urlMultimedia);

        public Task SendButtons(string destino, string mensaje, List<string> listButton);

        public Task SendList(string destino, string mensaje, List<ListMessage> listButton);

        public Task SendMessageFlow(string destino, string mensaje, string nameFlow, string wppSesionId, string screen = "", string? header = null, string? footer = null);
    }
}
