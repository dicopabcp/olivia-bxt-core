using OLIVIA.CORE.MODEL.DB_MODEL.REGISTROPRUEBAVIDA;

namespace OLIVIA.CORE.REPOSITORY.Interfaces
{
    // Repositorio de BD_WHATSAPP (DEVSSD01) para el registro persistente de prueba de vida por WhatsApp
    // (CI anverso + CI reverso + selfie). Ver Plan Maestro v3, seccion 7.1/7.3. Mismo patron de acceso a
    // datos que PassiveLifeTestRepository (canal Kiosko), adaptado a IManagerDataBase (CROSS.DATABASE),
    // que es el acceso a datos real de olivia-bxt-core.
    public interface IRegistroPruebaVidaRepository
    {
        Task<RegistroPruebaVidaEntity?> GetByCelularAsync(string celular);

        Task<bool> InsertUpdateAsync(RegistroPruebaVidaUpsertRequest request);
    }
}
