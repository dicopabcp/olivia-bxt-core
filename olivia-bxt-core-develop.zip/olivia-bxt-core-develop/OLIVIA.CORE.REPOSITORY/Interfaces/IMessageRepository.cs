using OLIVIA.CORE.MODEL;

namespace OLIVIA.CORE.REPOSITORY
{
    public interface IMessageRepository
    {
        public Task<bool> SaveMessages(MessagesSesionEntity messagesSesionEntity, SesionEntity sesion, MessagesSesionEntity? messagesSesionBefore = null);

    }
}
