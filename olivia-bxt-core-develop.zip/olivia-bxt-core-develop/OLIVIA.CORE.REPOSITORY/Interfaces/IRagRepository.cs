using OLIVIA.CORE.MODEL;

namespace OLIVIA.CORE.REPOSITORY
{
    public interface IRagRepository
    {
        public Task<WrapperResponseRag<AskToDocumentResponse>> RequestToRag(string idOperation, string question, List<HistoryItem> history);
    }
}
