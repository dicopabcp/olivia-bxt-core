using Microsoft.AspNetCore.Mvc;
using OLIVIA.CORE.MODEL.DTO.WppFlows;
using OLIVIA.CORE.SERVICE;

namespace OLIVIA.CORE.API.Controllers
{
    /// <summary>
    /// Controlador para el procesamiento de flujos de WhatsApp
    /// </summary>
    [ApiController]
    [Route("v1/[controller]")]
    public class WppFlowController : ControllerBase
    {

        private readonly IWppFlowService wppFlowService;
        public WppFlowController(IWppFlowService wppFlowService)
        {
            this.wppFlowService = wppFlowService;
        }

        /// <summary>
        /// Procesa una solicitud de flujo de WhatsApp
        /// </summary>
        /// <param name="request">Datos de la solicitud de flujo</param>
        /// <remarks>
        /// Request example:
        /// ```json
        /// {
        ///     "sesionId": "123456789",
        ///     "usuario": "USUARIO1",
        ///     "data": "Información adicional",
        ///     "flow": "FLUJO_EJEMPLO WHATSAPP"
        /// }
        /// ```
        /// </remarks>
        /// <response code="200">Procesamiento exitoso</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Respuesta del procesamiento del flujo de WhatsApp</returns>
        [HttpPost("Rekognition")]
        public async Task<IActionResult> ProcessFlowRekognition(WppFlowRequest request)
        {
            WppFlowResponse response = await wppFlowService.ProcessRekognitionWppFlow(request);
            return this.Ok(response);
        }

        /// <summary>
        /// Procesa una pantalla del WhatsApp Flow de apertura de cuenta (persona que no es cliente)
        /// </summary>
        /// <param name="request">Datos de la pantalla actual del Flow</param>
        /// <response code="200">Procesamiento exitoso</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Respuesta del procesamiento del flujo de WhatsApp</returns>
        [HttpPost("AperturaCuentaNoCliente")]
        public async Task<IActionResult> ProcessFlowAperturaCuentaNoCliente(WppFlowRequest request)
        {
            WppFlowResponse response = await wppFlowService.ProcessAperturaCuentaNoClienteWppFlow(request);
            return this.Ok(response);
        }

        /// <summary>
        /// Procesa una pantalla del WhatsApp Flow de apertura de cuenta (persona que ya es cliente y ya tiene Banca Movil)
        /// </summary>
        /// <param name="request">Datos de la pantalla actual del Flow</param>
        /// <response code="200">Procesamiento exitoso</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Respuesta del procesamiento del flujo de WhatsApp</returns>
        [HttpPost("AperturaCuentaYaClienteConBM")]
        public async Task<IActionResult> ProcessFlowAperturaCuentaYaClienteConBM(WppFlowRequest request)
        {
            WppFlowResponse response = await wppFlowService.ProcessAperturaCuentaYaClienteConBMWppFlow(request);
            return this.Ok(response);
        }

        /// <summary>
        /// Procesa una pantalla del WhatsApp Flow de apertura de cuenta (persona que ya es cliente pero no tiene Banca Movil)
        /// </summary>
        /// <param name="request">Datos de la pantalla actual del Flow</param>
        /// <response code="200">Procesamiento exitoso</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Respuesta del procesamiento del flujo de WhatsApp</returns>
        [HttpPost("AperturaCuentaYaClienteSinBM")]
        public async Task<IActionResult> ProcessFlowAperturaCuentaYaClienteSinBM(WppFlowRequest request)
        {
            WppFlowResponse response = await wppFlowService.ProcessAperturaCuentaYaClienteSinBMWppFlow(request);
            return this.Ok(response);
        }

        /// <summary>
        /// Procesa una pantalla del WhatsApp Flow de validacion de identidad (reutilizable por varios Flows nativos; Flow 1 de saldos: CSM_DATOS_CI/CSM_SELFIE/CSM_DOCUMENTO_ID/CSM_LOGIN_CLAVE)
        /// </summary>
        /// <param name="request">Datos de la pantalla actual del Flow</param>
        /// <response code="200">Procesamiento exitoso</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Respuesta del procesamiento del flujo de WhatsApp</returns>
        [HttpPost("ValidacionIdentidad")]
        public async Task<IActionResult> ProcessFlowValidacionIdentidad(WppFlowRequest request)
        {
            WppFlowResponse response = await wppFlowService.ProcessValidacionIdentidadWppFlow(request);
            return this.Ok(response);
        }

        /// <summary>
        /// Procesa una pantalla del WhatsApp Flow de consulta de saldos y movimientos (Flow 2: CSM_OTP_CORREO/CSM_ELEGIR_CUENTA/CSM_DETALLE_SALDO/CSM_ELEGIR_MOVIMIENTO/CSM_DETALLE_MOVIMIENTO/CSM_COMPARTIR_DATOS)
        /// </summary>
        /// <param name="request">Datos de la pantalla actual del Flow</param>
        /// <response code="200">Procesamiento exitoso</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Respuesta del procesamiento del flujo de WhatsApp</returns>
        [HttpPost("ConsultaMovimientos")]
        public async Task<IActionResult> ProcessFlowConsultaMovimientos(WppFlowRequest request)
        {
            WppFlowResponse response = await wppFlowService.ProcessConsultaMovimientosWppFlow(request);
            return this.Ok(response);
        }
    }
}