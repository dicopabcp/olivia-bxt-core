using Microsoft.AspNetCore.Mvc;
using OLIVIA.CORE.MODEL;
using OLIVIA.CORE.SERVICE;
using Serilog;

namespace OLIVIA.CORE.API.Controllers
{
    /// <summary>
    /// Controlador para la interacción con el chatbot
    /// </summary>
    [ApiController]
    [Route("v1/[controller]")]
    public class ChatBotController(IChatBotService chatBotService) : ControllerBase
    {
        /// <summary>
        /// Envía un mensaje al chatbot y recibe una respuesta del topico o fue enviado a Genesys
        /// </summary>
        /// <param name="body">Datos del mensaje y usuario</param>
        /// <remarks>
        /// Request example:
        /// ```json
        /// {
        ///     "usuario": "USUARIO1",
        ///     "mensaje": "¿Cuál es el horario de atención?"
        /// }
        /// ```
        /// </remarks>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Respuesta generada por el chatbot</returns>
        [HttpPost]
        public async Task<IActionResult> SendMessage(RequestChatBot body)
        {
            try
            {
                ResponseChatBot responseChatBot = new();
                if (string.IsNullOrEmpty(body.Mensaje))
                    body.Mensaje = "Necesito contactarme con un operador";
                (string answer, bool flag) = await chatBotService.ChatBotMain(body.Usuario, body.Mensaje);
                responseChatBot.Respuesta = answer;
                responseChatBot.EnviarGenesys = flag;
                return this.Ok(responseChatBot);
            }
            catch (Exception ex)
            {
                Log.Error("ERROR EN EL ChatBotController", ex);
                return this.Ok(ex);
            }
        }
    }
}