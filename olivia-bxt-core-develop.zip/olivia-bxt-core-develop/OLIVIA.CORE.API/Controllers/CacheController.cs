using Microsoft.AspNetCore.Mvc;
using OLIVIA.CORE.MODEL.DB_MODEL.PARAMETRO;
using OLIVIA.CORE.MODEL.DTO.Cache;
using OLIVIA.CORE.SERVICE.Interfaces;

namespace OLIVIA.CORE.API.Controllers
{
    /// <summary>
    /// Controlador para la gestión de caché y parámetros del sistema
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class CacheController(ICacheService service) : ControllerBase
    {
        /// <summary>
        /// Actualiza un parámetro del sistema en caché
        /// </summary>
        /// <param name="request">Datos del parámetro a actualizar</param>
        /// <remarks>
        /// Request example:
        /// ```json
        /// {
        ///     "nombre": "PARAMETRO_EJEMPLO",
        ///     "mensaje": "Descripción del parámetro",
        ///     "enabled": true,
        ///     "usuario": "USUARIO1"
        /// }
        /// ```
        /// </remarks>
        /// <response code="200">Actualización exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>True si la actualización fue exitosa, False en caso contrario</returns>
        [HttpPost("ParametroUpdate")]
        public async Task<ActionResult<bool>> ParametroUpdate([FromBody] ParametroDto request)
        {
            try
            {
                var result = await service.ParametroUpdateAsync(request);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        /// <summary>
        /// Obtiene un parámetro del sistema por su nombre
        /// </summary>
        /// <param name="nombre">Nombre del parámetro a consultar</param>
        /// <remarks>
        /// Example: GET /api/Cache/Parametro?nombre=PARAMETRO_EJEMPLO
        /// </remarks>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Datos del parámetro consultado</returns>
        [HttpGet("Parametro")]
        public async Task<ActionResult<ParametroEntitie>> ParametroGet([FromQuery] string nombre)
        {
            try
            {
                var result = await service.ParametroGetListAsync();
                var filter = result!.FirstOrDefault(x => x.Nombre.Equals(nombre, StringComparison.OrdinalIgnoreCase));
                return Ok(filter);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
