using CROSS.APIREST;
using CROSS.DATABASES.REDDIS;
using CROSS.LOGGER;
using MongoDB.Bson;
using MongoDB.Driver;
using OLIVIA.CORE.API;
using OLIVIA.CORE.MODEL.CONFIG;
using OLIVIA.CORE.SERVICE;
using Serilog;
using StackExchange.Redis;
using System.Reflection;

try
{
    WebApplicationBuilder builder = WebApplication.CreateBuilder(args);
    builder.Logging.AddLogger(builder.Configuration);
    // Add services to the container.
    builder.Services.AddControllers();

    // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
    builder.Services.AddEndpointsApiExplorer();

    DBOptions dBOption = new();
    builder.Configuration.GetSection("database").Bind(dBOption);
    DBOptionItems item = dBOption.Connections.First(x => x.Name == "OLIVIA_BXT_REDIS");
    ConnectionMultiplexer redis = ConnectionMultiplexer.Connect($"{item.Server}:{item.Port},allowAdmin=true");
    IServer server = redis.GetServer(host: item.Server, port: int.Parse(item.Port));
    server.ConfigSet("notify-keyspace-events", "Ex");
    redis.Close();

    DBOptionItems itemMongo = new();
    builder.Configuration.GetSection("database:connections:2").Bind(itemMongo);
    MongoClient client = new($"mongodb://{itemMongo.Server}:{itemMongo.Port}/");
    IMongoDatabase mongoDatabase = client.GetDatabase($"{itemMongo.DataBase}");
    IMongoCollection<BsonDocument> collection = mongoDatabase.GetCollection<BsonDocument>("sessions");
    IndexKeysDefinition<BsonDocument> indexKeys = Builders<BsonDocument>.IndexKeys.Descending("update_date");
    CreateIndexOptions indexOptions = new() { ExpireAfter = TimeSpan.FromHours(1) };
    CreateIndexModel<BsonDocument> indexModel = new CreateIndexModel<BsonDocument>(indexKeys, indexOptions);

    try
    {
        collection.Indexes.CreateOne(indexModel);
    }
    catch
    {
        Console.WriteLine("Error creating indexModel");
    }


    builder.Services.AddServicesOliviaBxt(builder.Configuration);


    builder.Services.AddSwaggerGen(swagger =>
    {
        var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
        swagger.IncludeXmlComments(Path.Combine(AppContext.BaseDirectory, xmlFile));
    });

    builder.Services.AddOptions<CacheConfig>()
        .BindConfiguration("Cache")
        .ValidateDataAnnotations()
        .ValidateOnStart();
    builder.Services.AddHttpContextAccessor();
    builder.Services.AddApiRest(builder.Configuration);


    WebApplication app = builder.Build();

    // Configure the HTTP request pipeline.
    bool dev = app.Configuration.GetValue<bool>("dev");
    if (dev)
    {
        app.UseSwagger();
        app.UseSwaggerUI();
    }

    app.UseHttpsRedirection();
    app.UseMiddleware<LogsMiddleware>();
    app.UseAuthorization();

    app.MapControllers();


    app.Lifetime.ApplicationStarted.Register(() =>
    {
        Log.Information("La aplicación ha iniciado.");
    });

    app.Lifetime.ApplicationStopping.Register(() =>
    {
        Log.Information("La aplicación está deteniéndose...");
    });

    app.Lifetime.ApplicationStopped.Register(() =>
    {
        Log.Information("La aplicación se ha detenido.");
        Log.CloseAndFlush();
    });

    Log.Debug("RUN APLICACION");
    app.Run();
}
catch (Exception ex)
{
    Log.Fatal(ex, "Host terminated unexpectedly");
}
finally
{
    Log.CloseAndFlush();
}