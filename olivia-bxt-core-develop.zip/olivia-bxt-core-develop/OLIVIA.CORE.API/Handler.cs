using Serilog;
using System.Diagnostics;
using System.Text;

namespace OLIVIA.CORE.API
{
    public class LogsMiddleware(RequestDelegate next)
    {

        private readonly HashSet<string> _loggableContentTypes = new(StringComparer.OrdinalIgnoreCase)
        {
            "application/json",
            "text/plain",
            "application/xml",
            "text/xml",
            "application/x-www-form-urlencoded"
        };


        public async Task InvokeAsync(HttpContext httpContext)
        {
            string correlationId = Guid.NewGuid().ToString();
            try
            {

                var sw = Stopwatch.StartNew();
                // 3) Datos base
                var request = httpContext.Request;
                var response = httpContext.Response;
                string? requestBody = await ReadRequestBodySafeAsync(httpContext);

                var originalBodyStream = response.Body;
                await using var responseBodyStream = new MemoryStream();
                response.Body = responseBodyStream;

                httpContext.Items.Add("X-Correlation-ID", correlationId);
                Log.Information(
                   "REQUEST IN | {CorrelationId} | {Method} {Url} | Body: {RequestBody}",
                   correlationId,
                   request.Method,
                   request.Path.Value,
                   requestBody);

                await next(httpContext);

                sw.Stop();
                var durationMs = sw.ElapsedMilliseconds;

                var responseBody = await ReadResponseBodySafeAsync(response);
                Log.Information(
                       "RESPONSE OUT | {CorrelationId} | Status: {StatusCode} | Time: {Duration}ms | Body: {ResponseBody}",
                       correlationId,
                       (int)response.StatusCode,
                       durationMs,
                       responseBody);

                responseBodyStream.Position = 0;
                await responseBodyStream.CopyToAsync(originalBodyStream);
            }
            catch (Exception ex)
            {
                Log.Error(
                    ex,
                    $"RESPONSE OUT ERROR | {correlationId}"
                    );
            }
        }


        private async Task<string?> ReadResponseBodySafeAsync(HttpResponse response)
        {
            if (response.Body == null)
                return null;

            // Posición al inicio para leer
            response.Body.Position = 0;

            // Si no es logueable, no lo leas (puede ser binario)
            if (!IsLoggableContentType(response.ContentType))
                return $"[Body omitido: Content-Type no logueable: {response.ContentType}]";

            using var reader = new StreamReader(response.Body, Encoding.UTF8, leaveOpen: true);
            var text = await reader.ReadToEndAsync();

            response.Body.Position = 0; // re-set para copiar luego
            return text;
        }


        private async Task<string?> ReadRequestBodySafeAsync(HttpContext context)
        {
            var request = context.Request;

            // No loguear si no hay body o si el content-type no conviene
            if (request.Body == null || request.ContentLength is null or 0)
                return null;

            if (!IsLoggableContentType(request.ContentType))
                return $"[Body omitido: Content-Type no logueable: {request.ContentType}]";

            request.EnableBuffering(); // permite leer sin consumir

            request.Body.Position = 0;

            using var reader = new StreamReader(
                request.Body,
                encoding: Encoding.UTF8,
                detectEncodingFromByteOrderMarks: false,
                bufferSize: 1024,
                leaveOpen: true
            );

            var body = await reader.ReadToEndAsync();
            request.Body.Position = 0;

            return body;
        }

        private bool IsLoggableContentType(string? contentType)
        {
            if (string.IsNullOrWhiteSpace(contentType)) return false;
            // content-type puede venir con charset: "application/json; charset=utf-8"
            var type = contentType.Split(';')[0].Trim();
            return _loggableContentTypes.Contains(type);
        }


    }
}
