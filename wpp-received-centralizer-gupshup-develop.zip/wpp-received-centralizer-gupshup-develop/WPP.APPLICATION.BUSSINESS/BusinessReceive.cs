﻿using Newtonsoft.Json;
using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.LOGGER;
using WPP.APPLICATION.CONNECTION.SERVICE;

namespace WPP.APPLICATION.BUSSINESS
{
    public interface IBusinessReceive
    {
        public Task ReceiveMessage(WhatsAppMensajeGupShupRequest _request, string _operation);

        public Task StatusMessage(WhatsAppEstadoGupShupRequest _request, string _operation);

        public Task<GenericResponse<string>> FlowSendMessage(EndpointPayload request, string flowName, string _operation);
    }
    public class BusinessReceive : IBusinessReceive
    {
        private readonly ILoggerInfo _logger;
        private readonly IReceivedCentralizerConnectionService _conectorBalancer;
        public BusinessReceive(ILoggerInfo logger, IReceivedCentralizerConnectionService conectorBalancer) { this._logger = logger; this._conectorBalancer = conectorBalancer; }

        public async Task<GenericResponse<string>> FlowSendMessage(EndpointPayload request, string flowName, string _operation)
        {
            return await _conectorBalancer.SendMessageFlow(request, flowName, _operation);
        }

        public async Task ReceiveMessage(WhatsAppMensajeGupShupRequest _request, string _operation)
        {
            try
            {
                if (_request.type == "message")
                {

                    this._logger.Debug(string.Format("[{0}]    MENSAJES RECIBIDO: {1}", _operation, "**************************"));

                    WhatsAppMensajeCoreRequest _requestCore = new WhatsAppMensajeCoreRequest();

                    _requestCore.json = JsonConvert.SerializeObject(_request);
                    _requestCore.messageCode = _request.payload!.id;
                    _requestCore.typeMessage = _request.payload.type!.ToUpper();
                    _requestCore.message = _request.payload.payload!.text;
                    _requestCore.cellphone = _request.payload.source;
                    _requestCore.campaignName = _request.app;
                    _requestCore.destinationAccount = "";

                    _requestCore.url = "";
                    _requestCore.nameMultimediaUrl = "";
                    _requestCore.classMultimedia = "";

                    switch (_requestCore.typeMessage)
                    {
                        case "TEXT":
                            _requestCore.url = "";
                            _requestCore.nameMultimediaUrl = "";
                            _requestCore.classMultimedia = "";
                            break;
                        case "IMAGE":
                        case "AUDIO":
                        case "VIDEO":
                        case "STICKER":
                            _requestCore.message = _request.payload.payload.caption;
                            _requestCore.url = _request.payload.payload.url;
                            _requestCore.nameMultimediaUrl = "";
                            _requestCore.classMultimedia = _request.payload.payload.contentType;
                            break;
                        case "FILE":
                            _requestCore.typeMessage = "DOCUMENT";
                            _requestCore.message = _request.payload.payload.caption;
                            _requestCore.url = _request.payload.payload.url;
                            _requestCore.nameMultimediaUrl = "";
                            _requestCore.classMultimedia = _request.payload.payload.contentType;
                            break;
                        case "LIST_REPLY":
                            _requestCore.typeMessage = "INTERACTIVE";
                            _requestCore.classInteractive = "LIST_BUTTON";
                            _requestCore.message = _request.payload.payload.reply;
                            _requestCore.message = _request.payload.payload.postbackText;

                            break;
                        case "BUTTON_REPLY":
                        case "QUICK_REPLY":
                            _requestCore.typeMessage = "INTERACTIVE";
                            _requestCore.classInteractive = "REPLY_BUTTON";
                            _requestCore.message = _request.payload.payload.postbackText;

                            break;
                        case "REACTION":
                            _requestCore.typeMessage = "TEXT";
                            _requestCore.message = _request.payload.payload.emoji;
                            _requestCore.messageCode = _request.payload.payload.gsId;

                            break;
                        default:
                            break;
                    }

                    await _conectorBalancer.SendMenssageWhatsapp(_requestCore, _operation);
                }
                else
                {
                    this._logger.Debug(string.Format("[{0}]    ESTADOS RECIBIDO: {1}", _operation, "**************************"));

                }

            }
            catch (Exception ex)
            {
                this._logger.Error(string.Format("[{0}] ERROR: {1}", _operation, ex.Message));
                throw;
            }
        }

        public async Task StatusMessage(WhatsAppEstadoGupShupRequest _request, string _operation)
        {
            try
            {
                this._logger.Debug(string.Format("[{0}]    ESTADOS RECIBIDO: {1}", _operation, "**************************"));
                WhatsAppEstadoCoreRequest _requestCore = new WhatsAppEstadoCoreRequest();

                _requestCore.messageCode = _request.payload!.gsId;
                _requestCore.status = _request.payload.type!.ToUpper();
                _requestCore.cellphone = _request.payload.destination;
                _requestCore.description = _request.payload.payload!.reason;
                _requestCore.date = DateTime.Now.ToString();
                _requestCore.json = JsonConvert.SerializeObject(_request);


                await _conectorBalancer.StatusMenssageWhatsapp(_requestCore, _operation);
            }
            catch (Exception ex)
            {
                this._logger.Error(string.Format("[{0}] ERROR: {1}", _operation, ex.Message));
                throw;
            }
        }
    }
}
