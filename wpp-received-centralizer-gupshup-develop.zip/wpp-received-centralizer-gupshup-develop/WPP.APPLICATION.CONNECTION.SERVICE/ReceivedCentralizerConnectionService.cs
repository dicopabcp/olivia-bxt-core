﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.LOGGER;
using WPP.APPLICATION.CONNECTION.SERVICE.Options;
using WPP.APPLICATION.CONNECTION.SERVICE.RestConnectionService;

namespace WPP.APPLICATION.CONNECTION.SERVICE
{
    public interface IReceivedCentralizerConnectionService
    {
        Task<GenericResponse> SendMenssageWhatsapp(WhatsAppMensajeCoreRequest _request, string _operation);
        
        Task<GenericResponse> StatusMenssageWhatsapp(WhatsAppEstadoCoreRequest _request, string _operation);
        
        Task<GenericResponse<string>> SendMessageFlow(EndpointPayload _request, string flowName, string _operation);
    }

    public class ReceivedCentralizerConnectionService : IReceivedCentralizerConnectionService
    {
        private readonly ILoggerInfo _logger;
        public readonly WhatsappBalancerOptions _balancerOptions;
        public readonly WhatsAppCoreStatusOptions _statusOptions;
        private readonly IReceivedCentralizerHttpConnectionService _httpConnection;
        public ReceivedCentralizerConnectionService(ILoggerInfo logger, IOptions<WhatsappBalancerOptions> balancerOptions, IReceivedCentralizerHttpConnectionService httpConnection, IOptions<WhatsAppCoreStatusOptions> statusOptions)
        {
            this._logger = logger;
            this._balancerOptions = balancerOptions.Value;
            this._statusOptions = statusOptions.Value;
            this._httpConnection = httpConnection;
        }

        public async Task<GenericResponse> SendMenssageWhatsapp(WhatsAppMensajeCoreRequest _request, string _operation)
        {
            try
            {
                _request.destinationAccount = this._balancerOptions.source;
                this._logger.Debug(string.Format("[{0}]      URL: {1}", _operation, this._balancerOptions.urlBalancerMessages + this._balancerOptions.methodBalanacerMessages));
                this._logger.Debug(string.Format("[{0}]  REQUEST: {1}", _operation, JsonConvert.SerializeObject(_request)));
                var _response = await this._httpConnection.Post<GenericResponse>(this._balancerOptions.urlBalancerMessages, this._balancerOptions.methodBalanacerMessages, _request, Authentication.None);
                this._logger.Debug(string.Format("[{0}] RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
                return _response;
            }
            catch (Exception ex)
            {
                this._logger.Error(string.Format("[{0}]    ERROR: {1}", _operation, " INTRANET MENSAJE: " + ex));
                throw ex;
            }
        }

        public async Task<GenericResponse> StatusMenssageWhatsapp(WhatsAppEstadoCoreRequest _request, string _operation)
        {
            try
            {
                this._logger.Debug(string.Format("[{0}]      URL: {1}", _operation, this._statusOptions.urlCoreStatus + this._statusOptions.methodCoreStatus));
                this._logger.Debug(string.Format("[{0}]  REQUEST: {1}", _operation, JsonConvert.SerializeObject(_request)));
                var _response = await this._httpConnection.Post<GenericResponse>(this._statusOptions.urlCoreStatus, this._statusOptions.methodCoreStatus, _request, Authentication.None);
                this._logger.Debug(string.Format("[{0}] RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
                return _response;
            }
            catch (Exception ex)
            {
                this._logger.Error(string.Format("[{0}]    ERROR: {1}", _operation, " INTRANET ESTADO: " + ex));
                throw ex;
            }
        }

        public async Task<GenericResponse<string>> SendMessageFlow(EndpointPayload _request, string flowName, string _operation)
        {
            GenericResponse<string> _response;
            this._logger.Debug(string.Format("[{0}] REQUEST: {1}", _operation, JsonConvert.SerializeObject(_request)));
            _response = await this._httpConnection.Post<GenericResponse<string>>(this._balancerOptions.urlBalancerMessages, this._balancerOptions.methodBalancerFlowMessages + flowName, _request, Authentication.None);
            this._logger.Debug(string.Format("[{0}] RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
            return _response;
        }
    }
}
