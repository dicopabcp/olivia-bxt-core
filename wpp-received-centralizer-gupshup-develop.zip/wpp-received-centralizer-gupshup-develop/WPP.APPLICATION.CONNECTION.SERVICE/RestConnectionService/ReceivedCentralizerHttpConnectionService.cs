﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Configuration;
using System.Net;
using System.Security.Authentication;
using System.Text;

namespace WPP.APPLICATION.CONNECTION.SERVICE.RestConnectionService
{
    public interface IReceivedCentralizerHttpConnectionService
    {
        Task<T> Post<T>(string _urlBase, string _method, object _request, Authentication _authentication, string _usuario = "", string _password = "", string _channel = "", string _publicToken = "", string _appUserid = "");
    }
    public class ReceivedCentralizerHttpConnectionService : IReceivedCentralizerHttpConnectionService
    {
        private readonly IConfiguration builder;

        public ReceivedCentralizerHttpConnectionService(IConfiguration configuration)
        {
            builder = configuration;
        }

        public async Task<T> Post<T>(string _urlBase, string _method, object _request, Authentication _authentication, string _usuario = "", string _password = "", string _channel = "", string _publicToken = "", string _appUserid = "")
        {
            HttpClientHandler httpClientHandler = new HttpClientHandler();

            if (builder.GetValue<bool>("Dev"))
            {
                httpClientHandler.ServerCertificateCustomValidationCallback = (sender, certificate, chain, sslPolicyErrors) => { return true; };
            }

            ServicePointManager.DefaultConnectionLimit = 9999;
            ServicePointManager.Expect100Continue = true;
            httpClientHandler.SslProtocols = SslProtocols.Tls12;
            using (var httpClient = new HttpClient(httpClientHandler))
            {
                switch (_authentication) 
                {   
                    case Authentication.None:
                        break;
                    case Authentication.Header:
                        httpClient.DefaultRequestHeaders.Add("USUARIO", _usuario);
                        httpClient.DefaultRequestHeaders.Add("PASSWORD", _password);
                        break;
                    case Authentication.Basic:
                        string _encodeBasic = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(_usuario + ":" + _password));
                        httpClient.DefaultRequestHeaders.Add("Authorization", $"Basic {_encodeBasic}");
                        break;
                    case Authentication.Complete:
                        string _encodeComplete = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(_usuario + ":" + _password));
                        httpClient.DefaultRequestHeaders.Add("Authorization", $"Basic {_encodeComplete}");
                        httpClient.DefaultRequestHeaders.Add("channel", _channel);
                        httpClient.DefaultRequestHeaders.Add("publicToken", _publicToken);
                        httpClient.DefaultRequestHeaders.Add("appUserId", _appUserid);
                        break;
                    case Authentication.WhatsApp:
                        break;
                    default:
                        break;
                }
                var _json = JsonConvert.SerializeObject(_request);
                var _content = new StringContent(_json, Encoding.UTF8, "application/json");
                var _result = await httpClient.PostAsync(new Uri(_urlBase + _method), _content);
                var _resultContent = await _result.Content.ReadAsStringAsync();
                HttpStatusCode _statusCode = _result.StatusCode;
                if (_statusCode == HttpStatusCode.OK)
                {
                    var _responseService = _resultContent == null ? "" : _resultContent;
                    return JsonConvert.DeserializeObject<T>(_responseService)!;
                }
                else
                {
                    throw new Exception($"ERROR => URL METHOD: {_urlBase + _method} ; STATUS: {_statusCode} ; CONTENT: {_resultContent}");
                }
            }
        }
    }
    public enum Authentication { None, Header, Basic, Complete, WhatsApp }
}
