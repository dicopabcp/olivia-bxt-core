﻿namespace WPP.APPLICATION.CONNECTION.SERVICE.Options
{
    public class WhatsappBalancerOptions
    {
        public string source { get; set; } = string.Empty;
        public string urlBalancerMessages { get; set; } = string.Empty;
        public string methodBalanacerMessages { get; set; } = string.Empty;
        public string methodBalancerFlowMessages { get; set; } = string.Empty;
    }
    
    public class WhatsAppCoreStatusOptions
    {
        public string urlCoreStatus { get; set; } = string.Empty;
        public string methodCoreStatus { get; set; } = string.Empty;
    }
}
