﻿using Newtonsoft.Json;

namespace WPP.ABSTRACTION.ENTITIES
{
    public class WhatsAppMensajeGupShupRequest
    {
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? app { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public int? version { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? type { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public datosMensajeWhatsapp? payload { get; set; }
      
    }

    public class datosMensajeWhatsapp
    {
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? id { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? source { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? type { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public payloadWhatsapp? payload { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public senderWhatsapp? sender { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public receiveMessageContext? context { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public receiveMessageReferral? referral { get; set; }

    }

    public class payloadWhatsapp
    {
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? text { get; set; }

        #region Multimedia
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? caption { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? url { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? contentType { get; set; }
        #endregion

        #region Mensaje Interativo

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? title { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? id { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? reply { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? postbackText { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? description { get; set; }

        #endregion

        #region reacciones

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? gsId { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? emoji { get; set; }


        #endregion

        #region location

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public int? longitude { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? latitude { get; set; }

        #endregion

      
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public int? code { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? reason { get; set; }

    }

    public class senderWhatsapp
    {
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? phone { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? name { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? country_code { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? dial_code { get; set; }

    }

    public class receiveMessageContext
    {
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? id { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? gsId { get; set; }
        

    }

    public class receiveMessageReferral
    {
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? body { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? headline { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public receiveMessageReferralImage? image { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? source_id { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? source_type { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? source_url { get; set; }

    }

    public class receiveMessageReferralImage
    {
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? id { get; set; }
        
    }


}
