﻿
namespace WPP.ABSTRACTION.ENTITIES
{
    public class GenericResponse
    {
        public bool success { get; set; }
        public string message { get; set; } = string.Empty;
        public string code { get; set; } = string.Empty;
    }

    public class GenericResponse<T>
    {
        public bool success { get; set; }
        public string message { get; set; } = string.Empty;
        public string code { get; set; } = string.Empty;
        public T data { get; set; }
    }
}
