﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPP.ABSTRACTION.ENTITIES
{
    public class WhatsAppMensajeCoreRequest
    {
        public string? message { get; set; }
        public string? messageCode { get; set; }
        public string? typeMessage { get; set; }
        public string? classMultimedia { get; set; }
        public string? classInteractive { get; set; }
        public string? cellphone { get; set; }
        public string? url { get; set; }
        public string? nameMultimediaUrl { get; set; }
        public string? campaignName { get; set; }
        public string? destinationAccount { get; set; }
        public string? json { get; set; }
    }
}
