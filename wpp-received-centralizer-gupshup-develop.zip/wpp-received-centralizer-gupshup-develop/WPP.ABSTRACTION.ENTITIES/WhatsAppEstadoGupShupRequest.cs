﻿using Newtonsoft.Json;

namespace WPP.ABSTRACTION.ENTITIES
{
    public class WhatsAppEstadoGupShupRequest
    {
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? app { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public int? version { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? type { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public payloadEstatusWhatsApp? payload { get; set; }
    }


    public class payloadEstatusWhatsApp
    {
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? id { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? gsId { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? type { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? destination { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public payloadEstatusWpp? payload { get; set; }

    }

    public class payloadEstatusWpp
    {
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? whatsappMessageId { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? type { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public int? code { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string? reason { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public conversationEstatusWpp? conversation { get; set; }

    }

    public class conversationEstatusWpp
    {

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] 
        public string? id { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] 
        public string? type { get; set; }
        
    }



}
