﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPP.ABSTRACTION.ENTITIES
{
    public class WhatsAppEstadoCoreRequest
    {
        public string? messageCode { get; set; }
        public string? status { get; set; }
        public string? description { get; set; }
        public string? date { get; set; }
        public string? cellphone { get; set; }
        public string? json { get; set; }
    }
}
