﻿namespace Wpp.Api.ReceivedCentralizer.commons
{
    public static class GenerateOperation
    {
        public static string generateOperation() 
        {
            return DateTime.Now.ToString("yyyyMMddhhmmssff");
        }
    }
}
