using System.Reflection;
using WPP.ABSTRACTION.LOGGER;
using WPP.APPLICATION.BUSSINESS;
using WPP.APPLICATION.CONNECTION.SERVICE;
using WPP.APPLICATION.CONNECTION.SERVICE.Options;
using WPP.APPLICATION.CONNECTION.SERVICE.RestConnectionService;

var builder = WebApplication.CreateBuilder(args);
// Add services to the container.
builder.Services.Configure<WhatsappBalancerOptions>(options => builder.Configuration.GetSection("WHATSAPP_BALANCER_MESSAGES").Bind(options));
builder.Services.Configure<WhatsAppCoreStatusOptions>(options => builder.Configuration.GetSection("WHATSAPP_STATUS_MESSAGES").Bind(options));
builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(swagger =>
{
    var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    swagger.IncludeXmlComments(Path.Combine(AppContext.BaseDirectory, xmlFile));
});
builder.Services.AddLogger();
builder.Services.AddSingleton<IReceivedCentralizerHttpConnectionService, ReceivedCentralizerHttpConnectionService>();
builder.Services.AddSingleton<IReceivedCentralizerConnectionService, ReceivedCentralizerConnectionService>();
builder.Services.AddSingleton<IBusinessReceive, BusinessReceive>();


var app = builder.Build();


app.MapGet("/", (HttpRequest request) =>
{
    var userAgent = request.Headers.UserAgent;
    var customHeader = request.Headers["x-custom-header"];

    return Results.Ok(new { userAgent = userAgent, customHeader = customHeader });
});

bool dev = builder.Configuration.GetValue<bool>("Dev");
if (dev)
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();
