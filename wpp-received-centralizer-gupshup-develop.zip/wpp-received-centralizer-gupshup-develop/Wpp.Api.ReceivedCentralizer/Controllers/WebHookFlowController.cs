﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Wpp.Api.ReceivedCentralizer.commons;
using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.LOGGER;
using WPP.APPLICATION.BUSSINESS;

namespace BCP.WebHook.Whatsapp.Controllers
{
    /// <summary>
    /// Controlador para la manejo de informacion de los formularios de WhatsApp Meta
    /// </summary>
    [Route("[controller]")]
    [ApiController]
    public class WebHookFlowController : ControllerBase
    {
        private readonly ILoggerInfo _logger;
        private readonly IBusinessReceive _bussiness;
        public WebHookFlowController(ILoggerInfo logger, IBusinessReceive bussiness) { this._logger = logger; this._bussiness = bussiness; }

        /// <summary>
        /// Se envia la informacion del formulario encriptada para rekognition
        /// </summary>
        /// <param name="wppFlowMessage">Informacion encriptada de los datos del formulario</param>
        /// <remarks>
        /// Request example:
        /// ```json
        ///{
        ///	"encrypted_aes_key": "nA1ETxlmcfhEqgezJ1rGcvRrObx0SN3aDGUChgSJQSq00skMmkNvaw012ES/ntpTh4QYKVz1StLZDv/1FE/y3pU8ATZa55wGx7tRwFPRVguG6kiohwckkg4x41tKmfkKo6VW5ysq6NLTNC+qlLpD6R7oEx/QFQcipAdAKT++bumDKGAIK5Eh0nExutfRHhjuBDFByo1B2PNYWD77FAC0mcyhn6DZNi43+7wqzfJtcfK+yjDshh86HGlKluHYSJ6fp/DPQvt57uZbc0TZL3JnHHua83iRhpHiKX+JnkrPSggbKUt5P3fwmZ4Iuwm7a3hAl4lPdEaR9Z3ZBH7vqzr6vA==",
        ///	"encrypted_flow_data": "AK85GSpNjhnJdQy/D63ue4OObDq0wtR2uX1p6GMaXat/osMrrbvxxK+C6h93kv38Uw==",
        ///	"initial_vector": "u6Wt5PkHC4uLTaeYkNe88Q=="
        ///}
        /// ```
        /// </remarks>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Respuesta generada por la api de flows</returns>
        [HttpPost("Rekognition")]
        public async Task<IActionResult> RekognitionFlow([FromBody] EndpointPayload wppFlowMessage)
        {
            string _operation = GenerateOperation.generateOperation();
            try
            {
                _logger.Debug(string.Format("{0} REQUEST: {1}", _operation, JsonConvert.SerializeObject(wppFlowMessage)));
                var _response = await _bussiness.FlowSendMessage(wppFlowMessage, "FlowRekognition", _operation);
                _logger.Debug(string.Format("{0} RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
                return Ok(_response.data);
            }
            catch (Exception ex)
            {
                _logger.Error(string.Format("[{0}] ERROR: {1}", _operation, "No se pudo procesar el mensaje flow entrante: " + ex));
                return StatusCode(500, "OCURRIO UN ERROR AL LAMAR EL SERVICIO");
            }
        }

        /// <summary>
        /// Se envia la informacion del formulario encriptada para encuestas
        /// </summary>
        /// <param name="wppFlowMessage">Informacion encriptada de los datos del formulario</param>
        /// <remarks>
        /// Request example:
        /// ```json
        ///{
        ///	"encrypted_aes_key": "nA1ETxlmcfhEqgezJ1rGcvRrObx0SN3aDGUChgSJQSq00skMmkNvaw012ES/ntpTh4QYKVz1StLZDv/1FE/y3pU8ATZa55wGx7tRwFPRVguG6kiohwckkg4x41tKmfkKo6VW5ysq6NLTNC+qlLpD6R7oEx/QFQcipAdAKT++bumDKGAIK5Eh0nExutfRHhjuBDFByo1B2PNYWD77FAC0mcyhn6DZNi43+7wqzfJtcfK+yjDshh86HGlKluHYSJ6fp/DPQvt57uZbc0TZL3JnHHua83iRhpHiKX+JnkrPSggbKUt5P3fwmZ4Iuwm7a3hAl4lPdEaR9Z3ZBH7vqzr6vA==",
        ///	"encrypted_flow_data": "AK85GSpNjhnJdQy/D63ue4OObDq0wtR2uX1p6GMaXat/osMrrbvxxK+C6h93kv38Uw==",
        ///	"initial_vector": "u6Wt5PkHC4uLTaeYkNe88Q=="
        ///}
        /// ```
        /// </remarks>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Respuesta generada por la api de flows</returns>
        [HttpPost("Encuesta")]
        public async Task<IActionResult> EncuestaFlow([FromBody] EndpointPayload wppFlowMessage)
        {
            string _operation = GenerateOperation.generateOperation();
            try
            {
                _logger.Debug(string.Format("{0} REQUEST: {1}", _operation, JsonConvert.SerializeObject(wppFlowMessage)));
                var _response = await _bussiness.FlowSendMessage(wppFlowMessage, "FlowEncuesta", _operation);
                _logger.Debug(string.Format("{0} RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
                return Ok(_response.data);
            }
            catch (Exception ex)
            {
                _logger.Error(string.Format("[{0}] ERROR: {1}", _operation, "No se pudo procesar el mensaje flow entrante: " + ex));
                return StatusCode(500, "OCURRIO UN ERROR AL LAMAR EL SERVICIO");
            }
        }

        /// <summary>
        /// Se envia la informacion del formulario encriptada para validacion de identidad de WhatsApp (Flow completo: CI + selfie + documento + clave BM)
        /// </summary>
        /// <param name="wppFlowMessage">Informacion encriptada de los datos del formulario</param>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Respuesta generada por la api de flows</returns>
        [HttpPost("ValidacionIdentidad")]
        public async Task<IActionResult> ValidacionIdentidadFlow([FromBody] EndpointPayload wppFlowMessage)
        {
            string _operation = GenerateOperation.generateOperation();
            try
            {
                _logger.Debug(string.Format("{0} REQUEST: {1}", _operation, JsonConvert.SerializeObject(wppFlowMessage)));
                var _response = await _bussiness.FlowSendMessage(wppFlowMessage, "FlowValidacionIdentidad", _operation);
                _logger.Debug(string.Format("{0} RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
                return Ok(_response.data);
            }
            catch (Exception ex)
            {
                _logger.Error(string.Format("[{0}] ERROR: {1}", _operation, "No se pudo procesar el mensaje flow entrante: " + ex));
                return StatusCode(500, "OCURRIO UN ERROR AL LAMAR EL SERVICIO");
            }
        }

        /// <summary>
        /// Se envia la informacion del formulario encriptada para validacion de identidad de WhatsApp (Flow de una sola pantalla: solo clave BM, cliente ya registrado)
        /// </summary>
        /// <param name="wppFlowMessage">Informacion encriptada de los datos del formulario</param>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Respuesta generada por la api de flows</returns>
        [HttpPost("ValidacionIdentidadClave")]
        public async Task<IActionResult> ValidacionIdentidadClaveFlow([FromBody] EndpointPayload wppFlowMessage)
        {
            string _operation = GenerateOperation.generateOperation();
            try
            {
                _logger.Debug(string.Format("{0} REQUEST: {1}", _operation, JsonConvert.SerializeObject(wppFlowMessage)));
                var _response = await _bussiness.FlowSendMessage(wppFlowMessage, "FlowValidacionIdentidadClave", _operation);
                _logger.Debug(string.Format("{0} RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
                return Ok(_response.data);
            }
            catch (Exception ex)
            {
                _logger.Error(string.Format("[{0}] ERROR: {1}", _operation, "No se pudo procesar el mensaje flow entrante: " + ex));
                return StatusCode(500, "OCURRIO UN ERROR AL LAMAR EL SERVICIO");
            }
        }

        /// <summary>
        /// Se envia la informacion del formulario encriptada para consulta de saldos y movimientos
        /// </summary>
        /// <param name="wppFlowMessage">Informacion encriptada de los datos del formulario</param>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Respuesta generada por la api de flows</returns>
        [HttpPost("ConsultaMovimientos")]
        public async Task<IActionResult> ConsultaMovimientosFlow([FromBody] EndpointPayload wppFlowMessage)
        {
            string _operation = GenerateOperation.generateOperation();
            try
            {
                _logger.Debug(string.Format("{0} REQUEST: {1}", _operation, JsonConvert.SerializeObject(wppFlowMessage)));
                var _response = await _bussiness.FlowSendMessage(wppFlowMessage, "FlowConsultaMovimientos", _operation);
                _logger.Debug(string.Format("{0} RESPONSE: {1}", _operation, JsonConvert.SerializeObject(_response)));
                return Ok(_response.data);
            }
            catch (Exception ex)
            {
                _logger.Error(string.Format("[{0}] ERROR: {1}", _operation, "No se pudo procesar el mensaje flow entrante: " + ex));
                return StatusCode(500, "OCURRIO UN ERROR AL LAMAR EL SERVICIO");
            }
        }
    }
}