﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Wpp.Api.ReceivedCentralizer.commons;
using WPP.ABSTRACTION.ENTITIES;
using WPP.ABSTRACTION.LOGGER;
using WPP.APPLICATION.BUSSINESS;

namespace BCP.WebHook.Whatsapp.Controllers
{
    /// <summary>
    /// Controlador para la recepcion de mensajes desde Gupshup
    /// </summary>
    [Route("[controller]")]
    [ApiController]
    public class WebHookController : ControllerBase
    {
        private readonly ILoggerInfo _logger;
        private readonly IBusinessReceive _bussiness;
        public WebHookController(ILoggerInfo logger, IBusinessReceive bussiness)
        {
            this._logger = logger;
            this._bussiness = bussiness;
        }

        /// <summary>
        /// Se reciben los mensajes desde Gupshup
        /// </summary>
        /// <param name="MsjEntrante">Mensaje entrante</param>
        /// <remarks>
        /// Request example:
        /// ```json
        ///        {
        ///    "app": "FUa7Zc1HLnCKefYWURUp9xVJ",
        ///    "version": 2,
        ///    "type": "message",
        ///    "payload": {
        ///        "id": "wamid.HBgLNTkxNjAxMjgzNTcVAgASGCBFNjA1NTVFRUM3M0RFNkY2MTAxQjRFRDJBODUwRkU4NwA=",
        ///        "source": "59160128357",
        ///        "type": "text",
        ///        "payload": {
        ///            "text": "No recuerdo la contraseña 🤦🏻‍♂️"
        ///        },
        ///        "sender": {
        ///            "phone": "59160128357",
        ///            "name": "Dan Copa",
        ///            "country_code": "591",
        ///            "dial_code": "60128357"
        ///        }
        ///    }
        ///}
        /// ```
        /// </remarks>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Respuesta generada por el chatbot</returns>
        [HttpPost("WPPReceiveMessage")]
        public async Task<ActionResult> RecibirWpp([FromBody] WhatsAppMensajeGupShupRequest MsjEntrante)
        {
            string _operation = GenerateOperation.generateOperation();
            await Task.Factory.StartNew(async delegate
            {
                try
                {
                    this._logger.Debug(string.Format("[{0}]    REQUEST: {1}", _operation, JsonConvert.SerializeObject(MsjEntrante)));

                    await this._bussiness.ReceiveMessage(MsjEntrante, _operation);
                }
                catch (Exception ex)
                {
                    this._logger.Error(string.Format("[{0}]    ERROR: {1}", _operation, "NO SE PUDO PROCESAR EL MENSAJE ENTRANTE: " + ex));
                }
            });
            return Ok();
        }

        /// <summary>
        /// Se recibe el estado del mensaje enviado desde WhatsApp
        /// </summary>
        /// <param name="MsjEntrante">Mensaje entrante con el estado</param>
        /// <remarks>
        /// Request example:
        /// ```json
        ///        {
        ///    "app": "UaxI729jQxkt5K7wKLT97eT5",
        ///    "version": 2,
        ///    "type": "message-event",
        ///    "payload": {
        ///        "id": "67a43e1c-db48-4256-a89c-3abe2cc34356",
        ///        "gsId": "48ebd6c4-3fda-4ed1-ac96-1db545833b31",
        ///        "type": "sent",
        ///        "destination": "59160128357",
        ///        "payload": {
        ///            "app": "UaxI729jQxkt5K7wKLT97eT5",
        ///            "version": 2,
        ///            "type": "message-event",
        ///            "payload": {
        ///                "id": "67a43e1c-db48-4256-a89c-3abe2cc34356",
        ///                "gsId": "48ebd6c4-3fda-4ed1-ac96-1db545833b31",
        ///                "type": "sent",
        ///                "destination": "59160128357",
        ///                "payload": {}
        ///            }
        ///        }
        ///    }
        ///}
        /// ```
        /// </remarks>
        /// <response code="200">Consulta exitosa</response>
        /// <response code="500">Error interno del servidor</response>
        /// <returns>Respuesta generada por el servicio de status</returns>
        [HttpPost("WPPStatusMessage")]
        public async Task<ActionResult> StatusWpp(WhatsAppEstadoGupShupRequest MsjEntrante)
        {
            string _operation = GenerateOperation.generateOperation();
            await Task.Factory.StartNew(async delegate
            {
                try
                {
                    this._logger.Debug(string.Format("[{0}]    REQUEST: {1}", _operation, JsonConvert.SerializeObject(MsjEntrante)));
                    await this._bussiness.StatusMessage(MsjEntrante, _operation);
                }
                catch (Exception ex)
                {
                    this._logger.Error(string.Format("[{0}]    ERROR: {1}", _operation, "NO SE PUDO PROCESAR EL ESTADO ENTRANTE: " + ex));
                }
            });
            return Ok();
        }
    }
}